<?php
/**
 * Punktacja i lokalne dane rocznej oceny serwisu.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Site_Assessment {
	const MAX_SCORE = 22;

	public static function criteria() {
		return array(
			'architecture' => array(
				__( 'Architektura i technologia', 'adinet-panel' ),
				__( 'Sprawdź architekturę projektu, zgodność wtyczek, problemy z aktualizacjami, możliwość rozbudowy i przestarzałe rozwiązania. Wersje PHP i Divi oceń osobno.', 'adinet-panel' ),
				array(
					__( '0 pkt — spójna architektura i sprawne aktualizacje.', 'adinet-panel' ),
					__( '1 pkt — pojedyncze problemy ze zgodnością lub rozbudową.', 'adinet-panel' ),
					__( '2 pkt — technologia istotnie utrudnia utrzymanie lub rozwój.', 'adinet-panel' ),
				),
			),
			'security'     => array(
				__( 'Bezpieczeństwo', 'adinet-panel' ),
				'',
				array(
					__( '0 pkt — brak wykrytych problemów.', 'adinet-panel' ),
					__( '1 pkt — sygnały lub usterki do sprawdzenia.', 'adinet-panel' ),
					__( '2 pkt — potwierdzona infekcja, złośliwy kod lub poważny incydent.', 'adinet-panel' ),
				),
			),
			'design'       => array(
				__( 'Wygląd i stylistyka', 'adinet-panel' ),
				'',
				array(
					__( '0 pkt — współczesny, profesjonalny wygląd.', 'adinet-panel' ),
					__( '1 pkt — częściowo przestarzała stylistyka.', 'adinet-panel' ),
					__( '2 pkt — wygląd wyraźnie przestarzały lub niedopasowany do firmy.', 'adinet-panel' ),
				),
			),
			'ux'           => array(
				__( 'UX i responsywność', 'adinet-panel' ),
				'',
				array(
					__( '0 pkt — wygodna obsługa na różnych ekranach.', 'adinet-panel' ),
					__( '1 pkt — drobne lub umiarkowane problemy.', 'adinet-panel' ),
					__( '2 pkt — istotne utrudnienia, zwłaszcza na urządzeniach mobilnych.', 'adinet-panel' ),
				),
			),
			'content'      => array(
				__( 'Treść i struktura', 'adinet-panel' ),
				'',
				array(
					__( '0 pkt — logiczna struktura i aktualne treści.', 'adinet-panel' ),
					__( '1 pkt — wybrane elementy do poprawy.', 'adinet-panel' ),
					__( '2 pkt — poważne braki, przestarzała oferta lub chaotyczna struktura.', 'adinet-panel' ),
				),
			),
			'seo'          => array(
				__( 'SEO i semantyka HTML', 'adinet-panel' ),
				__( 'Sprawdź hierarchię H1–H6, semantyczny HTML, opisy alternatywne obrazów, metadane, adresy canonical i podstawy technicznego SEO. Oceń Schema.org tam, gdzie ma zastosowanie.', 'adinet-panel' ),
				array(
					__( '0 pkt — podstawy SEO i semantyka są poprawne.', 'adinet-panel' ),
					__( '1 pkt — pojedyncze błędy lub braki w strukturze.', 'adinet-panel' ),
					__( '2 pkt — istotne problemy z indeksowaniem lub strukturą treści.', 'adinet-panel' ),
				),
			),
			'ai'           => array(
				__( 'Odkrywalność AI', 'adinet-panel' ),
				__( 'Sprawdź dostęp robotów do treści, blokady indeksowania, jasność opisów usług, odpowiedzi na pytania, strukturę informacji i oznaki wiarygodności firmy. FAQ i Schema.org mogą pomóc uporządkować treści. Widoczność w usługach AI zależy też od tych usług.', 'adinet-panel' ),
				array(
					__( '0 pkt — najważniejsze treści są jasne i dostępne.', 'adinet-panel' ),
					__( '1 pkt — część informacji trudno znaleźć lub odczytać.', 'adinet-panel' ),
					__( '2 pkt — kluczowe informacje są niedostępne, niejasne lub brakuje ich w witrynie.', 'adinet-panel' ),
				),
			),
			'performance'  => array(
				__( 'Wydajność', 'adinet-panel' ),
				__( 'Wybierz ocenę z wykonanego testu.', 'adinet-panel' ),
				array(
					__( '0 pkt — A.', 'adinet-panel' ),
					__( '1 pkt — B lub C.', 'adinet-panel' ),
					__( '2 pkt — D, E lub F.', 'adinet-panel' ),
				),
			),
			'business'     => array(
				__( 'Potrzeby biznesowe', 'adinet-panel' ),
				'',
				array(
					__( '0 pkt — strona odpowiada potrzebom firmy.', 'adinet-panel' ),
					__( '1 pkt — potrzebne są wybrane usprawnienia.', 'adinet-panel' ),
					__( '2 pkt — obecny projekt istotnie ogranicza realizację celów biznesowych.', 'adinet-panel' ),
				),
			),
			'divi'         => array(
				__( 'Motyw Divi', 'adinet-panel' ),
				__( 'W Divi 5 i nowszych wersjach potwierdź tryb zgodności.', 'adinet-panel' ),
				array(
					__( '0 pkt — Divi 5+ bez trybu zgodności lub inny motyw.', 'adinet-panel' ),
					__( '1 pkt — Divi 5+ w trybie zgodności.', 'adinet-panel' ),
					__( '2 pkt — Divi 4 lub starsza wersja.', 'adinet-panel' ),
				),
			),
			'php'          => array(
				__( 'Aktualizacja PHP', 'adinet-panel' ),
				__( 'Punktacja wynika z polityki modernizacyjnej AdiNet. Wsparcie bezpieczeństwa ocenia się osobno.', 'adinet-panel' ),
				array(
					__( '0 pkt — PHP 8.5 lub nowsze.', 'adinet-panel' ),
					__( '1 pkt — PHP 8.3–8.4.', 'adinet-panel' ),
					__( '2 pkt — wersja starsza niż PHP 8.3.', 'adinet-panel' ),
				),
			),
		);
	}

	public static function recommendations() {
		return array(
			'care'       => array( 6, __( 'Dobry stan — standardowa opieka', 'adinet-panel' ), __( 'Dalsza standardowa opieka', 'adinet-panel' ) ),
			'improve'    => array( 12, __( 'Zalecane usprawnienia — modernizacja wybranych elementów', 'adinet-panel' ), __( 'Modernizacja wybranych elementów', 'adinet-panel' ) ),
			'consider'   => array( 15, __( 'Warto rozważyć przebudowę', 'adinet-panel' ), __( 'Rozważenie przebudowy', 'adinet-panel' ) ),
			'rebuild'    => array( self::MAX_SCORE, __( 'Rekomendowana budowa nowego serwisu', 'adinet-panel' ), __( 'Budowa nowego serwisu internetowego', 'adinet-panel' ) ),
		);
	}

	public static function performance_grades() {
		return array( 'A' => 0, 'B' => 1, 'C' => 1, 'D' => 2, 'E' => 2, 'F' => 2 );
	}

	public static function compatibility_scores() {
		return array( 'yes' => 1, 'no' => 0 );
	}

	public static function date( $value ) {
		if ( ! is_string( $value ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $value ) ) {
			return null;
		}

		$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );
		return $date && $value === $date->format( 'Y-m-d' ) ? $date : null;
	}

	public static function format_date( $value ) {
		$date = self::date( $value );
		return $date ? wp_date( get_option( 'date_format' ), $date->getTimestamp() ) : '';
	}

	public static function environment() {
		$theme = wp_get_theme();
		$theme = $theme->parent() ?: $theme;
		$divi  = 'divi' === strtolower( $theme->get_stylesheet() );

		return array(
			'wordpress'   => get_bloginfo( 'version' ),
			'php'         => PHP_VERSION,
			'divi_active' => $divi,
			'divi'        => $divi ? $theme->get( 'Version' ) : '',
		);
	}

	public static function site() {
		$launch = get_option( AdiNet_Options::SITE_LAUNCH_DATE, '' );
		$launch = self::date( $launch ) ? $launch : '';

		return array(
			'launch' => $launch,
			'age'    => '' !== $launch && $launch <= wp_date( 'Y-m-d' ) ? AdiNet_Billing::get_site_age( $launch ) : '',
		);
	}

	/**
	 * Przygotowuje dane formularza i wylicza punktację po stronie serwera.
	 * Brak oceny jest zapisywany jako null, także jeśli nie wybrano wyniku testu.
	 */
	public static function evaluate( $input, $environment ) {
		$grades          = self::performance_grades();
		$compatibility   = self::compatibility_scores();
		$performance     = self::text( $input, 'performance_grade' );
		$performance_day = self::text( $input, 'performance_date' );
		$divi_mode       = self::text( $input, 'divi_compatibility' );
		$divi_needs_mode = self::needs_compatibility( $environment );
		if ( ! $divi_needs_mode || self::text( $input, 'divi_version' ) !== $environment['divi'] ) {
			$divi_mode = '';
		}

		$manual = isset( $input['scores'] ) && is_array( $input['scores'] ) ? $input['scores'] : array();
		$notes  = isset( $input['notes'] ) && is_array( $input['notes'] ) ? $input['notes'] : array();
		$scores = array();
		$notes_by_criterion = array();
		foreach ( self::criteria() as $key => $criterion ) {
			$score = $manual[ $key ] ?? '';
			$scores[ $key ] = in_array( $score, array( '0', '1', '2', 0, 1, 2 ), true ) ? (int) $score : null;
			$notes_by_criterion[ $key ] = self::text( $notes, $key, true );
		}
		$scores['performance'] = $grades[ $performance ] ?? null;
		$scores['divi']        = self::divi_score( $environment, $compatibility[ $divi_mode ] ?? null );
		$scores['php']         = self::php_score( $environment['php'] );
		$total                 = array_sum( $scores );
		$suggested             = self::suggest( $total );

		$choice = self::text( $input, 'recommendation' );
		if ( ! isset( self::recommendations()[ $choice ] ) ) {
			$choice = '';
		}

		return array(
			'scores'             => $scores,
			'notes'              => $notes_by_criterion,
			'performance_grade'  => isset( $grades[ $performance ] ) ? $performance : '',
			'performance_source' => self::text( $input, 'performance_source' ),
			'performance_date'   => self::date( $performance_day ) ? $performance_day : '',
			'divi_compatibility' => isset( $compatibility[ $divi_mode ] ) ? $divi_mode : '',
			'divi_version'       => $environment['divi'],
			'environment'        => $environment,
			'total'              => $total,
			'suggested'          => $suggested,
			'recommendation'     => $choice,
			'override_reason'    => self::text( $input, 'override_reason', true ),
			'client_reason'      => self::text( $input, 'client_reason', true ),
		);
	}

	private static function text( $input, $key, $multiline = false ) {
		$value = $input[ $key ] ?? '';
		if ( ! is_string( $value ) ) {
			return '';
		}

		return $multiline ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
	}

	public static function php_score( $version ) {
		if ( version_compare( $version, '8.3', '<' ) ) {
			return 2;
		}

		return version_compare( $version, '8.5', '<' ) ? 1 : 0;
	}

	public static function needs_compatibility( $environment ) {
		return $environment['divi_active'] && version_compare( $environment['divi'], '5', '>=' );
	}

	public static function divi_score( $environment, $mode_score ) {
		if ( ! $environment['divi_active'] ) {
			return 0;
		}

		if ( '' === $environment['divi'] ) {
			return null;
		}

		return self::needs_compatibility( $environment ) ? $mode_score : 2;
	}

	public static function suggest( $total ) {
		foreach ( self::recommendations() as $key => $range ) {
			if ( $total <= $range[0] ) {
				return $key;
			}
		}

		return 'rebuild';
	}

	public static function selected_recommendation( $assessment ) {
		return '' !== $assessment['recommendation'] ? $assessment['recommendation'] : $assessment['suggested'];
	}

	private static function has_project_proposal( $recommendation ) {
		return in_array( $recommendation, array( 'consider', 'rebuild' ), true );
	}

	/** Wypełnia edytor z wersji roboczej lub z ostatniej zatwierdzonej oceny. */
	public static function editor_values( $state, $environment, $today ) {
		$input = $state['draft'] ?? $state['approved'] ?? array();
		if ( ! $state['draft'] && $state['approved'] ) {
			// Older approvals only stored the final recommendation.
			$input['recommendation'] = $input['recommendation_choice']
				?? ( $input['recommendation'] === $input['suggested'] ? '' : $input['recommendation'] );
		}

		$values = self::evaluate( $input, $environment );
		if ( '' === $values['performance_date'] ) {
			$values['performance_date'] = $today;
		}

		return $values;
	}

	public static function approval_error( $assessment ) {
		return in_array( null, $assessment['scores'], true ) ? 'incomplete' : '';
	}

	public static function approve( $assessment, $site, $today ) {
		$assessment['id']                    = wp_generate_uuid4();
		$assessment['date']                  = $today;
		$assessment['site']                  = $site;
		$assessment['recommendation_choice'] = $assessment['recommendation'];
		$assessment['recommendation']        = self::selected_recommendation( $assessment );
		$assessment['client_message']        = self::client_message( $assessment );
		return $assessment;
	}

	private static function client_status( $recommendation ) {
		$labels = array(
			'care'     => __( 'Dobry stan', 'adinet-panel' ),
			'improve'  => __( 'Usprawnienia', 'adinet-panel' ),
			'consider' => __( 'Zalecana przebudowa', 'adinet-panel' ),
			'rebuild'  => __( 'Zalecane rozważenie budowy nowego serwisu internetowego', 'adinet-panel' ),
		);
		return $labels[ $recommendation ] ?? $labels['care'];
	}

	private static function refresh_client_status( $message ) {
		if ( self::has_project_proposal( $message['recommendation'] ) ) {
			$message['status'] = self::client_status( $message['recommendation'] );
		}
		return $message;
	}

	public static function client_areas_heading() {
		return __( 'Główne obszary wymagające uwagi:', 'adinet-panel' );
	}

	private static function client_areas( $scores ) {
		$labels = array(
			'security' => __( 'Bezpieczeństwo witryny', 'adinet-panel' ),
			'ux'       => __( 'Wygoda obsługi i działanie na telefonach', 'adinet-panel' ),
			'content'  => __( 'Treść i struktura serwisu', 'adinet-panel' ),
			'seo'      => __( 'Widoczność w wyszukiwarkach i struktura stron', 'adinet-panel' ),
			'ai'       => __( 'Dostępność treści dla usług AI', 'adinet-panel' ),
			'php'      => __( 'Wersja PHP', 'adinet-panel' ),
		);
		$areas = array();
		foreach ( self::criteria() as $key => $criterion ) {
			if ( 2 === ( $scores[ $key ] ?? null ) ) {
				$areas[] = $labels[ $key ] ?? $criterion[0];
			}
		}
		return $areas;
	}

	private static function maintenance_intro() {
		$host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		/* translators: %s: public website hostname. */
		$maintenance = '' !== $host
			? sprintf( __( 'Regularnie serwisuję i aktualizuję stronę internetową %s.', 'adinet-panel' ), $host )
			: __( 'Regularnie serwisuję i aktualizuję stronę internetową.', 'adinet-panel' );

		return $maintenance . ' ' . __( 'Mimo bieżącej opieki ostatni audyt pokazał, że strona wymaga szerszych prac.', 'adinet-panel' );
	}

	private static function client_recommendation_text( $recommendation ) {
		return 'rebuild' === $recommendation
			? __( 'Po ostatnim audycie rekomenduję zbudowanie nowego serwisu internetowego, dopasowanego do aktualnych potrzeb firmy i jej klientów.', 'adinet-panel' )
			: __( 'Po ostatnim audycie zalecam rozważenie przebudowy obecnej witryny, aby lepiej odpowiadała na potrzeby firmy i jej klientów.', 'adinet-panel' );
	}

	public static function client_message( $assessment ) {
		$recommendation = $assessment['recommendation'];
		$is_proposal    = self::has_project_proposal( $recommendation );
		$areas          = $is_proposal ? self::client_areas( $assessment['scores'] ?? array() ) : array();
		$contact        = __( 'Zachęcam do kontaktu, aby omówić możliwości i zakres prac.', 'adinet-panel' ) . "\nHubert Rosiński";
		$body = __( 'Strona internetowa jest w dobrym stanie. Ostatni audyt nie wykazał potrzeby jej gruntownej przebudowy. Zalecam dalszą regularną opiekę i aktualizacje.', 'adinet-panel' );

		if ( 'improve' === $recommendation ) {
			$body = __( 'Podczas ostatniego audytu zauważyłem elementy strony, które warto zmodernizować. Zalecam wprowadzać te usprawnienia stopniowo.', 'adinet-panel' );
		}

		if ( $is_proposal ) {
			$age = $assessment['site']['age'];
			/* translators: %s: age of the website, e.g. 7 lat. */
			$opening = '' !== $age ? sprintf( __( 'Strona internetowa ma %s.', 'adinet-panel' ), lcfirst( $age ) ) . ' ' : '';
			$opening .= self::maintenance_intro();
			$body = implode(
				"\n\n",
				array_filter(
					array(
						$areas ? '' : $opening,
						$assessment['client_reason'],
						self::client_recommendation_text( $recommendation ),
						$contact,
					),
					'strlen'
				)
			);
		}

		$message = array(
			'date'           => $assessment['date'],
			'status'         => self::client_status( $recommendation ),
			'body'           => $body,
			'recommendation' => $recommendation,
		);
		if ( $areas ) {
			$message['intro'] = $opening;
			$message['areas'] = $areas;
		}
		return $message;
	}

	public static function email( $assessment ) {
		if ( ! $assessment || ! self::has_project_proposal( $assessment['recommendation'] ) ) {
			return null;
		}

		$age        = $assessment['site']['age'];
		$paragraphs = array(
			__( 'Dzień dobry,', 'adinet-panel' ),
			self::maintenance_intro(),
		);
		if ( '' !== $age ) {
			/* translators: %s: age of the website, e.g. 7 lat. */
			$paragraphs[] = sprintf( __( 'Strona internetowa ma %s. Sposób korzystania z internetu zmienia się wraz z rozwojem urządzeń mobilnych, wyszukiwarek takich jak Google i narzędzi opartych na sztucznej inteligencji.', 'adinet-panel' ), lcfirst( $age ) );
		}
		$client = self::client_message( $assessment );
		if ( ! empty( $client['areas'] ) ) {
			$paragraphs[] = self::client_areas_heading() . "\n- " . implode( "\n- ", $client['areas'] );
		}
		if ( '' !== $assessment['client_reason'] ) {
			$paragraphs[] = $assessment['client_reason'];
		}
		$new_site = 'rebuild' === $assessment['recommendation'];
		$paragraphs[] = self::client_recommendation_text( $assessment['recommendation'] );
		$paragraphs[] = __( 'Chętnie przedstawię możliwy zakres prac i spodziewane korzyści dla firmy.', 'adinet-panel' );
		$paragraphs[] = __( 'Jeżeli temat jest interesujący, zachęcam do kontaktu.', 'adinet-panel' );
		$paragraphs[] = __( 'Pozdrawiam,', 'adinet-panel' ) . "\nHubert Rosiński\nAdiNet";

		return array(
			'subject' => $new_site
				? __( 'Czy warto pomyśleć o nowej stronie WWW?', 'adinet-panel' )
				: __( 'Czy warto przebudować obecną stronę WWW?', 'adinet-panel' ),
			'body'    => implode( "\n\n", $paragraphs ),
		);
	}

	public static function state() {
		return get_option(
			AdiNet_Options::SITE_ASSESSMENT,
			array(
				'revision'  => '',
				'draft'     => null,
				'approved'  => null,
				'published' => null,
				'sent_on'   => '',
			)
		);
	}

	public static function public_message() {
		$state   = self::state();
		$message = $state['published']['message'] ?? null;
		if ( ! $message ) {
			return null;
		}
		if ( isset( self::recommendations()[ $message['recommendation'] ] ) ) {
			return self::refresh_client_status( $message );
		}

		// Version 4.11.0 stored the recommendation label in the public message.
		if ( $state['published']['audit_id'] === ( $state['approved']['id'] ?? null ) ) {
			$level = $state['approved']['recommendation'];
		} else {
			$labels = array(
				__( 'Rekomendowana gruntowna przebudowa', 'adinet-panel' ) => 'rebuild',
				__( 'Rozważenie przebudowy', 'adinet-panel' )             => 'consider',
				__( 'Modernizacja wybranych elementów', 'adinet-panel' ) => 'improve',
				''                                                       => 'care',
			);
			$level = $labels[ $message['recommendation'] ] ?? null;
		}
		if ( null !== $level ) {
			$message['status'] = self::client_status( $level );
		}
		$message['recommendation'] = $level ?? '';
		return $message;
	}

	/**
	 * Atomowy zapis jednej opcji. Warunek na poprzednią wartość chroni m.in.
	 * publikację i datę kontaktu przed równoczesnym zatwierdzeniem innego audytu.
	 */
	public static function save( $previous, $next ) {
		global $wpdb;

		$next['revision'] = wp_generate_uuid4();
		$option = AdiNet_Options::SITE_ASSESSMENT;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The Options API has no conditional write.
		if ( '' === $previous['revision'] ) {
			$changed = $wpdb->query(
				$wpdb->prepare(
					"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
					$option,
					maybe_serialize( $next )
				)
			);
			wp_cache_delete( 'notoptions', 'options' );
		} else {
			$changed = $wpdb->update(
				$wpdb->options,
				array( 'option_value' => maybe_serialize( $next ) ),
				array( 'option_name' => $option, 'option_value' => maybe_serialize( $previous ) )
			);
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		wp_cache_delete( $option, 'options' );

		return 1 === $changed ? $next['revision'] : new WP_Error( false === $changed ? 'write-error' : 'conflict' );
	}
}
