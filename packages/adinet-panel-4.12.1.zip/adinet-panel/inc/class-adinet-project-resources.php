<?php
/**
 * Informacje i notatki o zasobach używanych na bieżącej witrynie.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Project_Resources {
	const PAGE_SLUG = 'adinet-project-resources';
	const ACTION = 'adinet_project_resource';
	private static $page_hook = '';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 25 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_action' ) );
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'adinet_project_resources';
	}

	public static function install_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = self::table();
		$collate = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			title varchar(190) NOT NULL,
			category varchar(30) NOT NULL,
			provider varchar(30) NOT NULL,
			role varchar(20) NOT NULL,
			data longtext NOT NULL,
			revision bigint(20) unsigned NOT NULL DEFAULT 1,
			updated_at datetime NOT NULL,
			updated_by varchar(100) NOT NULL,
			PRIMARY KEY  (id)
		) {$collate};" );
	}

	public static function can_manage() {
		return AdiNet_Admin::can_view_panel() && AdiNet_Admin::can_manage_panel();
	}

	public static function page_url( $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::PAGE_SLUG ), $args ), admin_url( 'admin.php' ) );
	}

	public static function add_menu() {
		self::$page_hook = add_submenu_page( AdiNet_Admin::PAGE_SLUG, __( 'Zasoby projektu — AdiNet', 'adinet-panel' ), __( 'Zasoby projektu', 'adinet-panel' ), 'manage_options', self::PAGE_SLUG, array( __CLASS__, 'render_page' ) );
		add_action( 'load-' . self::$page_hook, array( 'AdiNet_Admin', 'suppress_external_admin_notices' ) );
	}

	public static function enqueue_assets( $hook ) {
		if ( self::$page_hook !== $hook ) {
			return;
		}
		wp_enqueue_style( 'adinet-admin', ADINET_URL . 'assets/css/admin.css', array(), ADINET_VERSION );
		wp_enqueue_style( 'adinet-project-resources', ADINET_URL . 'assets/css/project-resources.css', array( 'adinet-admin' ), ADINET_VERSION );
		wp_enqueue_script( 'adinet-admin', ADINET_URL . 'assets/js/admin.js', array(), ADINET_VERSION, true );
		wp_enqueue_script( 'adinet-project-resources', ADINET_URL . 'assets/js/project-resources.js', array(), ADINET_VERSION, true );
		if ( self::can_manage() ) {
			wp_enqueue_media();
		}
	}

	private static function decode( $row ) {
		if ( ! is_array( $row ) ) {
			return null;
		}
		$data = json_decode( $row['data'], true );
		$row['details'] = is_array( $data ) ? $data : array();
		return $row;
	}

	public static function get_item( $id ) {
		global $wpdb;
		return self::decode( $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ), ARRAY_A ) );
	}

	public static function get_items() {
		global $wpdb;
		return array_map( array( __CLASS__, 'decode' ), (array) $wpdb->get_results( 'SELECT * FROM ' . self::table() . " ORDER BY CASE WHEN role = 'primary' THEN 0 ELSE 1 END, id ASC", ARRAY_A ) );
	}

	public static function scalar( $input, $key, $default = '' ) {
		return isset( $input[ $key ] ) && ( is_string( $input[ $key ] ) || is_int( $input[ $key ] ) || is_float( $input[ $key ] ) ) ? (string) $input[ $key ] : $default;
	}

	private static function length( $value ) {
		return preg_match_all( '/./us', $value, $matches );
	}

	/** Only web links are stored; none of them are fetched by the plugin. */
	private static function web_url( $value ) {
		if ( '' === $value ) {
			return '';
		}
		$parts = wp_parse_url( $value );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) || empty( $parts['scheme'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) || isset( $parts['user'] ) || isset( $parts['pass'] ) || strlen( $value ) > 2000 ) {
			return false;
		}
		return esc_url_raw( $value, array( 'https', 'http' ) );
	}

	public static function sanitize_profile( $input, $existing = null ) {
		foreach ( array( 'title', 'category', 'provider', 'role', 'service_name', 'service_url', 'source_url', 'family', 'author', 'collection', 'display_color', 'export_color', 'usage', 'notes', 'prompt', 'negative_prompt', 'reference_notes', 'examples', 'reference_id' ) as $key ) {
			if ( isset( $input[ $key ] ) && ! is_scalar( $input[ $key ] ) ) {
				return new WP_Error( 'invalid', __( 'Niepoprawna zawartość formularza. Sprawdź pola i zapisz ponownie.', 'adinet-panel' ) );
			}
		}
		$categories = AdiNet_Resource_Catalog::categories();
		$providers = AdiNet_Resource_Catalog::providers();
		$title = sanitize_text_field( self::scalar( $input, 'title' ) );
		$category = self::scalar( $input, 'category' );
		$provider = self::scalar( $input, 'provider' );
		$role = self::scalar( $input, 'role' );
		if ( '' === $title || self::length( $title ) > 190 || ! isset( $categories[ $category ] ) || ! in_array( $role, array( 'primary', 'supplementary' ), true ) || ( 'other' !== $provider && ! isset( $providers[ $provider ] ) ) || ( isset( $providers[ $provider ] ) && AdiNet_Resource_Catalog::provider_category( $providers[ $provider ] ) !== $category ) ) {
			return new WP_Error( 'invalid', __( 'Podaj nazwę profilu (do 190 znaków), kategorię, serwis i rolę.', 'adinet-panel' ) );
		}
		$data = array();
		foreach ( array( 'service_name' => 100, 'family' => 190, 'author' => 190, 'collection' => 190, 'display_color' => 190, 'usage' => 3000, 'notes' => 20000, 'prompt' => 20000, 'negative_prompt' => 10000, 'reference_notes' => 5000 ) as $key => $limit ) {
			$raw = self::scalar( $input, $key );
			if ( strlen( $raw ) > $limit * 4 || self::length( $raw ) > $limit ) {
				return new WP_Error( 'length', sprintf( __( 'Pole „%s” jest zbyt długie. Skróć wpis i zapisz ponownie.', 'adinet-panel' ), self::detail_labels()[ $key ] ) );
			}
			$data[ $key ] = in_array( $key, array( 'usage', 'notes', 'prompt', 'negative_prompt', 'reference_notes' ), true ) ? sanitize_textarea_field( $raw ) : sanitize_text_field( $raw );
			if ( in_array( $key, array( 'prompt', 'negative_prompt' ), true ) ) {
				// Prompts are plain text, including literal <tokens>; escape them at output.
				$data[ $key ] = wp_check_invalid_utf8( str_replace( "\0", '', $raw ) );
			}
			if ( 'generators' !== $category && in_array( $key, array( 'prompt', 'negative_prompt', 'reference_notes' ), true ) ) {
				$data[ $key ] = '';
			}
		}
		foreach ( array( 'service_url', 'source_url' ) as $key ) {
			$data[ $key ] = self::web_url( trim( self::scalar( $input, $key ) ) );
			if ( false === $data[ $key ] ) {
				return new WP_Error( 'url', __( 'Linki muszą być pełnymi adresami http:// lub https://, bez danych logowania.', 'adinet-panel' ) );
			}
		}
		if ( 'other' === $provider && ( '' === $data['service_name'] || '' === $data['service_url'] ) ) {
			return new WP_Error( 'service', __( 'Dla własnego serwisu podaj jego nazwę i adres WWW.', 'adinet-panel' ) );
		}
		if ( 'other' !== $provider ) {
			$data['service_name'] = $providers[ $provider ]['name'];
			$data['service_url'] = $providers[ $provider ]['url'];
		}
		$data['export_color'] = 'icons' === $category ? trim( self::scalar( $input, 'export_color' ) ) : '';
		if ( 'icons' !== $category ) {
			$data['display_color'] = '';
		}
		if ( '' !== $data['export_color'] && 'currentColor' !== $data['export_color'] && ! preg_match( '/^#(?:[a-f0-9]{3}|[a-f0-9]{6}|[a-f0-9]{8})$/iD', $data['export_color'] ) ) {
			return new WP_Error( 'color', __( 'Kolor eksportu wpisz jako HEX, np. #f91a1a, albo currentColor. Pole może pozostać puste.', 'adinet-panel' ) );
		}
		$data['settings'] = array();
		$data['parameters'] = array();
		$posted_settings = isset( $input['settings'][ $provider ] ) && is_array( $input['settings'][ $provider ] ) ? $input['settings'][ $provider ] : array();
		$fields = AdiNet_Resource_Catalog::fields( $provider, $posted_settings );
		$values = array();
		foreach ( $fields as $key => $field ) {
			if ( isset( $posted_settings[ $key ] ) && ! is_scalar( $posted_settings[ $key ] ) ) {
				return new WP_Error( 'setting', __( 'Niepoprawna wartość ustawienia biblioteki.', 'adinet-panel' ) );
			}
			$values[ $key ] = trim( self::scalar( $posted_settings, $key, (string) $field['default'] ) );
		}
		foreach ( $fields as $key => $field ) {
			if ( ! AdiNet_Resource_Catalog::field_visible( $field, $values ) ) {
				continue;
			}
			$value = $values[ $key ];
			$previous = $existing && $existing['provider'] === $provider && isset( $existing['details']['settings'][ $key ] ) ? $existing['details']['settings'][ $key ] : null;
			if ( 'magnific' === $provider && ( ! $existing || ( $existing['details']['settings']['model'] ?? '' ) !== $values['model'] ) ) {
				$previous = null;
			}
			if ( '' === $value && ! empty( $field['optional'] ) ) {
				continue;
			}
			$valid = 'select' === $field['type'] ? array_key_exists( $value, $field['choices'] ) : false;
			if ( 'text' === $field['type'] ) {
				$value = sanitize_text_field( $value );
				$valid = self::length( $value ) <= $field['maxlength'] && ( empty( $field['required'] ) || '' !== $value ) && ( ! isset( $field['pattern'] ) || preg_match( '~^(?:' . $field['pattern'] . ')$~D', $value ) );
			}
			if ( 'number' === $field['type'] ) {
				$value = str_replace( ',', '.', $value );
				if ( '' === $value && '' === $field['default'] ) {
					continue;
				}
				$number = (float) $value;
				$steps = ( $number - $field['min'] ) / $field['step'];
				$valid = preg_match( '/^-?\d+(?:\.\d+)?$/D', $value ) && $number >= $field['min'] && $number <= $field['max'] && abs( $steps - round( $steps ) ) < 0.000001;
				if ( $valid ) {
					$value = (string) $number;
				}
			}
			// A later catalog update must not force a change to an unchanged saved setting.
			if ( ! $valid && ( null === $previous || $value !== (string) $previous ) ) {
				return new WP_Error( 'setting', sprintf( __( 'Sprawdź wartość pola „%s” dla wybranego serwisu i modelu.', 'adinet-panel' ), $field['label'] ) );
			}
			$data['settings'][ $key ] = $value;
			if ( 'magnific' === $provider && 'model_name' === $key ) {
				continue;
			}
			$display_value = 'select' === $field['type'] && isset( $field['choices'][ $value ] ) ? (string) $field['choices'][ $value ] : $value;
			if ( 'magnific' === $provider && 'model' === $key && 'custom' === $value ) {
				$display_value = sanitize_text_field( $values['model_name'] );
			}
			$data['parameters'][] = array( 'label' => $field['label'], 'value' => $display_value );
		}
		$data['custom_parameters'] = array();
		$keys = isset( $input['custom_keys'] ) && is_array( $input['custom_keys'] ) ? array_values( $input['custom_keys'] ) : array();
		$values = isset( $input['custom_values'] ) && is_array( $input['custom_values'] ) ? array_values( $input['custom_values'] ) : array();
		if ( count( $keys ) > 20 || count( $values ) !== count( $keys ) ) {
			return new WP_Error( 'parameters', __( 'Możesz dodać do 20 własnych parametrów. Każdy powinien mieć nazwę i wartość.', 'adinet-panel' ) );
		}
		foreach ( $keys as $index => $key ) {
			$value = $values[ $index ];
			if ( ! is_string( $key ) || ! is_string( $value ) || self::length( $key ) > 100 || self::length( $value ) > 500 ) {
				return new WP_Error( 'parameters', __( 'Nazwa własnego parametru może mieć do 100 znaków, a wartość do 500.', 'adinet-panel' ) );
			}
			$key = sanitize_text_field( $key );
			$value = sanitize_text_field( $value );
			if ( '' === $key && '' === $value ) {
				continue;
			}
			if ( '' === $key || '' === $value ) {
				return new WP_Error( 'parameters', __( 'Uzupełnij nazwę i wartość własnego parametru albo usuń pusty wiersz.', 'adinet-panel' ) );
			}
			$data['custom_parameters'][] = array( 'label' => $key, 'value' => $value );
		}
		$data['examples'] = array();
		$examples = self::scalar( $input, 'examples' );
		if ( strlen( $examples ) > 20000 ) {
			return new WP_Error( 'examples', __( 'Dodaj najwyżej 10 linków do wzorców, po jednym w wierszu.', 'adinet-panel' ) );
		}
		foreach ( preg_split( '/\r\n|\r|\n/', $examples ) as $url ) {
			if ( '' === trim( $url ) ) {
				continue;
			}
			$url = self::web_url( trim( $url ) );
			if ( false === $url || count( $data['examples'] ) >= 10 ) {
				return new WP_Error( 'examples', __( 'Dodaj najwyżej 10 poprawnych linków http(s) do wzorców, po jednym w wierszu.', 'adinet-panel' ) );
			}
			$data['examples'][] = $url;
		}
		$data['reference_id'] = absint( self::scalar( $input, 'reference_id', '0' ) );
		if ( $data['reference_id'] && ( 'attachment' !== get_post_type( $data['reference_id'] ) || ! in_array( get_post_mime_type( $data['reference_id'] ), array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif' ), true ) ) ) {
			return new WP_Error( 'image', __( 'Jako zrzut ustawień wybierz obraz JPG, PNG, GIF, WebP lub AVIF z biblioteki mediów.', 'adinet-panel' ) );
		}
		return array( 'title' => $title, 'category' => $category, 'provider' => $provider, 'role' => $role, 'data' => wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
	}

	public static function handle_action() {
		if ( ! self::can_manage() ) {
			wp_die( esc_html__( 'Brak uprawnień do zmiany zasobów projektu.', 'adinet-panel' ) );
		}
		check_admin_referer( self::ACTION );
		$input = wp_unslash( $_POST );
		$id = absint( self::scalar( $input, 'resource_id', '0' ) );
		$revision = absint( self::scalar( $input, 'revision', '0' ) );
		$operation = self::scalar( $input, 'operation' );
		$item = $id ? self::get_item( $id ) : null;
		$error = null;
		global $wpdb;
		if ( ! in_array( $operation, array( 'save', 'delete' ), true ) || ( $id && ! $item ) || ( 'delete' === $operation && ! $id ) ) {
			$error = new WP_Error( 'missing', __( 'Nie znaleziono profilu lub wybrano niepoprawną operację.', 'adinet-panel' ) );
		} elseif ( $id && (int) $item['revision'] !== $revision ) {
			$error = new WP_Error( 'conflict', __( 'Ten profil zmieniono w innym oknie. Skopiuj swoje zmiany i wczytaj zapisaną wersję przed ponowną edycją.', 'adinet-panel' ) );
		} elseif ( 'delete' === $operation ) {
			$result = $wpdb->delete( self::table(), array( 'id' => $id, 'revision' => $revision ), array( '%d', '%d' ) );
			if ( 1 !== $result ) {
				$error = new WP_Error( 'delete', __( 'Nie usunięto profilu. Mógł zostać zmieniony w innym oknie; odśwież stronę.', 'adinet-panel' ) );
			}
		} else {
			$data = self::sanitize_profile( $input, $item );
			if ( is_wp_error( $data ) ) {
				$error = $data;
			} else {
				$data['updated_at'] = current_time( 'mysql', true );
				$data['updated_by'] = wp_get_current_user()->user_login;
				$data['revision'] = $id ? $revision + 1 : 1;
				$result = $id ? $wpdb->update( self::table(), $data, array( 'id' => $id, 'revision' => $revision ) ) : $wpdb->insert( self::table(), $data );
				if ( 1 !== $result ) {
					$error = new WP_Error( 'save', __( 'Nie zapisano profilu. Sprawdź połączenie z bazą lub wczytaj aktualną wersję profilu.', 'adinet-panel' ) );
				}
			}
		}
		$args = array( 'notice' => 'delete' === $operation ? 'deleted' : 'saved' );
		if ( $error ) {
			// A private, short-lived draft preserves entered notes after validation/DB errors.
			$token = wp_generate_uuid4();
			$draft = 'save' === $operation && strlen( (string) wp_json_encode( $input ) ) <= 500000 ? array_intersect_key( $input, array_flip( array( 'resource_id', 'revision', 'title', 'category', 'provider', 'role', 'service_name', 'service_url', 'source_url', 'family', 'author', 'collection', 'display_color', 'export_color', 'usage', 'notes', 'prompt', 'negative_prompt', 'reference_notes', 'examples', 'reference_id', 'settings', 'custom_keys', 'custom_values' ) ) ) : array();
			set_transient( 'adinet_resource_' . get_current_user_id() . '_' . $token, array( 'input' => $draft, 'message' => $error->get_error_message() ), 15 * MINUTE_IN_SECONDS );
			$args = array( 'draft' => $token );
			if ( 'save' === $operation ) {
				$args['edit'] = $id ? $id : 'new';
			}
		} else {
			AdiNet_Admin_Log::record( 'project_resource', 'standard', sprintf( 'Zasoby projektu: %s — %s', 'delete' === $operation ? 'usunięto' : 'zapisano', 'delete' === $operation ? $item['title'] : $data['title'] ), array( 'is_change' => true ) );
		}
		wp_safe_redirect( self::page_url( $args ) );
		exit;
	}

	public static function detail_labels() {
		return array( 'service_name' => __( 'Nazwa serwisu', 'adinet-panel' ), 'family' => __( 'Rodzina / styl / paczka', 'adinet-panel' ), 'author' => __( 'Autor', 'adinet-panel' ), 'collection' => __( 'Kolekcja / projekt w narzędziu docelowym', 'adinet-panel' ), 'export_color' => __( 'Kolor eksportu SVG', 'adinet-panel' ), 'display_color' => __( 'Kolor na stronie i sposób ustawienia', 'adinet-panel' ), 'usage' => __( 'Zastosowanie na tej stronie', 'adinet-panel' ), 'notes' => __( 'Notatki i instrukcja', 'adinet-panel' ), 'prompt' => __( 'Prompt wzorcowy', 'adinet-panel' ), 'negative_prompt' => __( 'Wykluczenia / negative prompt', 'adinet-panel' ), 'reference_notes' => __( 'Referencje i zasady spójności', 'adinet-panel' ) );
	}

	public static function copy_text( $item ) {
		$data = $item['details'];
		$categories = AdiNet_Resource_Catalog::categories();
		$lines = array( $item['title'], $categories[ $item['category'] ] ?? $item['category'], ( $data['service_name'] ?? '' ) . ' — ' . ( $data['service_url'] ?? '' ) );
		if ( ! empty( $data['source_url'] ) ) {
			$lines[] = ( 'generators' === $item['category'] ? __( 'Projekt / konfiguracja — link', 'adinet-panel' ) : __( 'Rodzina / paczka — link', 'adinet-panel' ) ) . ': ' . $data['source_url'];
		}
		foreach ( self::detail_labels() as $key => $label ) {
			if ( 'service_name' !== $key && ! empty( $data[ $key ] ) ) {
				$lines[] = $label . ': ' . $data[ $key ];
			}
		}
		foreach ( array_merge( $data['parameters'] ?? array(), $data['custom_parameters'] ?? array() ) as $parameter ) {
			$lines[] = $parameter['label'] . ': ' . $parameter['value'];
		}
		return implode( "\n", array_merge( $lines, $data['examples'] ?? array() ) );
	}

	public static function render_page() {
		if ( ! AdiNet_Admin::can_view_panel() ) {
			return;
		}
		$can_manage = self::can_manage();
		$providers = AdiNet_Resource_Catalog::providers();
		$categories = AdiNet_Resource_Catalog::categories();
		$items = self::get_items();
		$editing = $can_manage ? self::scalar( $_GET, 'edit' ) : '';
		$item = ctype_digit( $editing ) ? self::get_item( (int) $editing ) : null;
		$draft_token = self::scalar( $_GET, 'draft' );
		$draft = $can_manage && preg_match( '/^[a-f0-9-]{36}$/D', $draft_token ) ? get_transient( 'adinet_resource_' . get_current_user_id() . '_' . $draft_token ) : false;
		$form = $item ? array_merge( $item['details'], array( 'title' => $item['title'], 'category' => $item['category'], 'provider' => $item['provider'], 'role' => $item['role'], 'resource_id' => (string) $item['id'], 'revision' => (string) $item['revision'], 'examples' => implode( "\n", $item['details']['examples'] ?? array() ), 'settings' => array( $item['provider'] => $item['details']['settings'] ?? array() ) ) ) : array( 'category' => isset( $providers[ self::scalar( $_GET, 'provider' ) ] ) ? AdiNet_Resource_Catalog::provider_category( $providers[ self::scalar( $_GET, 'provider' ) ] ) : 'tools', 'provider' => isset( $providers[ self::scalar( $_GET, 'provider' ) ] ) ? self::scalar( $_GET, 'provider' ) : 'other', 'role' => 'primary' );
		if ( $draft && ! empty( $draft['input'] ) ) {
			$form = $draft['input'];
		}
		$missing = '' !== $editing && 'new' !== $editing && ! $item;
		require ADINET_PATH . 'inc/templates/project-resources.php';
	}
}
