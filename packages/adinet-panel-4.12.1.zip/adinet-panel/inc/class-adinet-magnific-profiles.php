<?php
/** Informational Magnific image profiles. No API connection or generation. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Magnific_Profiles {
	public static function catalog() {
		static $catalog;
		if ( null === $catalog ) {
			$catalog = require __DIR__ . '/magnific-image-models.php';
		}
		return $catalog;
	}

	public static function option_label( $value ) {
		return preg_match( '/^\d+(?:\.\d+)?k$/', $value ) ? strtoupper( $value ) : $value;
	}

	private static function select( $label, $choices, $condition = array(), $optional = true ) {
		return array( 'label' => $label, 'type' => 'select', 'choices' => $choices, 'default' => $optional ? '' : 'custom', 'optional' => $optional, 'condition' => $condition );
	}

	/** Null builds all controls for the editor; a model restricts server-side choices. */
	public static function fields( $model = null ) {
		$catalog = self::catalog();
		$models = $catalog['models'];
		$model_choices = array( 'custom' => __( 'Inny / nowy model — wpiszę nazwę', 'adinet-panel' ) );
		foreach ( $models as $key => $entry ) {
			$model_choices[ $key ] = $entry['name'];
		}
		$fields = array(
			'model' => self::select( __( 'Model i wersja', 'adinet-panel' ), $model_choices, array(), false ),
			'model_name' => array( 'label' => __( 'Nazwa i wersja własnego modelu', 'adinet-panel' ), 'type' => 'text', 'maxlength' => 190, 'default' => '', 'required' => true, 'condition' => array( 'model' => array( 'custom' ) ) ),
		);
		foreach ( array( 'aspect_ratio' => array( 'aspectRatios', __( 'Proporcje obrazu', 'adinet-panel' ) ), 'resolution' => array( 'resolutions', __( 'Rozdzielczość', 'adinet-panel' ) ), 'quality' => array( 'qualities', __( 'Jakość', 'adinet-panel' ) ), 'variant' => array( 'variants', __( 'Wariant modelu', 'adinet-panel' ) ), 'thinking' => array( 'thinkingLevels', __( 'Poziom rozumowania', 'adinet-panel' ) ), 'tier' => array( 'tiers', __( 'Tryb / poziom modelu', 'adinet-panel' ) ) ) as $key => $definition ) {
			list( $property, $label ) = $definition;
			$eligible = array();
			$choices = array( '' => __( 'Nie zapisano / domyślne w serwisie', 'adinet-panel' ) );
			foreach ( $models as $slug => $entry ) {
				if ( ! empty( $entry[ $property ] ) ) {
					$eligible[] = $slug;
					if ( null === $model || $model === $slug ) {
						foreach ( $entry[ $property ] as $value ) {
							$choices[ $value ] = self::option_label( $value );
						}
					}
				}
			}
			$fields[ $key ] = self::select( $label, $choices, array( 'model' => $eligible ) );
			$fields[ $key ]['model_property'] = $property;
		}
		$transparent = array_keys( array_filter( $models, static function ( $entry ) { return ! empty( $entry['transparentBackground'] ); } ) );
		$fields['transparent'] = self::select( __( 'Przezroczyste tło', 'adinet-panel' ), array( '' => __( 'Nie zapisano', 'adinet-panel' ), 'no' => __( 'Nie', 'adinet-panel' ), 'yes' => __( 'Tak', 'adinet-panel' ) ), array( 'model' => $transparent ) );
		$fields['seed'] = array( 'label' => __( 'Seed (jeśli ustawiony)', 'adinet-panel' ), 'type' => 'text', 'maxlength' => 32, 'pattern' => '-?[0-9]+', 'optional' => true, 'default' => '', 'condition' => array() );
		$cinematic_labels = array( 'camera' => __( 'Aparat / kamera', 'adinet-panel' ), 'lensBrand' => __( 'Obiektyw', 'adinet-panel' ), 'focalLength' => __( 'Ogniskowa', 'adinet-panel' ), 'aperture' => __( 'Przysłona', 'adinet-panel' ), 'shotType' => __( 'Kadr / ujęcie', 'adinet-panel' ), 'filmStock' => __( 'Materiał filmowy', 'adinet-panel' ), 'movieLook' => __( 'Filmowy styl', 'adinet-panel' ), 'lighting' => __( 'Oświetlenie', 'adinet-panel' ), 'motionBlur' => __( 'Rozmycie ruchu', 'adinet-panel' ), 'grain' => __( 'Ziarno', 'adinet-panel' ), 'halation' => __( 'Poświata (halation)', 'adinet-panel' ), 'tonalLook' => __( 'Wygląd tonalny', 'adinet-panel' ) );
		foreach ( $catalog['cinematic'] as $key => $values ) {
			$choices = array( '' => __( 'Nie zapisano / domyślne w serwisie', 'adinet-panel' ) );
			foreach ( $values as $value ) {
				$choices[ $value ] = ucwords( str_replace( array( '-', '_' ), ' ', $value ) );
			}
			$fields[ 'cinematic_' . $key ] = self::select( $cinematic_labels[ $key ], $choices, array( 'model' => array( 'cinematic' ) ) );
		}
		return $fields;
	}
}
