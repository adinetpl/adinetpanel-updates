<?php
/** Project resource notebook. Variables come from render_page(). */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$form_provider = self::scalar( $form, 'provider', 'other' );
$form_category = self::scalar( $form, 'category', 'icons' );
$labels = self::detail_labels();
?>
<div class="wrap adinet-admin adinet-project-resources">
	<header class="adinet-monitor-hero">
		<div><p class="adinet-eyebrow"><?php esc_html_e( 'Notatnik tej witryny', 'adinet-panel' ); ?></p><h1><?php esc_html_e( 'Zasoby projektu', 'adinet-panel' ); ?></h1><p><?php esc_html_e( 'Serwisy, wybrane style i instrukcje do wykorzystania przy kolejnych zmianach na stronie.', 'adinet-panel' ); ?></p></div>
		<a class="button" href="<?php echo esc_url( $can_manage ? self::page_url( array( 'edit' => 'new' ) ) : '#resource-catalog' ); ?>"><?php echo esc_html( $can_manage ? __( 'Dodaj zasób', 'adinet-panel' ) : __( 'Przeglądaj zasoby', 'adinet-panel' ) ); ?></a>
	</header>
	<?php if ( ! $can_manage ) : ?><div class="notice notice-info"><p><?php esc_html_e( 'Podgląd zasobów projektu. Zmiany może zapisywać konto serwisowe AdiNet.', 'adinet-panel' ); ?></p></div><?php endif; ?>
	<?php if ( $draft ) : ?><div class="notice notice-error"><p><?php echo esc_html( $draft['message'] ); ?></p><?php if ( $item ) : ?><p><a href="<?php echo esc_url( self::page_url( array( 'edit' => $item['id'] ) ) ); ?>"><?php esc_html_e( 'Wczytaj zapisaną wersję profilu', 'adinet-panel' ); ?></a></p><?php endif; ?></div><?php endif; ?>
	<?php if ( $missing ) : ?><div class="notice notice-warning"><p><?php esc_html_e( 'Nie znaleziono wybranego profilu. Wróć do listy zasobów.', 'adinet-panel' ); ?></p></div><?php endif; ?>
	<?php if ( in_array( self::scalar( $_GET, 'notice' ), array( 'saved', 'deleted' ), true ) ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html( 'saved' === self::scalar( $_GET, 'notice' ) ? __( 'Profil zasobu został zapisany.', 'adinet-panel' ) : __( 'Profil zasobu został usunięty.', 'adinet-panel' ) ); ?></p></div><?php endif; ?>

	<?php if ( $can_manage && ( 'new' === $editing || $item || ( $draft && ! empty( $draft['input'] ) ) ) ) : ?>
	<section class="adinet-card adinet-resource-editor" aria-labelledby="resource-editor-title">
		<h2 id="resource-editor-title"><?php echo esc_html( $item ? __( 'Edytuj profil zasobu', 'adinet-panel' ) : __( 'Nowy profil zasobu', 'adinet-panel' ) ); ?></h2>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" id="adinet-resource-form">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>"><input type="hidden" name="operation" value="save"><input type="hidden" name="resource_id" value="<?php echo esc_attr( self::scalar( $form, 'resource_id', '0' ) ); ?>"><input type="hidden" name="revision" value="<?php echo esc_attr( self::scalar( $form, 'revision', '0' ) ); ?>">
			<?php wp_nonce_field( self::ACTION ); ?>
			<fieldset><legend><?php esc_html_e( 'Profil i źródło', 'adinet-panel' ); ?></legend>
				<div class="adinet-resource-fields">
					<label class="is-wide" for="resource-title"><?php esc_html_e( 'Nazwa profilu', 'adinet-panel' ); ?><input id="resource-title" name="title" type="text" maxlength="190" required value="<?php echo esc_attr( self::scalar( $form, 'title' ) ); ?>" placeholder="<?php echo esc_attr__( 'Np. Ikony usług i atrakcji', 'adinet-panel' ); ?>"></label>
					<label for="resource-category"><?php esc_html_e( 'Kategoria', 'adinet-panel' ); ?><select id="resource-category" name="category"><?php foreach ( $categories as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>" <?php selected( $form_category, $key ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
					<label for="resource-role"><?php esc_html_e( 'Rola w projekcie', 'adinet-panel' ); ?><select id="resource-role" name="role"><option value="primary" <?php selected( self::scalar( $form, 'role', 'primary' ), 'primary' ); ?>><?php esc_html_e( 'Główny', 'adinet-panel' ); ?></option><option value="supplementary" <?php selected( self::scalar( $form, 'role' ), 'supplementary' ); ?>><?php esc_html_e( 'Uzupełniający', 'adinet-panel' ); ?></option></select></label>
					<label class="is-wide" for="resource-provider"><?php esc_html_e( 'Biblioteka / serwis', 'adinet-panel' ); ?><select id="resource-provider" name="provider"><option value="other" <?php selected( $form_provider, 'other' ); ?>><?php esc_html_e( 'Własny serwis lub narzędzie', 'adinet-panel' ); ?></option><?php foreach ( $providers as $key => $provider ) : ?><option data-provider-category="<?php echo esc_attr( AdiNet_Resource_Catalog::provider_category( $provider ) ); ?>" value="<?php echo esc_attr( $key ); ?>" <?php selected( $form_provider, $key ); ?>><?php echo esc_html( $provider['name'] ); ?></option><?php endforeach; ?></select></label>
				</div>
				<div class="adinet-resource-fields" data-custom-service <?php if ( 'other' !== $form_provider ) : ?>hidden<?php endif; ?>>
					<label for="resource-service-name"><?php esc_html_e( 'Nazwa własnego serwisu', 'adinet-panel' ); ?><input id="resource-service-name" name="service_name" maxlength="100" value="<?php echo esc_attr( self::scalar( $form, 'service_name' ) ); ?>" <?php disabled( 'other' !== $form_provider ); ?> <?php if ( 'other' === $form_provider ) : ?>required<?php endif; ?>></label>
					<label for="resource-service-url"><?php esc_html_e( 'Adres serwisu', 'adinet-panel' ); ?><input id="resource-service-url" type="url" name="service_url" maxlength="2000" placeholder="https://" value="<?php echo esc_attr( self::scalar( $form, 'service_url' ) ); ?>" <?php disabled( 'other' !== $form_provider ); ?> <?php if ( 'other' === $form_provider ) : ?>required<?php endif; ?>></label>
				</div>
				<div class="adinet-resource-fields">
					<label for="resource-family"><?php echo esc_html( $labels['family'] ); ?><input id="resource-family" name="family" maxlength="190" value="<?php echo esc_attr( self::scalar( $form, 'family' ) ); ?>"></label>
					<label for="resource-author"><?php echo esc_html( $labels['author'] ); ?><input id="resource-author" name="author" maxlength="190" value="<?php echo esc_attr( self::scalar( $form, 'author' ) ); ?>"></label>
					<label class="is-wide" for="resource-source-url"><?php esc_html_e( 'Link do rodziny, projektu, paczki lub konfiguracji', 'adinet-panel' ); ?><input id="resource-source-url" type="url" name="source_url" maxlength="2000" placeholder="https://" value="<?php echo esc_attr( self::scalar( $form, 'source_url' ) ); ?>"></label>
				</div>
			</fieldset>
			<?php foreach ( $providers as $provider_key => $provider ) : ?>
			<?php
			$settings = isset( $form['settings'][ $provider_key ] ) && is_array( $form['settings'][ $provider_key ] ) ? $form['settings'][ $provider_key ] : array();
			$setting_values = array();
			foreach ( $provider['fields'] as $key => $field ) {
				$setting_values[ $key ] = self::scalar( $settings, $key, (string) $field['default'] );
			}
			?>
			<fieldset data-resource-provider="<?php echo esc_attr( $provider_key ); ?>" data-provider-category="<?php echo esc_attr( AdiNet_Resource_Catalog::provider_category( $provider ) ); ?>" <?php if ( 'magnific' === $provider_key ) : ?>data-magnific-models="<?php echo esc_attr( wp_json_encode( AdiNet_Magnific_Profiles::catalog()['models'] ) ); ?>"<?php endif; ?> <?php if ( $form_provider !== $provider_key || AdiNet_Resource_Catalog::provider_category( $provider ) !== $form_category ) : ?>hidden<?php endif; ?>>
				<legend><?php echo esc_html( $provider['name'] . ' — ' . ( 'generators' === AdiNet_Resource_Catalog::provider_category( $provider ) ? __( 'ustawienia generowania', 'adinet-panel' ) : __( 'ustawienia pobierania', 'adinet-panel' ) ) ); ?></legend><p class="adinet-help"><?php echo esc_html( $provider['help'] ); ?></p>
				<div class="adinet-resource-fields">
					<?php foreach ( $provider['fields'] as $key => $field ) : ?>
					<?php $visible = $form_provider === $provider_key && AdiNet_Resource_Catalog::provider_category( $provider ) === $form_category && AdiNet_Resource_Catalog::field_visible( $field, $setting_values ); ?>
					<label for="resource-<?php echo esc_attr( $provider_key . '-' . $key ); ?>" data-setting-condition="<?php echo esc_attr( wp_json_encode( $field['condition'] ) ); ?>" <?php if ( isset( $field['model_property'] ) ) : ?>data-model-property="<?php echo esc_attr( $field['model_property'] ); ?>"<?php endif; ?> <?php if ( ! AdiNet_Resource_Catalog::field_visible( $field, $setting_values ) ) : ?>hidden<?php endif; ?>><?php echo esc_html( $field['label'] ); ?>
						<?php if ( 'select' === $field['type'] ) : ?>
						<select id="resource-<?php echo esc_attr( $provider_key . '-' . $key ); ?>" name="settings[<?php echo esc_attr( $provider_key ); ?>][<?php echo esc_attr( $key ); ?>]" data-setting-key="<?php echo esc_attr( $key ); ?>" <?php disabled( ! $visible ); ?>>
							<?php if ( ! array_key_exists( $setting_values[ $key ], $field['choices'] ) ) : ?><option value="<?php echo esc_attr( $setting_values[ $key ] ); ?>" selected><?php echo esc_html( $setting_values[ $key ] . ' (' . __( 'zapisana wartość', 'adinet-panel' ) . ')' ); ?></option><?php endif; ?>
							<?php foreach ( $field['choices'] as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $setting_values[ $key ], (string) $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?>
						</select>
						<?php elseif ( 'text' === $field['type'] ) : ?>
						<input id="resource-<?php echo esc_attr( $provider_key . '-' . $key ); ?>" name="settings[<?php echo esc_attr( $provider_key ); ?>][<?php echo esc_attr( $key ); ?>]" data-setting-key="<?php echo esc_attr( $key ); ?>" type="text" maxlength="<?php echo esc_attr( $field['maxlength'] ); ?>" value="<?php echo esc_attr( $setting_values[ $key ] ); ?>" <?php disabled( ! $visible ); ?> <?php if ( ! empty( $field['required'] ) ) : ?>required<?php endif; ?> <?php if ( isset( $field['pattern'] ) ) : ?>pattern="<?php echo esc_attr( $field['pattern'] ); ?>"<?php endif; ?>>
						<?php else : ?>
						<input id="resource-<?php echo esc_attr( $provider_key . '-' . $key ); ?>" name="settings[<?php echo esc_attr( $provider_key ); ?>][<?php echo esc_attr( $key ); ?>]" data-setting-key="<?php echo esc_attr( $key ); ?>" type="number" min="<?php echo esc_attr( $field['min'] ); ?>" max="<?php echo esc_attr( $field['max'] ); ?>" step="<?php echo esc_attr( $field['step'] ); ?>" value="<?php echo esc_attr( $setting_values[ $key ] ); ?>" <?php disabled( ! $visible ); ?> <?php if ( '' !== $field['default'] ) : ?>required<?php endif; ?>>
						<small><?php echo esc_html( sprintf( __( 'Zakres: %1$s–%2$s · krok: %3$s', 'adinet-panel' ), $field['min'], $field['max'], $field['step'] ) ); ?></small>
						<?php endif; ?>
					</label>
					<?php endforeach; ?>
				</div>
			</fieldset>
			<?php endforeach; ?>
			<fieldset data-icon-usage <?php if ( 'icons' !== $form_category ) : ?>hidden<?php endif; ?>>
				<legend><?php esc_html_e( 'Kolor i użycie ikon', 'adinet-panel' ); ?></legend>
				<p class="adinet-help"><?php esc_html_e( 'Icon Manager Divi nadaje ikonom kolor z modułu. Rozmiar pobieranego SVG jest niezależny od rozmiaru wyświetlania na stronie.', 'adinet-panel' ); ?></p>
				<div class="adinet-resource-fields">
					<label for="resource-export-color"><?php echo esc_html( $labels['export_color'] ); ?><input id="resource-export-color" name="export_color" maxlength="12" placeholder="#000000 lub currentColor" value="<?php echo esc_attr( self::scalar( $form, 'export_color' ) ); ?>" <?php disabled( 'icons' !== $form_category ); ?>></label>
					<label for="resource-display-color"><?php echo esc_html( $labels['display_color'] ); ?><input id="resource-display-color" name="display_color" maxlength="190" placeholder="<?php echo esc_attr__( 'Np. #f91a1a — ustawiany w module Divi', 'adinet-panel' ); ?>" value="<?php echo esc_attr( self::scalar( $form, 'display_color' ) ); ?>" <?php disabled( 'icons' !== $form_category ); ?>></label>
				</div>
			</fieldset>
			<fieldset data-generator-usage <?php if ( 'generators' !== $form_category ) : ?>hidden<?php endif; ?>>
				<legend><?php esc_html_e( 'Prompt i spójność zdjęć', 'adinet-panel' ); ?></legend>
				<p class="adinet-help"><?php esc_html_e( 'Zapisz sprawdzony prompt i wskaż, co zmieniasz przy kolejnych zdjęciach. Wymiary własne, siłę referencji oraz inne ustawienia możesz dopisać w parametrach własnych. Sam seed nie zapewnia identycznego wyniku po zmianie modelu lub jego wersji.', 'adinet-panel' ); ?></p>
				<div class="adinet-resource-fields">
					<?php foreach ( array( 'prompt' => 20000, 'negative_prompt' => 10000, 'reference_notes' => 5000 ) as $key => $limit ) : ?>
					<label class="is-wide" for="resource-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $labels[ $key ] ); ?><textarea id="resource-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" rows="<?php echo 'prompt' === $key ? '5' : '3'; ?>" maxlength="<?php echo esc_attr( $limit ); ?>" <?php disabled( 'generators' !== $form_category ); ?>><?php echo esc_textarea( self::scalar( $form, $key ) ); ?></textarea></label>
					<?php endforeach; ?>
				</div><p class="adinet-help"><?php esc_html_e( 'Wykluczenia / negative prompt zapisuj, jeśli używasz ich w danym modelu. Link do projektu lub wyniku możesz podać w polu linku do konfiguracji, a obrazy wzorcowe w linkach do przykładów.', 'adinet-panel' ); ?></p>
			</fieldset>
			<fieldset><legend><?php esc_html_e( 'Zastosowanie i notatki', 'adinet-panel' ); ?></legend>
				<div class="adinet-resource-fields">
					<label class="is-wide" for="resource-collection"><?php echo esc_html( $labels['collection'] ); ?><input id="resource-collection" name="collection" maxlength="190" value="<?php echo esc_attr( self::scalar( $form, 'collection' ) ); ?>"></label>
					<label class="is-wide" for="resource-usage"><?php echo esc_html( $labels['usage'] ); ?><textarea id="resource-usage" name="usage" rows="2" maxlength="3000" placeholder="<?php echo esc_attr__( 'Np. karty atrakcji i sekcje oferty', 'adinet-panel' ); ?>"><?php echo esc_textarea( self::scalar( $form, 'usage' ) ); ?></textarea></label>
					<label class="is-wide" for="resource-notes"><?php echo esc_html( $labels['notes'] ); ?><textarea id="resource-notes" name="notes" rows="5" maxlength="20000" placeholder="<?php echo esc_attr__( 'Jak dobierać kolejne zasoby i jakie ustawienia zachować?', 'adinet-panel' ); ?>"><?php echo esc_textarea( self::scalar( $form, 'notes' ) ); ?></textarea></label>
				</div>
			</fieldset>
			<fieldset><legend><?php esc_html_e( 'Własne parametry', 'adinet-panel' ); ?></legend><p class="adinet-help"><?php esc_html_e( 'Dodatkowe ustawienia dowolnego serwisu, np. format zdjęć, nazwa fontu lub wariant eksportu. Maksymalnie 20.', 'adinet-panel' ); ?></p>
				<div data-custom-parameters>
				<?php
				$custom = $form['custom_parameters'] ?? array();
				if ( isset( $form['custom_keys'], $form['custom_values'] ) && is_array( $form['custom_keys'] ) && is_array( $form['custom_values'] ) ) {
					$custom = array();
					foreach ( array_slice( array_values( $form['custom_keys'] ), 0, 20 ) as $index => $key ) {
						$custom[] = array( 'label' => is_string( $key ) ? $key : '', 'value' => self::scalar( array_values( $form['custom_values'] ), $index ) );
					}
				}
				if ( empty( $custom ) ) { $custom = array( array( 'label' => '', 'value' => '' ) ); }
				foreach ( $custom as $parameter ) : ?>
					<div class="adinet-resource-parameter"><label><?php esc_html_e( 'Nazwa parametru', 'adinet-panel' ); ?><input name="custom_keys[]" maxlength="100" value="<?php echo esc_attr( $parameter['label'] ); ?>"></label><label><?php esc_html_e( 'Wartość', 'adinet-panel' ); ?><input name="custom_values[]" maxlength="500" value="<?php echo esc_attr( $parameter['value'] ); ?>"></label><button type="button" class="button" data-remove-parameter><?php esc_html_e( 'Usuń parametr', 'adinet-panel' ); ?></button></div>
				<?php endforeach; ?>
				</div>
				<button type="button" class="button" data-add-parameter><?php esc_html_e( 'Dodaj parametr', 'adinet-panel' ); ?></button>
			</fieldset>
			<fieldset><legend><?php esc_html_e( 'Wzorce i zrzut ustawień', 'adinet-panel' ); ?></legend>
				<label for="resource-examples"><?php esc_html_e( 'Linki do przykładów — po jednym w wierszu, maksymalnie 10', 'adinet-panel' ); ?><textarea id="resource-examples" name="examples" rows="3" maxlength="20000"><?php echo esc_textarea( self::scalar( $form, 'examples' ) ); ?></textarea></label>
				<input type="hidden" name="reference_id" value="<?php echo esc_attr( self::scalar( $form, 'reference_id', '0' ) ); ?>" id="resource-reference-id">
				<div class="adinet-resource-reference" data-reference-preview><?php $reference = wp_get_attachment_image_url( absint( self::scalar( $form, 'reference_id', '0' ) ), 'medium' ); ?><?php if ( $reference ) : ?><img src="<?php echo esc_url( $reference ); ?>" alt="<?php echo esc_attr__( 'Zrzut ustawień zasobu', 'adinet-panel' ); ?>"><?php endif; ?></div>
				<div class="adinet-monitor-table__actions"><button type="button" class="button" data-select-reference><?php esc_html_e( 'Wybierz zrzut z mediów', 'adinet-panel' ); ?></button><button type="button" class="button" data-remove-reference><?php esc_html_e( 'Odłącz zrzut', 'adinet-panel' ); ?></button></div>
			</fieldset>
			<div class="adinet-resource-form-actions"><button type="submit" class="button button-primary"><?php esc_html_e( 'Zapisz profil zasobu', 'adinet-panel' ); ?></button><a class="button" href="<?php echo esc_url( self::page_url() ); ?>"><?php esc_html_e( 'Anuluj', 'adinet-panel' ); ?></a><span data-resource-save-status role="status"><?php esc_html_e( 'Brak nowych zmian', 'adinet-panel' ); ?></span></div>
		</form>
	</section>
	<?php endif; ?>

	<section aria-labelledby="resource-list-title">
		<div class="adinet-section-heading"><div><p class="adinet-eyebrow"><?php esc_html_e( 'Zapisane ustalenia', 'adinet-panel' ); ?></p><h2 id="resource-list-title"><?php esc_html_e( 'Używane na tej stronie', 'adinet-panel' ); ?></h2></div><a href="#resource-catalog"><?php esc_html_e( 'Przejdź do katalogu zasobów', 'adinet-panel' ); ?></a></div>
		<?php if ( empty( $items ) ) : ?>
		<div class="adinet-card adinet-resource-empty"><h3><?php esc_html_e( 'Zapisz pierwszy zasób projektu', 'adinet-panel' ); ?></h3><p><?php esc_html_e( 'Wybierz bibliotekę poniżej i zapisz styl oraz parametry. Możesz też dodać własny serwis do zdjęć, fontów lub innych zastosowań.', 'adinet-panel' ); ?></p><a class="button" href="#resource-catalog"><?php esc_html_e( 'Przeglądaj biblioteki ikon', 'adinet-panel' ); ?></a></div>
		<?php else : ?>
		<div class="adinet-resource-filters"><label for="resource-search"><?php esc_html_e( 'Szukaj w zasobach i notatkach', 'adinet-panel' ); ?><input id="resource-search" type="search" placeholder="<?php echo esc_attr__( 'Nazwa, serwis, ustawienie…', 'adinet-panel' ); ?>"></label><label for="resource-filter-category"><?php esc_html_e( 'Kategoria', 'adinet-panel' ); ?><select id="resource-filter-category"><option value=""><?php esc_html_e( 'Wszystkie kategorie', 'adinet-panel' ); ?></option><?php foreach ( $categories as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label><span data-resource-count role="status"><?php echo esc_html( sprintf( __( 'Liczba profili: %d', 'adinet-panel' ), count( $items ) ) ); ?></span></div>
		<div class="adinet-resource-list">
		<?php foreach ( $items as $resource ) : ?>
			<?php $data = $resource['details']; ?>
			<article class="adinet-card adinet-resource-profile" data-resource-category="<?php echo esc_attr( $resource['category'] ); ?>">
				<div class="adinet-resource-card-heading"><div><p class="adinet-eyebrow"><?php echo esc_html( $categories[ $resource['category'] ] ?? $resource['category'] ); ?></p><h3><?php echo esc_html( $resource['title'] ); ?></h3><p><?php echo esc_html( $data['service_name'] ?? '' ); ?></p></div><span class="adinet-status <?php echo 'primary' === $resource['role'] ? 'is-good' : 'is-neutral'; ?>"><?php echo esc_html( 'primary' === $resource['role'] ? __( 'Główny', 'adinet-panel' ) : __( 'Uzupełniający', 'adinet-panel' ) ); ?></span></div>
				<dl class="adinet-resource-values">
				<?php foreach ( array_merge( array_filter( array_map( static function ( $key ) use ( $data, $labels ) { return ! empty( $data[ $key ] ) ? array( 'label' => $labels[ $key ], 'value' => $data[ $key ] ) : null; }, array( 'family', 'author', 'export_color', 'display_color', 'collection' ) ) ), $data['parameters'] ?? array(), $data['custom_parameters'] ?? array() ) as $parameter ) : ?><div><dt><?php echo esc_html( $parameter['label'] ); ?></dt><dd><?php echo esc_html( $parameter['value'] ); ?></dd></div><?php endforeach; ?>
				</dl>
				<?php foreach ( array( 'usage', 'notes' ) as $key ) : ?><?php if ( ! empty( $data[ $key ] ) ) : ?><div class="adinet-resource-note"><strong><?php echo esc_html( $labels[ $key ] ); ?></strong><p><?php echo esc_html( $data[ $key ] ); ?></p></div><?php endif; ?><?php endforeach; ?>
				<?php foreach ( array( 'prompt', 'negative_prompt', 'reference_notes' ) as $key ) : ?><?php if ( ! empty( $data[ $key ] ) ) : ?><details class="adinet-resource-prompt"><summary><?php echo esc_html( $labels[ $key ] ); ?></summary><pre><?php echo esc_html( $data[ $key ] ); ?></pre><?php if ( 'prompt' === $key ) : ?><button type="button" class="button adinet-copy-button" data-copy="<?php echo esc_attr( $data[ $key ] ); ?>" data-default-label="<?php echo esc_attr__( 'Kopiuj prompt', 'adinet-panel' ); ?>"><?php esc_html_e( 'Kopiuj prompt', 'adinet-panel' ); ?></button><?php endif; ?></details><?php endif; ?><?php endforeach; ?>
				<?php if ( ! empty( $data['examples'] ) || ! empty( $data['reference_id'] ) ) : ?><details class="adinet-resource-examples"><summary><?php esc_html_e( 'Wzorce i zrzut ustawień', 'adinet-panel' ); ?></summary><?php foreach ( $data['examples'] ?? array() as $index => $url ) : ?><p><a target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( sprintf( __( 'Wzorzec %d', 'adinet-panel' ), $index + 1 ) . ' — ' . $url ); ?></a></p><?php endforeach; ?><?php $image = wp_get_attachment_image_url( $data['reference_id'] ?? 0, 'large' ); ?><?php if ( $image ) : ?><a href="<?php echo esc_url( $image ); ?>" target="_blank" rel="noopener noreferrer"><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr__( 'Zrzut ustawień zasobu', 'adinet-panel' ); ?>" loading="lazy"></a><?php endif; ?></details><?php endif; ?>
				<p class="adinet-help"><?php echo esc_html( sprintf( __( 'Zaktualizowano: %1$s · %2$s', 'adinet-panel' ), get_date_from_gmt( $resource['updated_at'], 'd.m.Y H:i' ), $resource['updated_by'] ) ); ?></p>
				<div class="adinet-monitor-table__actions">
					<a class="button" href="<?php echo esc_url( $data['service_url'] ?? '' ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Otwórz serwis', 'adinet-panel' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
					<?php if ( ! empty( $data['source_url'] ) ) : ?><a class="button" href="<?php echo esc_url( $data['source_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( 'generators' === $resource['category'] ? __( 'Projekt / konfiguracja', 'adinet-panel' ) : __( 'Rodzina / paczka', 'adinet-panel' ) ); ?></a><?php endif; ?>
					<button type="button" class="button adinet-copy-button" data-copy="<?php echo esc_attr( self::copy_text( $resource ) ); ?>" data-default-label="<?php echo esc_attr__( 'Kopiuj ustawienia', 'adinet-panel' ); ?>"><?php esc_html_e( 'Kopiuj ustawienia', 'adinet-panel' ); ?></button>
					<?php if ( $can_manage ) : ?><a class="button" href="<?php echo esc_url( self::page_url( array( 'edit' => $resource['id'] ) ) ); ?>"><?php esc_html_e( 'Edytuj', 'adinet-panel' ); ?></a><form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" data-confirm-form="<?php echo esc_attr__( 'Trwale usunąć ten profil zasobu wraz z notatkami?', 'adinet-panel' ); ?>"><input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>"><input type="hidden" name="operation" value="delete"><input type="hidden" name="resource_id" value="<?php echo esc_attr( $resource['id'] ); ?>"><input type="hidden" name="revision" value="<?php echo esc_attr( $resource['revision'] ); ?>"><?php wp_nonce_field( self::ACTION ); ?><button type="submit" class="button button-link-delete"><?php esc_html_e( 'Usuń', 'adinet-panel' ); ?></button></form><?php endif; ?>
				</div>
			</article>
		<?php endforeach; ?>
		</div><p data-resource-no-results hidden><?php esc_html_e( 'Brak zasobów pasujących do wyszukiwania.', 'adinet-panel' ); ?></p>
		<?php endif; ?>
	</section>
	<section id="resource-catalog" aria-labelledby="resource-catalog-title">
		<div class="adinet-section-heading"><div><p class="adinet-eyebrow"><?php esc_html_e( 'Poznaj dostępne źródła', 'adinet-panel' ); ?></p><h2 id="resource-catalog-title"><?php esc_html_e( 'Katalog zasobów', 'adinet-panel' ); ?></h2></div></div>
		<p class="adinet-help"><?php esc_html_e( 'Przejrzyj serwis, a wybrane ustawienia zapisz w profilu tej witryny. Możesz korzystać również z własnych źródeł.', 'adinet-panel' ); ?></p>
		<?php foreach ( array( 'icons' => __( 'Biblioteki ikon', 'adinet-panel' ), 'generators' => __( 'Generatory zdjęć i grafik', 'adinet-panel' ) ) as $catalog_category => $catalog_title ) : ?>
		<h3 class="adinet-resource-catalog-heading"><?php echo esc_html( $catalog_title ); ?></h3>
		<div class="adinet-resource-catalog">
		<?php foreach ( $providers as $key => $provider ) : ?>
			<?php if ( AdiNet_Resource_Catalog::provider_category( $provider ) !== $catalog_category ) { continue; } ?>
			<article class="adinet-card"><h3><?php echo esc_html( $provider['name'] ); ?></h3><span class="adinet-resource-access"><?php echo esc_html( $provider['access'] ); ?></span><p><?php echo esc_html( $provider['description'] ); ?></p><div class="adinet-monitor-table__actions"><a class="button" href="<?php echo esc_url( $provider['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( 'icons' === $catalog_category ? __( 'Przeglądaj ikony', 'adinet-panel' ) : __( 'Otwórz generator', 'adinet-panel' ) ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a><?php if ( $can_manage ) : ?><a class="button" href="<?php echo esc_url( self::page_url( array( 'edit' => 'new', 'provider' => $key ) ) ); ?>"><?php esc_html_e( 'Dodaj profil', 'adinet-panel' ); ?></a><?php endif; ?></div></article>
		<?php endforeach; ?>
		</div>
		<?php endforeach; ?>
	</section>
	<span class="screen-reader-text" id="adinet-copy-status" role="status" aria-live="polite"></span>
</div>
