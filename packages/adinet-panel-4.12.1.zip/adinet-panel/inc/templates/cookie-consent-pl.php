<?php
/**
 * Polskie teksty do pól Divi Pixel Cookie Consent.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'Banner' => array(
		'Title'       => 'Szanujemy Twoją prywatność',
		'Description' => 'Korzystamy z niezbędnych plików cookies, aby zapewnić prawidłowe działanie strony. Opcjonalne pliki cookies wykorzystujemy wyłącznie za Twoją zgodą. Możesz zaakceptować wszystkie, odrzucić opcjonalne lub dostosować swoje preferencje. Swoją decyzję możesz zmienić w dowolnym momencie.',
	),
	'Preference Center' => array(
		'Title'           => 'Ustawienia prywatności',
		'Description'     => "Pliki cookies pomagają zapewnić prawidłowe działanie strony oraz obsługiwać dodatkowe funkcje.\n\nNiezbędne pliki cookies są wykorzystywane do podstawowego funkcjonowania witryny i nie wymagają Twojej zgody.\n\nPozostałe pliki cookies, jeśli są używane na tej stronie, mogą służyć do obsługi dodatkowych funkcji, analizy ruchu lub działań marketingowych. Korzystamy z nich wyłącznie za Twoją zgodą.\n\nPoniżej możesz sprawdzić szczegóły poszczególnych kategorii i zdecydować, na które z nich wyrażasz zgodę. Niektóre opcjonalne funkcje mogą być niedostępne, jeśli odmówisz.",
		'Show more label' => 'Pokaż więcej',
		'Show less label' => 'Pokaż mniej',
	),
	'Buttons' => array(
		'Accept button'    => 'Akceptuj wszystkie',
		'Reject button'    => 'Odrzuć opcjonalne',
		'Customize button' => 'Dostosuj',
		'Save button'      => 'Zapisz preferencje',
	),
	'Policy Links' => array(
		'Privacy policy label' => 'Polityka prywatności',
		'Cookie policy label'  => 'Pliki cookies',
	),
	'Categories' => array(
		'Essential name'          => 'Niezbędne',
		'Essential description'   => 'Te pliki cookies są konieczne do prawidłowego i bezpiecznego działania strony. Umożliwiają korzystanie z podstawowych funkcji oraz zapamiętanie wybranych ustawień prywatności. Nie wymagają zgody i nie można ich wyłączyć za pomocą tego panelu.',
		'Functional name'         => 'Funkcjonalne',
		'Functional description'  => 'Umożliwiają korzystanie z dodatkowych funkcji strony oraz zapamiętywanie wybranych preferencji użytkownika. Ich wyłączenie może ograniczyć działanie niektórych funkcjonalności.',
		'Analytics name'          => 'Analityczne',
		'Analytics description'   => 'Pomagają zrozumieć, w jaki sposób odwiedzający korzystają ze strony, np. które podstrony są najczęściej odwiedzane. Zebrane informacje służą analizie ruchu i ulepszaniu witryny.',
		'Marketing name'          => 'Marketingowe',
		'Marketing description'   => 'Służą do pomiaru skuteczności działań reklamowych, a w przypadku korzystania z odpowiednich usług również do personalizacji reklam. Mogą być wykorzystywane przez zewnętrznych dostawców usług marketingowych.',
	),
	'Cookie Table Labels' => array(
		'Cookie column'      => 'Plik cookie',
		'Duration column'    => 'Okres przechowywania',
		'Description column' => 'Opis',
	),
);
