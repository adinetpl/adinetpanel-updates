<?php
/** Public image-model settings snapshot, read from Magnific on 2026-11-17. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
return json_decode( <<<'ADINET_MAGNIFIC_CATALOG'
{
  "checked_at": "2026-11-17",
  "models": {
    "auto": {
      "name": "Auto",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "2:3",
        "3:4",
        "1:2",
        "2:1",
        "4:5",
        "3:2",
        "4:3"
      ],
      "resolutions": [
        "1k",
        "2k",
        "4k"
      ],
      "customSize": {
        "maxAspectRatio": 16
      },
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "cinematic": {
      "name": "Cinematic",
      "aspectRatios": [
        "1:1",
        "21:9",
        "16:9",
        "9:16",
        "4:3",
        "4:5",
        "5:4",
        "3:4",
        "3:2",
        "2:3"
      ],
      "resolutions": [
        "1k",
        "2k",
        "4k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "character",
        "product",
        "image"
      ]
    },
    "classic": {
      "name": "Classic",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "fast": {
      "name": "Classic Fast",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "flux-dev": {
      "name": "Flux.1",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product"
      ]
    },
    "flux": {
      "name": "Flux.1 Fast",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "flux-kontext-high": {
      "name": "Flux.1 Kontext Max",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "2:3",
        "3:4",
        "1:2",
        "2:1",
        "4:5",
        "3:2",
        "4:3"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "flux-kontext": {
      "name": "Flux.1 Kontext Pro",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "2:3",
        "3:4",
        "1:2",
        "2:1",
        "4:5",
        "3:2",
        "4:3"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "flux-realism": {
      "name": "Flux.1 Realism",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": false
    },
    "flux-pro-plus": {
      "name": "Flux.1.1",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "flux-2-flex": {
      "name": "Flux.2 Flex",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "resolutions": [
        "1k",
        "2k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "flux-2-klein": {
      "name": "Flux.2 Klein",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "resolutions": [
        "1k",
        "2k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "flux-2-max": {
      "name": "Flux.2 Max",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "resolutions": [
        "1k",
        "2k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "flux-2": {
      "name": "Flux.2 Pro",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "resolutions": [
        "1k",
        "2k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "flux-3-image": {
      "name": "Flux.3 Image",
      "aspectRatios": [
        "auto",
        "21:9",
        "2:1",
        "16:9",
        "3:2",
        "7:5",
        "4:3",
        "5:4",
        "1:1",
        "4:5",
        "3:4",
        "5:7",
        "2:3",
        "9:16",
        "1:2",
        "9:21"
      ],
      "resolutions": [
        "768p",
        "1k",
        "1.5k",
        "2k",
        "4k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "gpt-2": {
      "name": "GPT 2",
      "aspectRatios": [
        "auto",
        "1:1",
        "2:1",
        "3:1",
        "2:3",
        "3:2",
        "3:4",
        "4:3",
        "16:9",
        "9:16",
        "21:9"
      ],
      "resolutions": [
        "1k",
        "2k",
        "4k"
      ],
      "qualities": [
        "low",
        "medium",
        "high"
      ],
      "transparentBackground": true,
      "customSize": {
        "maxAspectRatio": 8
      },
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "gpt-2-mini": {
      "name": "GPT 2.5",
      "aspectRatios": [
        "auto",
        "1:1",
        "2:1",
        "3:1",
        "2:3",
        "3:2",
        "3:4",
        "4:3",
        "16:9",
        "9:16",
        "21:9"
      ],
      "resolutions": [
        "1k",
        "2k",
        "4k"
      ],
      "qualities": [
        "low",
        "medium",
        "high",
        "xhigh",
        "max"
      ],
      "variants": [
        "flare",
        "sunburst"
      ],
      "transparentBackground": true,
      "customSize": {
        "maxAspectRatio": 8
      },
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ],
      "replacedBy": "gpt-2-6"
    },
    "gpt-2-6": {
      "name": "GPT 2.6",
      "aspectRatios": [
        "auto",
        "1:1",
        "2:1",
        "3:1",
        "2:3",
        "3:2",
        "3:4",
        "4:3",
        "16:9",
        "9:16",
        "21:9"
      ],
      "resolutions": [
        "1k",
        "2k",
        "4k"
      ],
      "qualities": [
        "low",
        "medium",
        "high",
        "xhigh",
        "max"
      ],
      "variants": [
        "flare",
        "sunburst"
      ],
      "thinkingLevels": [
        "low",
        "medium",
        "high"
      ],
      "transparentBackground": true,
      "customSize": {
        "maxAspectRatio": 8
      },
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "imagen-nano-banana": {
      "name": "Google Nano Banana",
      "aspectRatios": [
        "auto",
        "1:1",
        "21:9",
        "16:9",
        "9:16",
        "4:3",
        "4:5",
        "5:4",
        "3:4",
        "3:2",
        "2:3"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ],
      "replacedBy": "imagen-nano-banana-2-1"
    },
    "imagen-nano-banana-2-flash": {
      "name": "Google Nano Banana 2",
      "aspectRatios": [
        "auto",
        "1:1",
        "21:9",
        "8:1",
        "4:1",
        "16:9",
        "9:16",
        "1:4",
        "1:8",
        "4:3",
        "4:5",
        "5:4",
        "3:4",
        "3:2",
        "2:3"
      ],
      "resolutions": [
        "1k",
        "2k",
        "4k"
      ],
      "thinkingLevels": [
        "minimal",
        "high"
      ],
      "customSize": {
        "maxAspectRatio": 8
      },
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "imagen-nano-banana-2-lite": {
      "name": "Google Nano Banana 2 Lite",
      "aspectRatios": [
        "1:1",
        "2:3",
        "3:2",
        "4:3",
        "3:4",
        "5:4",
        "4:5",
        "16:9",
        "9:16",
        "21:9"
      ],
      "thinkingLevels": [
        "minimal",
        "high"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "imagen-nano-banana-2-1": {
      "name": "Google Nano Banana 2.1",
      "aspectRatios": [
        "auto",
        "1:1",
        "21:9",
        "8:1",
        "4:1",
        "16:9",
        "9:16",
        "1:4",
        "1:8",
        "4:3",
        "4:5",
        "5:4",
        "3:4",
        "3:2",
        "2:3"
      ],
      "resolutions": [
        "1k",
        "2k",
        "4k"
      ],
      "customSize": {
        "maxAspectRatio": 8
      },
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "imagen-nano-banana-2": {
      "name": "Google Nano Banana Pro",
      "aspectRatios": [
        "auto",
        "1:1",
        "21:9",
        "16:9",
        "9:16",
        "4:3",
        "4:5",
        "5:4",
        "3:4",
        "3:2",
        "2:3"
      ],
      "resolutions": [
        "1k",
        "2k",
        "4k"
      ],
      "customSize": {
        "maxAspectRatio": 8
      },
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "grok": {
      "name": "Grok",
      "aspectRatios": [
        "auto",
        "1:1",
        "16:9",
        "9:16",
        "2:3",
        "3:4",
        "1:2",
        "2:1",
        "3:2",
        "4:3"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "grok-imagine-2": {
      "name": "Grok Imagine 2.0",
      "aspectRatios": [
        "auto",
        "1:1",
        "16:9",
        "9:16",
        "2:3",
        "3:4",
        "1:2",
        "2:1",
        "3:2",
        "4:3"
      ],
      "qualities": [
        "low",
        "medium"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "ideogram": {
      "name": "Ideogram",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character"
      ]
    },
    "ideogram-4": {
      "name": "Ideogram 4",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "10:16",
        "16:10",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "4:5",
        "5:4",
        "2:1",
        "1:2",
        "3:1",
        "1:3"
      ],
      "qualities": [
        "turbo",
        "mid",
        "high"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "ideogram-4-5": {
      "name": "Ideogram 4.5",
      "aspectRatios": [
        "1:1",
        "4:5",
        "5:4",
        "3:4",
        "4:3",
        "2:3",
        "3:2",
        "9:16",
        "16:9",
        "1:2",
        "2:1",
        "1:3",
        "3:1"
      ],
      "qualities": [
        "very_low",
        "low",
        "medium",
        "high"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "ideogram-vector": {
      "name": "Ideogram Vector",
      "aspectRatios": [
        "auto",
        "1:1",
        "1:4",
        "1:3",
        "1:2",
        "9:16",
        "10:16",
        "2:3",
        "3:4",
        "4:5",
        "5:4",
        "4:3",
        "3:2",
        "16:10",
        "16:9",
        "2:1",
        "3:1",
        "4:1"
      ],
      "qualities": [
        "low",
        "medium",
        "high"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "image"
      ]
    },
    "krea-2": {
      "name": "Krea 2",
      "aspectRatios": [
        "1:1",
        "4:3",
        "3:2",
        "16:9",
        "2.35:1",
        "4:5",
        "2:3",
        "9:16"
      ],
      "qualities": [
        "medium",
        "high"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "image"
      ]
    },
    "krea-3": {
      "name": "Krea 3",
      "aspectRatios": [
        "1:1",
        "4:3",
        "3:2",
        "16:9",
        "2.35:1",
        "4:5",
        "2:3",
        "9:16"
      ],
      "resolutions": [
        "1k",
        "2k"
      ],
      "qualities": [
        "high",
        "turbo"
      ],
      "thinkingLevels": [
        "low",
        "medium"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "image"
      ]
    },
    "luma-uni-1": {
      "name": "Luma Uni-1.1",
      "aspectRatios": [
        "1:1",
        "1:2",
        "1:3",
        "2:1",
        "2:3",
        "3:1",
        "3:2",
        "9:16",
        "16:9"
      ],
      "qualities": [
        "mid",
        "max"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "mai-image-2-5": {
      "name": "MAI Image 2.5",
      "aspectRatios": [
        "auto",
        "1:1",
        "4:3",
        "3:4",
        "16:9",
        "9:16",
        "3:2",
        "2:3"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "image",
        "character",
        "product",
        "locations"
      ]
    },
    "mystic": {
      "name": "Mystic 1.0",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "2:3",
        "3:4",
        "1:2",
        "2:1",
        "4:5",
        "3:2",
        "4:3"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product"
      ]
    },
    "mystic-2-5": {
      "name": "Mystic 2.5",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "2:3",
        "3:4",
        "1:2",
        "2:1",
        "4:5",
        "3:2",
        "4:3"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product"
      ]
    },
    "mystic-2-5-flexible": {
      "name": "Mystic 2.5 Flexible",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "2:3",
        "3:4",
        "1:2",
        "2:1",
        "4:5",
        "3:2",
        "4:3"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "mystic-2-5-fluid": {
      "name": "Mystic 2.5 Fluid",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "3:4"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "p-image-ideogram": {
      "name": "P-Image Ideogram",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "16:10",
        "10:16",
        "5:4",
        "4:5",
        "2:1",
        "1:2"
      ],
      "resolutions": [
        "1k",
        "2k"
      ],
      "qualities": [
        "very-low",
        "low",
        "medium",
        "high"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "qwen": {
      "name": "Qwen",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "qwen-image-3-0": {
      "name": "Qwen Image 3.0",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "qwen-image-3-0-pro": {
      "name": "Qwen Image 3.0 Pro",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "resolutions": [
        "1k",
        "2k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "recraft-v4": {
      "name": "Recraft V4",
      "aspectRatios": [
        "1:1",
        "2:1",
        "1:2",
        "3:2",
        "2:3",
        "4:3",
        "3:4",
        "5:4",
        "4:5",
        "16:9",
        "9:16"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "recraft-v4-pro": {
      "name": "Recraft V4 Pro",
      "aspectRatios": [
        "1:1",
        "2:1",
        "1:2",
        "3:2",
        "2:3",
        "4:3",
        "3:4",
        "5:4",
        "4:5",
        "16:9",
        "9:16"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "recraft-v4-1": {
      "name": "Recraft V4.1",
      "aspectRatios": [
        "1:1",
        "2:1",
        "1:2",
        "3:2",
        "2:3",
        "4:3",
        "3:4",
        "5:4",
        "4:5",
        "16:9",
        "9:16"
      ],
      "variants": [
        "standard",
        "utility"
      ],
      "tiers": [
        "mid",
        "pro"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    },
    "runway-gen4": {
      "name": "Runway",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "seedream-4": {
      "name": "Seedream 4",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5",
        "21:9"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ],
      "replacedBy": "seedream-5-5"
    },
    "seedream-4-4k": {
      "name": "Seedream 4 4K",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5",
        "21:9"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ],
      "replacedBy": "seedream-5-5"
    },
    "seedream-4-5": {
      "name": "Seedream 4.5",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5",
        "21:9"
      ],
      "resolutions": [
        "2k",
        "4k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ],
      "replacedBy": "seedream-5-5"
    },
    "seedream-5-flash": {
      "name": "Seedream 5 Flash",
      "aspectRatios": [
        "1:1",
        "4:3",
        "3:4",
        "16:9",
        "9:16",
        "3:2",
        "2:3",
        "21:9"
      ],
      "resolutions": [
        "1.5k",
        "2k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ],
      "replacedBy": "seedream-5-5"
    },
    "seedream-5-lite": {
      "name": "Seedream 5 Lite",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5",
        "21:9"
      ],
      "resolutions": [
        "2k",
        "3k",
        "4k"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ],
      "replacedBy": "seedream-5-5"
    },
    "seedream-5-pro": {
      "name": "Seedream 5 Pro",
      "aspectRatios": [
        "1:1",
        "4:3",
        "3:4",
        "16:9",
        "9:16",
        "3:2",
        "2:3",
        "21:9"
      ],
      "resolutions": [
        "1.5k",
        "2k"
      ],
      "thinkingLevels": [
        "minimal",
        "high"
      ],
      "customSize": {
        "maxAspectRatio": 16
      },
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ],
      "replacedBy": "seedream-5-5"
    },
    "seedream-5-5": {
      "name": "Seedream 5.5",
      "aspectRatios": [
        "1:1",
        "4:3",
        "3:4",
        "16:9",
        "9:16",
        "3:2",
        "2:3",
        "21:9"
      ],
      "resolutions": [
        "1k",
        "1.5k",
        "2k"
      ],
      "transparentBackground": true,
      "customSize": {
        "maxAspectRatio": 16
      },
      "supportsReferences": true,
      "referenceTypes": [
        "style",
        "character",
        "product",
        "image"
      ]
    },
    "z-image": {
      "name": "Z-Image",
      "aspectRatios": [
        "1:1",
        "16:9",
        "9:16",
        "4:3",
        "3:4",
        "3:2",
        "2:3",
        "1:2",
        "2:1",
        "4:5"
      ],
      "supportsReferences": true,
      "referenceTypes": [
        "style"
      ]
    }
  },
  "cinematic": {
    "camera": [
      "arri-alexa-35",
      "sony-venice",
      "red-v-raptor",
      "imax-70mm",
      "pixelvision",
      "vhs-camcorder",
      "8mm-film",
      "35mm-film",
      "medium-format",
      "Auto",
      "arri-alexa-mini-lf",
      "sony-venice-2",
      "blackmagic-ursa-mini-pro",
      "canon-c500-mark-ii",
      "sony-fx9"
    ],
    "lensBrand": [
      "panavision-g",
      "zeiss-master",
      "cooke-s4",
      "cooke-panchro",
      "arri-signature",
      "canon-k35",
      "leica-summilux",
      "zeiss-distagon",
      "contax-g",
      "hasselblad-planar",
      "pentax-67",
      "mamiya-sekor",
      "Auto",
      "cooke-s4-35mm",
      "zeiss-master-prime-50mm",
      "leica-summilux-c-75mm",
      "cooke-anamorphic-i-40mm",
      "hawk-v-lite-65mm-anamorphic",
      "angenieux-optimo-25-250mm"
    ],
    "focalLength": [
      "14mm",
      "24mm",
      "35mm",
      "50mm",
      "85mm",
      "135mm",
      "200mm",
      "Auto"
    ],
    "aperture": [
      "f/1.2",
      "f/1.4",
      "f/2",
      "f/2.8",
      "f/4",
      "f/5.6",
      "f/8",
      "f/11",
      "f/16",
      "Auto"
    ],
    "shotType": [
      "extreme-close-front",
      "extreme-close-45",
      "extreme-close-profile",
      "close-up-front",
      "close-up-45",
      "close-up-profile",
      "medium-front",
      "medium-45",
      "medium-profile",
      "three-quarter-front",
      "three-quarter-45-right",
      "three-quarter-profile",
      "long-front",
      "long-profile",
      "wide-front",
      "wide-45-right",
      "over-shoulder",
      "back",
      "pov",
      "high-angle",
      "low-angle",
      "dutch-angle",
      "birds-eye",
      "worms-eye"
    ],
    "filmStock": [
      "cinestill-800t",
      "kodak-portra-400",
      "kodak-portra-800",
      "kodak-gold-200",
      "kodak-ektar-100",
      "kodak-tri-x-400",
      "kodak-tmax-400",
      "kodak-vision3-500t",
      "kodak-vision3-250d",
      "fuji-pro-400h",
      "fuji-superia-400",
      "fuji-velvia-50",
      "fuji-provia-100f",
      "ilford-delta-3200",
      "lomography-800",
      "agfa-vista-400",
      "ektachrome-e100",
      "polaroid-600"
    ],
    "movieLook": [
      "blade-runner",
      "dune",
      "interstellar",
      "matrix",
      "her",
      "ex-machina",
      "tron-legacy",
      "arrival",
      "amelie",
      "grand-budapest",
      "eternal-sunshine",
      "call-me-by-your-name",
      "mad-max-fury-road",
      "sicario",
      "se7en",
      "collateral",
      "1917",
      "schindlers-list",
      "the-revenant",
      "gladiator",
      "midsommar",
      "lady-bird",
      "parasite",
      "pride-and-prejudice",
      "the-favourite",
      "phantom-thread",
      "documentary-natural",
      "tarantino-style",
      "kubrick-style",
      "spielberg-style"
    ],
    "lighting": [
      "golden-hour",
      "rembrandt",
      "butterfly",
      "loop",
      "split",
      "broad",
      "short",
      "high-key",
      "low-key",
      "rim",
      "backlight",
      "three-point",
      "natural-window",
      "overcast",
      "hard-sunlight",
      "blue-hour",
      "neon",
      "chiaroscuro",
      "candle",
      "moonlight",
      "stage",
      "volumetric",
      "dappled",
      "studio-soft",
      "beauty-dish",
      "parabolic",
      "practical",
      "silhouette",
      "contre-jour",
      "bounce",
      "overhead"
    ],
    "motionBlur": [
      "none",
      "subtle-cinematic",
      "moderate-cinematic",
      "heavy-cinematic",
      "subject-motion-blur-only",
      "camera-motion-blur-only",
      "rack-focus-pull-blur",
      "zoom-blur",
      "long-exposure-light-trails"
    ],
    "grain": [
      "35mm-silver-halide",
      "16mm-coarse",
      "fine-organic-sensor-noise",
      "barely-visible-shadow-grain"
    ],
    "halation": [
      "none",
      "warm-orange-red-halo",
      "strong-warm-bloom",
      "green-yellow-fringe"
    ],
    "tonalLook": [
      "kodak-vision3-500t",
      "fujifilm-eterna-500",
      "kodak-portra-400",
      "kodak-double-x",
      "arri-alexa-natural",
      "sony-venice-natural"
    ]
  }
}
ADINET_MAGNIFIC_CATALOG
, true );
