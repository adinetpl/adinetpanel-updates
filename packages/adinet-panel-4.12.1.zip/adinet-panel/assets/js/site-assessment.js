( function () {
	'use strict';

	const form = document.getElementById( 'adinet-assessment-form' );
	const criteria = Array.from( form.querySelectorAll( '[data-criterion]' ) );
	const ranges = Array.from( form.querySelectorAll( '[data-recommendation]' ) );
	const total = form.querySelector( '[data-total]' );
	const interpretation = form.querySelector( '[data-interpretation]' );
	const securityAlert = document.getElementById( 'adinet-assessment-security' );

	function getPoints( criterion ) {
		const select = criterion.querySelector( '[data-score-select]' );
		if ( select ) {
			const points = select.selectedOptions[ 0 ].dataset.points;
			const output = criterion.querySelector( '[data-points-output]' );
			output.textContent = points === undefined ? '—' : form.dataset.pointLabel.replace( '%d', points );
			return points;
		}

		const fixed = criterion.querySelector( '[data-fixed-score]' );
		return fixed ? fixed.dataset.fixedScore : criterion.querySelector( 'input[type=radio]:checked' )?.value;
	}

	function updateScore() {
		const scores = criteria.map( getPoints );
		const complete = scores.every( ( score ) => score !== undefined && score !== '' );
		const sum = scores.reduce( ( result, score ) => result + Number( score || 0 ), 0 );
		const range = ranges.find( ( item ) => sum <= Number( item.dataset.maximum ) );
		total.textContent = sum;
		interpretation.textContent = complete ? range.querySelector( 'span' ).textContent : interpretation.dataset.partial;
		ranges.forEach( ( item ) => item.classList.toggle( 'is-current', complete && item === range ) );
		securityAlert.hidden = form.querySelector( '[data-criterion=security] input[value="2"]' ).checked === false;
	}

	form.addEventListener( 'change', updateScore );
	updateScore();

	const panel = form.closest( '.adinet-assessment' );
	const revisions = panel.querySelectorAll( 'input[name=revision]' );
	const autosaveStatus = document.getElementById( 'adinet-assessment-autosave' );
	const draftStatus = document.getElementById( 'adinet-assessment-draft-status' );
	let revision = form.elements.revision.value;
	let saved = snapshot();
	let pending = null;
	let timer = 0;
	let leaving = false;
	let conflict = false;

	function snapshot() {
		const data = new URLSearchParams( new FormData( form ) );
		data.delete( 'revision' );
		return data.toString();
	}

	function saveDraft() {
		if ( pending ) {
			return pending;
		}
		const current = snapshot();
		if ( current === saved || leaving || conflict ) {
			return Promise.resolve( current === saved );
		}

		const data = new URLSearchParams( current );
		data.set( 'revision', revision );
		data.set( 'operation', 'autosave' );
		autosaveStatus.textContent = autosaveStatus.dataset.saving;
		autosaveStatus.classList.remove( 'is-error' );
		pending = fetch( form.getAttribute( 'action' ), { method: 'POST', body: data } ).then( async ( response ) => {
			conflict = response.status === 409;
			const result = response.ok ? await response.json() : null;
			if ( ! result?.success || ! result.data.revision ) {
				throw new Error( 'Draft save failed.' );
			}
			saved = current;
			revision = result.data.revision;
			revisions.forEach( ( field ) => { field.value = revision; } );
			draftStatus.hidden = false;
			autosaveStatus.textContent = autosaveStatus.dataset.saved;
			return true;
		} ).catch( () => {
			autosaveStatus.textContent = conflict ? autosaveStatus.dataset.conflict : autosaveStatus.dataset.error;
			autosaveStatus.classList.add( 'is-error' );
			return false;
		} ).finally( () => { pending = null; } );
		return pending;
	}

	async function flushDraft() {
		window.clearTimeout( timer );
		while ( pending || snapshot() !== saved ) {
			if ( ! await saveDraft() ) {
				return false;
			}
		}
		return true;
	}

	function scheduleSave( event ) {
		window.clearTimeout( timer );
		timer = window.setTimeout( flushDraft, event.type === 'change' ? 0 : 500 );
	}

	form.addEventListener( 'input', scheduleSave );
	form.addEventListener( 'change', scheduleSave );
	panel.addEventListener( 'submit', async ( event ) => {
		window.clearTimeout( timer );
		if ( conflict ) {
			event.preventDefault();
			autosaveStatus.focus();
			return;
		}
		const editor = event.target === form;
		if ( ! pending && ( editor || snapshot() === saved ) ) {
			leaving = true;
			return;
		}

		event.preventDefault();
		if ( await ( editor ? pending : flushDraft() ) ) {
			event.target.requestSubmit( event.submitter );
		} else {
			autosaveStatus.focus();
		}
	} );
	document.addEventListener( 'click', async ( event ) => {
		const link = event.target.closest( 'a[href]' );
		if ( event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ||
			! link || ( link.target && link.target !== '_self' ) || link.hasAttribute( 'download' ) ||
			link.origin !== window.location.origin || link.getAttribute( 'href' ).startsWith( '#' ) || ( ! pending && snapshot() === saved ) ) {
			return;
		}

		event.preventDefault();
		if ( await flushDraft() ) {
			leaving = true;
			window.location.assign( link.href );
		} else {
			autosaveStatus.focus();
		}
	} );
	window.addEventListener( 'beforeunload', ( event ) => {
		if ( ! leaving && ( pending || snapshot() !== saved ) ) {
			event.preventDefault();
			event.returnValue = '';
		}
	} );

	const contactForm = document.getElementById( 'adinet-assessment-contact-form' );
	if ( contactForm ) {
		const sent = document.getElementById( 'adinet-assessment-sent' );
		const date = document.getElementById( 'adinet-assessment-sent-on' );
		const today = contactForm.querySelector( '[data-today]' );

		function updateDate() {
			date.disabled = ! sent.checked;
			if ( sent.checked && ! date.value ) {
				date.value = today.dataset.today;
			}
		}

		today.addEventListener( 'click', ( event ) => {
			event.preventDefault();
			sent.checked = true;
			date.value = today.dataset.today;
			updateDate();
		} );
		sent.addEventListener( 'change', updateDate );
		updateDate();
	}
}() );
