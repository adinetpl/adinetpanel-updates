<?php
/**
 * Strona opiekuna i akcje rocznej oceny serwisu.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Site_Assessment_Admin {
	const PAGE_SLUG = 'adinet-site-assessment';
	const ACTION    = 'adinet_site_assessment';

	private static $page_hook = '';

	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_action' ) );
		add_action( 'admin_notices', array( __CLASS__, 'render_security_notice' ) );
		add_filter( 'pre_update_option_' . AdiNet_Options::SITE_ASSESSMENT, array( __CLASS__, 'preserve_option' ), 10, 2 );
	}

	/** Prevents the core all-options form from bypassing the audit workflow. */
	public static function preserve_option( $value, $previous ) {
		return $previous;
	}

	public static function add_menu() {
		self::$page_hook = add_submenu_page(
			AdiNet_Admin::PAGE_SLUG,
			__( 'Audyt i ocena serwisu — AdiNet', 'adinet-panel' ),
			__( 'Audyt i ocena serwisu', 'adinet-panel' ),
			AdiNet_Admin::MANAGE_CAPABILITY,
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function enqueue_assets( $hook ) {
		if ( ! self::$page_hook || self::$page_hook !== $hook || ! AdiNet_Admin::can_manage_panel() ) {
			return;
		}

		wp_enqueue_style( 'adinet-admin', ADINET_URL . 'assets/css/admin.css', array(), ADINET_VERSION );
		wp_enqueue_style( 'adinet-site-assessment', ADINET_URL . 'assets/css/site-assessment.css', array( 'adinet-admin' ), ADINET_VERSION );
		wp_enqueue_script( 'adinet-admin', ADINET_URL . 'assets/js/admin.js', array(), ADINET_VERSION, true );
		wp_enqueue_script( 'adinet-site-assessment', ADINET_URL . 'assets/js/site-assessment.js', array(), ADINET_VERSION, true );
	}

	public static function security_alert() {
		return __( 'Pilna interwencja. Najpierw rozwiąż problem bezpieczeństwa. Rekomendację przebudowy oprzyj na niezależnych przesłankach.', 'adinet-panel' );
	}

	public static function render_security_notice() {
		if ( ! AdiNet_Admin::can_manage_panel() ) {
			return;
		}

		$screen = get_current_screen();
		if ( $screen && self::$page_hook === $screen->id ) {
			return;
		}

		$state = AdiNet_Site_Assessment::state();
		if ( 2 !== ( $state['draft']['scores']['security'] ?? null ) && 2 !== ( $state['approved']['scores']['security'] ?? null ) ) {
			return;
		}
		?>
		<div class="notice notice-error"><p>
			<?php echo esc_html( self::security_alert() ); ?>
			<a href="<?php echo esc_url( self::page_url() ); ?>"><?php esc_html_e( 'Otwórz audyt i ocenę serwisu', 'adinet-panel' ); ?></a>
		</p></div>
		<?php
	}

	private static function page_url() {
		return add_query_arg( 'page', self::PAGE_SLUG, admin_url( 'admin.php' ) );
	}

	private static function redirect( $notice ) {
		wp_safe_redirect( add_query_arg( 'adinet-assessment-notice', $notice, self::page_url() ), 303 );
		exit;
	}

	/**
	 * Chroni edycję, publikację i kontakt tym samym uprawnieniem opiekuna.
	 */
	public static function handle_action() {
		if ( ! AdiNet_Admin::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do obsługi oceny serwisu.', 'adinet-panel' ), '', array( 'response' => 403 ) );
		}

		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			wp_die( esc_html__( 'Wymagana jest metoda POST.', 'adinet-panel' ), '', array( 'response' => 405 ) );
		}

		check_admin_referer( self::ACTION );
		$operation = isset( $_POST['operation'] ) && is_string( $_POST['operation'] ) ? sanitize_key( wp_unslash( $_POST['operation'] ) ) : '';
		$revision  = isset( $_POST['revision'] ) && is_string( $_POST['revision'] ) ? sanitize_key( wp_unslash( $_POST['revision'] ) ) : '';
		$state     = AdiNet_Site_Assessment::state();
		if ( $revision !== $state['revision'] ) {
			if ( 'autosave' === $operation ) {
				wp_send_json_error( array( 'code' => 'conflict' ), 409 );
			}
			self::redirect( 'conflict' );
		}

		$next  = $state;
		$today = wp_date( 'Y-m-d' );
		switch ( $operation ) {
			case 'autosave':
			case 'draft':
			case 'approve':
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- evaluate() validates each field against its expected type.
				$input         = isset( $_POST['assessment'] ) && is_array( $_POST['assessment'] ) ? wp_unslash( $_POST['assessment'] ) : array();
				$next['draft'] = AdiNet_Site_Assessment::evaluate( $input, AdiNet_Site_Assessment::environment() );
				$notice        = 'draft-saved';
				if ( 'approve' === $operation ) {
					$error = AdiNet_Site_Assessment::approval_error( $next['draft'] );
					if ( '' === $error ) {
						$next['approved'] = AdiNet_Site_Assessment::approve( $next['draft'], AdiNet_Site_Assessment::site(), $today );
						$next['draft']    = null;
						$next['sent_on']  = '';
						$notice           = 'approved';
					} else {
						$notice = $error;
					}
				}
				break;

			case 'publish':
				if ( ! $state['approved'] ) {
					self::redirect( 'no-approval' );
				}
				$next['published'] = array(
					'audit_id' => $state['approved']['id'],
					'message'  => AdiNet_Site_Assessment::client_message( $state['approved'] ),
				);
				$notice = 'published';
				break;

			case 'hide':
				$next['published'] = null;
				$notice            = 'hidden';
				break;

			case 'contact':
			case 'contact-today':
				if ( ! $state['approved'] ) {
					self::redirect( 'no-approval' );
				}
				$sent_on = isset( $_POST['sent_on'] ) && is_string( $_POST['sent_on'] ) ? sanitize_text_field( wp_unslash( $_POST['sent_on'] ) ) : '';
				if ( 'contact-today' === $operation ) {
					$sent_on = $today;
				} elseif ( '1' !== ( $_POST['sent'] ?? '' ) ) {
					$sent_on = '';
				} elseif ( '' === $sent_on ) {
					$sent_on = $today;
				}
				if ( '' !== $sent_on && ( ! AdiNet_Site_Assessment::date( $sent_on ) || $sent_on > $today ) ) {
					self::redirect( 'contact-date' );
				}
				$next['sent_on'] = $sent_on;
				$notice          = 'contact-saved';
				break;

			default:
				wp_die( esc_html__( 'Nieznana operacja audytu.', 'adinet-panel' ), '', array( 'response' => 400 ) );
		}

		$result = AdiNet_Site_Assessment::save( $state, $next );
		if ( 'autosave' === $operation ) {
			if ( is_wp_error( $result ) ) {
				$code = $result->get_error_code();
				wp_send_json_error( array( 'code' => $code ), 'conflict' === $code ? 409 : 500 );
			}
			wp_send_json_success( array( 'revision' => $result ) );
		}
		self::redirect( is_wp_error( $result ) ? $result->get_error_code() : $notice );
	}

	private static function render_notice() {
		$code = isset( $_GET['adinet-assessment-notice'] ) && is_string( $_GET['adinet-assessment-notice'] ) ? sanitize_key( wp_unslash( $_GET['adinet-assessment-notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only an allowlisted display message.
		$successes = array(
			'draft-saved'   => __( 'Zapisano wersję roboczą.', 'adinet-panel' ),
			'approved'      => __( 'Zatwierdzono ocenę. Możesz teraz opublikować komunikat w kokpicie klienta.', 'adinet-panel' ),
			'published'     => __( 'Opublikowano komunikat w kokpicie klienta.', 'adinet-panel' ),
			'hidden'        => __( 'Ukryto komunikat w kokpicie klienta.', 'adinet-panel' ),
			'contact-saved' => __( 'Zapisano status kontaktu.', 'adinet-panel' ),
		);
		$errors = array(
			'incomplete'             => __( 'Zapisano wersję roboczą. Przed zatwierdzeniem uzupełnij oceny wszystkich kryteriów.', 'adinet-panel' ),
			'no-approval'            => __( 'Najpierw zatwierdź ocenę.', 'adinet-panel' ),
			'conflict'               => __( 'Stan audytu zmienił się w trakcie edycji. Sprawdź bieżące dane i ponów operację.', 'adinet-panel' ),
			'write-error'            => __( 'Nie udało się zapisać danych audytu. Spróbuj ponownie.', 'adinet-panel' ),
			'contact-date'           => __( 'Wybierz prawidłową datę wysłania, najpóźniej dzisiaj.', 'adinet-panel' ),
		);

		if ( isset( $successes[ $code ] ) ) {
			printf( '<div class="adinet-assessment__notice" role="status">%s</div>', esc_html( $successes[ $code ] ) );
		} elseif ( isset( $errors[ $code ] ) ) {
			printf( '<div class="adinet-assessment__notice is-error" role="alert">%s</div>', esc_html( $errors[ $code ] ) );
		}
	}

	private static function form_fields( $revision ) {
		?>
		<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( self::ACTION ) ); ?>">
		<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
		<input type="hidden" name="revision" value="<?php echo esc_attr( $revision ); ?>">
		<?php
	}

	public static function render_page() {
		if ( ! AdiNet_Admin::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do obsługi oceny serwisu.', 'adinet-panel' ), '', array( 'response' => 403 ) );
		}

		$state           = AdiNet_Site_Assessment::state();
		$environment     = AdiNet_Site_Assessment::environment();
		$today           = wp_date( 'Y-m-d' );
		$draft           = AdiNet_Site_Assessment::editor_values( $state, $environment, $today );
		$approved        = $state['approved'];
		$published       = $state['published'];
		$site            = AdiNet_Site_Assessment::site();
		$criteria        = AdiNet_Site_Assessment::criteria();
		$recommendations = AdiNet_Site_Assessment::recommendations();
		$email           = AdiNet_Site_Assessment::email( $approved );
		$action_url      = admin_url( 'admin-post.php' );
		$latest_visible  = $published && $approved && $published['audit_id'] === $approved['id'];
		$divi_label      = self::divi_label( $environment );

		require ADINET_PATH . 'inc/templates/site-assessment.php';
	}

	private static function divi_label( $environment ) {
		if ( ! $environment['divi_active'] ) {
			return __( 'Nie dotyczy', 'adinet-panel' );
		}

		return '' !== $environment['divi'] ? $environment['divi'] : __( 'Nieznana wersja', 'adinet-panel' );
	}

	private static function score_label( $score ) {
		/* translators: %d: number of points. */
		return null === $score ? '—' : sprintf( __( '%d pkt', 'adinet-panel' ), $score );
	}
}
