<?php
/**
 * Punktacja i lokalne dane rocznej oceny serwisu.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Site_Assessment {
	const MAX_SCORE = 22;

	public static function criteria() {
		return array(
			'architecture' => array(
				__( 'Architektura i technologia', 'adinet-panel' ),
				__( 'Sprawdź architekturę projektu, zgodność wtyczek, problemy z aktualizacjami, możliwość rozbudowy i przestarzałe rozwiązania. Wersje PHP i Divi oceń osobno.', 'adinet-panel' ),
			),
			'security'     => array(
				__( 'Bezpieczeństwo', 'adinet-panel' ),
				__( '0 — brak wykrytych problemów. 1 — sygnały lub usterki do sprawdzenia. 2 — potwierdzona infekcja, złośliwy kod lub poważny incydent.', 'adinet-panel' ),
			),
			'design'       => array(
				__( 'Wygląd i stylistyka', 'adinet-panel' ),
				__( '0 — współczesny, profesjonalny wygląd. 1 — częściowo przestarzała stylistyka. 2 — wygląd wyraźnie przestarzały lub niedopasowany do firmy.', 'adinet-panel' ),
			),
			'ux'           => array(
				__( 'UX i responsywność', 'adinet-panel' ),
				__( '0 — wygodna obsługa na różnych ekranach. 1 — drobne lub umiarkowane problemy. 2 — istotne utrudnienia, zwłaszcza na urządzeniach mobilnych.', 'adinet-panel' ),
			),
			'content'      => array(
				__( 'Treść i struktura', 'adinet-panel' ),
				__( '0 — logiczna struktura i aktualne treści. 1 — wybrane elementy do poprawy. 2 — poważne braki, przestarzała oferta lub chaotyczna struktura.', 'adinet-panel' ),
			),
			'seo'          => array(
				__( 'SEO i semantyka HTML', 'adinet-panel' ),
				__( 'Sprawdź hierarchię H1–H6, semantyczny HTML, opisy alternatywne obrazów, metadane, adresy canonical i podstawy technicznego SEO. Oceń Schema.org tam, gdzie ma zastosowanie.', 'adinet-panel' ),
			),
			'ai'           => array(
				__( 'Odkrywalność AI', 'adinet-panel' ),
				__( 'Sprawdź dostęp robotów do treści, blokady indeksowania, jasność opisów usług, odpowiedzi na pytania, strukturę informacji i oznaki wiarygodności firmy. FAQ i Schema.org mogą pomóc uporządkować treści. Widoczność w usługach AI zależy też od tych usług.', 'adinet-panel' ),
			),
			'performance'  => array(
				__( 'Wydajność', 'adinet-panel' ),
				__( 'Wybierz ocenę z wykonanego testu. A = 0 pkt, B–C = 1 pkt, D–F = 2 pkt.', 'adinet-panel' ),
			),
			'business'     => array(
				__( 'Potrzeby biznesowe', 'adinet-panel' ),
				__( '0 — strona odpowiada potrzebom firmy. 1 — potrzebne są wybrane usprawnienia. 2 — obecny projekt istotnie ogranicza realizację celów biznesowych.', 'adinet-panel' ),
			),
			'divi'         => array(
				__( 'Motyw Divi', 'adinet-panel' ),
				__( 'Divi 4 i starsze = 2 pkt. W Divi 5 i nowszych potwierdź, czy moduły działają w trybie zgodności (1 pkt) czy bez niego (0 pkt).', 'adinet-panel' ),
			),
			'php'          => array(
				__( 'Aktualizacja PHP', 'adinet-panel' ),
				__( 'Polityka modernizacyjna AdiNet: poniżej PHP 8.3 = 2 pkt, 8.3–8.4 = 1 pkt, od 8.5 = 0 pkt. Wsparcie bezpieczeństwa PHP ocenia się osobno.', 'adinet-panel' ),
			),
		);
	}

	public static function recommendations() {
		return array(
			'care'       => array( 6, __( 'Dobry stan — standardowa opieka', 'adinet-panel' ), __( 'Dalsza standardowa opieka', 'adinet-panel' ) ),
			'improve'    => array( 12, __( 'Zalecane usprawnienia — modernizacja wybranych elementów', 'adinet-panel' ), __( 'Modernizacja wybranych elementów', 'adinet-panel' ) ),
			'consider'   => array( 15, __( 'Warto rozważyć przebudowę', 'adinet-panel' ), __( 'Rozważenie przebudowy', 'adinet-panel' ) ),
			'rebuild'    => array( self::MAX_SCORE, __( 'Wysoki priorytet analizy przebudowy', 'adinet-panel' ), __( 'Rekomendowana gruntowna przebudowa', 'adinet-panel' ) ),
		);
	}

	public static function performance_grades() {
		return array( 'A' => 0, 'B' => 1, 'C' => 1, 'D' => 2, 'E' => 2, 'F' => 2 );
	}

	public static function compatibility_scores() {
		return array( 'yes' => 1, 'no' => 0 );
	}

	public static function date( $value ) {
		if ( ! is_string( $value ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $value ) ) {
			return null;
		}

		$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );
		return $date && $value === $date->format( 'Y-m-d' ) ? $date : null;
	}

	public static function format_date( $value ) {
		$date = self::date( $value );
		return $date ? wp_date( get_option( 'date_format' ), $date->getTimestamp() ) : '';
	}

	public static function environment() {
		$theme = wp_get_theme();
		$theme = $theme->parent() ?: $theme;
		$divi  = 'divi' === strtolower( $theme->get_stylesheet() );

		return array(
			'wordpress'   => get_bloginfo( 'version' ),
			'php'         => PHP_VERSION,
			'divi_active' => $divi,
			'divi'        => $divi ? $theme->get( 'Version' ) : '',
		);
	}

	public static function site() {
		$launch = get_option( AdiNet_Options::SITE_LAUNCH_DATE, '' );
		$launch = self::date( $launch ) ? $launch : '';

		return array(
			'launch' => $launch,
			'age'    => '' !== $launch && $launch <= wp_date( 'Y-m-d' ) ? AdiNet_Billing::get_site_age( $launch ) : '',
		);
	}

	/**
	 * Przygotowuje dane formularza i wylicza punktację po stronie serwera.
	 * Brak oceny jest zapisywany jako null, także jeśli nie wybrano wyniku testu.
	 */
	public static function evaluate( $input, $environment ) {
		$grades          = self::performance_grades();
		$compatibility   = self::compatibility_scores();
		$performance     = self::text( $input, 'performance_grade' );
		$performance_day = self::text( $input, 'performance_date' );
		$divi_mode       = self::text( $input, 'divi_compatibility' );
		$divi_needs_mode = self::needs_compatibility( $environment );
		if ( ! $divi_needs_mode || self::text( $input, 'divi_version' ) !== $environment['divi'] ) {
			$divi_mode = '';
		}

		$manual = isset( $input['scores'] ) && is_array( $input['scores'] ) ? $input['scores'] : array();
		$notes  = isset( $input['notes'] ) && is_array( $input['notes'] ) ? $input['notes'] : array();
		$scores = array();
		$notes_by_criterion = array();
		foreach ( self::criteria() as $key => $criterion ) {
			$score = $manual[ $key ] ?? '';
			$scores[ $key ] = in_array( $score, array( '0', '1', '2', 0, 1, 2 ), true ) ? (int) $score : null;
			$notes_by_criterion[ $key ] = self::text( $notes, $key, true );
		}
		$scores['performance'] = $grades[ $performance ] ?? null;
		$scores['divi']        = self::divi_score( $environment, $compatibility[ $divi_mode ] ?? null );
		$scores['php']         = self::php_score( $environment['php'] );
		$total                 = array_sum( $scores );
		$suggested             = self::suggest( $total );

		$choice = self::text( $input, 'recommendation' );
		if ( ! isset( self::recommendations()[ $choice ] ) ) {
			$choice = '';
		}

		return array(
			'scores'             => $scores,
			'notes'              => $notes_by_criterion,
			'performance_grade'  => isset( $grades[ $performance ] ) ? $performance : '',
			'performance_source' => self::text( $input, 'performance_source' ),
			'performance_date'   => self::date( $performance_day ) ? $performance_day : '',
			'divi_compatibility' => isset( $compatibility[ $divi_mode ] ) ? $divi_mode : '',
			'divi_version'       => $environment['divi'],
			'environment'        => $environment,
			'total'              => $total,
			'suggested'          => $suggested,
			'recommendation'     => $choice,
			'override_reason'    => self::text( $input, 'override_reason', true ),
			'client_reason'      => self::text( $input, 'client_reason', true ),
		);
	}

	private static function text( $input, $key, $multiline = false ) {
		$value = $input[ $key ] ?? '';
		if ( ! is_string( $value ) ) {
			return '';
		}

		return $multiline ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
	}

	public static function php_score( $version ) {
		if ( version_compare( $version, '8.3', '<' ) ) {
			return 2;
		}

		return version_compare( $version, '8.5', '<' ) ? 1 : 0;
	}

	public static function needs_compatibility( $environment ) {
		return $environment['divi_active'] && version_compare( $environment['divi'], '5', '>=' );
	}

	public static function divi_score( $environment, $mode_score ) {
		if ( ! $environment['divi_active'] ) {
			return 0;
		}

		if ( '' === $environment['divi'] ) {
			return null;
		}

		return self::needs_compatibility( $environment ) ? $mode_score : 2;
	}

	public static function suggest( $total ) {
		foreach ( self::recommendations() as $key => $range ) {
			if ( $total <= $range[0] ) {
				return $key;
			}
		}

		return 'rebuild';
	}

	public static function selected_recommendation( $assessment ) {
		return '' !== $assessment['recommendation'] ? $assessment['recommendation'] : $assessment['suggested'];
	}

	public static function is_rebuild( $recommendation ) {
		return in_array( $recommendation, array( 'consider', 'rebuild' ), true );
	}

	public static function approval_error( $assessment ) {
		if ( in_array( null, $assessment['scores'], true ) ) {
			return 'incomplete';
		}

		$recommendation = self::selected_recommendation( $assessment );
		if ( $recommendation !== $assessment['suggested'] && '' === $assessment['override_reason'] ) {
			return 'override-required';
		}

		if ( self::is_rebuild( $recommendation ) && '' === $assessment['client_reason'] ) {
			return 'client-reason-required';
		}

		return '';
	}

	public static function approve( $assessment, $site, $today ) {
		$assessment['id']   = wp_generate_uuid4();
		$assessment['date'] = $today;
		$assessment['site'] = $site;
		$assessment['recommendation'] = self::selected_recommendation( $assessment );
		$assessment['client_message']  = self::client_message( $assessment );
		return $assessment;
	}

	private static function client_message( $assessment ) {
		$recommendation = $assessment['recommendation'];
		$message = array(
			'date'           => $assessment['date'],
			'status'         => __( 'Dobry stan', 'adinet-panel' ),
			'body'           => __( 'Twoja strona internetowa jest w dobrym stanie. Ostatni audyt nie wykazał potrzeby jej gruntownej przebudowy. Zalecamy dalszą regularną opiekę i aktualizacje.', 'adinet-panel' ),
			'recommendation' => '',
		);

		if ( 'improve' === $recommendation ) {
			$message['status'] = __( 'Zalecane usprawnienia', 'adinet-panel' );
			$message['body']   = __( 'Podczas ostatniego audytu zidentyfikowaliśmy elementy strony, które warto zmodernizować. Nie oznacza to konieczności tworzenia nowego serwisu, ale zalecamy stopniowe wprowadzanie usprawnień.', 'adinet-panel' );
			$message['recommendation'] = self::recommendations()[ $recommendation ][2];
		}

		if ( self::is_rebuild( $recommendation ) ) {
			$message['status'] = __( 'Warto omówić przyszłość strony', 'adinet-panel' );
			$age = $assessment['site']['age'];
			/* translators: %s: age of the website, e.g. 7 lat. */
			$opening = '' !== $age ? sprintf( __( 'Twoja strona internetowa ma %s.', 'adinet-panel' ), lcfirst( $age ) ) . ' ' : '';
			$opening .= __( 'Regularnie serwisujemy i aktualizujemy Twoją stronę. Podczas ostatniego audytu zauważyliśmy ograniczenia, które mogą utrudniać jej dalszy rozwój.', 'adinet-panel' );
			$message['body'] = implode(
				"\n\n",
				array(
					$opening,
					$assessment['client_reason'],
					__( 'Dlatego warto rozważyć stworzenie nowej wersji strony, lepiej dostosowanej do współczesnych technologii i potrzeb Twojej firmy.', 'adinet-panel' ),
					__( 'Jeśli chcesz omówić możliwości przebudowy, skontaktuj się z opiekunem AdiNet.', 'adinet-panel' ),
				)
			);
			$message['recommendation'] = self::recommendations()[ $recommendation ][2];
		}

		return $message;
	}

	public static function email( $assessment ) {
		if ( ! $assessment || ! self::is_rebuild( $assessment['recommendation'] ) || '' === $assessment['client_reason'] ) {
			return null;
		}

		$age        = $assessment['site']['age'];
		$paragraphs = array(
			__( 'Dzień dobry,', 'adinet-panel' ),
			__( 'Strona internetowa jest trochę jak samochód. Regularnie ją serwisujemy i aktualizujemy, żeby jak najdłużej dobrze spełniała swoje zadanie. Przychodzi jednak moment, kiedy warto zastanowić się nad zmianą na nowszy model.', 'adinet-panel' ),
		);
		if ( '' !== $age ) {
			/* translators: %s: age of the website, e.g. 7 lat. */
			$paragraphs[] = sprintf( __( 'Państwa strona internetowa ma %s. Sposób korzystania z internetu zmienia się wraz z rozwojem urządzeń mobilnych, wyszukiwarek takich jak Google i narzędzi opartych na sztucznej inteligencji.', 'adinet-panel' ), lcfirst( $age ) );
		}
		$paragraphs[] = __( 'Podczas ostatniego audytu zwróciłem szczególną uwagę na następujące kwestie:', 'adinet-panel' );
		$paragraphs[] = $assessment['client_reason'];
		$paragraphs[] = 'rebuild' === $assessment['recommendation']
			? __( 'Na tej podstawie rekomenduję rozmowę o stworzeniu nowej strony, dopasowanej do współczesnych technologii i potrzeb klientów.', 'adinet-panel' )
			: __( 'Dlatego uważam, że warto rozważyć zbudowanie nowej strony, uwzględniającej współczesne technologie i potrzeby klientów.', 'adinet-panel' );
		$paragraphs[] = __( 'Chętnie przedstawię, jak mogłaby wyglądać nowa witryna i jakie konkretne korzyści mogłaby przynieść Państwa firmie.', 'adinet-panel' );
		$paragraphs[] = __( 'Jeżeli temat jest interesujący, zapraszam do kontaktu.', 'adinet-panel' );
		$paragraphs[] = __( 'Pozdrawiam,', 'adinet-panel' ) . "\nHubert Rosiński\nAdiNet";

		return array(
			'subject' => __( 'Czy warto pomyśleć o nowej stronie WWW?', 'adinet-panel' ),
			'body'    => implode( "\n\n", $paragraphs ),
		);
	}

	public static function state() {
		return get_option(
			AdiNet_Options::SITE_ASSESSMENT,
			array(
				'revision'  => '',
				'draft'     => null,
				'approved'  => null,
				'published' => null,
				'sent_on'   => '',
			)
		);
	}

	public static function public_message() {
		return self::state()['published']['message'] ?? null;
	}

	/**
	 * Atomowy zapis jednej opcji. Warunek na poprzednią wartość chroni m.in.
	 * publikację i datę kontaktu przed równoczesnym zatwierdzeniem innego audytu.
	 */
	public static function save( $previous, $next ) {
		global $wpdb;

		$next['revision'] = wp_generate_uuid4();
		$option = AdiNet_Options::SITE_ASSESSMENT;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The Options API has no conditional write.
		if ( '' === $previous['revision'] ) {
			$changed = $wpdb->query(
				$wpdb->prepare(
					"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
					$option,
					maybe_serialize( $next )
				)
			);
			wp_cache_delete( 'notoptions', 'options' );
		} else {
			$changed = $wpdb->update(
				$wpdb->options,
				array( 'option_value' => maybe_serialize( $next ) ),
				array( 'option_name' => $option, 'option_value' => maybe_serialize( $previous ) )
			);
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		wp_cache_delete( $option, 'options' );

		return 1 === $changed ? '' : ( false === $changed ? 'write-error' : 'conflict' );
	}
}
