( function () {
	'use strict';

	const form = document.getElementById( 'adinet-assessment-form' );
	const criteria = Array.from( form.querySelectorAll( '[data-criterion]' ) );
	const ranges = Array.from( form.querySelectorAll( '[data-recommendation]' ) );
	const total = form.querySelector( '[data-total]' );
	const interpretation = form.querySelector( '[data-interpretation]' );
	const securityAlert = document.getElementById( 'adinet-assessment-security' );
	const recommendation = document.getElementById( 'adinet-assessment-recommendation' );
	const overrideReason = document.getElementById( 'adinet-assessment-override-reason' );
	const clientReason = document.getElementById( 'adinet-assessment-client-reason' );

	function getPoints( criterion ) {
		const select = criterion.querySelector( '[data-score-select]' );
		if ( select ) {
			const points = select.selectedOptions[ 0 ].dataset.points;
			const output = criterion.querySelector( '[data-points-output]' );
			output.textContent = points === undefined ? '—' : form.dataset.pointLabel.replace( '%d', points );
			return points;
		}

		const fixed = criterion.querySelector( '[data-fixed-score]' );
		return fixed ? fixed.dataset.fixedScore : criterion.querySelector( 'input[type=radio]:checked' )?.value;
	}

	function updateScore() {
		const scores = criteria.map( getPoints );
		const complete = scores.every( ( score ) => score !== undefined && score !== '' );
		const sum = scores.reduce( ( result, score ) => result + Number( score || 0 ), 0 );
		const range = ranges.find( ( item ) => sum <= Number( item.dataset.maximum ) );
		const selection = recommendation.value || range.dataset.recommendation;

		total.textContent = sum;
		interpretation.textContent = complete ? range.querySelector( 'span' ).textContent : interpretation.dataset.partial;
		ranges.forEach( ( item ) => item.classList.toggle( 'is-current', complete && item === range ) );
		securityAlert.hidden = form.querySelector( '[data-criterion=security] input[value="2"]' ).checked === false;
		overrideReason.setAttribute( 'aria-required', String( complete && selection !== range.dataset.recommendation ) );
		clientReason.setAttribute( 'aria-required', String( ( complete || recommendation.value !== '' ) && [ 'consider', 'rebuild' ].includes( selection ) ) );
	}

	form.addEventListener( 'change', updateScore );
	updateScore();

	const contactForm = document.getElementById( 'adinet-assessment-contact-form' );
	if ( contactForm ) {
		const sent = document.getElementById( 'adinet-assessment-sent' );
		const date = document.getElementById( 'adinet-assessment-sent-on' );
		const today = contactForm.querySelector( '[data-today]' );

		function updateDate() {
			date.disabled = ! sent.checked;
			if ( sent.checked && ! date.value ) {
				date.value = today.dataset.today;
			}
		}

		today.addEventListener( 'click', ( event ) => {
			event.preventDefault();
			sent.checked = true;
			date.value = today.dataset.today;
			updateDate();
		} );
		sent.addEventListener( 'change', updateDate );
		updateDate();
	}
}() );
