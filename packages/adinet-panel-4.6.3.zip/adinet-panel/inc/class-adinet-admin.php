<?php
/**
 * Panel administracyjny AdiNet.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Admin {
	const PAGE_SLUG      = 'adinet';
	const SETTINGS_GROUP = 'adinet_settings';
	const UPDATE_CHANNEL_GROUP = 'adinet_update_channel_settings';
	const MANAGE_CAPABILITY = 'adinet_manage_panel';
	const DEFAULT_OWNER_LOGIN = 'adinet';

	/**
	 * Rejestruje hooki panelu administracyjnego.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu_page' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'add_admin_bar_link' ), 80 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_adinet_delete_note', array( __CLASS__, 'delete_note' ) );
		add_filter( 'map_meta_cap', array( __CLASS__, 'map_manage_capability' ), 10, 4 );
		add_filter( 'option_page_capability_' . self::SETTINGS_GROUP, array( __CLASS__, 'filter_settings_capability' ) );
		add_filter( 'option_page_capability_' . self::UPDATE_CHANNEL_GROUP, array( __CLASS__, 'filter_settings_capability' ) );
	}

	/**
	 * Zwraca login właściciela panelu. Stała w wp-config.php pozwala zmienić
	 * właściciela na pojedynczej instalacji bez modyfikowania wtyczki.
	 *
	 * @return string
	 */
	public static function get_owner_login() {
		$owner_login = defined( 'ADINET_PANEL_OWNER_LOGIN' ) ? ADINET_PANEL_OWNER_LOGIN : self::DEFAULT_OWNER_LOGIN;

		return is_string( $owner_login ) ? sanitize_user( $owner_login, true ) : self::DEFAULT_OWNER_LOGIN;
	}

	/**
	 * Sprawdza, czy bieżący użytkownik może oglądać panel.
	 *
	 * @return bool
	 */
	public static function can_view_panel() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Sprawdza, czy bieżący użytkownik może zmieniać dane panelu.
	 *
	 * @return bool
	 */
	public static function can_manage_panel() {
		return current_user_can( self::MANAGE_CAPABILITY );
	}

	/**
	 * Mapuje wewnętrzne uprawnienie zapisu wyłącznie na konto właściciela.
	 *
	 * @param string[] $caps    Wymagane uprawnienia.
	 * @param string   $cap     Sprawdzane uprawnienie.
	 * @param int      $user_id Identyfikator użytkownika.
	 * @param mixed[]  $args    Dodatkowe argumenty sprawdzenia.
	 * @return string[]
	 */
	public static function map_manage_capability( $caps, $cap, $user_id, $args ) {
		unset( $args );

		if ( self::MANAGE_CAPABILITY !== $cap ) {
			return $caps;
		}

		$user = get_userdata( $user_id );

		if ( $user && self::get_owner_login() === $user->user_login && user_can( $user, 'manage_options' ) ) {
			return array( 'manage_options' );
		}

		return array( 'do_not_allow' );
	}

	/**
	 * Wymusza uprawnienie właściciela również dla options.php.
	 *
	 * @return string
	 */
	public static function filter_settings_capability() {
		return self::MANAGE_CAPABILITY;
	}

	/**
	 * Dodaje główną pozycję „AdiNet” do menu WordPressa.
	 *
	 * @return void
	 */
	public static function add_menu_page() {
		$hook_suffix = add_menu_page(
			esc_html__( 'AdiNet — panel administracyjny', 'adinet-panel' ),
			esc_html__( 'AdiNet', 'adinet-panel' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' ),
			'dashicons-admin-tools',
			81
		);

		add_action( 'load-' . $hook_suffix, array( __CLASS__, 'suppress_external_admin_notices' ) );
	}

	/**
	 * Dodaje skrót do panelu na pasku narzędzi administratora.
	 *
	 * @param WP_Admin_Bar $admin_bar Pasek narzędzi WordPressa.
	 * @return void
	 */
	public static function add_admin_bar_link( $admin_bar ) {
		if ( ! self::can_view_panel() ) {
			return;
		}

		$admin_bar->add_node(
			array(
				'id'    => 'adinet-panel',
				'title' => esc_html__( 'AdiNet Panel', 'adinet-panel' ),
				'href'  => admin_url( 'admin.php?page=' . self::PAGE_SLUG ),
			)
		);
	}

	/**
	 * Ukrywa globalne komunikaty WordPressa i innych wtyczek na stronie AdiNet.
	 * Komunikaty generowane bezpośrednio przez panel pozostają widoczne.
	 *
	 * @return void
	 */
	public static function suppress_external_admin_notices() {
		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
	}

	/**
	 * Rejestruje ustawienia używane przez panel.
	 *
	 * @return void
	 */
	public static function register_settings() {
		register_setting(
			self::UPDATE_CHANNEL_GROUP,
			AdiNet_Options::UPDATE_CHANNEL,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_update_channel' ),
				'default'           => 'stable',
			)
		);
		add_action( 'update_option_' . AdiNet_Options::UPDATE_CHANNEL, array( 'AdiNet_Updater', 'clear_update_cache' ) );
		add_action( 'add_option_' . AdiNet_Options::UPDATE_CHANNEL, array( 'AdiNet_Updater', 'clear_update_cache' ) );

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::UPDATE_EMAIL_MODE,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_update_email_mode' ),
				'default'           => AdiNet_Options::EMAIL_MODE_FAILURES,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::ADMIN_NOTE,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_admin_note' ),
				'default'           => '',
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::DISABLE_WP_CRON,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_boolean' ),
				'default'           => 0,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::DISABLE_COMMENTS,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_boolean' ),
				'default'           => 0,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::MONITOR_404_ENABLED,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'AdiNet_404_Monitor', 'sanitize_enabled' ),
				'default'           => 0,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::ADMIN_LOG_ENABLED,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'AdiNet_Admin_Log', 'sanitize_enabled' ),
				'default'           => 0,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::DISALLOW_FILE_EDIT,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_boolean' ),
				'default'           => 0,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::LOGIN_URL_ENABLED,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_login_url_enabled' ),
				'default'           => 0,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::LOGIN_SLUG,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_login_slug' ),
				'default'           => AdiNet_Options::DEFAULT_LOGIN_SLUG,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::DEBUG_DISPLAY_MODE,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'AdiNet_Debug_Control', 'sanitize_display' ),
				'default'           => AdiNet_Options::DEBUG_MODE_INHERIT,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::DEBUG_LOG_MODE,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'AdiNet_Debug_Control', 'sanitize_log' ),
				'default'           => AdiNet_Options::DEBUG_MODE_INHERIT,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::REVISION_LIMIT,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_revision_limit' ),
				'default'           => AdiNet_Options::DEFAULT_REVISION_LIMIT,
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::REVISION_MAX_AGE,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_revision_max_age' ),
				'default'           => AdiNet_Options::DEFAULT_REVISION_MAX_AGE,
			)
		);
	}

	/**
	 * Ładuje panelowe CSS i JS wyłącznie na stronie AdiNet.
	 *
	 * @param string $hook_suffix Identyfikator ekranu administracyjnego.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'toplevel_page_' . self::PAGE_SLUG !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'adinet-admin',
			ADINET_URL . 'assets/css/admin.css',
			array(),
			ADINET_VERSION
		);

		wp_enqueue_script(
			'adinet-admin',
			ADINET_URL . 'assets/js/admin.js',
			array(),
			ADINET_VERSION,
			true
		);
	}

	/**
	 * Usuwa notatkę po potwierdzeniu operacji przez administratora.
	 *
	 * @return void
	 */
	public static function delete_note() {
		if ( ! self::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do usunięcia tej notatki.', 'adinet-panel' ) );
		}

		check_admin_referer( 'adinet_delete_note' );
		delete_option( AdiNet_Options::ADMIN_NOTE );

		$redirect_url = add_query_arg(
			array(
				'page'                => self::PAGE_SLUG,
				'adinet-note-deleted' => '1',
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $redirect_url );
		exit;
	}

	/**
	 * Zwraca dane prezentacyjne wybranego trybu e-maili.
	 *
	 * @param string $mode Identyfikator trybu.
	 * @return array{label:string,class:string}
	 */
	private static function get_email_mode_presentation( $mode ) {
		$presentations = array(
			AdiNet_Options::EMAIL_MODE_ALL => array(
				'label' => __( 'Wszystkie powiadomienia', 'adinet-panel' ),
				'class' => 'is-neutral',
			),
			AdiNet_Options::EMAIL_MODE_FAILURES => array(
				'label' => __( 'Tylko błędy i alerty krytyczne', 'adinet-panel' ),
				'class' => 'is-recommended',
			),
			AdiNet_Options::EMAIL_MODE_NONE => array(
				'label' => __( 'Wszystkie wyciszone', 'adinet-panel' ),
				'class' => 'is-muted',
			),
		);

		return isset( $presentations[ $mode ] )
			? $presentations[ $mode ]
			: $presentations[ AdiNet_Options::EMAIL_MODE_FAILURES ];
	}

	/**
	 * Zwraca odmienioną jednostkę czasu dla liczby.
	 *
	 * @param int    $number Liczba.
	 * @param string $unit   Jednostka: year albo month.
	 * @return string
	 */
	private static function format_polish_time_unit( $number, $unit ) {
		$number    = absint( $number );
		$last_two  = $number % 100;
		$last_one  = $number % 10;
		$is_few    = $last_one >= 2 && $last_one <= 4 && ( $last_two < 12 || $last_two > 14 );

		if ( 'year' === $unit ) {
			$word = 1 === $number ? __( 'rok', 'adinet-panel' ) : ( $is_few ? __( 'lata', 'adinet-panel' ) : __( 'lat', 'adinet-panel' ) );
		} else {
			$word = 1 === $number ? __( 'miesiąc', 'adinet-panel' ) : ( $is_few ? __( 'miesiące', 'adinet-panel' ) : __( 'miesięcy', 'adinet-panel' ) );
		}

		return number_format_i18n( $number ) . ' ' . $word;
	}

	/**
	 * Oblicza czytelny wiek strony na podstawie zapisanej daty publikacji.
	 *
	 * @param string $date_string Data YYYY-MM-DD.
	 * @return string
	 */
	private static function get_site_age( $date_string ) {
		if ( '' === $date_string ) {
			return '';
		}

		$launch = DateTimeImmutable::createFromFormat( '!Y-m-d', $date_string, wp_timezone() );
		$now    = new DateTimeImmutable( 'now', wp_timezone() );

		if ( false === $launch ) {
			return '';
		}

		if ( $launch > $now ) {
			return __( 'Data publikacji jest w przyszłości.', 'adinet-panel' );
		}

		$difference = $launch->diff( $now );

		if ( 0 === $difference->y && 0 === $difference->m ) {
			return __( 'Mniej niż miesiąc', 'adinet-panel' );
		}

		$parts = array();

		if ( $difference->y > 0 ) {
			$parts[] = self::format_polish_time_unit( $difference->y, 'year' );
		}

		if ( $difference->m > 0 ) {
			$parts[] = self::format_polish_time_unit( $difference->m, 'month' );
		}

		return implode( ' i ', $parts );
	}

	/**
	 * Zwraca lokalną nazwę miesiąca.
	 *
	 * @param int $month Numer miesiąca 1–12.
	 * @return string
	 */
	private static function get_month_name( $month ) {
		global $wp_locale;

		$month = absint( $month );

		if ( $month < 1 || $month > 12 || ! isset( $wp_locale ) ) {
			return '';
		}

		return (string) $wp_locale->get_month( zeroise( $month, 2 ) );
	}

	/**
	 * Zwraca treść komunikatu po osobnej akcji administracyjnej.
	 *
	 * @param string $code Kod komunikatu.
	 * @return array{class:string,message:string}|null
	 */
	private static function get_action_notice( $code ) {
		$notices = array(
			'audit-marked' => array(
				'class'   => 'notice-success',
				'message' => __( 'Dzisiejsza data została zapisana jako termin ostatniego audytu.', 'adinet-panel' ),
			),
			'audit-cleared' => array(
				'class'   => 'notice-success',
				'message' => __( 'Data ostatniego audytu została usunięta.', 'adinet-panel' ),
			),
			'htaccess-saved' => array(
				'class'   => 'notice-success',
				'message' => __( 'Zarządzany blok AdiNet w pliku .htaccess został zapisany.', 'adinet-panel' ),
			),
			'htaccess-error' => array(
				'class'   => 'notice-error',
				'message' => __( 'Nie udało się zapisać pliku .htaccess. Poprzedni wybór reguł pozostał bez zmian.', 'adinet-panel' ),
			),
			'php-log-deleted' => array(
				'class'   => 'notice-success',
				'message' => __( 'Plik logu PHP został usunięty. Jeśli logowanie nadal jest aktywne, plik może zostać utworzony ponownie.', 'adinet-panel' ),
			),
			'php-log-error' => array(
				'class'   => 'notice-error',
				'message' => __( 'Nie udało się wykonać operacji na logu PHP. Plik mógł zostać przeniesiony albo serwer odmówił dostępu.', 'adinet-panel' ),
			),
		);

		return isset( $notices[ $code ] ) ? $notices[ $code ] : null;
	}

	/**
	 * Buduje odnośnik dPanelu właściwy dla wykrytego konta.
	 *
	 * @param array $hosting Dane konta hostingowego.
	 * @return array{label:string,description:string,url:string,icon:string,recommended:bool}
	 */
	private static function get_dpanel_link( $hosting ) {
		$is_dhosting = ! empty( $hosting['account'] )
			&& isset( $hosting['provider'] )
			&& 'dhosting' === strtolower( (string) $hosting['provider'] );

		return array(
			'label'       => 'dPanel',
			'description' => $is_dhosting
				? sprintf(
					/* translators: %s: detected dhosting account name. */
					__( 'Logowanie do konta %s.', 'adinet-panel' ),
					(string) $hosting['account']
				)
				: __( 'Nie wykryto konta dhosting — otwórz stronę logowania.', 'adinet-panel' ),
			'url'         => $is_dhosting
				? 'https://dpanel.pl/kooperacja/ja/login/' . rawurlencode( (string) $hosting['account'] ) . '/'
				: 'https://dpanel.pl/',
			'icon'        => 'dashicons-dashboard',
			'recommended' => false,
		);
	}

	/**
	 * Buduje listę przydatnych narzędzi z adresami właściwymi dla bieżącej strony.
	 *
	 * @param array $hosting Dane konta hostingowego.
	 * @return array<int,array{label:string,description:string,url:string,icon:string,recommended:bool}>
	 */
	private static function get_external_links( $hosting ) {
		$dpanel_link = self::get_dpanel_link( $hosting );
		$pagespeed_url = add_query_arg(
			'url',
			home_url( '/' ),
			'https://pagespeed.web.dev/analysis'
		);
		$wave_url = add_query_arg(
			'url',
			home_url( '/' ),
			'https://wave.webaim.org/report'
		);
		$html_validator_url = add_query_arg(
			'doc',
			home_url( '/' ),
			'https://validator.w3.org/nu/'
		);
		$site_host = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$search_console_domain = is_string( $site_host )
			? preg_replace( '/^www\./i', '', $site_host )
			: '';
		$search_console_url = '' !== $search_console_domain
			? add_query_arg(
				'resource_id',
				'sc-domain:' . $search_console_domain,
				'https://search.google.com/search-console'
			)
			: 'https://search.google.com/search-console';
		$search_console_description = '' !== $search_console_domain
			? sprintf(
				/* translators: %s: current site domain. */
				__( 'Otwórz właściwość domeny %s w Search Console.', 'adinet-panel' ),
				$search_console_domain
			)
			: __( 'Indeksowanie, skuteczność i stan strony w wyszukiwarce Google.', 'adinet-panel' );

		return array(
			$dpanel_link,
			array(
				'label'       => 'dPoczta',
				'description' => __( 'Webmail dla skrzynek pocztowych.', 'adinet-panel' ),
				'url'         => 'https://dpoczta.pl',
				'icon'        => 'dashicons-email-alt',
				'recommended' => false,
			),
			array(
				'label'       => __( 'Panel domen', 'adinet-panel' ),
				'description' => __( 'Zarządzanie domenami w AdiNet.', 'adinet-panel' ),
				'url'         => 'https://domeny.adinet.pl',
				'icon'        => 'dashicons-admin-site-alt3',
				'recommended' => false,
			),
			array(
				'label'       => 'PageSpeed Insights',
				'description' => __( 'Uruchom analizę bieżącej strony.', 'adinet-panel' ),
				'url'         => $pagespeed_url,
				'icon'        => 'dashicons-performance',
				'recommended' => false,
			),
			array(
				'label'       => 'WAVE',
				'description' => __( 'Automatyczne wskazówki dostępności dla bieżącej strony.', 'adinet-panel' ),
				'url'         => $wave_url,
				'icon'        => 'dashicons-universal-access-alt',
				'recommended' => false,
			),
			array(
				'label'       => 'W3C HTML Checker',
				'description' => __( 'Sprawdź błędy i ostrzeżenia w kodzie HTML bieżącej strony.', 'adinet-panel' ),
				'url'         => $html_validator_url,
				'icon'        => 'dashicons-editor-code',
				'recommended' => false,
			),
			array(
				'label'       => 'Google Search Console',
				'description' => $search_console_description,
				'url'         => $search_console_url,
				'icon'        => 'dashicons-chart-line',
				'recommended' => false,
			),
			array(
				'label'       => 'Google Cloud Console',
				'description' => __( 'Projekty i klucze API dla Google Maps oraz reCAPTCHA.', 'adinet-panel' ),
				'url'         => 'https://console.cloud.google.com/',
				'icon'        => 'dashicons-cloud',
				'recommended' => false,
			),
			array(
				'label'       => 'Cloudflare Turnstile',
				'description' => __( 'Widżety oraz klucze Site Key i Secret Key dla Turnstile.', 'adinet-panel' ),
				'url'         => 'https://dash.cloudflare.com/144d0c87c4dafd5abc6909e8462e28b6/turnstile',
				'icon'        => 'dashicons-shield',
				'recommended' => false,
			),
			array(
				'label'       => __( 'Bezpieczna poczta', 'adinet-panel' ),
				'description' => __( 'Test SPF, DKIM, DMARC i SSL od CERT Polska.', 'adinet-panel' ),
				'url'         => 'https://bezpiecznapoczta.cert.pl',
				'icon'        => 'dashicons-shield-alt',
				'recommended' => false,
			),
			array(
				'label'       => 'Moje CERT',
				'description' => __( 'Infrastruktura i usługi organizacji.', 'adinet-panel' ),
				'url'         => 'https://moje.cert.pl/organization/',
				'icon'        => 'dashicons-building',
				'recommended' => false,
			),
		);
	}

	/**
	 * Renderuje stronę panelu.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! self::can_view_panel() ) {
			return;
		}

		$can_manage = self::can_manage_panel();

		$email_mode         = AdiNet_Options::get_update_email_mode();
		$email_presentation = self::get_email_mode_presentation( $email_mode );
		$hosting            = AdiNet_System_Info::get_hosting();
		$php_info           = AdiNet_System_Info::get_php();
		$database_info      = AdiNet_System_Info::get_database();
		$page_cache         = AdiNet_System_Info::get_page_cache();
		$object_cache       = AdiNet_System_Info::get_object_cache();
		$debug_state        = AdiNet_Debug_Control::get_state();
		$php_logs           = AdiNet_Debug_Control::get_log_files();
		$last_audit        = AdiNet_Audit::get_last_audit();
		$mark_audit_url    = AdiNet_Audit::get_action_url( 'mark' );
		$clear_audit_url   = AdiNet_Audit::get_action_url( 'clear' );
		$htaccess_status   = AdiNet_Htaccess::get_status();
		$htaccess_rules    = AdiNet_Htaccess::get_definitions();
		$selected_htaccess = AdiNet_Htaccess::get_selected_rules();
		$htaccess_count    = count( array_filter( $selected_htaccess ) );
		$cron_health        = AdiNet_Cron_Health::get_state();
		$cron_option        = AdiNet_Options::should_disable_wp_cron();
		$cron_disabled      = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
		$cron_managed       = defined( 'ADINET_CONTROLS_WP_CRON' ) && ADINET_CONTROLS_WP_CRON;
		$cron_status        = 'neutral';
		$cron_label         = __( 'Uruchamiany przez ruch', 'adinet-panel' );
		$cron_detail        = __( 'WordPress może uruchamiać zaplanowane zadania podczas wejść użytkowników na stronę.', 'adinet-panel' );
		$wp_cron_url        = site_url( '/wp-cron.php?doing_wp_cron' );
		$login_url_enabled  = AdiNet_Options::is_login_url_enabled();
		$login_slug         = AdiNet_Options::get_login_slug();
		$custom_login_url   = AdiNet_Login_URL::get_login_url();
		$comments_disabled  = AdiNet_Options::are_comments_disabled();
		$monitor_404_state  = AdiNet_404_Monitor::get_state();
		$monitor_404_url    = AdiNet_404_Monitor::get_page_url();
		$admin_log_enabled  = AdiNet_Admin_Log::is_enabled();
		$admin_log_url      = AdiNet_Admin_Log::get_page_url();
		$file_edit_option   = AdiNet_Options::should_disallow_file_edit();
		$file_edit_managed  = defined( 'ADINET_CONTROLS_FILE_EDIT' ) && ADINET_CONTROLS_FILE_EDIT;
		$file_edit_constant = defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT;
		$file_mods_constant = defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS;
		$file_edit_disabled = $file_edit_constant || $file_mods_constant;
		$file_edit_status   = 'neutral';
		$file_edit_label    = __( 'Edytory dostępne', 'adinet-panel' );
		$file_edit_detail   = __( 'Administratorzy mogą edytować kod motywów i wtyczek bezpośrednio w panelu WordPressa.', 'adinet-panel' );
		$revision_limit     = AdiNet_Options::get_revision_limit();
		$revision_max_age   = AdiNet_Options::get_revision_max_age();
		$external_links     = self::get_external_links( $hosting );
		$dpanel_link        = self::get_dpanel_link( $hosting );

		if ( $cron_disabled && $cron_managed ) {
			$cron_status = 'good';
			$cron_label  = __( 'Wyłączony przez AdiNet', 'adinet-panel' );
			$cron_detail = __( 'Automatyczne wywołania przez ruch są wyłączone. Bezpośrednie wywołanie wp-cron.php przez serwer nadal działa.', 'adinet-panel' );
		} elseif ( $cron_disabled ) {
			$cron_status = 'good';
			$cron_label  = __( 'Wyłączony w konfiguracji', 'adinet-panel' );
			$cron_detail = __( 'Stała DISABLE_WP_CRON została ustawiona poza wtyczką, najpewniej w pliku wp-config.php.', 'adinet-panel' );
		} elseif ( $cron_option && defined( 'DISABLE_WP_CRON' ) ) {
			$cron_status = 'danger';
			$cron_label  = __( 'Blokowany przez konfigurację', 'adinet-panel' );
			$cron_detail = __( 'AdiNet ma zapisane wyłączenie, ale wcześniejsza definicja DISABLE_WP_CRON ma wartość false i nie może zostać nadpisana przez wtyczkę.', 'adinet-panel' );
		}

		if ( $file_edit_managed && $file_edit_disabled ) {
			$file_edit_status = 'good';
			$file_edit_label  = __( 'Wyłączone przez AdiNet', 'adinet-panel' );
			$file_edit_detail = __( 'AdiNet definiuje DISALLOW_FILE_EDIT=true i blokuje edytory kodu motywów oraz wtyczek.', 'adinet-panel' );
		} elseif ( $file_mods_constant ) {
			$file_edit_status = 'good';
			$file_edit_label  = __( 'Wyłączone w konfiguracji', 'adinet-panel' );
			$file_edit_detail = __( 'Stała DISALLOW_FILE_MODS wyłącza edytory oraz dodatkowo blokuje instalowanie i aktualizowanie motywów i wtyczek.', 'adinet-panel' );
		} elseif ( $file_edit_constant ) {
			$file_edit_status = 'good';
			$file_edit_label  = __( 'Wyłączone w konfiguracji', 'adinet-panel' );
			$file_edit_detail = __( 'Stała DISALLOW_FILE_EDIT została ustawiona poza wtyczką, najpewniej w pliku wp-config.php.', 'adinet-panel' );
		} elseif ( $file_edit_option && defined( 'DISALLOW_FILE_EDIT' ) ) {
			$file_edit_status = 'danger';
			$file_edit_label  = __( 'Blokowane przez konfigurację', 'adinet-panel' );
			$file_edit_detail = __( 'AdiNet ma zapisane wyłączenie, ale wcześniejsza definicja DISALLOW_FILE_EDIT ma wartość false i nie może zostać nadpisana przez wtyczkę.', 'adinet-panel' );
		}
		$note               = get_option( AdiNet_Options::ADMIN_NOTE, '' );
		$note               = is_string( $note ) ? $note : '';
		$delete_note_url    = wp_nonce_url(
			add_query_arg( 'action', 'adinet_delete_note', admin_url( 'admin-post.php' ) ),
			'adinet_delete_note'
		);
		$note_deleted       = isset( $_GET['adinet-note-deleted'] )
			&& '1' === sanitize_text_field( wp_unslash( $_GET['adinet-note-deleted'] ) );
		$notice_code        = isset( $_GET['adinet-notice'] )
			? sanitize_key( wp_unslash( $_GET['adinet-notice'] ) )
			: '';
		$action_notice      = self::get_action_notice( $notice_code );
		?>
		<div class="wrap adinet-admin">
			<header class="adinet-hero">
				<div class="adinet-hero__brand">
					<img src="<?php echo esc_url( ADINET_URL . 'Logo_400_bialetlo.png' ); ?>" alt="<?php echo esc_attr__( 'AdiNet', 'adinet-panel' ); ?>">
				</div>
				<div class="adinet-hero__content">
					<p class="adinet-eyebrow"><?php esc_html_e( 'WordPress Service Panel', 'adinet-panel' ); ?></p>
					<h1><?php esc_html_e( 'AdiNet', 'adinet-panel' ); ?></h1>
					<p><?php esc_html_e( 'Funkcje administracyjne, dokumentacja i kontakt w jednym miejscu.', 'adinet-panel' ); ?></p>
				</div>
				<div class="adinet-version">
					<span><?php esc_html_e( 'Wersja', 'adinet-panel' ); ?></span>
					<strong><?php echo esc_html( ADINET_VERSION ); ?></strong>
				</div>
			</header>

			<?php settings_errors(); ?>

			<?php if ( is_array( $action_notice ) ) : ?>
				<div class="notice <?php echo esc_attr( $action_notice['class'] ); ?> is-dismissible"><p><?php echo esc_html( $action_notice['message'] ); ?></p></div>
			<?php endif; ?>

			<?php if ( $note_deleted ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Notatka została usunięta.', 'adinet-panel' ); ?></p></div>
			<?php endif; ?>

			<?php if ( ! $can_manage ) : ?>
				<div class="notice notice-info"><p><?php esc_html_e( 'Panel jest dostępny tylko do odczytu. Zmiany może wprowadzać wyłącznie konto serwisowe AdiNet.', 'adinet-panel' ); ?></p></div>
			<?php endif; ?>

			<form action="options.php" method="post" id="adinet-settings-form" class="adinet-settings-form<?php echo $can_manage ? '' : ' is-readonly'; ?>" data-adinet-readonly="<?php echo $can_manage ? '0' : '1'; ?>">
				<?php settings_fields( self::SETTINGS_GROUP ); ?>

				<div class="adinet-save-bar adinet-save-bar--top" data-adinet-order="1">
					<div>
						<strong><?php esc_html_e( 'Zapis ustawień panelu', 'adinet-panel' ); ?></strong>
						<span><?php esc_html_e( 'Ten przycisk zapisuje ten sam zestaw ustawień co przycisk na końcu formularza.', 'adinet-panel' ); ?></span>
					</div>
					<?php submit_button( __( 'Zapisz ustawienia', 'adinet-panel' ), 'primary', 'submit_top', false ); ?>
				</div>

				<div class="adinet-section-heading adinet-section-heading--functions" data-adinet-order="50">
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Funkcje wtyczki', 'adinet-panel' ); ?></p>
						<h2><?php esc_html_e( 'Narzędzia codziennej pracy', 'adinet-panel' ); ?></h2>
					</div>
					<p><?php esc_html_e( 'Funkcje działają niezależnie od aktywnego motywu i używanego kreatora stron.', 'adinet-panel' ); ?></p>
				</div>

				<div class="adinet-grid" data-adinet-order="60">
					<section class="adinet-card" aria-labelledby="adinet-year-title">
						<div class="adinet-card__topline">
							<span class="adinet-card__icon dashicons dashicons-calendar-alt" aria-hidden="true"></span>
							<span class="adinet-status is-active"><?php esc_html_e( 'Aktywna', 'adinet-panel' ); ?></span>
						</div>
						<h3 id="adinet-year-title"><?php esc_html_e( 'Automatyczny rok', 'adinet-panel' ); ?></h3>
						<p><?php esc_html_e( 'Wpisz shortcode w treści strony, wpisu albo module tekstowym dowolnego kreatora. Rok jest pobierany zgodnie ze strefą czasową ustawioną w WordPressie.', 'adinet-panel' ); ?></p>

						<div class="adinet-shortcode-feature">
							<strong class="adinet-shortcode-label"><?php esc_html_e( 'Tylko aktualny rok', 'adinet-panel' ); ?></strong>
							<div class="adinet-shortcode">
								<code id="adinet-year-shortcode">[year]</code>
								<button
									type="button"
									class="button adinet-copy-button"
									data-copy="[year]"
									data-default-label="<?php echo esc_attr__( 'Kopiuj', 'adinet-panel' ); ?>"
									data-copied-label="<?php echo esc_attr__( 'Skopiowano', 'adinet-panel' ); ?>"
									aria-describedby="adinet-copy-status"
								>
									<?php esc_html_e( 'Kopiuj', 'adinet-panel' ); ?>
								</button>
							</div>
							<p class="adinet-help"><?php esc_html_e( 'Przykład: © [year] AdiNet wyświetli bieżący rok automatycznie.', 'adinet-panel' ); ?></p>
						</div>

						<div class="adinet-shortcode-feature is-secondary">
							<strong class="adinet-shortcode-label"><?php esc_html_e( 'Gotowa stopka AdiNet', 'adinet-panel' ); ?></strong>
							<div class="adinet-shortcode">
								<code id="adinet-footer-shortcode">[adinet_footer]</code>
								<button
									type="button"
									class="button adinet-copy-button"
									data-copy="[adinet_footer]"
									data-default-label="<?php echo esc_attr__( 'Kopiuj', 'adinet-panel' ); ?>"
									data-copied-label="<?php echo esc_attr__( 'Skopiowano', 'adinet-panel' ); ?>"
									aria-describedby="adinet-copy-status"
								>
									<?php esc_html_e( 'Kopiuj', 'adinet-panel' ); ?>
								</button>
							</div>
							<p class="adinet-footer-preview">
								<?php
								echo wp_kses_post(
									AdiNet_Footer_Shortcode::render()
								);
								?>
							</p>
						</div>
						<p class="screen-reader-text" id="adinet-copy-status" aria-live="polite"></p>
					</section>

					<section class="adinet-card adinet-card--email" aria-labelledby="adinet-email-title">
						<div class="adinet-card__topline">
							<span class="adinet-card__icon dashicons dashicons-email-alt" aria-hidden="true"></span>
							<span class="adinet-status <?php echo esc_attr( $email_presentation['class'] ); ?>">
								<?php echo esc_html( $email_presentation['label'] ); ?>
							</span>
						</div>
						<h3 id="adinet-email-title"><?php esc_html_e( 'E-maile o automatycznych aktualizacjach', 'adinet-panel' ); ?></h3>
						<p><?php esc_html_e( 'Wybierz, które systemowe powiadomienia WordPressa mają trafiać do administratora.', 'adinet-panel' ); ?></p>

						<fieldset class="adinet-radio-group">
							<legend class="screen-reader-text"><?php esc_html_e( 'Tryb powiadomień o aktualizacjach', 'adinet-panel' ); ?></legend>

							<label class="adinet-radio-option">
								<input type="radio" name="<?php echo esc_attr( AdiNet_Options::UPDATE_EMAIL_MODE ); ?>" value="all" <?php checked( $email_mode, AdiNet_Options::EMAIL_MODE_ALL ); ?>>
								<span>
									<strong><?php esc_html_e( 'Wszystkie powiadomienia', 'adinet-panel' ); ?></strong>
									<small><?php esc_html_e( 'Standardowe zachowanie WordPressa: sukcesy, błędy i alerty krytyczne.', 'adinet-panel' ); ?></small>
								</span>
							</label>

							<label class="adinet-radio-option is-recommended">
								<input type="radio" name="<?php echo esc_attr( AdiNet_Options::UPDATE_EMAIL_MODE ); ?>" value="failures" <?php checked( $email_mode, AdiNet_Options::EMAIL_MODE_FAILURES ); ?>>
								<span>
									<strong><?php esc_html_e( 'Tylko błędy i alerty krytyczne', 'adinet-panel' ); ?></strong>
									<small><?php esc_html_e( 'Rekomendowane: bez wiadomości o sukcesach, ale z informacją, gdy wymagana jest reakcja.', 'adinet-panel' ); ?></small>
								</span>
								<em><?php esc_html_e( 'Polecane', 'adinet-panel' ); ?></em>
							</label>

							<label class="adinet-radio-option">
								<input type="radio" name="<?php echo esc_attr( AdiNet_Options::UPDATE_EMAIL_MODE ); ?>" value="none" <?php checked( $email_mode, AdiNet_Options::EMAIL_MODE_NONE ); ?>>
								<span>
									<strong><?php esc_html_e( 'Nie wysyłaj żadnych', 'adinet-panel' ); ?></strong>
									<small><?php esc_html_e( 'Wycisza także wiadomości o nieudanych i krytycznych aktualizacjach.', 'adinet-panel' ); ?></small>
								</span>
							</label>
						</fieldset>

						<p class="adinet-help adinet-help--warning"><?php esc_html_e( 'To ustawienie nie wyłącza samych aktualizacji — steruje wyłącznie wiadomościami e-mail generowanymi przez WordPress.', 'adinet-panel' ); ?></p>
					</section>

					<section class="adinet-card adinet-card--comments" aria-labelledby="adinet-comments-title">
						<div class="adinet-comments-layout">
							<div>
								<div class="adinet-card__topline">
									<span class="adinet-card__icon dashicons dashicons-admin-comments" aria-hidden="true"></span>
									<span class="adinet-status <?php echo $comments_disabled ? 'is-good' : 'is-neutral'; ?>">
										<?php echo $comments_disabled ? esc_html__( 'Zablokowane', 'adinet-panel' ) : esc_html__( 'Ustawienia WordPressa', 'adinet-panel' ); ?>
									</span>
								</div>
								<h3 id="adinet-comments-title"><?php esc_html_e( 'Komentarze i pingbacki', 'adinet-panel' ); ?></h3>
								<p><?php esc_html_e( 'Jedna blokada dla wpisów, stron i wszystkich niestandardowych typów treści — także tych utworzonych przed włączeniem funkcji.', 'adinet-panel' ); ?></p>
							</div>

							<div class="adinet-comments-control">
								<input type="hidden" name="<?php echo esc_attr( AdiNet_Options::DISABLE_COMMENTS ); ?>" value="0">
								<label class="adinet-toggle-option" for="adinet-disable-comments">
									<input
										type="checkbox"
										id="adinet-disable-comments"
										name="<?php echo esc_attr( AdiNet_Options::DISABLE_COMMENTS ); ?>"
										value="1"
										<?php checked( $comments_disabled ); ?>
									>
									<span>
										<strong><?php esc_html_e( 'Całkowicie wyłącz komentarze', 'adinet-panel' ); ?></strong>
										<small><?php esc_html_e( 'Blokuje formularze, REST API, pingbacki i trackbacki oraz ukrywa publicznie istniejące komentarze. Nie usuwa danych z bazy.', 'adinet-panel' ); ?></small>
									</span>
								</label>
								<p class="adinet-help adinet-help--warning"><?php esc_html_e( 'Uwaga: funkcja wyłączy również recenzje produktów WooCommerce i inne funkcje wtyczek oparte na systemie komentarzy WordPressa.', 'adinet-panel' ); ?></p>
							</div>
						</div>
					</section>

					<section class="adinet-card adinet-card--monitor" aria-labelledby="adinet-monitor-title">
						<div class="adinet-monitor-layout">
							<div>
								<div class="adinet-card__topline">
									<span class="adinet-card__icon dashicons dashicons-chart-bar" aria-hidden="true"></span>
									<span class="adinet-status <?php echo $monitor_404_state['active'] ? 'is-active' : 'is-neutral'; ?>">
										<?php echo esc_html( AdiNet_404_Monitor::get_status_label( $monitor_404_state ) ); ?>
									</span>
								</div>
								<h3 id="adinet-monitor-title"><?php esc_html_e( 'Monitoring 404', 'adinet-panel' ); ?></h3>
								<p><?php esc_html_e( 'Zlicza przez 7 dni adresy IP wywołujące błędy 404. Po tym czasie zapis zatrzymuje się, ale wyniki pozostają do ręcznego usunięcia.', 'adinet-panel' ); ?></p>
								<?php if ( $monitor_404_state['has_period'] ) : ?>
									<p class="adinet-monitor-period">
										<strong><?php esc_html_e( 'Okres danych:', 'adinet-panel' ); ?></strong>
										<?php echo esc_html( AdiNet_404_Monitor::format_timestamp( $monitor_404_state['started_at'] ) . ' – ' . AdiNet_404_Monitor::format_timestamp( $monitor_404_state['ends_at'] ) ); ?>
									</p>
								<?php endif; ?>
							</div>

							<div class="adinet-monitor-control">
								<input type="hidden" name="<?php echo esc_attr( AdiNet_Options::MONITOR_404_ENABLED ); ?>" value="0">
								<label class="adinet-toggle-option" for="adinet-monitor-404-enabled">
									<input
										type="checkbox"
										id="adinet-monitor-404-enabled"
										name="<?php echo esc_attr( AdiNet_Options::MONITOR_404_ENABLED ); ?>"
										value="1"
										<?php checked( $monitor_404_state['active'] ); ?>
									>
									<span>
										<strong><?php esc_html_e( 'Włącz monitoring na 7 dni', 'adinet-panel' ); ?></strong><small><?php esc_html_e( 'Każde nowe uruchomienie usuwa poprzednie wyniki 404. Zapis ustawień w trakcie aktywnej sesji zachowuje wyniki i termin zakończenia.', 'adinet-panel' ); ?></small>
										<small><?php esc_html_e( 'Wyłączenie funkcji zatrzymuje nowe zapisy i nie usuwa dotychczasowych wyników.', 'adinet-panel' ); ?></small>
									</span>
								</label>
								<a href="<?php echo esc_url( $monitor_404_url ); ?>" class="button"><?php esc_html_e( 'Otwórz wyniki', 'adinet-panel' ); ?></a>
							</div>
						</div>
					</section>

					<section class="adinet-card adinet-card--admin-log" aria-labelledby="adinet-admin-log-title">
						<div class="adinet-monitor-layout">
							<div>
								<div class="adinet-card__topline">
									<span class="adinet-card__icon dashicons dashicons-list-view" aria-hidden="true"></span>
									<span class="adinet-status <?php echo $admin_log_enabled ? 'is-active' : 'is-neutral'; ?>">
										<?php echo $admin_log_enabled ? esc_html__( 'Aktywny', 'adinet-panel' ) : esc_html__( 'Nieaktywny', 'adinet-panel' ); ?>
									</span>
								</div>
								<h3 id="adinet-admin-log-title"><?php esc_html_e( 'Log administracyjny', 'adinet-panel' ); ?></h3>
								<p><?php esc_html_e( 'Zapisuje najważniejsze logowania i zmiany użytkowników, treści, ustawień, wtyczek, motywów oraz Divi. Rekordy są przechowywane przez 30 dni, maksymalnie 10 000.', 'adinet-panel' ); ?></p>
							</div>

							<div class="adinet-monitor-control">
								<input type="hidden" name="<?php echo esc_attr( AdiNet_Options::ADMIN_LOG_ENABLED ); ?>" value="0">
								<label class="adinet-toggle-option" for="adinet-admin-log-enabled">
									<input
										type="checkbox"
										id="adinet-admin-log-enabled"
										name="<?php echo esc_attr( AdiNet_Options::ADMIN_LOG_ENABLED ); ?>"
										value="1"
										<?php checked( $admin_log_enabled ); ?>
									>
									<span>
										<strong><?php esc_html_e( 'Włącz log administracyjny', 'adinet-panel' ); ?></strong>
										<small><?php esc_html_e( 'Wyłączenie zatrzymuje nowe zapisy i zachowuje dotychczasowy log oraz daty aktywności administratorów.', 'adinet-panel' ); ?></small>
									</span>
								</label>
								<a href="<?php echo esc_url( $admin_log_url ); ?>" class="button"><?php esc_html_e( 'Otwórz log', 'adinet-panel' ); ?></a>
							</div>
						</div>
					</section>

				</div>

				<div class="adinet-section-heading adinet-section-heading--technical" data-adinet-order="10">
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Stan środowiska', 'adinet-panel' ); ?></p>
						<h2><?php esc_html_e( 'Informacje techniczne', 'adinet-panel' ); ?></h2>
					</div>
					<p><?php esc_html_e( 'Dane są odczytywane na bieżąco z WordPressa i konfiguracji serwera.', 'adinet-panel' ); ?></p>
				</div>

				<div class="adinet-technical-grid" data-adinet-order="20">
					<section class="adinet-card adinet-tech-card" aria-labelledby="adinet-hosting-title">
						<div class="adinet-card__topline">
							<span class="adinet-card__icon dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
							<span class="adinet-status <?php echo ! empty( $hosting['detected'] ) ? 'is-good' : 'is-neutral'; ?>">
								<?php echo ! empty( $hosting['detected'] ) ? esc_html__( 'Wykryto', 'adinet-panel' ) : esc_html__( 'Brak dopasowania', 'adinet-panel' ); ?>
							</span>
						</div>
						<h3 id="adinet-hosting-title"><?php esc_html_e( 'Konto hostingowe', 'adinet-panel' ); ?></h3>

						<?php if ( ! empty( $hosting['detected'] ) && ! empty( $hosting['account'] ) ) : ?>
							<p class="adinet-tech-value"><?php echo esc_html( $hosting['account'] ); ?></p>
							<p class="adinet-help">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %s: hosting provider name. */
										__( 'Konto rozpoznane w strukturze hostingu %s.', 'adinet-panel' ),
										isset( $hosting['provider'] ) ? $hosting['provider'] : ''
									)
								);
								?>
							</p>
						<?php else : ?>
							<p class="adinet-tech-value is-empty"><?php esc_html_e( 'Nie wykryto automatycznie', 'adinet-panel' ); ?></p>
							<p class="adinet-help"><?php esc_html_e( 'Automatyczne rozpoznawanie obsługuje strukturę /home/…dhosting.pl/konto/…. Dla innych hostingów można dodać filtr adinet_hosting_info.', 'adinet-panel' ); ?></p>
						<?php endif; ?>

						<?php if ( ! empty( $hosting['path'] ) ) : ?>
							<div class="adinet-installation-path">
								<strong><?php esc_html_e( 'Ścieżka instalacji', 'adinet-panel' ); ?></strong>
								<code><?php echo esc_html( $hosting['path'] ); ?></code>
							</div>
						<?php endif; ?>

						<a href="<?php echo esc_url( $dpanel_link['url'] ); ?>" class="button adinet-hosting-login" target="_blank" rel="noopener noreferrer">
							<span class="dashicons dashicons-dashboard" aria-hidden="true"></span>
							<?php echo 'https://dpanel.pl/' !== $dpanel_link['url'] ? esc_html__( 'Otwórz dPanel tego konta', 'adinet-panel' ) : esc_html__( 'Otwórz dPanel', 'adinet-panel' ); ?>
							<span class="screen-reader-text"><?php esc_html_e( 'Otwiera w nowej karcie.', 'adinet-panel' ); ?></span>
						</a>
					</section>

					<section class="adinet-card adinet-tech-card" aria-labelledby="adinet-runtime-title">
						<div class="adinet-card__topline">
							<span class="adinet-card__icon dashicons dashicons-editor-code" aria-hidden="true"></span>
						</div>
						<h3 id="adinet-runtime-title"><?php esc_html_e( 'Wersje środowiska', 'adinet-panel' ); ?></h3>

						<div class="adinet-tech-row">
							<div class="adinet-tech-row__heading">
								<strong>PHP <?php echo esc_html( $php_info['version'] ); ?></strong>
								<span class="adinet-status is-<?php echo esc_attr( $php_info['status'] ); ?>"><?php echo esc_html( $php_info['label'] ); ?></span>
							</div>
							<p><?php echo esc_html( $php_info['detail'] ); ?></p>
						</div>

						<div class="adinet-tech-row">
							<div class="adinet-tech-row__heading">
								<strong><?php echo esc_html( $database_info['engine'] . ' ' . $database_info['version'] ); ?></strong>
								<span class="adinet-status is-<?php echo esc_attr( $database_info['status'] ); ?>"><?php echo esc_html( $database_info['label'] ); ?></span>
							</div>
							<p><?php echo esc_html( $database_info['detail'] ); ?></p>
						</div>
					</section>

					<section class="adinet-card adinet-tech-card" aria-labelledby="adinet-cache-title">
						<div class="adinet-card__topline">
							<span class="adinet-card__icon dashicons dashicons-performance" aria-hidden="true"></span>
						</div>
						<h3 id="adinet-cache-title"><?php esc_html_e( 'Mechanizmy cache', 'adinet-panel' ); ?></h3>

						<div class="adinet-tech-row">
							<p class="adinet-tech-kicker"><?php esc_html_e( 'Cache stron', 'adinet-panel' ); ?></p>
							<div class="adinet-tech-row__heading">
								<strong><?php echo esc_html( $page_cache['label'] ); ?></strong>
								<span class="adinet-status is-<?php echo esc_attr( $page_cache['status'] ); ?>"><?php echo 'good' === $page_cache['status'] ? esc_html__( 'Aktywny', 'adinet-panel' ) : esc_html__( 'Informacja', 'adinet-panel' ); ?></span>
							</div>
							<p><?php echo esc_html( $page_cache['detail'] ); ?></p>
						</div>

						<div class="adinet-tech-row">
							<p class="adinet-tech-kicker"><?php esc_html_e( 'Object cache', 'adinet-panel' ); ?></p>
							<div class="adinet-tech-row__heading">
								<strong><?php echo esc_html( $object_cache['label'] ); ?></strong>
								<span class="adinet-status is-<?php echo esc_attr( $object_cache['status'] ); ?>"><?php echo 'good' === $object_cache['status'] ? esc_html__( 'Aktywny', 'adinet-panel' ) : esc_html__( 'Informacja', 'adinet-panel' ); ?></span>
							</div>
							<p><?php echo esc_html( $object_cache['detail'] ); ?></p>
						</div>
					</section>
				</div>

				<section class="adinet-resources" aria-labelledby="adinet-resources-title" data-adinet-order="40">
					<div class="adinet-resources__header">
						<div>
							<p class="adinet-eyebrow"><?php esc_html_e( 'Narzędzia serwisowe', 'adinet-panel' ); ?></p>
							<h2 id="adinet-resources-title"><?php esc_html_e( 'Przydatne panele i narzędzia', 'adinet-panel' ); ?></h2>
						</div>
						<p><?php esc_html_e( 'Linki otwierają się w nowej karcie. dPanel, PageSpeed, WAVE, W3C i Search Console są dopasowywane automatycznie do tej instalacji.', 'adinet-panel' ); ?></p>
					</div>

					<div class="adinet-resources__grid">
						<?php foreach ( $external_links as $external_link ) : ?>
							<a href="<?php echo esc_url( $external_link['url'] ); ?>" class="adinet-resource-link" target="_blank" rel="noopener noreferrer">
								<span class="adinet-resource-link__icon dashicons <?php echo esc_attr( $external_link['icon'] ); ?>" aria-hidden="true"></span>
								<span class="adinet-resource-link__content">
									<span class="adinet-resource-link__heading">
										<strong><?php echo esc_html( $external_link['label'] ); ?></strong>
										<?php if ( $external_link['recommended'] ) : ?><em><?php esc_html_e( 'Polecane do botów', 'adinet-panel' ); ?></em><?php endif; ?>
									</span>
									<small><?php echo esc_html( $external_link['description'] ); ?></small>
								</span>
								<span class="dashicons dashicons-external" aria-hidden="true"></span>
								<span class="screen-reader-text"><?php esc_html_e( 'Otwiera w nowej karcie.', 'adinet-panel' ); ?></span>
							</a>
						<?php endforeach; ?>
					</div>
				</section>

				<div class="adinet-section-heading adinet-section-heading--configuration" data-adinet-order="80">
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Ustawienia serwisowe', 'adinet-panel' ); ?></p>
						<h2><?php esc_html_e( 'Konfiguracja techniczna', 'adinet-panel' ); ?></h2>
					</div>
					<p><?php esc_html_e( 'Opcje używane podczas diagnostyki oraz konfiguracji automatycznych zadań WordPressa.', 'adinet-panel' ); ?></p>
				</div>

				<section class="adinet-card adinet-card--debug" aria-labelledby="adinet-debug-title" data-adinet-order="90">
					<div class="adinet-debug-header">
						<div>
							<div class="adinet-card__topline">
								<span class="adinet-card__icon dashicons dashicons-warning" aria-hidden="true"></span>
								<span class="adinet-status <?php echo $debug_state['wp_debug'] ? 'is-warning' : 'is-good'; ?>">
									WP_DEBUG: <?php echo $debug_state['wp_debug'] ? esc_html__( 'włączony', 'adinet-panel' ) : esc_html__( 'wyłączony', 'adinet-panel' ); ?>
								</span>
							</div>
							<h3 id="adinet-debug-title"><?php esc_html_e( 'Diagnostyka i błędy PHP', 'adinet-panel' ); ?></h3>
							<p><?php esc_html_e( 'Stan WP_DEBUG jest tylko odczytywany. Poniższe ustawienia pozwalają niezależnie sterować wyświetlaniem i logowaniem błędów od momentu załadowania wtyczki.', 'adinet-panel' ); ?></p>
						</div>

						<div class="adinet-debug-constants">
							<div><small>WP_DEBUG_DISPLAY</small><strong><?php echo esc_html( AdiNet_Debug_Control::format_constant_value( $debug_state['wp_debug_display'] ) ); ?></strong></div>
							<div><small>WP_DEBUG_LOG</small><strong><?php echo esc_html( AdiNet_Debug_Control::format_constant_value( $debug_state['wp_debug_log'] ) ); ?></strong></div>
							<div><small>PHP display_errors</small><strong><?php echo $debug_state['php_display_errors'] ? esc_html__( 'aktywne', 'adinet-panel' ) : esc_html__( 'wyłączone', 'adinet-panel' ); ?></strong></div>
							<div><small><?php esc_html_e( 'Log PHP', 'adinet-panel' ); ?></small><strong><?php echo $debug_state['php_log_errors'] ? esc_html__( 'aktywny', 'adinet-panel' ) : esc_html__( 'wyłączony', 'adinet-panel' ); ?></strong></div>
						</div>
					</div>

					<div class="adinet-php-logs" aria-labelledby="adinet-php-logs-title">
						<div class="adinet-php-logs__heading">
							<div>
								<h4 id="adinet-php-logs-title"><?php esc_html_e( 'Pliki logów PHP', 'adinet-panel' ); ?></h4>
								<p><?php esc_html_e( 'Panel udostępnia plik przez chronioną akcję administratora. Nie tworzy publicznego linku do logu.', 'adinet-panel' ); ?></p>
							</div>
						</div>

						<?php if ( empty( $php_logs ) ) : ?>
							<div class="adinet-php-log-row is-empty">
								<strong><?php esc_html_e( 'PHP nie ujawnia lokalizacji logu', 'adinet-panel' ); ?></strong>
								<span><?php esc_html_e( 'Sprawdź logi PHP w dPanelu. Samo włączenie log_errors nie gwarantuje pliku dostępnego dla WordPressa.', 'adinet-panel' ); ?></span>
							</div>
						<?php else : ?>
							<?php foreach ( $php_logs as $php_log ) : ?>
								<div class="adinet-php-log-row">
									<div class="adinet-php-log-row__data">
										<div class="adinet-php-log-row__title">
											<strong><?php echo esc_html( implode( ' / ', $php_log['sources'] ) ); ?></strong>
											<span class="adinet-status <?php echo $php_log['exists'] ? 'is-warning' : 'is-neutral'; ?>"><?php echo $php_log['exists'] ? esc_html__( 'Plik istnieje', 'adinet-panel' ) : esc_html__( 'Brak pliku', 'adinet-panel' ); ?></span>
										</div>
										<code><?php echo esc_html( $php_log['path'] ); ?></code>
										<?php if ( $php_log['exists'] ) : ?>
											<small><?php echo esc_html( sprintf( __( 'Rozmiar: %1$s · modyfikacja: %2$s', 'adinet-panel' ), size_format( $php_log['size'] ), wp_date( 'd.m.Y H:i:s', $php_log['modified'] ) ) ); ?></small>
										<?php endif; ?>
										<?php if ( ! $php_log['manageable'] ) : ?>
											<small class="is-warning"><?php esc_html_e( 'To log serwera albo ścieżka poza wp-content. Ze względów bezpieczeństwa zarządzaj nim w dPanelu.', 'adinet-panel' ); ?></small>
										<?php elseif ( $php_log['exists'] ) : ?>
											<small class="is-warning"><?php esc_html_e( 'Plik w wp-content może być dostępny publicznie, jeśli serwer nie blokuje jego adresu. Po diagnozie pobierz go i usuń.', 'adinet-panel' ); ?></small>
										<?php endif; ?>
									</div>

									<?php if ( $can_manage && $php_log['manageable'] && $php_log['exists'] && ( $php_log['readable'] || $php_log['deletable'] ) ) : ?>
										<div class="adinet-php-log-row__actions">
											<?php if ( $php_log['readable'] ) : ?><a href="<?php echo esc_url( AdiNet_Debug_Control::get_log_action_url( 'download', $php_log['id'] ) ); ?>" class="button"><?php esc_html_e( 'Pobierz log', 'adinet-panel' ); ?></a><?php endif; ?>
											<?php if ( $php_log['deletable'] ) : ?><a href="<?php echo esc_url( AdiNet_Debug_Control::get_log_action_url( 'delete', $php_log['id'] ) ); ?>" class="button button-link-delete" data-confirm="<?php echo esc_attr__( 'Czy na pewno usunąć cały plik logu PHP? Tej operacji nie można cofnąć.', 'adinet-panel' ); ?>"><?php esc_html_e( 'Usuń plik', 'adinet-panel' ); ?></a><?php endif; ?>
										</div>
									<?php endif; ?>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>

						<p class="adinet-help"><?php esc_html_e( 'Cztery godziny to bezpieczny domyślny czas ręcznej diagnostyki. Przy rzadkim błędzie możesz włączyć tryb ponownie. Wygaśnięcie trybu zatrzymuje wymuszenie AdiNet, ale nie usuwa pliku i nie wyłącza logowania ustawionego w wp-config.php, php.ini lub hostingu.', 'adinet-panel' ); ?></p>
					</div>

					<?php foreach ( array( 'display_until' => __( 'Wyświetlanie błędów do', 'adinet-panel' ), 'log_until' => __( 'Wymuszone logowanie błędów do', 'adinet-panel' ) ) as $timer => $timer_label ) : ?>
						<?php if ( $debug_state[ $timer ] > time() ) : ?><p class="adinet-help adinet-help--warning"><?php echo esc_html( $timer_label . ' ' . wp_date( 'd.m.Y H:i', $debug_state[ $timer ] ) ); ?></p><?php endif; ?>
					<?php endforeach; ?>
					<p class="adinet-help"><?php esc_html_e( 'Limit 4 godzin nie wymaga sprawnego WP-Cron. Zwykły zapis innych ustawień nie przedłuża diagnostyki.', 'adinet-panel' ); ?></p>
					<div class="adinet-debug-controls">
						<fieldset class="adinet-debug-control">
							<legend><?php esc_html_e( 'Wyświetlanie błędów', 'adinet-panel' ); ?></legend>

							<label class="adinet-radio-option">
								<input type="radio" name="<?php echo esc_attr( AdiNet_Options::DEBUG_DISPLAY_MODE ); ?>" value="inherit" <?php checked( $debug_state['display_mode'], AdiNet_Options::DEBUG_MODE_INHERIT ); ?>>
								<span><strong><?php esc_html_e( 'Zgodnie z wp-config.php', 'adinet-panel' ); ?></strong><small><?php esc_html_e( 'AdiNet nie zmienia sposobu wyświetlania błędów.', 'adinet-panel' ); ?></small></span>
							</label>

							<label class="adinet-radio-option is-recommended">
								<input type="radio" name="<?php echo esc_attr( AdiNet_Options::DEBUG_DISPLAY_MODE ); ?>" value="disabled" <?php checked( $debug_state['display_mode'], AdiNet_Options::DEBUG_MODE_DISABLED ); ?>>
								<span><strong><?php esc_html_e( 'Ukrywaj błędy', 'adinet-panel' ); ?></strong><small><?php esc_html_e( 'Zalecane dla strony publicznej. Ustawia display_errors=0 po załadowaniu wtyczki.', 'adinet-panel' ); ?></small></span>
								<em><?php esc_html_e( 'Bezpieczne', 'adinet-panel' ); ?></em>
							</label>

							<label class="adinet-radio-option">
								<input type="radio" name="<?php echo esc_attr( AdiNet_Options::DEBUG_DISPLAY_MODE ); ?>" value="enabled" <?php checked( $debug_state['display_mode'], AdiNet_Options::DEBUG_MODE_ENABLED ); ?>>
								<span><strong><?php esc_html_e( 'Pokazuj na stronie przez 4 godziny', 'adinet-panel' ); ?></strong><small><?php esc_html_e( 'Błędy będą widoczne również dla odwiedzających. Po 4 godzinach AdiNet je ukryje. Nie obejmuje panelu, AJAX ani REST API.', 'adinet-panel' ); ?></small></span>
							</label>
						</fieldset>

						<fieldset class="adinet-debug-control">
							<legend><?php esc_html_e( 'Zapisywanie błędów', 'adinet-panel' ); ?></legend>

							<label class="adinet-radio-option">
								<input type="radio" name="<?php echo esc_attr( AdiNet_Options::DEBUG_LOG_MODE ); ?>" value="inherit" <?php checked( $debug_state['log_mode'], AdiNet_Options::DEBUG_MODE_INHERIT ); ?>>
								<span><strong><?php esc_html_e( 'Zgodnie z wp-config.php i serwerem', 'adinet-panel' ); ?></strong><small><?php esc_html_e( 'AdiNet pozostawia bieżące ustawienie log_errors.', 'adinet-panel' ); ?></small></span>
							</label>

							<label class="adinet-radio-option">
								<input type="radio" name="<?php echo esc_attr( AdiNet_Options::DEBUG_LOG_MODE ); ?>" value="enabled" <?php checked( $debug_state['log_mode'], AdiNet_Options::DEBUG_MODE_ENABLED ); ?>>
								<span><strong><?php esc_html_e( 'Włącz logowanie PHP na 4 godziny', 'adinet-panel' ); ?></strong><small><?php esc_html_e( 'Po 4 godzinach przywraca logowanie zgodne z konfiguracją serwera. Nie usuwa logów. Lokalizacja logu wynika z PHP/WP_DEBUG_LOG.', 'adinet-panel' ); ?></small></span>
							</label>

							<label class="adinet-radio-option">
								<input type="radio" name="<?php echo esc_attr( AdiNet_Options::DEBUG_LOG_MODE ); ?>" value="disabled" <?php checked( $debug_state['log_mode'], AdiNet_Options::DEBUG_MODE_DISABLED ); ?>>
								<span><strong><?php esc_html_e( 'Wyłącz logowanie PHP', 'adinet-panel' ); ?></strong><small><?php esc_html_e( 'Ustawia log_errors=0 po załadowaniu wtyczki. Nie usuwa logów ani nie blokuje jawnych wywołań error_log() w kodzie.', 'adinet-panel' ); ?></small></span>
							</label>
						</fieldset>
					</div>

					<p class="adinet-help adinet-help--warning"><?php esc_html_e( 'Wtyczka nie przechwytuje błędów powstałych przed jej załadowaniem. Do pełnej diagnostyki całego startu WordPressa nadal służą stałe w wp-config.php.', 'adinet-panel' ); ?></p>
				</section>

				<section class="adinet-card adinet-card--cron" aria-labelledby="adinet-cron-title" data-adinet-order="100">
					<div class="adinet-cron-health">
						<h3><?php esc_html_e( 'Czy WP-Cron wykonuje zadania?', 'adinet-panel' ); ?></h3>
						<span class="adinet-status is-<?php echo esc_attr( $cron_health['status'] ); ?>"><?php echo esc_html( $cron_health['label'] ); ?></span>
						<p><?php esc_html_e( 'Ostatnie rzeczywiste wykonanie kontroli:', 'adinet-panel' ); ?> <strong><?php echo esc_html( $cron_health['last'] ? wp_date( 'd.m.Y H:i:s', $cron_health['last'] ) : __( 'jeszcze nie wykonano', 'adinet-panel' ) ); ?></strong></p>
						<p><?php esc_html_e( 'Następny termin:', 'adinet-panel' ); ?> <?php echo esc_html( $cron_health['next'] ? wp_date( 'd.m.Y H:i:s', $cron_health['next'] ) : __( 'brak zadania', 'adinet-panel' ) ); ?></p>
						<p class="adinet-help"><?php esc_html_e( 'Kontrola jest zaplanowana co 15 minut; po ponad 45 minutach bez wykonania pojawi się ostrzeżenie. Gdy wyłączysz cron od ruchu, zadanie może wykonać cron hostingu lub inne zewnętrzne wywołanie. Ten pomiar potwierdza wykonanie, ale nie rozpoznaje jego źródła. Odśwież stronę, aby odczytać aktualny stan.', 'adinet-panel' ); ?></p>
					</div>
					<div class="adinet-cron-layout">
						<div>
							<div class="adinet-card__topline">
								<span class="adinet-card__icon dashicons dashicons-clock" aria-hidden="true"></span>
								<span class="adinet-status is-<?php echo esc_attr( $cron_status ); ?>"><?php echo esc_html( $cron_label ); ?></span>
							</div>
							<h3 id="adinet-cron-title"><?php esc_html_e( 'Sterowanie WP-Cron', 'adinet-panel' ); ?></h3>
							<p><?php echo esc_html( $cron_detail ); ?></p>
						</div>

						<div class="adinet-cron-control">
							<input type="hidden" name="<?php echo esc_attr( AdiNet_Options::DISABLE_WP_CRON ); ?>" value="0">
							<label class="adinet-toggle-option" for="adinet-disable-wp-cron">
								<input
									type="checkbox"
									id="adinet-disable-wp-cron"
									name="<?php echo esc_attr( AdiNet_Options::DISABLE_WP_CRON ); ?>"
									value="1"
									<?php checked( $cron_option ); ?>
								>
								<span>
									<strong><?php esc_html_e( 'Wyłącz uruchamianie WP-Cron przez wejścia na stronę', 'adinet-panel' ); ?></strong>
									<small><?php esc_html_e( 'Włącz tylko wtedy, gdy na hostingu działa osobne, cykliczne wywołanie wp-cron.php.', 'adinet-panel' ); ?></small>
								</span>
							</label>
							<p class="adinet-help adinet-help--warning"><?php esc_html_e( 'Opcja nie usuwa zaplanowanych zadań. Ustawienie DISABLE_WP_CRON w wp-config.php zawsze ma pierwszeństwo, a wyłączenie wtyczki wyłącza kontrolę AdiNet.', 'adinet-panel' ); ?></p>
						</div>
					</div>

					<div class="adinet-cron-guide">
							<div class="adinet-cron-guide__intro">
								<span class="dashicons dashicons-admin-tools" aria-hidden="true"></span>
								<div>
									<strong><?php esc_html_e( 'Jak ustawić prawdziwy cron w dPanelu', 'adinet-panel' ); ?></strong>
									<span><?php esc_html_e( 'Zrób to przed zaznaczeniem opcji wyłączającej WP-Cron przez ruch.', 'adinet-panel' ); ?></span>
								</div>
							</div>
							<ol>
								<li><?php esc_html_e( 'W dPanelu dodaj nowe zadanie typu „Wget”.', 'adinet-panel' ); ?></li>
								<li><?php esc_html_e( 'Ustaw wykonywanie co 10 minut.', 'adinet-panel' ); ?></li>
								<li><?php esc_html_e( 'Wklej poniższy adres jako URL zadania.', 'adinet-panel' ); ?></li>
							</ol>
							<div class="adinet-shortcode adinet-cron-url">
								<code><?php echo esc_html( $wp_cron_url ); ?></code>
								<button
									type="button"
									class="button adinet-copy-button"
									data-copy="<?php echo esc_attr( $wp_cron_url ); ?>"
									data-default-label="<?php echo esc_attr__( 'Kopiuj URL', 'adinet-panel' ); ?>"
									data-copied-label="<?php echo esc_attr__( 'Skopiowano', 'adinet-panel' ); ?>"
									aria-describedby="adinet-copy-status"
								>
									<?php esc_html_e( 'Kopiuj URL', 'adinet-panel' ); ?>
								</button>
							</div>
						</div>
				</section>

				<section class="adinet-card adinet-card--revisions" aria-labelledby="adinet-revisions-title" data-adinet-order="105">
					<div class="adinet-revisions-layout">
						<div>
							<div class="adinet-card__topline">
								<span class="adinet-card__icon dashicons dashicons-backup" aria-hidden="true"></span>
								<span class="adinet-status is-good"><?php esc_html_e( 'Kontrolowane przez AdiNet', 'adinet-panel' ); ?></span>
							</div>
							<h3 id="adinet-revisions-title"><?php esc_html_e( 'Rewizje treści', 'adinet-panel' ); ?></h3>
							<p><?php esc_html_e( 'Ogranicz liczbę wcześniejszych wersji osobno dla każdego wpisu, strony i innego typu treści obsługującego rewizje.', 'adinet-panel' ); ?></p>
						</div>

						<div class="adinet-revisions-control">
							<div class="adinet-revisions-fields">
								<label for="adinet-revision-limit">
									<span><?php esc_html_e( 'Maksymalna liczba rewizji', 'adinet-panel' ); ?></span>
									<input
										type="number"
										id="adinet-revision-limit"
										name="<?php echo esc_attr( AdiNet_Options::REVISION_LIMIT ); ?>"
										value="<?php echo esc_attr( $revision_limit ); ?>"
										min="1"
										max="1000"
										step="1"
										required
									>
								</label>

								<label for="adinet-revision-max-age">
									<span><?php esc_html_e( 'Maksymalny wiek rewizji', 'adinet-panel' ); ?></span>
									<span class="adinet-number-with-unit">
										<input
											type="number"
											id="adinet-revision-max-age"
											name="<?php echo esc_attr( AdiNet_Options::REVISION_MAX_AGE ); ?>"
											value="<?php echo esc_attr( $revision_max_age ); ?>"
											min="1"
											max="36500"
											step="1"
											required
										>
										<em><?php esc_html_e( 'dni', 'adinet-panel' ); ?></em>
									</span>
								</label>
							</div>
							<p class="adinet-help"><?php esc_html_e( 'Domyślnie: 10 wersji i 370 dni. Starsze rewizje są porządkowane przy kolejnym zapisaniu danej treści; autosave pozostaje obsługiwany przez WordPressa.', 'adinet-panel' ); ?></p>
							<p class="adinet-help adinet-help--warning"><?php esc_html_e( 'Jeżeli limit WP_POST_REVISIONS był ustawiony ręcznie w wp-config.php, jego wpis można usunąć. AdiNet zastępuje tę wartość przez oficjalny filtr WordPressa.', 'adinet-panel' ); ?></p>
						</div>
					</div>
				</section>

				<div class="adinet-section-heading adinet-section-heading--security" data-adinet-order="110">
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Konfiguracja jednorazowa', 'adinet-panel' ); ?></p>
						<h2><?php esc_html_e( 'Bezpieczeństwo i dostęp', 'adinet-panel' ); ?></h2>
					</div>
					<p><?php esc_html_e( 'Ustawienia wdrożeniowe, które zwykle konfigurujesz raz i później jedynie kontrolujesz.', 'adinet-panel' ); ?></p>
				</div>

				<section class="adinet-card adinet-card--file-edit" aria-labelledby="adinet-file-edit-title" data-adinet-order="120">
					<div class="adinet-file-edit-layout">
						<div>
							<div class="adinet-card__topline">
								<span class="adinet-card__icon dashicons dashicons-editor-code" aria-hidden="true"></span>
								<span class="adinet-status is-<?php echo esc_attr( $file_edit_status ); ?>"><?php echo esc_html( $file_edit_label ); ?></span>
							</div>
							<h3 id="adinet-file-edit-title"><?php esc_html_e( 'Edycja plików w panelu WordPressa', 'adinet-panel' ); ?></h3>
							<p><?php echo esc_html( $file_edit_detail ); ?></p>
						</div>

						<div class="adinet-file-edit-control">
							<input type="hidden" name="<?php echo esc_attr( AdiNet_Options::DISALLOW_FILE_EDIT ); ?>" value="0">
							<label class="adinet-toggle-option" for="adinet-disallow-file-edit">
								<input
									type="checkbox"
									id="adinet-disallow-file-edit"
									name="<?php echo esc_attr( AdiNet_Options::DISALLOW_FILE_EDIT ); ?>"
									value="1"
									<?php checked( $file_edit_option ); ?>
								>
								<span>
									<strong><?php esc_html_e( 'Zablokuj edytory plików motywów i wtyczek', 'adinet-panel' ); ?></strong>
									<small><?php esc_html_e( 'Ustawia DISALLOW_FILE_EDIT=true. Chroni przed przypadkową zmianą kodu bez blokowania instalacji ani aktualizacji.', 'adinet-panel' ); ?></small>
								</span>
							</label>
							<p class="adinet-help adinet-help--warning"><?php esc_html_e( 'Ustawienie z wp-config.php ma pierwszeństwo. Niektóre wtyczki błędnie wykorzystujące uprawnienie edit_plugins mogą po włączeniu ograniczyć także własne ekrany.', 'adinet-panel' ); ?></p>
						</div>
					</div>
				</section>

				<section class="adinet-card adinet-card--login" aria-labelledby="adinet-login-title" data-adinet-order="130">
					<div class="adinet-login-layout">
						<div>
							<div class="adinet-card__topline">
								<span class="adinet-card__icon dashicons dashicons-lock" aria-hidden="true"></span>
								<span class="adinet-status <?php echo $login_url_enabled ? 'is-good' : 'is-neutral'; ?>">
									<?php echo $login_url_enabled ? esc_html__( 'Włączony', 'adinet-panel' ) : esc_html__( 'Wyłączony', 'adinet-panel' ); ?>
								</span>
							</div>
							<h3 id="adinet-login-title"><?php esc_html_e( 'Własny adres logowania', 'adinet-panel' ); ?></h3>
							<p><?php esc_html_e( 'Ukrywa standardowe wp-login.php i wp-admin przed niezalogowanymi użytkownikami. Próba wejścia pod te adresy zwróci stronę 404.', 'adinet-panel' ); ?></p>
						</div>

						<div class="adinet-login-control">
							<input type="hidden" name="<?php echo esc_attr( AdiNet_Options::LOGIN_URL_ENABLED ); ?>" value="0">
							<label class="adinet-toggle-option" for="adinet-login-url-enabled">
								<input
									type="checkbox"
									id="adinet-login-url-enabled"
									name="<?php echo esc_attr( AdiNet_Options::LOGIN_URL_ENABLED ); ?>"
									value="1"
									<?php checked( $login_url_enabled ); ?>
								>
								<span>
									<strong><?php esc_html_e( 'Włącz ochronę adresu logowania', 'adinet-panel' ); ?></strong>
									<small><?php esc_html_e( 'Po zapisaniu loguj się wyłącznie przez adres podany poniżej.', 'adinet-panel' ); ?></small>
								</span>
							</label>

							<label class="adinet-login-slug-label" for="adinet-login-slug"><?php esc_html_e( 'Końcówka adresu logowania', 'adinet-panel' ); ?></label>
							<div class="adinet-login-slug-field">
								<span aria-hidden="true">/</span>
								<input
									type="text"
									id="adinet-login-slug"
									name="<?php echo esc_attr( AdiNet_Options::LOGIN_SLUG ); ?>"
									value="<?php echo esc_attr( $login_slug ); ?>"
									pattern="[a-z0-9-]+"
									maxlength="80"
									autocomplete="off"
									required
								>
								<span aria-hidden="true">/</span>
							</div>

							<div class="adinet-shortcode adinet-login-url">
								<code><?php echo esc_html( $custom_login_url ); ?></code>
								<button
									type="button"
									class="button adinet-copy-button"
									data-copy="<?php echo esc_attr( $custom_login_url ); ?>"
									data-default-label="<?php echo esc_attr__( 'Kopiuj URL', 'adinet-panel' ); ?>"
									data-copied-label="<?php echo esc_attr__( 'Skopiowano', 'adinet-panel' ); ?>"
									aria-describedby="adinet-copy-status"
								>
									<?php esc_html_e( 'Kopiuj URL', 'adinet-panel' ); ?>
								</button>
							</div>
						</div>
					</div>
					<p class="adinet-help adinet-help--warning"><?php esc_html_e( 'Zapisz lub dodaj ten adres do zakładek przed wylogowaniem. Wyłączenie tej opcji albo całej wtyczki natychmiast przywraca standardowy adres wp-login.php. Jeśli używasz cache strony lub CDN, wyklucz nowy adres logowania z pamięci podręcznej.', 'adinet-panel' ); ?></p>
				</section>

				<section class="adinet-card adinet-card--audit" aria-labelledby="adinet-audit-title" data-adinet-order="32">
					<div class="adinet-audit-layout">
						<div class="adinet-audit-status <?php echo '' !== $last_audit['date'] ? 'has-date' : 'is-empty'; ?>">
							<span class="adinet-card__icon dashicons dashicons-clipboard" aria-hidden="true"></span>
							<div>
								<p class="adinet-eyebrow"><?php esc_html_e( 'Przegląd techniczny', 'adinet-panel' ); ?></p>
								<h3 id="adinet-audit-title"><?php esc_html_e( 'Data ostatniego audytu', 'adinet-panel' ); ?></h3>
								<?php if ( '' !== $last_audit['date'] ) : ?>
									<strong class="adinet-audit-date"><?php echo esc_html( $last_audit['formatted'] ); ?></strong>
									<?php if ( '' !== $last_audit['user_name'] ) : ?>
										<small><?php echo esc_html( sprintf( __( 'Oznaczył: %s', 'adinet-panel' ), $last_audit['user_name'] ) ); ?></small>
									<?php endif; ?>
								<?php else : ?>
									<p><?php esc_html_e( 'Nie zapisano jeszcze żadnego audytu tej strony.', 'adinet-panel' ); ?></p>
								<?php endif; ?>
							</div>
						</div>

						<div class="adinet-audit-actions">
							<?php if ( $can_manage ) : ?>
							<a href="<?php echo esc_url( $mark_audit_url ); ?>" class="button button-primary">
								<span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
								<?php esc_html_e( 'Oznacz audyt jako wykonany dzisiaj', 'adinet-panel' ); ?>
							</a>
							<span><?php esc_html_e( 'Przycisk od razu zapisze aktualną datę i administratora.', 'adinet-panel' ); ?></span>
							<?php if ( '' !== $last_audit['date'] ) : ?>
								<a
									href="<?php echo esc_url( $clear_audit_url ); ?>"
									class="button-link-delete adinet-clear-audit"
									data-confirm="<?php echo esc_attr__( 'Czy na pewno chcesz usunąć datę ostatniego audytu?', 'adinet-panel' ); ?>"
								><?php esc_html_e( 'Wyczyść datę audytu', 'adinet-panel' ); ?></a>
							<?php endif; ?>
							<?php endif; ?>
						</div>
					</div>
				</section>

				<div class="adinet-section-heading adinet-section-heading--notes" data-adinet-order="33">
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Organizacja projektu', 'adinet-panel' ); ?></p>
						<h2><?php esc_html_e( 'Notatka dla administratorów', 'adinet-panel' ); ?></h2>
					</div>
					<p><?php esc_html_e( 'Zapisz zadanie, ustalenie albo ważny komunikat dotyczący tej strony.', 'adinet-panel' ); ?></p>
				</div>

				<section class="adinet-card adinet-card--note" aria-labelledby="adinet-note-title" data-adinet-order="34">
					<div class="adinet-note-layout">
						<div>
							<h3 id="adinet-note-title"><?php esc_html_e( 'Treść notatki', 'adinet-panel' ); ?></h3>
							<label class="screen-reader-text" for="adinet-admin-note"><?php esc_html_e( 'Notatka dla administratorów', 'adinet-panel' ); ?></label>
							<textarea
								id="adinet-admin-note"
								name="<?php echo esc_attr( AdiNet_Options::ADMIN_NOTE ); ?>"
								rows="7"
								maxlength="5000"
								placeholder="<?php echo esc_attr__( 'Np. Po akceptacji klienta zaktualizować zdjęcia w sekcji Oferta…', 'adinet-panel' ); ?>"
							><?php echo esc_textarea( $note ); ?></textarea>
							<p class="adinet-help"><?php esc_html_e( 'Notatka jest widoczna dla administratorów mających dostęp do panelu AdiNet. Zapisywany jest zwykły tekst.', 'adinet-panel' ); ?></p>
						</div>

						<div class="adinet-current-note <?php echo '' === $note ? 'is-empty' : ''; ?>">
							<p class="adinet-current-note__label"><?php esc_html_e( 'Aktualna notatka', 'adinet-panel' ); ?></p>
							<?php if ( '' !== $note ) : ?>
								<div class="adinet-current-note__content"><?php echo wp_kses_post( wpautop( esc_html( $note ) ) ); ?></div>
								<?php if ( $can_manage ) : ?>
									<a
									href="<?php echo esc_url( $delete_note_url ); ?>"
									class="button button-link-delete adinet-delete-note"
									data-confirm="<?php echo esc_attr__( 'Czy na pewno chcesz usunąć tę notatkę?', 'adinet-panel' ); ?>"
								>
									<span class="dashicons dashicons-trash" aria-hidden="true"></span>
									<?php esc_html_e( 'Usuń notatkę', 'adinet-panel' ); ?>
									</a>
								<?php endif; ?>
							<?php else : ?>
								<p><?php esc_html_e( 'Brak zapisanej notatki. Możesz dodać ją w polu obok.', 'adinet-panel' ); ?></p>
							<?php endif; ?>
						</div>
					</div>
				</section>

				<div class="adinet-save-bar adinet-save-bar--fixed" data-adinet-order="140">
					<div>
						<strong id="adinet-save-status" role="status" aria-live="polite"><?php esc_html_e( 'Brak nowych zmian', 'adinet-panel' ); ?></strong>
						<span><?php esc_html_e( 'Zapisuje wszystkie ustawienia powyżej. Reguły .htaccess mają osobny zapis.', 'adinet-panel' ); ?></span>
					</div>
					<?php submit_button( __( 'Zapisz ustawienia', 'adinet-panel' ), 'primary', 'submit', false ); ?>
				</div>
			</form>

			<div class="adinet-section-heading adinet-section-heading--htaccess">
				<div>
					<p class="adinet-eyebrow"><?php esc_html_e( 'Konfiguracja serwera', 'adinet-panel' ); ?></p>
					<h2><?php esc_html_e( 'Reguły bezpieczeństwa .htaccess', 'adinet-panel' ); ?></h2>
				</div>
				<p><?php esc_html_e( 'AdiNet zarządza wyłącznie własnym blokiem i zachowuje reguły WordPressa, hostingu oraz wtyczek.', 'adinet-panel' ); ?></p>
			</div>

			<section class="adinet-card adinet-card--htaccess" aria-labelledby="adinet-htaccess-title">
				<div class="adinet-htaccess-header">
					<div>
						<div class="adinet-card__topline">
							<span class="adinet-card__icon dashicons dashicons-shield-alt" aria-hidden="true"></span>
							<span class="adinet-status <?php echo $htaccess_status['writable'] ? 'is-good' : 'is-danger'; ?>">
								<?php echo $htaccess_status['writable'] ? esc_html__( 'Plik zapisywalny', 'adinet-panel' ) : esc_html__( 'Brak prawa zapisu', 'adinet-panel' ); ?>
							</span>
						</div>
						<h3 id="adinet-htaccess-title"><?php echo esc_html( sprintf( __( 'Wybrane reguły AdiNet: %d', 'adinet-panel' ), $htaccess_count ) ); ?></h3>
						<p><?php echo $htaccess_status['marker_exists'] ? esc_html__( 'W pliku wykryto zarządzany blok # BEGIN AdiNet.', 'adinet-panel' ) : esc_html__( 'Blok AdiNet nie został jeszcze zapisany w pliku.', 'adinet-panel' ); ?></p>
					</div>

					<div class="adinet-htaccess-meta">
						<div><small><?php esc_html_e( 'Serwer', 'adinet-panel' ); ?></small><strong><?php echo '' !== $htaccess_status['server'] ? esc_html( $htaccess_status['server'] ) : esc_html__( 'Nie rozpoznano', 'adinet-panel' ); ?></strong></div>
						<div><small><?php esc_html_e( 'Plik', 'adinet-panel' ); ?></small><code><?php echo esc_html( $htaccess_status['path'] ); ?></code></div>
					</div>
				</div>

				<p class="adinet-help <?php echo $htaccess_status['rules_match'] ? '' : 'adinet-help--warning'; ?>">
					<?php echo esc_html( ! $htaccess_status['block_valid'] ? __( 'Blok AdiNet jest niekompletny lub niejednoznaczny. Zapis zostanie odrzucony; uporządkuj markery przez FTP.', 'adinet-panel' ) : ( $htaccess_status['rules_match'] ? __( 'Blok w pliku odpowiada ustawieniom panelu. Wykonanie reguł przez serwer nie było testowane.', 'adinet-panel' ) : __( 'Plik różni się od ustawień panelu lub nie zawiera prawidłowo położonego bloku. Zapisz reguły i sprawdź stronę.', 'adinet-panel' ) ) ); ?>
				</p>
				<p class="adinet-help"><?php esc_html_e( 'Przed zmianą istniejącego pliku zapisujemy jedną ostatnią kopię do .htaccess.adinet-backup w tym samym katalogu. Przy błędzie strony możesz przywrócić ją przez FTP. Włącz wyświetlanie plików ukrytych.', 'adinet-panel' ); ?> <?php echo $htaccess_status['backup_exists'] ? esc_html__( 'Kopia jest dostępna.', 'adinet-panel' ) : esc_html__( 'Kopia powstanie przy pierwszej zmianie istniejącego pliku.', 'adinet-panel' ); ?></p>
				<?php if ( ! $htaccess_status['compatible'] ) : ?>
					<p class="adinet-help adinet-help--warning"><?php esc_html_e( 'Nagłówek serwera nie wskazuje Apache ani LiteSpeed. Reguły .htaccess mogą być ignorowane, np. przez samodzielny Nginx.', 'adinet-panel' ); ?></p>
				<?php endif; ?>

				<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" class="adinet-htaccess-form<?php echo $can_manage ? '' : ' is-readonly'; ?>" data-adinet-readonly="<?php echo $can_manage ? '0' : '1'; ?>">
					<input type="hidden" name="action" value="adinet_save_htaccess">
					<?php wp_nonce_field( 'adinet_save_htaccess' ); ?>

					<div class="adinet-htaccess-rules">
						<?php foreach ( $htaccess_rules as $rule_id => $rule ) : ?>
							<label class="adinet-htaccess-rule">
								<input
									type="checkbox"
									name="adinet_htaccess_rules[<?php echo esc_attr( $rule_id ); ?>]"
									value="1"
									<?php checked( ! empty( $selected_htaccess[ $rule_id ] ) ); ?>
								>
								<span>
									<span class="adinet-htaccess-rule__heading">
										<strong><?php echo esc_html( $rule['label'] ); ?></strong>
										<?php if ( 'warning' === $rule['level'] ) : ?>
											<em><?php esc_html_e( 'Sprawdź skutki', 'adinet-panel' ); ?></em>
										<?php elseif ( 'recommended' === $rule['level'] ) : ?>
											<em class="is-recommended"><?php esc_html_e( 'Polecane', 'adinet-panel' ); ?></em>
										<?php endif; ?>
									</span>
									<small><?php echo esc_html( $rule['description'] ); ?></small>
								</span>
							</label>
						<?php endforeach; ?>
					</div>

					<div class="adinet-htaccess-save">
						<div>
							<strong><?php esc_html_e( 'Osobny zapis konfiguracji serwera', 'adinet-panel' ); ?></strong>
							<span><?php esc_html_e( 'Zapisuje tylko reguły .htaccess. Ochrona kopii FTP pozostaje zawsze; inne ustawienia zapiszesz niebieskim przyciskiem.', 'adinet-panel' ); ?></span>
						</div>
						<?php submit_button( __( 'Zapisz reguły .htaccess', 'adinet-panel' ), 'secondary', 'submit', false, $htaccess_status['writable'] ? array() : array( 'disabled' => 'disabled' ) ); ?>
					</div>
				</form>

				<p class="adinet-help adinet-help--danger"><?php esc_html_e( 'Błędna reguła .htaccess może spowodować błąd 500. Po zmianie sprawdź stronę w nowej karcie. Dyrektywy php_flag wymagają zgodnego trybu obsługi PHP, blokada XML-RPC może przerwać działanie zewnętrznych integracji, a HTTPS może kolidować z nietypową konfiguracją proxy.', 'adinet-panel' ); ?></p>
			</section>

			<form action="options.php" method="post" class="adinet-card adinet-update-channel">
				<?php settings_fields( self::UPDATE_CHANNEL_GROUP ); ?>
				<label for="adinet-update-channel"><?php esc_html_e( 'Kanał aktualizacji', 'adinet-panel' ); ?></label>
				<select id="adinet-update-channel" name="<?php echo esc_attr( AdiNet_Options::UPDATE_CHANNEL ); ?>" <?php disabled( ! $can_manage ); ?>>
					<option value="stable" <?php selected( AdiNet_Options::get_update_channel(), 'stable' ); ?>>Stable</option>
					<option value="beta" <?php selected( AdiNet_Options::get_update_channel(), 'beta' ); ?>>Beta</option>
				</select>
				<?php if ( $can_manage ) : ?>
					<?php submit_button( __( 'Zapisz kanał', 'adinet-panel' ), 'secondary', 'submit', false ); ?>
				<?php endif; ?>
			</form>

			<section class="adinet-contact" aria-labelledby="adinet-contact-title">
				<div class="adinet-contact__intro">
					<span class="adinet-contact__icon dashicons dashicons-sos" aria-hidden="true"></span>
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Pomoc techniczna', 'adinet-panel' ); ?></p>
						<h2 id="adinet-contact-title"><?php esc_html_e( 'Potrzebujesz wsparcia?', 'adinet-panel' ); ?></h2>
						<p><?php esc_html_e( 'Skontaktuj się z AdiNet w sprawie działania lub obsługi strony internetowej.', 'adinet-panel' ); ?></p>
					</div>
				</div>
				<div class="adinet-contact__methods">
					<a href="mailto:kontakt@adinet.pl" class="adinet-contact-method is-preferred">
						<span class="dashicons dashicons-email" aria-hidden="true"></span>
						<span>
							<small><?php esc_html_e( 'Preferowana forma kontaktu', 'adinet-panel' ); ?></small>
							<strong>kontakt@adinet.pl</strong>
						</span>
					</a>
					<a href="tel:+48793032998" class="adinet-contact-method">
						<span class="dashicons dashicons-phone" aria-hidden="true"></span>
						<span>
							<small><?php esc_html_e( 'Telefon', 'adinet-panel' ); ?></small>
							<strong>+48 793 032 998</strong>
						</span>
					</a>
				</div>
			</section>

			</div>
		<?php
	}
}
