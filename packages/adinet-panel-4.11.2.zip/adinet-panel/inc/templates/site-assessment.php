<?php
/**
 * Ekran rocznej oceny dla opiekuna AdiNet.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$assessment_details = array(
	__( 'Data uruchomienia', 'adinet-panel' )            => AdiNet_Site_Assessment::format_date( $site['launch'] ),
	__( 'Wiek strony', 'adinet-panel' )                  => $site['age'],
	__( 'Ostatni zatwierdzony audyt', 'adinet-panel' )    => AdiNet_Site_Assessment::format_date( $approved['date'] ?? '' ),
	'WordPress'                                        => $environment['wordpress'],
	'PHP'                                              => $environment['php'],
	'Divi'                                             => $divi_label,
);
$divi_needs_mode = AdiNet_Site_Assessment::needs_compatibility( $environment );
$complete        = ! in_array( null, $draft['scores'], true );
?>
<div class="wrap adinet-admin adinet-assessment">
	<header class="adinet-hero adinet-assessment__hero">
		<div class="adinet-hero__content">
			<h1><?php esc_html_e( 'Audyt i ocena serwisu', 'adinet-panel' ); ?></h1>
			<p><?php esc_html_e( 'Coroczna ocena witryny w ramach opieki AdiNet RAS.', 'adinet-panel' ); ?></p>
		</div>
	</header>
	<hr class="wp-header-end" hidden>

	<?php self::render_notice(); ?>

	<section class="adinet-card" aria-labelledby="adinet-assessment-site">
		<div class="adinet-assessment__heading">
			<h2 id="adinet-assessment-site"><?php esc_html_e( 'Informacje o stronie i audycie', 'adinet-panel' ); ?></h2>
			<a href="<?php echo esc_url( AdiNet_Billing::get_page_url() ); ?>"><?php esc_html_e( 'Metryka projektu w Rozliczeniach', 'adinet-panel' ); ?></a>
		</div>
		<dl class="adinet-assessment__facts">
			<?php foreach ( $assessment_details as $label => $value ) : ?>
				<div>
					<dt><?php echo esc_html( $label ); ?></dt>
					<dd><?php echo '' !== $value ? esc_html( $value ) : esc_html__( 'Brak danych', 'adinet-panel' ); ?></dd>
				</div>
			<?php endforeach; ?>
		</dl>
		<div class="adinet-assessment__statuses">
			<span class="adinet-status" id="adinet-assessment-draft-status" <?php echo $state['draft'] ? '' : 'hidden'; ?>><?php esc_html_e( 'Zapisana wersja robocza', 'adinet-panel' ); ?></span>
			<?php if ( $approved ) : ?>
				<span class="adinet-status"><?php esc_html_e( 'Ocena zatwierdzona', 'adinet-panel' ); ?></span>
			<?php endif; ?>
			<?php if ( $latest_visible ) : ?>
				<span class="adinet-status is-good"><?php esc_html_e( 'Opublikowana w kokpicie', 'adinet-panel' ); ?></span>
			<?php elseif ( $published ) : ?>
				<span class="adinet-status"><?php esc_html_e( 'Klient nadal widzi poprzedni komunikat', 'adinet-panel' ); ?></span>
			<?php else : ?>
				<span class="adinet-status"><?php esc_html_e( 'Komunikat ukryty', 'adinet-panel' ); ?></span>
			<?php endif; ?>
		</div>
	</section>

	<form method="post" action="<?php echo esc_url( $action_url ); ?>" id="adinet-assessment-form" data-point-label="<?php esc_attr_e( '%d pkt', 'adinet-panel' ); ?>">
		<?php self::form_fields( $state['revision'] ); ?>
		<input type="hidden" name="assessment[divi_version]" value="<?php echo esc_attr( $environment['divi'] ); ?>">

		<section class="adinet-card" aria-labelledby="adinet-assessment-criteria">
			<h2 id="adinet-assessment-criteria"><?php esc_html_e( 'Kalkulator oceny', 'adinet-panel' ); ?></h2>
			<p><?php esc_html_e( '0 pkt — stan prawidłowy. 1 pkt — umiarkowane problemy. 2 pkt — poważne problemy.', 'adinet-panel' ); ?></p>
			<div class="adinet-assessment__scorebar">
				<output id="adinet-assessment-total" class="adinet-assessment__total" aria-live="polite" aria-atomic="true">
					<strong><span data-total><?php echo esc_html( $draft['total'] ); ?></span> / <?php echo esc_html( AdiNet_Site_Assessment::MAX_SCORE ); ?></strong>
					<span data-interpretation data-partial="<?php esc_attr_e( 'Wynik częściowy — uzupełnij kryteria', 'adinet-panel' ); ?>"><?php echo $complete ? esc_html( $recommendations[ $draft['suggested'] ][1] ) : esc_html__( 'Wynik częściowy — uzupełnij kryteria', 'adinet-panel' ); ?></span>
				</output>
			</div>
			<div class="adinet-assessment__alert" id="adinet-assessment-security" role="alert" <?php echo 2 === $draft['scores']['security'] ? '' : 'hidden'; ?>>
				<?php echo esc_html( self::security_alert() ); ?>
			</div>

			<div class="adinet-assessment__criteria-grid">
				<?php foreach ( $criteria as $key => $criterion ) : ?>
					<?php
					list( $title, $description ) = $criterion;
					$rules = $criterion[2] ?? array();
					$id    = 'adinet-assessment-' . $key;
					?>
					<fieldset class="adinet-assessment__criterion" data-criterion="<?php echo esc_attr( $key ); ?>" aria-describedby="<?php echo esc_attr( $id . '-description' ); ?>">
						<legend><?php echo esc_html( $title ); ?></legend>
						<div id="<?php echo esc_attr( $id . '-description' ); ?>">
							<?php if ( '' !== $description ) : ?>
								<p><?php echo esc_html( $description ); ?></p>
							<?php endif; ?>
							<?php if ( $rules ) : ?>
								<ul class="adinet-assessment__rules">
									<?php foreach ( $rules as $rule ) : ?>
										<li><?php echo esc_html( $rule ); ?></li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
						</div>
						<?php if ( 'performance' === $key ) : ?>
							<label for="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Wynik testu', 'adinet-panel' ); ?></label>
							<div class="adinet-assessment__measurement">
								<select id="<?php echo esc_attr( $id ); ?>" name="assessment[performance_grade]" data-score-select>
									<option value=""><?php esc_html_e( 'Wybierz ocenę A–F', 'adinet-panel' ); ?></option>
									<?php foreach ( AdiNet_Site_Assessment::performance_grades() as $grade => $points ) : ?>
										<option value="<?php echo esc_attr( $grade ); ?>" data-points="<?php echo esc_attr( $points ); ?>" <?php selected( $draft['performance_grade'], $grade ); ?>><?php echo esc_html( $grade ); ?></option>
									<?php endforeach; ?>
								</select>
								<span class="adinet-status" data-points-output><?php echo esc_html( self::score_label( $draft['scores'][ $key ] ) ); ?></span>
							</div>
							<div class="adinet-assessment__measurement-fields">
								<div>
									<label for="adinet-assessment-performance-source"><?php esc_html_e( 'Źródło wyniku', 'adinet-panel' ); ?></label>
									<input type="text" id="adinet-assessment-performance-source" name="assessment[performance_source]" value="<?php echo esc_attr( $draft['performance_source'] ); ?>" placeholder="GTmetrix">
								</div>
								<div>
									<label for="adinet-assessment-performance-date"><?php esc_html_e( 'Data pomiaru', 'adinet-panel' ); ?></label>
									<input type="date" id="adinet-assessment-performance-date" name="assessment[performance_date]" value="<?php echo esc_attr( $draft['performance_date'] ); ?>">
								</div>
							</div>
						<?php elseif ( 'divi' === $key || 'php' === $key ) : ?>
							<?php if ( 'divi' === $key && $divi_needs_mode ) : ?>
								<label for="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Czy moduły działają w trybie zgodności?', 'adinet-panel' ); ?></label>
								<div class="adinet-assessment__measurement">
									<select id="<?php echo esc_attr( $id ); ?>" name="assessment[divi_compatibility]" data-score-select>
										<option value=""><?php esc_html_e( 'Potwierdź tryb zgodności', 'adinet-panel' ); ?></option>
										<?php foreach ( AdiNet_Site_Assessment::compatibility_scores() as $mode => $points ) : ?>
											<option value="<?php echo esc_attr( $mode ); ?>" data-points="<?php echo esc_attr( $points ); ?>" <?php selected( $draft['divi_compatibility'], $mode ); ?>><?php echo 'yes' === $mode ? esc_html__( 'Tak', 'adinet-panel' ) : esc_html__( 'Nie', 'adinet-panel' ); ?></option>
										<?php endforeach; ?>
									</select>
									<span class="adinet-status" data-points-output><?php echo esc_html( self::score_label( $draft['scores'][ $key ] ) ); ?></span>
								</div>
							<?php else : ?>
								<p>
									<strong><?php echo esc_html( 'divi' === $key ? $divi_label : $environment['php'] ); ?></strong>
									<span class="adinet-status" data-fixed-score="<?php echo esc_attr( $draft['scores'][ $key ] ?? '' ); ?>"><?php echo esc_html( self::score_label( $draft['scores'][ $key ] ) ); ?></span>
								</p>
							<?php endif; ?>
						<?php else : ?>
							<div class="adinet-assessment__choices">
								<?php for ( $points = 0; $points <= 2; ++$points ) : ?>
									<label>
										<input type="radio" name="assessment[scores][<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $points ); ?>" <?php checked( $draft['scores'][ $key ], $points ); ?>>
										<span><?php echo esc_html( self::score_label( $points ) ); ?></span>
									</label>
								<?php endfor; ?>
							</div>
						<?php endif; ?>
						<details class="adinet-assessment__notes" <?php echo '' !== $draft['notes'][ $key ] ? 'open' : ''; ?>>
							<summary><?php esc_html_e( 'Uwagi opiekuna (prywatne)', 'adinet-panel' ); ?></summary>
							<label for="<?php echo esc_attr( $id . '-notes' ); ?>" class="screen-reader-text"><?php echo esc_html( $title . ' — ' . __( 'uwagi opiekuna', 'adinet-panel' ) ); ?></label>
							<textarea id="<?php echo esc_attr( $id . '-notes' ); ?>" name="assessment[notes][<?php echo esc_attr( $key ); ?>]" rows="3"><?php echo esc_textarea( $draft['notes'][ $key ] ); ?></textarea>
						</details>
					</fieldset>
				<?php endforeach; ?>
			</div>
			<div class="adinet-assessment__actions">
				<button type="submit" name="operation" value="draft" class="button"><?php esc_html_e( 'Zapisz wersję roboczą', 'adinet-panel' ); ?></button>
				<button type="submit" name="operation" value="approve" class="button button-primary"><?php esc_html_e( 'Zatwierdź ocenę', 'adinet-panel' ); ?></button>
				<span id="adinet-assessment-autosave" tabindex="-1" role="status"
					data-saving="<?php esc_attr_e( 'Zapisywanie wersji roboczej…', 'adinet-panel' ); ?>"
					data-saved="<?php esc_attr_e( 'Zapisano automatycznie.', 'adinet-panel' ); ?>"
					data-conflict="<?php esc_attr_e( 'Audyt zmienił się w innej karcie. Odśwież stronę przed ponownym zapisem.', 'adinet-panel' ); ?>"
					data-error="<?php esc_attr_e( 'Automatyczny zapis się nie powiódł. Spróbuj zapisać wersję roboczą przyciskiem.', 'adinet-panel' ); ?>"></span>
			</div>
		</section>

		<section class="adinet-card" aria-labelledby="adinet-assessment-recommendation-title">
			<h2 id="adinet-assessment-recommendation-title"><?php esc_html_e( 'Wynik i rekomendacja', 'adinet-panel' ); ?></h2>
			<ul class="adinet-assessment__ranges">
				<?php $minimum = 0; ?>
				<?php foreach ( $recommendations as $key => list( $maximum, $interpretation, $label ) ) : ?>
					<li data-recommendation="<?php echo esc_attr( $key ); ?>" data-maximum="<?php echo esc_attr( $maximum ); ?>" class="<?php echo $complete && $draft['suggested'] === $key ? 'is-current' : ''; ?>">
						<strong><?php echo esc_html( $minimum . '–' . $maximum ); ?></strong>
						<span><?php echo esc_html( $interpretation ); ?></span>
					</li>
					<?php $minimum = $maximum + 1; ?>
				<?php endforeach; ?>
			</ul>
			<p><?php esc_html_e( 'Punktacja podpowiada rekomendację. Zatwierdź ją zgodnie z ustaleniami audytu.', 'adinet-panel' ); ?></p>
			<label class="adinet-assessment__field" for="adinet-assessment-recommendation">
				<strong><?php esc_html_e( 'Rekomendacja opiekuna', 'adinet-panel' ); ?></strong>
				<select id="adinet-assessment-recommendation" name="assessment[recommendation]" aria-describedby="adinet-assessment-override-hint">
					<option value=""><?php esc_html_e( 'Użyj sugestii z punktacji', 'adinet-panel' ); ?></option>
					<?php foreach ( $recommendations as $key => list( $maximum, $interpretation, $label ) ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $draft['recommendation'], $key ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label class="adinet-assessment__field" for="adinet-assessment-override-reason" id="adinet-assessment-override">
				<strong><?php esc_html_e( 'Uzasadnienie zmiany rekomendacji (opcjonalne, prywatne)', 'adinet-panel' ); ?></strong>
				<span id="adinet-assessment-override-hint" class="description"><?php esc_html_e( 'Możesz zapisać tu powody swojej decyzji.', 'adinet-panel' ); ?></span>
				<textarea id="adinet-assessment-override-reason" name="assessment[override_reason]" rows="3"><?php echo esc_textarea( $draft['override_reason'] ); ?></textarea>
			</label>
		</section>

		<section class="adinet-card" aria-labelledby="adinet-assessment-client-title">
			<h2 id="adinet-assessment-client-title"><?php esc_html_e( 'Komunikat dla klienta', 'adinet-panel' ); ?></h2>
			<label class="adinet-assessment__field" for="adinet-assessment-client-reason">
				<strong><?php esc_html_e( 'Indywidualne uzasadnienie dla klienta (opcjonalne)', 'adinet-panel' ); ?></strong>
				<span id="adinet-assessment-client-hint" class="description"><?php esc_html_e( 'Przy przebudowie lub budowie nowego serwisu wpisany tekst trafi do propozycji e-mail i do komunikatu w kokpicie po publikacji.', 'adinet-panel' ); ?></span>
				<textarea id="adinet-assessment-client-reason" name="assessment[client_reason]" rows="4" aria-describedby="adinet-assessment-client-hint"><?php echo esc_textarea( $draft['client_reason'] ); ?></textarea>
			</label>
			<div class="adinet-assessment__actions">
				<button type="submit" name="operation" value="draft" class="button"><?php esc_html_e( 'Zapisz wersję roboczą', 'adinet-panel' ); ?></button>
				<button type="submit" name="operation" value="approve" class="button button-primary"><?php esc_html_e( 'Zatwierdź ocenę', 'adinet-panel' ); ?></button>
			</div>
		</section>
	</form>

	<?php if ( $approved ) : ?>
		<section class="adinet-card" aria-labelledby="adinet-assessment-approval-title">
			<h2 id="adinet-assessment-approval-title"><?php esc_html_e( 'Zatwierdzona ocena', 'adinet-panel' ); ?></h2>
			<?php if ( 2 === $approved['scores']['security'] ) : ?>
				<p class="adinet-assessment__alert"><?php echo esc_html( self::security_alert() ); ?></p>
			<?php endif; ?>
			<?php $message = AdiNet_Site_Assessment::client_message( $approved ); ?>
			<p class="adinet-assessment__approved-summary">
				<time datetime="<?php echo esc_attr( $message['date'] ); ?>"><?php echo esc_html( AdiNet_Site_Assessment::format_date( $message['date'] ) ); ?></time>
				<strong><?php echo esc_html( $approved['total'] . ' / ' . AdiNet_Site_Assessment::MAX_SCORE ); ?></strong>
				<span><?php echo esc_html( $recommendations[ $approved['recommendation'] ][2] ); ?></span>
			</p>
			<details class="adinet-assessment__approved">
				<summary><?php esc_html_e( 'Punktacja i prywatne ustalenia', 'adinet-panel' ); ?></summary>
				<p>
					<?php
					/* translators: 1: WordPress version, 2: PHP version, 3: Divi version or not applicable. */
					echo esc_html( sprintf( __( 'Środowisko w dniu audytu: WordPress %1$s · PHP %2$s · Divi: %3$s', 'adinet-panel' ), $approved['environment']['wordpress'], $approved['environment']['php'], self::divi_label( $approved['environment'] ) ) );
					?>
				</p>
				<dl class="adinet-assessment__approved-scores">
					<?php foreach ( $criteria as $key => list( $title, $description ) ) : ?>
						<div>
							<dt><?php echo esc_html( $title ); ?></dt>
							<dd>
								<strong><?php echo esc_html( self::score_label( $approved['scores'][ $key ] ) ); ?></strong>
								<?php if ( 'performance' === $key ) : ?>
									<span><?php echo esc_html( implode( ' · ', array_filter( array( $approved['performance_grade'], $approved['performance_source'], AdiNet_Site_Assessment::format_date( $approved['performance_date'] ) ) ) ) ); ?></span>
								<?php endif; ?>
								<?php if ( '' !== $approved['notes'][ $key ] ) : ?>
									<p class="adinet-assessment__plain-text"><?php echo esc_html( $approved['notes'][ $key ] ); ?></p>
								<?php endif; ?>
							</dd>
						</div>
					<?php endforeach; ?>
				</dl>
				<?php if ( '' !== $approved['override_reason'] ) : ?>
					<p class="adinet-assessment__plain-text"><strong><?php esc_html_e( 'Uzasadnienie zmiany rekomendacji', 'adinet-panel' ); ?></strong><br><?php echo esc_html( $approved['override_reason'] ); ?></p>
				<?php endif; ?>
			</details>

			<div class="adinet-assessment__preview">
				<h3><?php esc_html_e( 'Podgląd komunikatu dla klienta', 'adinet-panel' ); ?></h3>
				<strong><?php echo esc_html( $message['status'] ); ?></strong>
				<p class="adinet-assessment__plain-text"><?php echo esc_html( $message['body'] ); ?></p>
			</div>
			<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="adinet-assessment__actions">
				<?php self::form_fields( $state['revision'] ); ?>
				<?php if ( ! $latest_visible || $published['message'] !== $message ) : ?>
					<button type="submit" name="operation" value="publish" class="button button-primary"><?php echo $latest_visible ? esc_html__( 'Zaktualizuj komunikat w kokpicie', 'adinet-panel' ) : esc_html__( 'Opublikuj w kokpicie klienta', 'adinet-panel' ); ?></button>
				<?php endif; ?>
				<?php if ( $published ) : ?>
					<button type="submit" name="operation" value="hide" class="button"><?php esc_html_e( 'Ukryj ocenę przed klientem', 'adinet-panel' ); ?></button>
				<?php endif; ?>
			</form>
		</section>
	<?php endif; ?>

	<section class="adinet-card" aria-labelledby="adinet-assessment-email-title">
		<h2 id="adinet-assessment-email-title"><?php esc_html_e( 'Propozycja dla klienta', 'adinet-panel' ); ?></h2>
		<?php if ( $email ) : ?>
			<label class="adinet-assessment__field" for="adinet-assessment-email-subject">
				<strong><?php esc_html_e( 'Temat', 'adinet-panel' ); ?></strong>
				<input id="adinet-assessment-email-subject" type="text" value="<?php echo esc_attr( $email['subject'] ); ?>">
			</label>
			<label class="adinet-assessment__field" for="adinet-assessment-email-body">
				<strong><?php esc_html_e( 'Treść wiadomości', 'adinet-panel' ); ?></strong>
				<textarea id="adinet-assessment-email-body" rows="17"><?php echo esc_textarea( $email['body'] ); ?></textarea>
			</label>
			<div class="adinet-assessment__actions">
				<button type="button" class="button adinet-copy-button" data-copy-field="adinet-assessment-email-subject" data-default-label="<?php esc_attr_e( 'Kopiuj temat', 'adinet-panel' ); ?>" data-copied-label="<?php esc_attr_e( 'Skopiowano temat', 'adinet-panel' ); ?>" data-copy-error="<?php esc_attr_e( 'Użyj skrótu kopiowania, aby skopiować zaznaczony temat.', 'adinet-panel' ); ?>"><?php esc_html_e( 'Kopiuj temat', 'adinet-panel' ); ?></button>
				<button type="button" class="button button-primary adinet-copy-button" data-copy-field="adinet-assessment-email-body" data-default-label="<?php esc_attr_e( 'Kopiuj wiadomość', 'adinet-panel' ); ?>" data-copied-label="<?php esc_attr_e( 'Skopiowano wiadomość', 'adinet-panel' ); ?>" data-copy-error="<?php esc_attr_e( 'Użyj skrótu kopiowania, aby skopiować zaznaczoną wiadomość.', 'adinet-panel' ); ?>"><?php esc_html_e( 'Kopiuj wiadomość', 'adinet-panel' ); ?></button>
				<span id="adinet-copy-status" role="status"></span>
			</div>
		<?php else : ?>
			<p><?php esc_html_e( 'Propozycja pojawi się po zatwierdzeniu rekomendacji przebudowy lub budowy nowego serwisu.', 'adinet-panel' ); ?></p>
		<?php endif; ?>
	</section>

	<section class="adinet-card" aria-labelledby="adinet-assessment-contact-title">
		<h2 id="adinet-assessment-contact-title"><?php esc_html_e( 'Status kontaktu z klientem', 'adinet-panel' ); ?></h2>
		<?php if ( $approved ) : ?>
			<?php $sent_date = AdiNet_Site_Assessment::format_date( $state['sent_on'] ); ?>
			<p><span class="adinet-status"><?php echo '' !== $sent_date ? esc_html( __( 'Wysłano', 'adinet-panel' ) . ' · ' . $sent_date ) : esc_html__( 'Nie wysłano', 'adinet-panel' ); ?></span></p>
			<form method="post" action="<?php echo esc_url( $action_url ); ?>" id="adinet-assessment-contact-form">
				<?php self::form_fields( $state['revision'] ); ?>
				<label><input type="checkbox" id="adinet-assessment-sent" name="sent" value="1" <?php checked( '' !== $state['sent_on'] ); ?>> <?php esc_html_e( 'Wysłano propozycję klientowi', 'adinet-panel' ); ?></label>
				<div class="adinet-assessment__actions">
					<label for="adinet-assessment-sent-on"><?php esc_html_e( 'Data wysłania', 'adinet-panel' ); ?></label>
					<input type="date" id="adinet-assessment-sent-on" name="sent_on" value="<?php echo esc_attr( $state['sent_on'] ); ?>" max="<?php echo esc_attr( $today ); ?>">
					<button type="submit" name="operation" value="contact-today" class="button" data-today="<?php echo esc_attr( $today ); ?>" formnovalidate><?php esc_html_e( 'Dzisiaj', 'adinet-panel' ); ?></button>
				</div>
				<button type="submit" name="operation" value="contact" class="button button-primary"><?php esc_html_e( 'Zapisz status kontaktu', 'adinet-panel' ); ?></button>
			</form>
		<?php else : ?>
			<p><?php esc_html_e( 'Status kontaktu będzie dostępny po zatwierdzeniu oceny.', 'adinet-panel' ); ?></p>
		<?php endif; ?>
	</section>
</div>
