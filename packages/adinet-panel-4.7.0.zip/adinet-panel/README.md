# AdiNet Panel

Samodzielna wtyczka administracyjno-serwisowa dla WordPressa. Nie zależy od Divi ani od żadnego innego motywu lub kreatora stron.

## Wymagania

- WordPress 6.0 lub nowszy,
- PHP 7.4 lub nowszy,
- uprawnienie administratora `manage_options` do podglądu panelu.

## Instalacja

1. Wgraj katalog `adinet-panel` do `wp-content/plugins/` albo zainstaluj przygotowany plik ZIP przez **Wtyczki → Dodaj wtyczkę → Wyślij wtyczkę na serwer**.
2. Aktywuj wtyczkę **AdiNet Panel**.
3. Otwórz pozycję **AdiNet** w głównym menu administracyjnym lub **AdiNet Panel** na górnym pasku WordPressa. Skrót na pasku widzą administratorzy również podczas przeglądania strony; uprawnienia edycji panelu pozostają bez zmian.

## Aktualizacje

W sekcji **Kanał aktualizacji**, pod regułami .htaccess w panelu **AdiNet**, wybierz **Stable** (domyślny) albo **Beta**. Przełącznik automatycznych aktualizacji na ekranie **Wtyczki** obowiązuje na obu kanałach. Po zmianie kanału WordPress pobierze aktualny manifest. Zmiana z Beta na Stable nie obniża już zainstalowanej wersji.

Od 4.6.0 updater wymaga rozszerzenia PHP OpenSSL. Sprawdza podpis manifestu oraz SHA-256 ZIP-a. Serwer udostępnia osobne manifesty Stable i Beta, a paczki można pobrać przez HTTPS.

Seria **4.x** jest punktem odniesienia dla wydań z wbudowanym systemem aktualizacji. Mechanizm był już dostępny w 3.3.x; wersje 3.2.x i starsze wymagają jednorazowego ręcznego wgrania nowszej paczki. Wersja 4.4 dodaje panel powitalny w kokpicie i skrót „+1 rok” dla daty przedłużenia w Rozliczeniach. Wersja 4.4.1 wyróżnia panel powitalny wizualnie, 4.4.2 poprawia czytelność nagłówków, a 4.4.3 umieszcza panel na pełnej szerokości kokpitu i usuwa wcześniejszy wąski widżet. Wersja 4.4.4 dodaje automatyczną domenę witryny do shortcode’u `[adinet_footer]`. Wersja 4.5 pokazuje aktualną kwotę do zapłaty w kokpicie, dodaje zbiorczą zmianę numeru faktury i przycisk uruchomienia monitoringu bezpośrednio na podstronie Monitoring 404.

Panel powitalny widzą wszyscy użytkownicy kokpitu WordPressa, niezależnie od roli. Pokazuje kontakt do opiekuna strony, przydatne linki oraz kartę „Twoje rozliczenia”. Aktualna kwota do zapłaty to suma wszystkich pozycji „Wezwano do zapłaty”, również jednorazowych, bez ograniczenia do daty zakupu, odnowienia lub miesiąca rocznego rozliczenia. Karta pokazuje usługi i numery faktur / pro form. Pozycje oczekujące na rozliczenie są wykazywane osobno, a rozliczone pozostają w historii. Brak ceny jest oznaczany jako „Do wyliczenia”. Gdy wszystkie zapisane pozycje są rozliczone, karta pokazuje 0,00 zł i „Wszystko opłacone”. Prognoza kolejnego rocznego rozliczenia jest osobnym rozwijanym elementem; kwota odnowień pozostaje orientacyjna. Link do pełnych Rozliczeń widzą użytkownicy z uprawnieniem podglądu panelu.

AdiNet Panel korzysta ze standardowego systemu aktualizacji WordPressa, ale pobiera informacje o wydaniach i paczki z publicznego repozytorium `adinetpl/adinetpanel-updates`. Nowa wersja pojawia się na ekranie **Wtyczki** oraz **Kokpit → Aktualizacje** i może zostać zainstalowana przyciskiem **Zaktualizuj teraz**.

Standardowy przełącznik **Włącz automatyczne aktualizacje** pozwala uruchomić aktualizacje automatyczne osobno na każdej witrynie. Wtyczka nie wymusza ich włączenia i respektuje blokady WordPressa, uprawnienia systemu plików oraz konfigurację WP-Cron.

Niedostępność GitHuba nie wyłącza działającej instalacji. Powoduje jedynie, że WordPress nie otrzyma w danym momencie informacji o nowym wydaniu.

## Dostęp do ustawień

Każdy administrator może zobaczyć panel, Rozliczenia, zarządzanie aktualizacjami i bibliotekę Wtyczki, wyniki Monitoringu 404 i Logu administracyjnego. Zmieniać główne ustawienia i blokady aktualizacji, zapisywać reguły `.htaccess`, czyścić dane oraz instalować i aktywować paczki z biblioteki może wyłącznie administrator o loginie `adinet`. Rozliczenia może edytować administrator o loginie `adinet` albo adresie e-mail `kontakt@adinet.pl`; pozostali administratorzy mają podgląd tylko do odczytu.

Na pojedynczej stronie można wskazać innego właściciela poza panelem, w pliku `wp-config.php`:

```php
define( 'ADINET_PANEL_OWNER_LOGIN', 'twoj-login-adinet' );
```

Adres właściciela Rozliczeń można zmienić analogicznie:

```php
define( 'ADINET_PANEL_OWNER_EMAIL', 'twoj-email-adinet@example.com' );
```

Stałą należy dodać przed linią `/* That's all, stop editing! */`. Właściciel musi nadal być administratorem WordPressa. Ograniczenie chroni panel przed przypadkowymi zmianami innych administratorów, ale nie zastępuje kontroli dostępu do hostingu ani wtyczek.

## Przejście z motywu „Divi & AdiNet 2”

Wtyczka korzysta z tych samych opcji `adinet_*`, dlatego zachowuje istniejącą notatkę, daty projektu, datę audytu, ustawienia e-maili, diagnostyki, WP-Cron i wybrane reguły `.htaccess`.

Wtyczka nie sprawdza aktywnego motywu i uruchamia się od razu po aktywacji. Przy przejściu ze starej wersji motywowej trzeba samodzielnie dopilnować, aby te same funkcje nie pozostały równocześnie aktywne w motywie.

1. Przełącz motyw potomny **Divi & AdiNet 2** na Divi albo inny docelowy motyw.
2. Wgraj i aktywuj **AdiNet Panel**.
3. Otwórz panel AdiNet i sprawdź zapisane ustawienia oraz stan WP-Cron i `.htaccess`.
4. Dopiero po teście usuń stary motyw potomny.

Samo przełączenie motywu nie usuwa ustawień AdiNet z bazy.

## Funkcje

Panel rozpoczyna się od bieżącego stanu technicznego witryny, następnie grupuje funkcje witryny i narzędzia serwisowe. Informacje o projekcie znajdują się na podstronie **AdiNet → Rozliczenia**. Diagnostyka, WP-Cron oraz ustawienia bezpieczeństwa znajdują się niżej, a osobno zapisywane reguły `.htaccess` pozostają ostatnim blokiem konfiguracyjnym. Nagłówek wykorzystuje pełne logo AdiNet z pliku `Logo_400_bialetlo.png`.

Na głównej stronie AdiNet ukrywane są globalne komunikaty WordPressa i innych wtyczek, aby nie rozdzielały elementów panelu. Komunikaty własne AdiNet, w tym potwierdzenia wykonanych działań i ostrzeżenia, pozostają widoczne. W pozostałych ekranach kokpitu wszystkie komunikaty działają standardowo.

Główny formularz ma przycisk **Zapisz ustawienia** na początku oraz stale widoczny pasek przy dolnej krawędzi ekranu. Pasek wskazuje niezapisane zmiany i zapisuje cały formularz. Przełączniki zaczynają działać po zapisie. Reguły `.htaccess` mają osobny formularz; próba ich zapisania z niezapisanymi ustawieniami głównymi wymaga potwierdzenia utraty tych zmian.

### Zarządzanie aktualizacjami wtyczek

Od 4.7.0 domyślna zakładka **AdiNet → Wtyczki → Zarządzanie aktualizacjami** pokazuje wszystkie zainstalowane wtyczki: aktywne i nieaktywne, również spoza biblioteki AdiNet. Właściciel panelu może zaznaczyć jedną lub kilka pozycji i wybrać **Zablokuj aktualizacje** albo **Odblokuj aktualizacje**. Przy blokowaniu można podać wspólny powód (do 300 znaków). Tabela pokazuje powód, datę i konto ustawiające blokadę. Pozostali administratorzy mają podgląd bez formularza; bezpośredni zapis wymaga uprawnienia właściciela i tokenu bezpieczeństwa.

Blokada usuwa oferty wybranych wtyczek ze standardowej listy aktualizacji WordPressa, komunikatów i licznika. **Aktualizuj wszystko** pomija te pozycje; aktualizacje automatyczne i standardowa próba instalacji aktualizacji również są blokowane. Na liście wtyczek pozostaje etykieta „Aktualizacje zablokowane przez AdiNet”. Zablokowanie nie zmienia zapisanej preferencji automatycznych aktualizacji — po odblokowaniu ponownie obowiązuje jej wcześniejsze ustawienie. Blokada dotyczy także właściciela panelu, dopóki świadomie jej nie zdejmie.

Odblokowanie czyści pamięć informacji o aktualizacjach, ale samo nie uruchamia instalacji. WordPress przy ponownym sprawdzeniu pobiera dostępne wersje; do tego czasu nie należy traktować braku oferty jako potwierdzenia aktualności. Włączenie i zdjęcie blokady trafiają do Logu administracyjnego, jeśli jest aktywny. Nowe wtyczki domyślnie mają aktualizacje dozwolone. Ustawienia są zachowywane po dezaktywacji AdiNet, ale blokady działają tylko wtedy, gdy wtyczka jest aktywna.

Funkcja zabezpiecza standardową obsługę WordPressa przed przypadkową aktualizacją. Nie blokuje podmiany plików przez hosting/FTP ani narzędzi omijających WordPress; własne instalatory i powiadomienia producentów mogą wymagać osobnej integracji. Motywy i rdzeń WordPressa pozostają poza zakresem. W multisite blokady są wspólne dla sieci, a ich zapis wymaga dodatkowo `manage_network_plugins`; aby działały w całej sieci, AdiNet powinien być aktywny w całej sieci.

### Instalator wtyczek

Zakładka **AdiNet → Wtyczki → Biblioteka AdiNet** pobiera aktualną listę paczek ZIP z `https://adinet.pl/adinet-panel/wtyczki/?format=json`. Lista nie wymaga ręcznego podawania nazw wtyczek ani wersji — po dodaniu pliku ZIP do katalogu serwera pojawia się przy kolejnym odświeżeniu strony. Przeglądanie zarządzania aktualizacjami nie wymaga połączenia z biblioteką.

Instalacja korzysta ze standardowego `Plugin_Upgrader` WordPressa, a aktywacja jest osobną czynnością. Panel nie nadpisuje już istniejącego folderu wtyczki i nie porównuje wersji paczek. Po udanej instalacji automatycznie zapamiętuje główny plik wtyczki, aby pokazywać stan „Zainstalowana, nieaktywna” albo „Aktywna”.

Przyciski **Zainstaluj** i **Aktywuj** są dostępne wyłącznie właścicielowi panelu i wymagają dodatkowo natywnych uprawnień `install_plugins` oraz `activate_plugins`. Bezpośrednie wywołania akcji są chronione tym samym sprawdzeniem oraz tokenem bezpieczeństwa WordPressa. `DISALLOW_FILE_MODS` i brak dostępu WordPressa do systemu plików nadal blokują instalację.

### Shortcode’y

`[year]` wyświetla bieżący rok zgodnie ze strefą czasową WordPressa. Dla zgodności ze starszą wersją obsługiwany jest także parametr `format`, np. `[year format="Y – F"]`.

`[adinet_footer]` wyświetla gotową stopkę:

```text
© bieżący rok domena.pl | Stworzone i obsługiwane przez AdiNet
```

Domena jest pobierana automatycznie z adresu strony ustawionego w WordPressie, bez protokołu, portu i ścieżki.

Nazwa AdiNet prowadzi do `https://adinet.pl`.

### E-maile o automatycznych aktualizacjach

Panel oferuje trzy tryby:

- **Wszystkie powiadomienia** — standardowe zachowanie WordPressa.
- **Tylko błędy i alerty krytyczne** — tryb domyślny; wycisza wiadomości o udanych aktualizacjach.
- **Nie wysyłaj żadnych** — wycisza wszystkie systemowe e-maile o automatycznych aktualizacjach.

Ustawienie nie wyłącza aktualizacji i nie obejmuje wiadomości generowanych niezależnie przez inne wtyczki.

### Globalna blokada komentarzy

Opcjonalny przełącznik całkowicie wyłącza komentarze, pingbacki i trackbacki dla wpisów, stron oraz wszystkich niestandardowych typów treści — także utworzonych wcześniej. Blokada obejmuje standardowy formularz WordPressa, REST API i XML-RPC, ukrywa publiczne formularze, zapisane komentarze, liczniki i odnośniki do kanałów komentarzy oraz porządkuje panel administracyjny.

Funkcja nie usuwa komentarzy ani nie zmienia statusów poszczególnych treści w bazie. Po jej wyłączeniu WordPress wraca do wcześniejszych ustawień. Administrator może nadal otworzyć ekran starych komentarzy przez bezpośredni adres `wp-admin/edit-comments.php`.

WooCommerce przechowuje recenzje produktów jako komentarze. Globalna blokada wyłącza również recenzje oraz inne funkcje wtyczek oparte na systemie komentarzy WordPressa.

### Monitoring 404

Opcjonalny Monitoring 404 przez siedem dni zlicza publiczne adresy IPv4 i IPv6, z których wywoływane są błędy 404. W głównym panelu AdiNet znajduje się przełącznik funkcji, jej stan oraz okres zbierania danych. Wyniki są dostępne na osobnej podstronie **AdiNet → Monitoring 404**. Gdy monitoring jest wyłączony lub zakończony, właściciel panelu może uruchomić go bezpośrednio na tej podstronie przyciskiem **Uruchom monitoring na 7 dni**. Po uruchomieniu pozostaje na stronie raportu. Aktywna sesja nie pokazuje przycisku startu, a ponowione żądanie nie czyści wyników ani nie przedłuża terminu.

Wtyczka przechowuje po jednym zagregowanym rekordzie dla każdego adresu IP: licznik błędów, pierwsze i ostatnie wystąpienie. Nie zapisuje wywoływanego adresu URL, nagłówka User-Agent ani strony odsyłającej. Podstrona pokazuje pięć IP z największą liczbą błędów, datę pierwszego i ostatniego wejścia, kopiuje sam adres IP oraz otwiera raporty w AbuseIPDB i GreyNoise. Po ręcznym utworzeniu reguły blokującej w Cloudflare akcja **Zablokowane** usuwa pojedynczy adres z wyników; sama nie komunikuje się z Cloudflare i nie tworzy reguły.

Po siedmiu dniach monitoring automatycznie przestaje dopisywać nowe zdarzenia, pokazuje stan **Monitoring zakończony**, ale nie usuwa wyników. W panelu widoczny jest zakres dat ostatniego lub bieżącego okresu zbierania. Również ręczne wyłączenie funkcji zachowuje dane. Każde ponowne uruchomienie zakończonego lub wyłączonego monitoringu usuwa wszystkie dotychczasowe rekordy 404. Nie usuwa logu administracyjnego. Niepowodzenie czyszczenia blokuje start nowej sesji. Administrator usuwa je przyciskiem **Wyczyść dane** po zakończeniu analizy. Wyczyszczenie podczas aktywnego monitoringu rozpoczyna pusty zestaw danych bez przedłużania jego terminu.

Tabela jest ograniczona do 5000 unikalnych adresów. Po osiągnięciu limitu liczniki znanych IP są nadal zwiększane, ale nowe adresy nie są dodawane. Nagłówek `CF-Connecting-IP` jest akceptowany tylko wtedy, gdy `REMOTE_ADDR` należy do zaufanego zakresu Cloudflare. `CF-Connecting-IPv6` jest używany wyłącznie przy adresie Pseudo IPv4 w zakresie 240.0.0.0/4. W pozostałych przypadkach używany jest `REMOTE_ADDR`, również gdy hosting już odtworzył w nim IP. Zakresy zweryfikowano 09.09.2026 na oficjalnych listach Cloudflare. Filtr `adinet_trusted_proxy_ranges` pozwala skonfigurować dodatkowe proxy, które muszą samodzielnie usuwać nagłówki dostarczone przez klienta. Nie dodawać 0.0.0.0/0 ani ::/0. Filtr `adinet_404_client_ip` pozwala zmienić wykryty adres w nietypowej konfiguracji proxy.

Monitoring jest narzędziem diagnostycznym, a nie blokadą ruchu. Żądanie musi dotrzeć do WordPressa, aby zostało policzone. Po analizie blokadę lub wyzwanie dla wybranego adresu należy skonfigurować w Cloudflare albo innej warstwie przed serwerem.

### Log administracyjny

Opcjonalny log administracyjny zapisuje istotne zdarzenia związane z bezpieczeństwem i zmianami w witrynie: prawidłowe oraz błędne logowania, wylogowania, tworzenie, modyfikowanie i usuwanie użytkowników, zmiany ról, edycje treści, instalowanie, aktualizowanie, aktywowanie i usuwanie wtyczek lub motywów oraz wybrane ustawienia WordPressa. Od 4.1 dziennik zapisuje wynik osobno dla każdego składnika: sukces, błąd z kodem, pominięcie albo brak potwierdzonego wyniku. Koniec operacji zbiorczej nie jest traktowany jako dowód sukcesu. Zmiany ról są rejestrowane również przez dedykowane hooki WordPressa. Przy operacjach dotyczących wtyczek zapisuje zarówno ich czytelną nazwę, jak i jednoznaczny plik główny, np. `Nazwa wtyczki (katalog/wtyczka.php)`.

Zdarzenia mają trzy czytelnie oznaczone poziomy: **Standardowe**, **Ostrzeżenie** i **Krytyczne**. Pojedyncze błędne logowanie jest ostrzeżeniem, a każde dziesięć prób z jednego IP w ciągu 15 minut tworzy dodatkowy alert krytyczny. Podstrona **AdiNet → Log administracyjny** pozwala filtrować rekordy według użytkownika, poziomu i okresu 24 godzin, 7 albo 30 dni. Nie ma wyszukiwarki pełnotekstowej. Pokazuje także liczby zdarzeń, jednego najaktywniejszego użytkownika oraz wszystkich bieżących administratorów z datą ich ostatniej istotnej zmiany.

Szczegółowe rekordy zawierają datę, użytkownika, poziom, opis działania i — jeśli jest dostępny — adres IP. Są przechowywane przez 30 dni i ograniczone do 10 000 najnowszych pozycji. Data ostatniej aktywności każdego administratora jest przechowywana osobno, dlatego nie znika razem ze starszymi rekordami ani po ręcznym wyczyszczeniu tabeli. Log nie zapisuje haseł, treści formularzy, zawartości edytowanych stron ani poprzednich i nowych wartości ustawień.

Integracja z Divi rozpoznaje edycję strony korzystającej z kreatora, elementy Biblioteki Divi, techniczne typy Theme Buildera oraz wybrane opcje Divi. Zwykła edycja strony lub wpisu, także w Divi, otrzymuje poziom **Standardowe**. Zmiany globalnych szablonów Theme Buildera i jego konfiguracji nadal otrzymują **Ostrzeżenie**. Historyczne wpisy logu zachowują pierwotny poziom. Wtyczka celowo nie porównuje wewnętrznych struktur modułów Divi, dlatego informuje, jaki obiekt został edytowany, ale nie opisuje każdej zmienionej właściwości modułu. Zakres wykrywania może zależeć od wersji Divi i sposobu zapisu użytego przez Elegant Themes.

### Blokada edytorów plików

Opcjonalny przełącznik definiuje `DISALLOW_FILE_EDIT=true` i odbiera administratorom możliwość edytowania kodu motywów oraz wtyczek przez wbudowane edytory WordPressa. Nie blokuje instalowania, usuwania ani aktualizowania motywów i wtyczek.

Jeśli `DISALLOW_FILE_EDIT` albo szersza stała `DISALLOW_FILE_MODS` została wcześniej zdefiniowana w `wp-config.php` lub przez inną warstwę konfiguracji, wcześniejsza wartość ma pierwszeństwo. Panel pokazuje rzeczywisty stan i informuje o konflikcie. Wyłączenie opcji albo całej wtyczki przywraca edytory tylko wtedy, gdy nie blokuje ich zewnętrzna konfiguracja.

Niektóre wtyczki mogą błędnie uzależniać własne funkcje od uprawnienia `edit_plugins`; po włączeniu blokady ich wybrane ekrany mogą stać się niedostępne.

### Notatka i informacje o projekcie

Administrator może zapisać zwykłą notatkę widoczną dla użytkowników z uprawnieniem `manage_options`, a następnie ją edytować albo usunąć. Panel przechowuje również:

- datę opublikowania strony i automatycznie obliczony wiek projektu,
- miesiąc corocznego rozliczenia hostingu i obsługi,
- datę oraz administratora ostatniego audytu technicznego — bez godziny.

Data publikacji, wiek strony i miesiąc rocznego rozliczenia są wyświetlane na podstronie **Rozliczenia**. Data ostatniego audytu pozostaje w głównym panelu.

### Rozliczenia

Podstrona **AdiNet → Rozliczenia** przechowuje koszty dotyczące wyłącznie bieżącej witryny. Każda pozycja zawiera nazwę usługi, opcjonalną cenę, datę zakupu, datę kolejnego przedłużenia, status, opcjonalny numer faktury oraz opis. Brak ceny oznacza **Do wyliczenia**; taka pozycja jest wskazywana obok sumy zamiast być liczona jako 0 zł. Dla usługi lifetime albo jednorazowej termin kolejnego przedłużenia może pozostać pusty.

Dostępne statusy to **Oczekuje na rozliczenie**, **Wezwano do zapłaty** i **Rozliczono**. Podsumowanie pokazuje osobno kwoty i liczbę pozycji w każdym statusie. Konto uprawnione do edycji może zaznaczyć kilka usług lub całą tabelę i zbiorczo zmienić ich status albo numer faktury. Wspólne zaznaczenie obsługuje dwa osobne przyciski: „Zmień status” i „Zmień numer faktury”. Zmiana numeru faktury zastępuje numer tylko w zaznaczonych usługach, bez zmiany statusu; wymagany jest niepusty numer do 100 znaków. Obie operacje wymagają uprawnienia do edycji i właściwego tokenu bezpieczeństwa. Kolejne odnowienie usługi należy dodać jako nową pozycję, dzięki czemu wcześniejsze rozliczenia pozostają w tabeli jako historia. Pozycje można edytować albo trwale usuwać po potwierdzeniu.

Rozliczenia nie mają kategorii, osobnej daty zapłaty, pola cyklu ani eksportu do programu fakturowego. Nie należy zapisywać w opisie haseł, kluczy licencyjnych ani innych danych dostępowych.

### Karta techniczna

Panel pokazuje:

- konto hostingowe wykryte w strukturze dhosting `/home/nazwa.dhosting.pl/konto/…`,
- wersję PHP oraz ocenę jej aktualności,
- silnik i wersję MariaDB/MySQL,
- mechanizm cache stron na podstawie `WP_CACHE`, `advanced-cache.php` i znanych wtyczek,
- trwały object cache z wykrytym backendem, m.in. Redis, Memcached, Object Cache Pro, Docket Cache, Relay lub APCu, oraz widoczne rozszerzenia PHP.

Cache działający wyłącznie po stronie hostingu, reverse proxy albo CDN może nie być widoczny z poziomu WordPressa. Zainstalowane rozszerzenie PHP Redis/Memcached nie jest samo w sobie dowodem działania object cache. Rozpoznawanie innej struktury hostingu można rozszerzyć filtrem `adinet_hosting_info`.

### WP-Cron

Wtyczka może zdefiniować `DISABLE_WP_CRON` podczas swojego ładowania. Wyłącza to uruchamianie zadań przez ruch na stronie, ale nie blokuje bezpośredniego wywołania `wp-cron.php` przez prawdziwy cron serwera.

Najpierw skonfiguruj w dPanelu zadanie typu **Wget**, wykonywane co 10 minut, używając adresu generowanego w panelu. Dopiero potem włącz wyłączenie WP-Cron przez ruch. Definicja `DISABLE_WP_CRON` z `wp-config.php` jest ładowana wcześniej i zawsze ma pierwszeństwo. Wyłączenie wtyczki wyłącza jej kontrolę WP-Cron.

### Rewizje treści

Panel ustawia maksymalną liczbę rewizji przechowywanych osobno dla każdego wpisu, strony i niestandardowego typu treści obsługującego rewizje. Domyślny limit wynosi 10 wersji. Ustawienie korzysta z oficjalnego filtra WordPressa i zastępuje wartość `WP_POST_REVISIONS`, dlatego wcześniejszy wpis `define('WP_POST_REVISIONS', 10);` w `wp-config.php` można usunąć.

Drugi limit określa maksymalny wiek rewizji w dniach; domyślnie jest to 370 dni. Przeterminowane wersje danej treści są usuwane przy jej kolejnym zapisaniu. Funkcja nie wykonuje jednorazowego masowego czyszczenia całej bazy i nie zmienia standardowej obsługi autosave przez WordPressa.

### Własny adres logowania

Opcjonalna funkcja ukrywa `wp-login.php` oraz `wp-admin` przed niezalogowanymi użytkownikami i udostępnia formularz pod własnym adresem. Domyślny slug to `/logowanie`, ale można zmienić go w panelu. Funkcja jest domyślnie wyłączona.

WordPress automatycznie używa nowego adresu w linkach logowania, wylogowania i resetowania hasła. Niezalogowane wejście na `wp-admin` otrzymuje bezpieczną odpowiedź 404 bez uruchamiania szablonu aktywnego motywu. Techniczne punkty `admin-ajax.php`, `admin-post.php` i `async-upload.php` pozostają dostępne. Formularz hasła chroniącego pojedynczy wpis również nadal działa przez standardowy punkt WordPressa.

Niepoprawna zmiana adresu zachowuje poprzedni slug oraz dotychczasowe włączenie funkcji. Pierwsza aktywacja z błędnym slugiem pozostaje zablokowana. Przed wylogowaniem należy skopiować lub zapisać własny adres. Wyłączenie opcji albo całej wtyczki natychmiast przywraca standardowe `wp-login.php`. Przy aktywnym cache strony lub CDN własny adres logowania trzeba wykluczyć z pamięci podręcznej.

### Kontrola wykonania WP-Cron

Od 4.1 wtyczka planuje jedno zadanie `adinet_cron_health_check` co 15 minut i nadpisuje jeden znacznik czasu rzeczywistego wykonania. Nie tworzy historii ani dodatkowej tabeli. Gdy cron od ruchu jest wyłączony, zadanie nadal oczekuje na wywołanie WP-Cron przez hosting, WP-CLI lub inny mechanizm. Panel pokazuje czas ostatniego wykonania, następny termin, oczekiwanie albo ostrzeżenie po ponad 45 minutach bez wykonania. Odśwież panel, aby zobaczyć aktualny stan. Pomiar potwierdza wykonanie zadania, lecz nie identyfikuje jego źródła i nie dowodzi działania wszystkich innych zadań. Dezaktywacja usuwa zadanie kontrolne i jego pomiar.

### Diagnostyka PHP

Wyświetlanie i wymuszone logowanie błędów wygasają po 4 godzinach. Wyświetlanie przechodzi na „Ukrywaj błędy”, logowanie wraca do konfiguracji serwera. Zapis innych ustawień nie przedłuża terminu. Kontrola czasu działa przy ładowaniu wtyczki i nie wymaga WP-Cron. Aktywne ustawienia z 4.0 dostają limit przy pierwszym uruchomieniu 4.1. Błędy na froncie są publiczne; cache może zachować starszą odpowiedź, dlatego diagnozowaną stronę należy wyłączyć z cache.

Panel odczytuje `WP_DEBUG`, `WP_DEBUG_DISPLAY` i `WP_DEBUG_LOG`. Pozwala też niezależnie:

- pozostawić sposób wyświetlania błędów bez zmian, ukryć błędy albo tymczasowo pokazywać je na publicznym froncie,
- pozostawić logowanie bez zmian, włączyć `log_errors` i pełne raportowanie albo wyłączyć `log_errors`.

Tryb pokazywania błędów nie obejmuje panelu, AJAX ani REST API. Wtyczka nie wpływa na błędy powstałe przed jej załadowaniem, dlatego do diagnostyki całego startu WordPressa nadal służy `wp-config.php`. Wyłączenie `log_errors` nie blokuje jawnych wywołań `error_log()` wykonanych przez inne elementy kodu.

Cztery godziny są bezpiecznym domyślnym czasem ręcznej diagnostyki. Przy rzadkim błędzie tryb można włączyć ponownie. Wygaśnięcie ustawienia zatrzymuje wymuszenie AdiNet, lecz nie usuwa pliku i nie wyłącza logowania skonfigurowanego niezależnie w `wp-config.php`, `php.ini` albo hostingu.

Panel pokazuje lokalizacje ujawnione przez `WP_DEBUG_LOG` i `php.ini error_log`, rozmiar pliku oraz czas ostatniej modyfikacji. Właściciel panelu może pobrać albo usunąć istniejący log wewnątrz `wp-content` przez chronioną akcję administracyjną. Wtyczka nie tworzy publicznego linku i nie obsługuje logów serwera ani ścieżek poza `wp-content`; nimi należy zarządzać w dPanelu. Usunięty plik może pojawić się ponownie po następnym błędzie, jeśli logowanie pozostaje aktywne.

### Zarządzane reguły `.htaccess`

AdiNet zapisuje wyłącznie własny blok pomiędzy markerami:

```text
# BEGIN AdiNet
...
# END AdiNet
```

Pozostała zawartość `.htaccess`, w tym blok WordPressa, nie jest zastępowana. Dostępne reguły obejmują ochronę `.htaccess` i `wp-config.php`, blokadę XML-RPC i skanowania autorów, ograniczenie prób logowania LiteSpeed, przekierowanie HTTPS oraz wyłączenie wyświetlania błędów PHP.

Opcja wyłączania błędów PHP dodaje:

```apache
# Wyświetlanie błędów PHP
php_flag display_errors Off
php_flag display_startup_errors Off
```

Dyrektywy `php_flag` działają, gdy serwer udostępnia zgodną obsługę ustawień PHP w `.htaccess`, typowo przy PHP jako module Apache. Przy PHP-FPM, CGI lub FastCGI mogą być niedozwolone i spowodować błąd 500; w takich środowiskach ustawienia należy wprowadzić mechanizmem hostingu albo w `.user.ini`.

Funkcja jest przeznaczona dla Apache i LiteSpeed. Zapis odmawia działania przy niepełnych, podwójnych lub zagnieżdżonych markerach. Istniejący blok AdiNet za blokiem WordPressa jest przenoszony przed niego. Odczyt, modyfikacja i odczyt kontrolny odbywają się pod blokadą pliku. Inne programy edytujące plik muszą respektować blokady, aby uniknąć konfliktu zapisu.

Przed zmianą istniejącego pliku powstaje **jedna kopia `.htaccess.adinet-backup` w tym samym katalogu**, zawierająca dokładne poprzednie bajty. Kolejna zmiana zastępuje kopię; zapis bez zmian jej nie nadpisuje. Błąd utworzenia kopii blokuje zmianę `.htaccess`. Przez FTP włącz widoczność plików ukrytych. Przy awarii pobierz oba pliki, zachowaj wadliwy `.htaccess` lokalnie, a kopię wgraj pod nazwą `.htaccess` i sprawdź witrynę. Kopia ma uprawnienia 0600; w razie potrzeby ustaw przy odtwarzaniu prawa wymagane przez hosting (zwykle 0644). Plik kopii blokowany jest przez stałą regułę FilesMatch. Na serwerze ignorującym `.htaccess` ochronę plików ukrytych musi zapewnić konfiguracja hostingu.

Panel odróżnia wybór reguł w bazie od zgodności bloku w pliku. Zgodny blok nie oznacza potwierdzenia wykonania dyrektyw przez serwer. Po każdej zmianie sprawdź stronę w nowej karcie. Odznaczenie wszystkich opcji usuwa reguły opcjonalne, ale pozostawia ochronę kopii FTP. Dezaktywacja nie usuwa bloku ani kopii.

### Kontakt i narzędzia

Panel zawiera dane kontaktowe AdiNet, dynamiczny odnośnik do dPanelu, dPocztę, panel domen, PageSpeed Insights, WAVE, W3C HTML Checker, Google Search Console, Google Cloud Console, Cloudflare Turnstile oraz narzędzia CERT. Ten sam odnośnik do właściwego konta dPanelu znajduje się bezpośrednio pod ścieżką instalacji w Informacjach technicznych. Odnośniki PageSpeed, WAVE, W3C i Search Console są automatycznie dopasowane do bieżącej witryny. Automatyczny test WAVE pomaga znaleźć część problemów dostępności, ale nie potwierdza pełnej zgodności z WCAG.

Sprawdzanie konkretnych adresów IPv4 i IPv6 w AbuseIPDB i GreyNoise jest dostępne przy wynikach Monitoringu 404.

## Przechowywanie danych

Wtyczka korzysta z istniejących opcji WordPressa o nazwach `adinet_*`, metadanych użytkowników z prefiksem `adinet_` oraz tabel `wp_adinet_404_ip_stats`, `wp_adinet_admin_log` i `wp_adinet_billing_items` z prefiksem właściwym dla danej instalacji. Dezaktywacja i usunięcie plików wtyczki nie kasują ustawień, notatek, dat ani zapisanych tabel. Dane można wcześniej usunąć ręcznie z odpowiednich podstron.

## Struktura

- `adinet-panel.php` — główny plik wtyczki i rejestracja aktywacji,
- `inc/class-adinet-plugin.php` — kontroler inicjalizujący funkcje,
- `inc/class-adinet-404-monitor.php` — siedmiodniowy licznik błędów 404 według adresów IP,
- `inc/class-adinet-admin-log.php` — trzydziestodniowy log istotnych zdarzeń administracyjnych,
- `inc/class-adinet-billing.php` — metryka projektu i lokalna tabela rozliczeń klienta,
- `inc/class-adinet-plugin-installer.php` — lista, instalacja i aktywacja paczek ZIP z biblioteki AdiNet,
- `inc/class-adinet-plugin-updates.php` — blokady aktualizacji wybranych wtyczek i panel zarządzania nimi,
- `inc/` — niezależne moduły panelu,
- `assets/css/admin.css` — style ładowane tylko na ekranie AdiNet,
- `assets/js/admin.js` — kopiowanie wartości, wyszukiwanie IP i potwierdzanie operacji.


## Rozwój i wydania

1. Pracuj w prywatnym repozytorium `adinetpl/adinetpanel`. Zmiany Codex trafiają na osobną gałąź i do pull requesta. W środowisku Codex wybierz to repozytorium i ustaw Node 24.22.2 oraz Python 3.
2. GitHub Actions skanuje repozytorium, uruchamia testy na PHP 7.4, 8.3 i 8.5 oraz zapisuje ZIP i SHA-256 jako artefakt. Do lokalnego uruchomienia użyj `npm install --prefix /tmp/adinet-php-tests --ignore-scripts @php-wasm/node@3.1.62`, potem `node tests/run.mjs . 7.4`. Paczkę lokalną utworzysz poleceniem `python3 scripts/build-release.py dist`.
3. Ustaw unikatowy numer wydania w nagłówku wtyczki i w `ADINET_VERSION`. Po scaleniu na `main` udane CI uruchamia publikację nowego numeru na Beta. GitHub używa artefaktu z tego samego commita i podpisuje manifest w Actions. Publikację Beta można też ponowić ręcznie w **Actions → Publikacja AdiNet Panel → Run workflow**.
4. Po testach uruchom ten sam workflow z kanałem `stable` i numerem bieżącego wydania Beta. Workflow zweryfikuje podpis Beta i sumę ZIP-a, po czym opublikuje manifest Stable wskazujący tę samą paczkę.
5. Aby zatrzymać dystrybucję, przywróć poprzedni podpisany manifest kanału w repozytorium wydań. Na zaktualizowanej stronie odtwórz poprzednią paczkę ręcznie po sprawdzeniu podpisu i sumy ZIP-a. Wcześniej wykonaj kopię plików i bazy. Jeśli wydanie zmieniło format danych, zastosuj procedurę cofnięcia opisaną dla tego wydania.

Wersja 4.6.2 jest wydaniem pomostowym. Starsze instalacje otrzymują ją z adinet.pl. Po jej instalacji wtyczka sprawdza wybrany kanał bezpośrednio na GitHubie. Sekrety `ADINET_SIGNING_KEY` i `ADINET_PUBLISH_KEY` są używane przez workflow publikacji. Klucz publikacji ma dostęp wyłącznie do publicznego repozytorium wydań.
