<?php
/**
 * Teksty Divi Pixel i generator polityki prywatności.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cookie_texts = require ADINET_PATH . 'inc/templates/cookie-consent-pl.php';
$policy_url   = get_privacy_policy_url();
$domain       = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
$services     = array(
	'hosting'       => array( 'Hosting i logi', 'Udostępnianie witryny oraz diagnostyka i zabezpieczanie jej na podstawie logów serwera.' ),
	'contact'       => array( 'Formularz kontaktowy', 'Umożliwienie kontaktu z właścicielem witryny lub jego przedstawicielem oraz udzielanie odpowiedzi na przesłane zapytania.' ),
	'mail'          => array( 'Poczta elektroniczna', 'Obsługa korespondencji e-mail.' ),
	'maintenance'   => array( 'Obsługa techniczna witryny', 'Administrowanie, aktualizacje i diagnostyka witryny, w tym na podstawie logów dostępu na hostingu.' ),
	'cloudflare'    => array( 'Cloudflare — proxy i ochrona ruchu', 'Dostarczanie treści, ochrona i diagnostyka ruchu. Do Cloudflare trafiają żądania HTTP, które mogą zawierać adres IP i inne dane techniczne.' ),
	'turnstile'     => array( 'Cloudflare Turnstile', 'Ochrona formularzy przed spamem i automatycznymi zgłoszeniami.' ),
	'newsletter'    => array( 'Newsletter', 'Wysyłka newslettera i zarządzanie subskrypcją.' ),
	'analytics'     => array( 'Google Analytics', 'Pomiar ruchu i sposobu korzystania ze strony.' ),
	'youtube'       => array( 'YouTube', 'Wyświetlanie osadzonych filmów.' ),
	'maps'          => array( 'Mapy Google', 'Wyświetlanie osadzonych map.' ),
	'other'         => array( 'Inny cel lub usługa', '' ),
);
$service_defaults = array(
	'hosting'     => array(
		'basis'    => 'Art. 6 ust. 1 lit. f RODO — uzasadniony interes administratora polegający na zapewnieniu bezpieczeństwa i dostępności witryny.',
		'receiver' => 'dhosting.pl Sp. z o.o.',
	),
	'contact'     => array(
		'basis' => 'Art. 6 ust. 1 lit. f RODO — uzasadniony interes administratora polegający na obsłudze korespondencji i udzielaniu odpowiedzi na zapytania.',
	),
	'maintenance' => array(
		'basis'    => 'Art. 6 ust. 1 lit. f RODO — uzasadniony interes administratora polegający na utrzymaniu sprawności i bezpieczeństwa witryny.',
		'receiver' => 'AdiNet Hubert Rosiński',
	),
	'cloudflare'  => array( 'receiver' => 'Cloudflare' ),
	'turnstile'   => array( 'receiver' => 'Cloudflare' ),
);
$service_fields = array(
	'purpose'   => 'Cel przetwarzania',
	'basis'     => 'Podstawa prawna',
	'receiver'  => 'Odbiorcy danych lub ich kategorie',
	'retention' => 'Okres przechowywania lub sposób jego ustalenia',
);
$service_help = array(
	'hosting' => array(
		'when'      => 'Domyślnie ustawiony jest dhosting. Zmień dostawcę, jeśli ta witryna korzysta z innego hostingu.',
		'retention' => 'Podaj rzeczywisty okres przechowywania logów lub sposób jego ustalenia, zgodnie z konfiguracją i zasadami hostingu.',
	),
	'contact' => array(
		'basis'    => 'Ogólne pytanie: przykładowo art. 6 ust. 1 lit. f RODO — obsługa korespondencji. Przygotowanie umowy na prośbę użytkownika: art. 6 ust. 1 lit. b, jeśli dane są do tego niezbędne.',
		'receiver' => 'Uwzględnij dostawców, przez których przechodzi zgłoszenie, np. hosting lub pocztę, oraz uprawnioną firmę serwisującą, jeśli ma do niego dostęp.',
	),
	'mail' => array(
		'basis'    => 'Uwzględnij cel korespondencji, np. odpowiedź na pytanie lub podjęcie działań przed zawarciem umowy.',
		'receiver' => 'Wpisz dostawcę skrzynki lub usługę SMTP, która obsługuje wiadomości. Przy wspólnym hostingu nazwa może być ta sama.',
	),
	'maintenance' => array(
		'when'     => 'Zaznacz, jeśli zewnętrzny opiekun strony może mieć dostęp do danych, np. w logach, WordPressie lub panelu hostingu.',
		'basis'    => 'Przykład po ocenie niezbędności: art. 6 ust. 1 lit. f RODO — utrzymanie i zabezpieczenie witryny.',
		'receiver' => 'Domyślnie ustawiono AdiNet. Dopasuj nazwę i opis dostępu do rzeczywistego zakresu obsługi oraz umowy powierzenia.',
	),
	'cloudflare' => array(
		'when'  => 'Zaznacz, gdy ruch witryny przechodzi przez proxy Cloudflare. Statystyki ruchu w panelu strefy wynikają z obsługi tych żądań.',
		'basis' => 'Przykład po ocenie niezbędności: art. 6 ust. 1 lit. f RODO — ochrona witryny przed nadużyciami.',
	),
	'turnstile' => array(
		'basis' => 'Przykład po ocenie niezbędności: art. 6 ust. 1 lit. f RODO — ochrona formularzy przed spamem i automatycznymi zgłoszeniami.',
	),
);
$clearance_description = 'Zapamiętuje wynik weryfikacji bezpieczeństwa Cloudflare, aby ograniczyć ponowne wyświetlanie wyzwania.';
?>
<div class="adinet-privacy">
	<p><a href="#adinet-consent-texts">Teksty do Divi Pixel</a> · <a href="#adinet-policy-generator">Generator polityki</a></p>

	<section class="adinet-card" aria-labelledby="adinet-consent-texts">
		<h2 id="adinet-consent-texts">Polskie teksty do Divi Pixel</h2>
		<p>Skopiuj teksty do odpowiadających im pól w Cookie Consent w Divi Pixel 2.60.</p>
		<?php foreach ( $cookie_texts as $group => $fields ) : ?>
			<details class="adinet-privacy-group"<?php if ( 'Banner' === $group ) : ?> open<?php endif; ?>>
				<summary><?php echo esc_html( $group ); ?></summary>
				<?php foreach ( $fields as $label => $translation ) : ?>
					<div class="adinet-shortcode-feature">
						<strong class="adinet-shortcode-label"><?php echo esc_html( $label ); ?></strong>
						<div class="adinet-shortcode">
							<span class="adinet-privacy-text"><?php echo esc_html( $translation ); ?></span>
							<button type="button" class="button adinet-copy-button" data-copy="<?php echo esc_attr( $translation ); ?>" aria-label="<?php echo esc_attr( 'Kopiuj: ' . $group . ' – ' . $label ); ?>">Kopiuj</button>
						</div>
					</div>
				<?php endforeach; ?>
				<?php if ( 'Policy Links' === $group ) : ?>
					<p><label class="adinet-shortcode-label" for="adinet-policy-url">Ścieżka lub adres opublikowanej strony polityki</label>
						<input id="adinet-policy-url" class="large-text" type="text" value="<?php echo esc_url( $policy_url ); ?>" placeholder="/polityka-prywatnosci/"></p>
					<p class="description">WordPress podpowiada adres ustawionej strony. Do Divi Pixel skopiujesz ścieżki zaczynające się od ukośnika, np. <code>/polityka-prywatnosci/#pliki-cookies</code>.</p>
					<?php foreach ( array( 'privacy' => 'Privacy policy URL', 'cookies' => 'Cookie policy URL' ) as $type => $label ) : ?>
						<?php $field_id = 'adinet-policy-link-' . $type; ?>
						<div class="adinet-shortcode-feature">
							<label class="adinet-shortcode-label" for="<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $label ); ?></label>
							<div class="adinet-shortcode">
								<input id="<?php echo esc_attr( $field_id ); ?>" class="large-text" type="text" readonly>
								<button type="button" class="button adinet-copy-button" data-copy-field="<?php echo esc_attr( $field_id ); ?>" aria-label="<?php echo esc_attr( 'Kopiuj: ' . $label ); ?>" disabled>Kopiuj</button>
							</div>
						</div>
					<?php endforeach; ?>
					<p id="adinet-policy-url-status" class="description" aria-live="polite"></p>
				<?php endif; ?>
			</details>
		<?php endforeach; ?>
		<p class="screen-reader-text" id="adinet-copy-status" aria-live="polite"></p>
	</section>

	<section class="adinet-card" aria-labelledby="adinet-policy-generator">
		<h2 id="adinet-policy-generator">Generator polityki prywatności i plików cookies</h2>
		<p>Wypełnij dane dla tej witryny. Formularz i wynik są dostępne w otwartej karcie. Aby zachować pracę, skopiuj HTML do strony WordPressa.</p>
		<noscript><p>Generator i podpowiedzi adresów wymagają JavaScriptu.</p></noscript>
		<form id="adinet-policy-form" autocomplete="off">
			<fieldset id="adinet-policy-fields" disabled>
				<legend class="screen-reader-text">Dane do polityki</legend>
				<h3>Administrator danych</h3>
				<div class="adinet-privacy-grid">
					<label>Nazwa administratora <input type="text" id="adinet-policy-controller" required></label>
					<label>Adres administratora <input type="text" id="adinet-policy-address" required></label>
					<label>E-mail kontaktowy <input type="email" id="adinet-policy-email" required></label>
					<label>Domena witryny <input type="text" id="adinet-policy-domain" value="<?php echo esc_attr( $domain ?? '' ); ?>" required></label>
					<label>Kontakt do inspektora ochrony danych, jeśli wyznaczono <input type="text" id="adinet-policy-dpo"></label>
				</div>
				<h3>Funkcje i usługi witryny</h3>
				<p class="description">Zaznacz używane usługi i sprawdź wstępnie wypełnione pola. Podstawę prawną dobierz do celu przetwarzania. Przy uzasadnionym interesie wpisz też, na czym polega. Jako odbiorców podaj podmioty, które dostają dane lub mają do nich dostęp, albo ich kategorie. Wpisz „Brak”, jeśli nie ma takich odbiorców.</p>
				<?php foreach ( $services as $key => list( $label, $purpose ) ) : ?>
					<div class="adinet-privacy-service" data-policy-service>
						<label><input type="checkbox" data-service-toggle aria-controls="<?php echo esc_attr( 'adinet-policy-service-' . $key ); ?>" <?php checked( in_array( $key, array( 'hosting', 'maintenance', 'cloudflare' ), true ) ); ?>> <strong><?php echo esc_html( $label ); ?></strong></label>
						<?php if ( isset( $service_help[ $key ]['when'] ) ) : ?>
							<p class="description"><?php echo esc_html( $service_help[ $key ]['when'] ); ?></p>
						<?php endif; ?>
						<fieldset id="<?php echo esc_attr( 'adinet-policy-service-' . $key ); ?>" data-service-fields hidden disabled>
							<legend class="screen-reader-text"><?php echo esc_html( $label ); ?></legend>
							<div class="adinet-privacy-grid">
								<?php foreach ( $service_fields as $field => $field_label ) : ?>
									<?php
									$value   = 'purpose' === $field ? $purpose : ( $service_defaults[ $key ][ $field ] ?? '' );
									$hint    = $service_help[ $key ][ $field ] ?? '';
									$hint_id = 'adinet-policy-help-' . $key . '-' . $field;
									?>
									<div>
										<label>
											<?php echo esc_html( $field_label ); ?>
											<input type="text" data-policy-field="<?php echo esc_attr( $field ); ?>" value="<?php echo esc_attr( $value ); ?>"<?php if ( $hint ) : ?> aria-describedby="<?php echo esc_attr( $hint_id ); ?>"<?php endif; ?>>
										</label>
										<?php if ( $hint ) : ?><p class="description" id="<?php echo esc_attr( $hint_id ); ?>"><?php echo esc_html( $hint ); ?></p><?php endif; ?>
									</div>
								<?php endforeach; ?>
							</div>
							<?php if ( 'turnstile' === $key ) : ?>
								<p class="description">Opis uwzględni sygnały techniczne sprawdzane przez Turnstile. Dodaj wpis o <code>cf_clearance</code>, jeśli widzisz to cookie na docelowej stronie.</p>
							<?php endif; ?>
						</fieldset>
					</div>
				<?php endforeach; ?>
				<p><label class="adinet-shortcode-label" for="adinet-policy-other">Dodatkowe informacje o przetwarzaniu</label>
					<textarea id="adinet-policy-other" class="large-text" rows="3" placeholder="Np. przekazywanie danych poza EOG i stosowane zabezpieczenia, obowiązek podania danych i skutki ich niepodania."></textarea></p>

				<h3 id="adinet-policy-cookies-heading">Pliki cookies</h3>
				<p><label><input type="checkbox" id="adinet-policy-declaration" aria-controls="adinet-policy-manual-cookies"> Wstaw tabelę cookies z Divi Pixel <code>[dipi_cookie_declaration]</code></label></p>
				<p id="adinet-policy-manual-cookies"><label class="adinet-shortcode-label" for="adinet-policy-cookie-details">Własny wykaz plików cookies</label>
					<textarea id="adinet-policy-cookie-details" class="large-text" rows="3" aria-describedby="adinet-policy-cookie-details-help"></textarea>
					<span id="adinet-policy-cookie-details-help" class="description">Dla każdego używanego cookie wpisz nazwę, cel i czas ważności. Jeśli włączysz tabelę Divi Pixel, wykaz uzupełnisz w jego Cookie List.</span></p>
				<p><label class="adinet-shortcode-label" for="adinet-policy-cookie-settings">Jak użytkownik może zmienić ustawienia cookies?</label>
					<textarea id="adinet-policy-cookie-settings" class="large-text" rows="2" aria-describedby="adinet-policy-cookie-settings-help"></textarea>
					<span id="adinet-policy-cookie-settings-help" class="description">Wskaż działający element na stronie, np. „Wybór można zmienić przez link Ustawienia cookies w stopce”. Przy wyłącznie niezbędnych cookies i braku panelu preferencji pole możesz pominąć.</span></p>
				<p><label><input type="checkbox" id="adinet-policy-clearance" aria-controls="adinet-policy-clearance-fields" aria-describedby="adinet-policy-clearance-help"> Witryna zapisuje <code>cf_clearance</code></label></p>
				<p class="description" id="adinet-policy-clearance-help">Zaznacz, jeśli potwierdzisz, że Cloudflare zapisuje to cookie na tej witrynie. Pole służy do opisania cookie w polityce.</p>
				<fieldset id="adinet-policy-clearance-fields" hidden disabled>
					<legend class="screen-reader-text">Dane cookie cf_clearance</legend>
					<label for="adinet-policy-clearance-duration">Rzeczywisty okres ważności cookie <code>cf_clearance</code></label>
					<input type="text" id="adinet-policy-clearance-duration" placeholder="Np. 30 minut">
				</fieldset>
				<div id="adinet-policy-clearance-divi" hidden>
					<p>Uzupełnij pozycję w <strong>Divi Pixel → Cookie List</strong>. Z tej listy shortcode pobierze dane do tabeli.</p>
					<div class="adinet-privacy-grid">
						<?php
						$clearance_fields = array(
							'name'        => array( 'Cookie', 'cf_clearance' ),
							'duration'    => array( 'Duration', '' ),
							'description' => array( 'Description', $clearance_description ),
						);
						foreach ( $clearance_fields as $key => list( $label, $value ) ) :
							$field_id = 'adinet-clearance-copy-' . $key;
							?>
							<div>
								<label class="adinet-shortcode-label" for="<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $label ); ?></label>
								<div class="adinet-shortcode">
									<input id="<?php echo esc_attr( $field_id ); ?>" class="large-text" type="text" value="<?php echo esc_attr( $value ); ?>" readonly>
									<button type="button" class="button adinet-copy-button" data-copy-field="<?php echo esc_attr( $field_id ); ?>" aria-label="<?php echo esc_attr( 'Kopiuj: ' . $label . ' cf_clearance' ); ?>"<?php disabled( '' === $value ); ?>>Kopiuj</button>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<p><button type="submit" class="button button-primary">Wygeneruj politykę</button></p>
			</fieldset>
		</form>
		<div id="adinet-policy-result" hidden>
			<h3 id="adinet-policy-preview-heading" tabindex="-1">Podgląd dokumentu</h3>
			<div id="adinet-policy-warnings" class="notice notice-warning inline" role="status" hidden>
				<p>Sprawdź te informacje przed publikacją:</p>
				<ul></ul>
			</div>
			<div id="adinet-policy-preview" class="adinet-policy-preview"></div>
			<p><label class="adinet-shortcode-label" for="adinet-policy-html">HTML polityki</label>
				<textarea class="large-text code" id="adinet-policy-html" rows="7" readonly></textarea></p>
			<p><button type="button" class="button button-primary adinet-copy-button" data-copy-field="adinet-policy-html" data-default-label="Kopiuj HTML">Kopiuj HTML</button></p>
			<p class="description">Na stronie „Polityka prywatności i plików cookies” wklej HTML w trybie Tekst modułu Tekst w Divi.</p>
		</div>
	</section>
</div>
