<?php
/**
 * Treść komunikatu w kokpicie i w podglądzie opiekuna.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php if ( ! empty( $message['areas'] ) ) : ?>
	<p class="adinet-assessment-copy__text"><?php echo esc_html( $message['intro'] ); ?></p>
	<div>
		<p><?php echo esc_html( AdiNet_Site_Assessment::client_areas_heading() ); ?></p>
		<ul class="adinet-assessment-copy__areas">
			<?php foreach ( $message['areas'] as $area ) : ?>
				<li><?php echo esc_html( $area ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
<?php endif; ?>
<?php if ( '' !== $message['body'] ) : ?>
	<p class="adinet-assessment-copy__text"><?php echo esc_html( $message['body'] ); ?></p>
<?php endif; ?>
