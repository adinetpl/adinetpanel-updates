( function () {
	'use strict';

	function escapeHtml( value ) {
		const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '[': '&#91;', ']': '&#93;' };
		return value.replace( /[&<>\[\]]/g, function ( character ) {
			return entities[ character ];
		} );
	}

	function paragraphs( value ) {
		return value.trim().split( /\n\s*\n/ ).filter( Boolean ).map( function ( paragraph ) {
			return '<p>' + escapeHtml( paragraph ).replace( /\r?\n/g, '<br>\n' ) + '</p>';
		} );
	}

	function setCopyValue( field, value ) {
		field.value = value;
		document.querySelector( '[data-copy-field="' + field.id + '"]' ).disabled = ! value;
	}

	function initLinks() {
		const address = document.getElementById( 'adinet-policy-url' );
		const privacy = document.getElementById( 'adinet-policy-link-privacy' );
		const cookies = document.getElementById( 'adinet-policy-link-cookies' );
		const status = document.getElementById( 'adinet-policy-url-status' );

		function updateLinks() {
			const input = address.value.trim();
			let url;
			try {
				if ( /^\/(?!\/)/.test( input ) && ! input.includes( '\\' ) ) {
					url = new URL( input, window.location.origin );
					if ( url.origin !== window.location.origin ) {
						url = null;
					}
				} else if ( /^https?:\/\//i.test( input ) ) {
					url = new URL( input );
				}
			} catch ( error ) {
				url = null;
			}
			if ( url && ! url.username && ! url.password && ! url.pathname.startsWith( '//' ) ) {
				const path = url.pathname + url.search;
				setCopyValue( privacy, path );
				setCopyValue( cookies, path + '#pliki-cookies' );
				status.textContent = '';
				return;
			}
			setCopyValue( privacy, '' );
			setCopyValue( cookies, '' );
			status.textContent = input
				? 'Wpisz ścieżkę zaczynającą się od jednego ukośnika albo pełny adres HTTP lub HTTPS.'
				: 'Wpisz adres opublikowanej strony, aby skopiować odnośniki.';
		}

		address.addEventListener( 'input', updateLinks );
		updateLinks();
	}

	function addService( html, warnings, service ) {
		const title = service.querySelector( 'strong' ).textContent;
		const missing = [];
		const entries = [];
		html.push( '<h3>' + escapeHtml( title ) + '</h3>' );
		service.querySelectorAll( '[data-policy-field]' ).forEach( function ( field ) {
			const label = field.closest( 'label' ).textContent.trim();
			const value = field.value.trim();
			if ( value ) {
				entries.push( '<li><strong>' + escapeHtml( label ) + '</strong> ' + escapeHtml( value ) + '</li>' );
			} else {
				missing.push( label.toLowerCase() );
			}
		} );
		if ( missing.length ) {
			warnings.push( title + ' — uzupełnij: ' + missing.join( ', ' ) + '.' );
		}
		if ( entries.length ) {
			html.push( '<ul>', ...entries, '</ul>' );
		}
		if ( service.querySelector( '#adinet-policy-service-turnstile' ) ) {
			html.push( '<p>Turnstile przetwarza sygnały techniczne, takie jak adres IP, informacje o przeglądarce i cechy połączenia, aby odróżnić użytkowników od botów. Szczegóły podaje <a href="https://www.cloudflare.com/turnstile-privacy-policy/">informacja Cloudflare o prywatności Turnstile</a>.</p>' );
		}
	}

	function initGenerator( form ) {
		const get = function ( field ) {
			return document.getElementById( 'adinet-policy-' + field );
		};
		const fields = get( 'fields' );
		const services = Array.from( form.querySelectorAll( '[data-policy-service]' ) );
		const warningsBox = get( 'warnings' );
		const output = get( 'html' );
		const clearanceDuration = get( 'clearance-duration' );
		const durationCopy = document.getElementById( 'adinet-clearance-copy-duration' );
		const clearanceDescription = document.getElementById( 'adinet-clearance-copy-description' ).value;

		function updateFields() {
			services.forEach( function ( service ) {
				const active = service.querySelector( '[data-service-toggle]' ).checked;
				const details = service.querySelector( '[data-service-fields]' );
				details.hidden = ! active;
				details.disabled = ! active;
			} );
			const useDeclaration = get( 'declaration' ).checked;
			get( 'manual-cookies' ).hidden = useDeclaration;
			get( 'cookie-details' ).disabled = useDeclaration;
			const clearance = get( 'clearance' ).checked;
			get( 'clearance-fields' ).hidden = ! clearance;
			get( 'clearance-fields' ).disabled = ! clearance;
			get( 'clearance-divi' ).hidden = ! clearance || ! useDeclaration;
			setCopyValue( durationCopy, clearanceDuration.value.trim() );
		}

		function value( field ) {
			return get( field ).value.trim();
		}

		function generate( event ) {
			event.preventDefault();
			const identityFields = [ 'controller', 'address', 'email', 'domain' ].map( get );
			identityFields.forEach( function ( field ) {
				field.value = field.value.trim();
			} );
			if ( ! form.reportValidity() ) {
				return;
			}
			const warnings = [];
			const html = [
				'<h2>Administrator danych</h2>',
				'<p>Administratorem danych osobowych przetwarzanych w związku z działaniem witryny <strong>' + escapeHtml( value( 'domain' ) )
					+ '</strong> jest <strong>' + escapeHtml( value( 'controller' ) ) + '</strong>, ' + escapeHtml( value( 'address' ) )
					+ '. W sprawach związanych z danymi osobowymi można kontaktować się pod adresem ' + escapeHtml( value( 'email' ) ) + '.</p>',
			];
			if ( value( 'dpo' ) ) {
				html.push( '<p>Kontakt do inspektora ochrony danych: ' + escapeHtml( value( 'dpo' ) ) + '.</p>' );
			}
			const selected = services.filter( function ( service ) {
				return service.querySelector( '[data-service-toggle]' ).checked;
			} );
			if ( selected.length ) {
				html.push( '<h2>Cele i zasady przetwarzania danych</h2>' );
				selected.forEach( function ( service ) {
					addService( html, warnings, service );
				} );
			} else {
				warnings.push( 'Sprawdź, czy trzeba opisać cele przetwarzania, np. hosting, logi lub korespondencję.' );
			}
			html.push( ...paragraphs( value( 'other' ) ) );
			const useDeclaration = get( 'declaration' ).checked;
			html.push(
				'<h2>Prawa osób, których dane dotyczą</h2>',
				'<p>Możesz zwrócić się do administratora o dostęp do danych i ich sprostowanie. Gdy spełnione są odpowiednie warunki, przysługuje Ci także prawo do usunięcia danych, ograniczenia przetwarzania, przenoszenia danych lub wniesienia sprzeciwu wobec przetwarzania.</p>',
				'<p>Jeśli podstawą przetwarzania jest zgoda, możesz ją wycofać w dowolnym momencie. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, które miało miejsce przed jej wycofaniem. Możesz także wnieść skargę do Prezesa Urzędu Ochrony Danych Osobowych.</p>',
				'<h2 id="pliki-cookies">Pliki cookies</h2>',
				...paragraphs( value( 'cookie-settings' ) )
			);
			if ( ! useDeclaration ) {
				html.push( ...paragraphs( value( 'cookie-details' ) ) );
				if ( ! value( 'cookie-details' ) ) {
					warnings.push( 'Potwierdź, jakie cookies zapisuje witryna, i uzupełnij ich wykaz.' );
				}
			}
			if ( get( 'clearance' ).checked ) {
				const duration = clearanceDuration.value.trim();
				if ( ! duration ) {
					warnings.push( 'Podaj rzeczywisty okres ważności cookie cf_clearance.' );
				}
				if ( useDeclaration ) {
					warnings.push( 'Sprawdź, czy wpis cf_clearance jest włączony i uzupełniony w Cookie List w Divi Pixel.' );
				} else {
					html.push( '<p><code>cf_clearance</code>. ' + escapeHtml( clearanceDescription )
						+ ( duration ? ' Okres ważności: ' + escapeHtml( duration ) + '.' : '' ) + '</p>' );
				}
			}
			const documentHtml = html.join( '\n' );
			output.value = documentHtml + ( useDeclaration ? '\n[dipi_cookie_declaration]' : '' );
			// Only fixed markup and escaped text are inserted into the preview.
			get( 'preview' ).innerHTML = documentHtml + ( useDeclaration ? '<p><code>[dipi_cookie_declaration]</code></p>' : '' );
			const list = warningsBox.querySelector( 'ul' );
			list.textContent = '';
			warnings.forEach( function ( warning ) {
				const item = document.createElement( 'li' );
				item.textContent = warning;
				list.appendChild( item );
			} );
			warningsBox.hidden = ! warnings.length;
			get( 'result' ).hidden = false;
			get( 'preview-heading' ).focus();
		}

		form.addEventListener( 'input', function () {
			get( 'result' ).hidden = true;
		} );
		form.addEventListener( 'change', updateFields );
		clearanceDuration.addEventListener( 'input', function () {
			setCopyValue( durationCopy, clearanceDuration.value.trim() );
		} );
		form.addEventListener( 'submit', generate );
		fields.disabled = false;
		updateFields();
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		const form = document.getElementById( 'adinet-policy-form' );
		if ( form ) {
			initLinks();
			initGenerator( form );
		}
	} );
} )();
