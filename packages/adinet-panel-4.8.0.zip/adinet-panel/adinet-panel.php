<?php
/**
 * Plugin Name:       AdiNet Panel
 * Plugin URI:        https://adinet.pl
 * Description:       Panel administracyjny AdiNet z informacjami technicznymi, notatkami, shortcode'ami i narzędziami obsługi WordPressa.
 * Version:           4.8.0
 * Author:            AdiNet Hubert Rosiński
 * Author URI:        https://adinet.pl
 * Text Domain:       adinet-panel
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Update URI:        https://adinet.pl/adinet-panel/
 * License:           GNU General Public License v2.0 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ADINET_VERSION', '4.8.0' );
define( 'ADINET_FILE', __FILE__ );
define( 'ADINET_PATH', plugin_dir_path( __FILE__ ) );
define( 'ADINET_URL', plugin_dir_url( __FILE__ ) );

require_once ADINET_PATH . 'inc/class-adinet-options.php';
require_once ADINET_PATH . 'inc/class-adinet-client-ip.php';
require_once ADINET_PATH . 'inc/class-adinet-cron-health.php';
require_once ADINET_PATH . 'inc/class-adinet-updater.php';
require_once ADINET_PATH . 'inc/class-adinet-login-url.php';
require_once ADINET_PATH . 'inc/class-adinet-snippets.php';
require_once ADINET_PATH . 'inc/class-adinet-year-shortcode.php';
require_once ADINET_PATH . 'inc/class-adinet-footer-shortcode.php';
require_once ADINET_PATH . 'inc/class-adinet-update-emails.php';
require_once ADINET_PATH . 'inc/class-adinet-comments-control.php';
require_once ADINET_PATH . 'inc/class-adinet-revisions-control.php';
require_once ADINET_PATH . 'inc/class-adinet-404-monitor.php';
require_once ADINET_PATH . 'inc/class-adinet-admin-log.php';
require_once ADINET_PATH . 'inc/class-adinet-update-log.php';
require_once ADINET_PATH . 'inc/class-adinet-system-info.php';
require_once ADINET_PATH . 'inc/class-adinet-debug-control.php';
require_once ADINET_PATH . 'inc/class-adinet-admin.php';
require_once ADINET_PATH . 'inc/class-adinet-billing.php';
require_once ADINET_PATH . 'inc/class-adinet-dashboard.php';
require_once ADINET_PATH . 'inc/class-adinet-plugin-installer.php';
require_once ADINET_PATH . 'inc/class-adinet-plugin-updates.php';
require_once ADINET_PATH . 'inc/class-adinet-audit.php';
require_once ADINET_PATH . 'inc/class-adinet-htaccess.php';
require_once ADINET_PATH . 'inc/class-adinet-plugin.php';

register_activation_hook( ADINET_FILE, array( 'AdiNet_Plugin', 'activate' ) );
register_deactivation_hook( ADINET_FILE, array( 'AdiNet_Cron_Health', 'deactivate' ) );

AdiNet_Plugin::init();
