<?php
/** Gotowe shortcode’y oraz wzór stopki Divi. @package AdiNetPanel */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
					<section class="adinet-card" aria-labelledby="adinet-year-title">
						<div class="adinet-card__topline">
							<span class="adinet-card__icon dashicons dashicons-calendar-alt" aria-hidden="true"></span>
							<span class="adinet-status"><?php esc_html_e( 'Shortcode’y i wzory do skopiowania', 'adinet-panel' ); ?></span>
						</div>
						<h3 id="adinet-year-title"><?php esc_html_e( 'Automatyczny rok', 'adinet-panel' ); ?></h3>
						<p><?php esc_html_e( 'Wpisz shortcode w treści strony, wpisu albo module tekstowym dowolnego kreatora. Rok jest pobierany zgodnie ze strefą czasową ustawioną w WordPressie.', 'adinet-panel' ); ?></p>

						<div class="adinet-shortcode-feature">
							<strong class="adinet-shortcode-label"><?php esc_html_e( 'Tylko aktualny rok', 'adinet-panel' ); ?></strong>
							<div class="adinet-shortcode">
								<code id="adinet-year-shortcode">[year]</code>
								<button
									type="button"
									class="button adinet-copy-button"
									data-copy="[year]"
									data-default-label="<?php echo esc_attr__( 'Kopiuj', 'adinet-panel' ); ?>"
									data-copied-label="<?php echo esc_attr__( 'Skopiowano', 'adinet-panel' ); ?>"
									aria-describedby="adinet-copy-status"
								>
									<?php esc_html_e( 'Kopiuj', 'adinet-panel' ); ?>
								</button>
							</div>
							<p class="adinet-help"><?php esc_html_e( 'Przykład: © [year] AdiNet wyświetli bieżący rok automatycznie.', 'adinet-panel' ); ?></p>
						</div>

						<div class="adinet-shortcode-feature is-secondary">
							<strong class="adinet-shortcode-label"><?php esc_html_e( 'Gotowa stopka AdiNet', 'adinet-panel' ); ?></strong>
							<div class="adinet-shortcode">
								<code id="adinet-footer-shortcode">[adinet_footer]</code>
								<button
									type="button"
									class="button adinet-copy-button"
									data-copy="[adinet_footer]"
									data-default-label="<?php echo esc_attr__( 'Kopiuj', 'adinet-panel' ); ?>"
									data-copied-label="<?php echo esc_attr__( 'Skopiowano', 'adinet-panel' ); ?>"
									aria-describedby="adinet-copy-status"
								>
									<?php esc_html_e( 'Kopiuj', 'adinet-panel' ); ?>
								</button>
							</div>
							<p class="adinet-footer-preview">
								<?php
								echo wp_kses_post(
									AdiNet_Footer_Shortcode::render()
								);
								?>
							</p>
						</div>
						<div class="adinet-shortcode-feature is-secondary">
							<?php $divi_footer = '© $variable({"type":"content","value":{"name":"current_date","settings":{"before":"","after":"","date_format":"custom","custom_date_format":"Y"}}})$ $variable({"type":"content","value":{"name":"site_title","settings":{}}})$ | Stworzone i obsługiwane przez <a href="https://adinet.pl" target="_blank" rel="noopener" title="AdiNet Hubert Rosiński">AdiNet</a>'; ?>
							<label class="adinet-shortcode-label" for="adinet-divi-footer"><?php esc_html_e( 'Gotowa stopka dla Divi 5.18+', 'adinet-panel' ); ?></label>
							<div class="adinet-shortcode">
								<textarea id="adinet-divi-footer" class="large-text code" rows="4" readonly><?php echo esc_textarea( $divi_footer ); ?></textarea>
								<button
									type="button"
									class="button adinet-copy-button"
									data-copy="<?php echo esc_attr( $divi_footer ); ?>"
									data-default-label="<?php echo esc_attr__( 'Kopiuj', 'adinet-panel' ); ?>"
									data-copied-label="<?php echo esc_attr__( 'Skopiowano', 'adinet-panel' ); ?>"
									aria-describedby="adinet-copy-status"
								>
									<?php esc_html_e( 'Kopiuj', 'adinet-panel' ); ?>
								</button>
							</div>
							<p class="adinet-help"><?php esc_html_e( 'Wklej kod w zakładce Tekst w edytorze treści modułu Tekst w Divi.', 'adinet-panel' ); ?></p>
						</div>
						<p class="screen-reader-text" id="adinet-copy-status" aria-live="polite"></p>
					</section>
