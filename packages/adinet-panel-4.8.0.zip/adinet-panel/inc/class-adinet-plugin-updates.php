<?php
/**
 * Blokowanie standardowych aktualizacji wybranych wtyczek.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Plugin_Updates {
	const OPTION_LOCKS = 'adinet_plugin_update_locks';
	const SAVE_ACTION  = 'adinet_save_plugin_update_locks';

	/** Rejestruje blokady także dla crona i aktualizacji poza panelem. */
	public static function init() {
		add_filter( 'site_transient_update_plugins', array( __CLASS__, 'filter_updates' ), PHP_INT_MAX );
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'filter_updates' ), PHP_INT_MAX );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'filter_auto_update' ), PHP_INT_MAX, 2 );
		add_filter( 'upgrader_pre_install', array( __CLASS__, 'guard_update' ), 1, 2 );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'plugin_row_meta' ), 10, 2 );
		add_filter( 'plugin_auto_update_setting_html', array( __CLASS__, 'auto_update_html' ), 10, 2 );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'save' ) );
	}

	/** W multisite wtyczki i ich aktualizacje są wspólne dla całej sieci. */
	public static function can_manage() {
		return AdiNet_Admin::can_manage_panel()
			&& ( ! is_multisite() || current_user_can( 'manage_network_plugins' ) );
	}

	/** Zwraca blokady; na zwykłej instalacji site option jest zwykłą opcją. */
	public static function get_locks() {
		$locks = get_site_option( self::OPTION_LOCKS, array() );
		return is_array( $locks ) ? $locks : array();
	}

	/** Ukrywa oferty bez zmieniania danych pozostałych wtyczek. */
	public static function filter_updates( $value ) {
		if ( ! is_object( $value ) ) {
			return $value;
		}

		// Nie modyfikuj przez referencję obiektu przechowywanego w object cache.
		$value = clone $value;
		foreach ( self::get_locks() as $plugin => $lock ) {
			unset( $value->response[ $plugin ], $value->no_update[ $plugin ] );
		}
		return $value;
	}

	/** Zachowuje wcześniejszą decyzję WordPressa dla niezablokowanych wtyczek. */
	public static function filter_auto_update( $update, $item ) {
		$locks = self::get_locks();
		return isset( $item->plugin, $locks[ $item->plugin ] ) ? false : $update;
	}

	/** Chroni również aktualizację rozpoczętą ze starszego, otwartego ekranu. */
	public static function guard_update( $response, $extra ) {
		// Aktualizacja zbiorcza przekazuje sam plik wtyczki, bez type/action.
		// Wykonaj kontrolę przed standardowym wyłączeniem wtyczki przez instalator.
		if ( is_wp_error( $response ) || 'update' !== ( $extra['action'] ?? 'update' ) || 'plugin' !== ( $extra['type'] ?? 'plugin' ) ) {
			return $response;
		}
		$locks = self::get_locks();
		if ( isset( $extra['plugin'], $locks[ $extra['plugin'] ] ) ) {
			return new WP_Error( 'adinet_plugin_update_locked', __( 'Aktualizacja tej wtyczki jest zablokowana przez AdiNet. Opiekun strony musi najpierw zdjąć blokadę w AdiNet → Wtyczki.', 'adinet-panel' ) );
		}
		return $response;
	}

	/** Oznaczenie na standardowej liście wtyczek WordPressa. */
	public static function plugin_row_meta( $links, $plugin ) {
		$locks = self::get_locks();
		if ( isset( $locks[ $plugin ] ) ) {
			$links[] = esc_html__( 'Aktualizacje zablokowane przez AdiNet', 'adinet-panel' );
		}
		return $links;
	}

	/** Nie pokazuj działającego z pozoru przełącznika automatycznych aktualizacji. */
	public static function auto_update_html( $html, $plugin ) {
		$locks = self::get_locks();
		return isset( $locks[ $plugin ] ) ? esc_html__( 'Zablokowane przez AdiNet', 'adinet-panel' ) : $html;
	}

	/** Pobiera wszystkie zwykłe wtyczki, także nieaktywne i spoza biblioteki. */
	private static function get_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return get_plugins();
	}

	/** Zapisuje wyłącznie zaznaczone, rzeczywiście zainstalowane wtyczki. */
	public static function save() {
		if ( ! self::can_manage() ) {
			wp_die( esc_html__( 'Tylko właściciel panelu AdiNet może zmieniać blokady aktualizacji.', 'adinet-panel' ) );
		}
		check_admin_referer( self::SAVE_ACTION );

		$operation = isset( $_POST['operation'] ) && is_string( $_POST['operation'] ) ? wp_unslash( $_POST['operation'] ) : '';
		$selected  = isset( $_POST['plugins'] ) && is_array( $_POST['plugins'] ) ? wp_unslash( $_POST['plugins'] ) : array();
		$installed = self::get_plugins();
		$selected  = array_values( array_unique( array_filter( $selected, static function ( $plugin ) use ( $installed ) {
			return is_string( $plugin ) && isset( $installed[ $plugin ] );
		} ) ) );
		if ( ! in_array( $operation, array( 'lock', 'unlock' ), true ) || empty( $selected ) ) {
			self::redirect( 'empty' );
		}

		$reason = isset( $_POST['reason'] ) && is_string( $_POST['reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['reason'] ) ) : '';
		$reason = wp_html_excerpt( $reason, 300, '' );
		$locks  = self::get_locks();
		$before = $locks;
		$user   = wp_get_current_user();
		foreach ( $selected as $plugin ) {
			if ( 'lock' === $operation ) {
				$locks[ $plugin ] = array( 'reason' => $reason, 'at' => time(), 'by' => $user->user_login );
			} else {
				unset( $locks[ $plugin ] );
			}
		}

		if ( $locks !== $before && ! update_site_option( self::OPTION_LOCKS, $locks ) ) {
			self::redirect( 'error' );
		}
		// Po odblokowaniu kolejny standardowy odczyt może pobrać aktualną ofertę.
		delete_site_transient( 'update_plugins' );
		foreach ( $selected as $plugin ) {
			if ( ( $before[ $plugin ] ?? null ) !== ( $locks[ $plugin ] ?? null ) ) {
				AdiNet_Admin_Log::record( 'plugin_update_lock', 'standard', sprintf(
					'lock' === $operation ? __( 'Zablokowano aktualizacje: %s', 'adinet-panel' ) : __( 'Odblokowano aktualizacje: %s', 'adinet-panel' ),
					$installed[ $plugin ]['Name'] . ' (' . $plugin . ')'
				), array( 'is_change' => 1 ) );
			}
		}
		self::redirect( 'lock' === $operation ? 'locked' : 'unlocked' );
	}

	private static function redirect( $notice ) {
		wp_safe_redirect( add_query_arg( 'adinet-updates-notice', $notice, admin_url( 'admin.php?page=' . AdiNet_Plugin_Installer::PAGE_SLUG ) ) );
		exit;
	}

	/** Panel do odczytu dla administratorów, z formularzem wyłącznie dla właściciela. */
	public static function render_panel() {
		if ( ! AdiNet_Admin::can_view_panel() ) {
			return;
		}
		$plugins    = self::get_plugins();
		$locks      = self::get_locks();
		$can_manage = self::can_manage();
		$locked     = count( array_intersect_key( $plugins, $locks ) );
		$notice     = isset( $_GET['adinet-updates-notice'] ) && is_string( $_GET['adinet-updates-notice'] ) ? sanitize_key( wp_unslash( $_GET['adinet-updates-notice'] ) ) : '';
		$notices    = array(
			'locked'   => array( 'success', __( 'Zapisano blokady aktualizacji zaznaczonych wtyczek.', 'adinet-panel' ) ),
			'unlocked' => array( 'success', __( 'Zdjęto blokady zaznaczonych wtyczek. Dostępne aktualizacje pojawią się po ponownym sprawdzeniu przez WordPress.', 'adinet-panel' ) ),
			'empty'    => array( 'warning', __( 'Zaznacz co najmniej jedną zainstalowaną wtyczkę i wybierz blokowanie lub odblokowanie.', 'adinet-panel' ) ),
			'error'    => array( 'error', __( 'Nie udało się zapisać blokad. Spróbuj ponownie.', 'adinet-panel' ) ),
		);
		?>
		<div class="wrap adinet-admin adinet-plugin-updates-page">
			<header class="adinet-monitor-hero">
				<div>
					<p class="adinet-eyebrow"><?php esc_html_e( 'Kontrola aktualizacji', 'adinet-panel' ); ?></p>
					<h1><?php esc_html_e( 'Zarządzanie aktualizacjami', 'adinet-panel' ); ?></h1>
					<p><?php esc_html_e( 'Wybierz wtyczki, które mogą być aktualizowane dopiero po testach i świadomym zdjęciu blokady.', 'adinet-panel' ); ?></p>
				</div>
				<span class="adinet-status is-neutral"><?php echo esc_html( sprintf( __( 'Zablokowane: %1$d z %2$d', 'adinet-panel' ), $locked, count( $plugins ) ) ); ?></span>
			</header>
			<?php if ( isset( $notices[ $notice ] ) ) : ?>
				<div class="notice notice-<?php echo esc_attr( $notices[ $notice ][0] ); ?> is-dismissible"><p><?php echo esc_html( $notices[ $notice ][1] ); ?></p></div>
			<?php endif; ?>
			<?php if ( ! $can_manage ) : ?>
				<div class="notice notice-info"><p><?php esc_html_e( 'Podgląd tylko do odczytu. Blokady aktualizacji może zmieniać wyłącznie właściciel panelu AdiNet.', 'adinet-panel' ); ?></p></div>
			<?php endif; ?>
			<p class="adinet-help"><?php esc_html_e( 'Blokada ukrywa standardowe informacje o nowych wersjach i wyłącza aktualizacje ręczne, zbiorcze oraz automatyczne. Obowiązuje także właściciela panelu. Pozostałe wtyczki aktualizują się bez zmian.', 'adinet-panel' ); ?></p>
			<?php if ( is_multisite() ) : ?><p class="adinet-help"><?php esc_html_e( 'Blokady obowiązują w całej sieci witryn. Ich zmiana wymaga także uprawnień administratora sieci.', 'adinet-panel' ); ?></p><?php endif; ?>
			<?php if ( $can_manage ) : ?>
			<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" class="adinet-plugin-updates-form">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>">
				<?php wp_nonce_field( self::SAVE_ACTION ); ?>
			<?php endif; ?>
			<section class="adinet-plugin-library">
				<h2><?php esc_html_e( 'Zainstalowane wtyczki', 'adinet-panel' ); ?></h2>
				<div class="adinet-monitor-table-wrap">
					<table class="widefat striped adinet-monitor-table adinet-plugin-updates-table">
						<thead><tr>
							<?php if ( $can_manage ) : ?><td class="check-column"><input type="checkbox" data-adinet-select-all aria-label="<?php esc_attr_e( 'Zaznacz wszystkie wtyczki', 'adinet-panel' ); ?>"></td><?php endif; ?>
							<th scope="col"><?php esc_html_e( 'Wtyczka / wersja', 'adinet-panel' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Aktualizacje', 'adinet-panel' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Powód blokady', 'adinet-panel' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Ustawienie blokady', 'adinet-panel' ); ?></th>
						</tr></thead>
						<tbody>
						<?php foreach ( $plugins as $plugin => $data ) : ?>
							<?php $lock = $locks[ $plugin ] ?? null; ?>
							<tr>
								<?php if ( $can_manage ) : ?><th scope="row" class="check-column"><input type="checkbox" name="plugins[]" value="<?php echo esc_attr( $plugin ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Zaznacz: %s', 'adinet-panel' ), $data['Name'] ) ); ?>"></th><?php endif; ?>
								<td><strong><?php echo esc_html( $data['Name'] ); ?></strong><small class="adinet-plugin-library-name"><?php echo esc_html( $data['Version'] ); ?> · <?php echo esc_html( is_plugin_active( $plugin ) ? __( 'Aktywna', 'adinet-panel' ) : __( 'Nieaktywna', 'adinet-panel' ) ); ?></small></td>
								<td><span class="adinet-status <?php echo $lock ? 'is-warning' : 'is-good'; ?>"><?php echo esc_html( $lock ? __( 'Zablokowane', 'adinet-panel' ) : __( 'Dozwolone', 'adinet-panel' ) ); ?></span></td>
								<td><?php echo esc_html( ! empty( $lock['reason'] ) ? $lock['reason'] : '—' ); ?></td>
								<td><?php if ( $lock ) : ?><?php echo esc_html( wp_date( 'd.m.Y H:i', $lock['at'] ) ); ?><small class="adinet-plugin-library-name"><?php echo esc_html( $lock['by'] ); ?></small><?php else : ?>—<?php endif; ?></td>
							</tr>
						<?php endforeach; ?>
						<?php if ( empty( $plugins ) ) : ?><tr><td colspan="<?php echo $can_manage ? '5' : '4'; ?>"><?php esc_html_e( 'Nie znaleziono zainstalowanych wtyczek.', 'adinet-panel' ); ?></td></tr><?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if ( $can_manage && ! empty( $plugins ) ) : ?>
					<div class="adinet-plugin-updates-actions">
						<label for="adinet-lock-reason"><?php esc_html_e( 'Powód blokady (opcjonalnie)', 'adinet-panel' ); ?></label>
						<textarea id="adinet-lock-reason" name="reason" rows="2" maxlength="300" placeholder="<?php echo esc_attr__( 'Np. aktualizacja po testach integracji', 'adinet-panel' ); ?>"></textarea>
						<p class="adinet-help"><?php esc_html_e( 'Powód zostanie zapisany dla zaznaczonych wtyczek przy blokowaniu. Odblokowanie nie uruchamia aktualizacji.', 'adinet-panel' ); ?></p>
						<div class="adinet-monitor-table__actions">
							<button type="submit" name="operation" value="lock" class="button button-primary"><?php esc_html_e( 'Zablokuj aktualizacje', 'adinet-panel' ); ?></button>
							<button type="submit" name="operation" value="unlock" class="button"><?php esc_html_e( 'Odblokuj aktualizacje', 'adinet-panel' ); ?></button>
						</div>
					</div>
				<?php endif; ?>
			</section>
			<?php if ( $can_manage ) : ?></form><?php endif; ?>
			<p class="adinet-help"><?php esc_html_e( 'Blokada działa, gdy AdiNet Panel jest aktywny. Własne komunikaty i instalatory producentów mogą wymagać osobnej obsługi.', 'adinet-panel' ); ?></p>
		</div>
		<?php
	}
}
