<?php
/**
 * Shortcode automatycznego roku.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Year_Shortcode {
	/**
	 * Rejestruje hook inicjujący shortcode.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Rejestruje shortcode [year].
	 *
	 * @return void
	 */
	public static function register() {
		if ( ! AdiNet_Snippets::builtin_enabled( 'year' ) ) {
			return;
		}
		add_shortcode( 'year', array( __CLASS__, 'render' ) );
	}

	/**
	 * Zwraca aktualny rok lub datę w opcjonalnym formacie zgodnym z PHP.
	 *
	 * @param array|string $atts Atrybuty shortcode.
	 * @return string
	 */
	public static function render( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'format' => 'Y',
			),
			(array) $atts,
			'year'
		);

		$format = sanitize_text_field( (string) $atts['format'] );

		if ( '' === $format || strlen( $format ) > 40 ) {
			$format = 'Y';
		}

		$value = wp_date( $format );

		return false === $value ? '' : esc_html( $value );
	}
}
