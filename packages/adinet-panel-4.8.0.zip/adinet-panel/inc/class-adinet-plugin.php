<?php
/**
 * Główny kontroler wtyczki AdiNet Panel.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Plugin {
	/**
	 * Zapobiega podwójnej inicjalizacji.
	 *
	 * @var bool
	 */
	private static $initialized = false;

	/**
	 * Uruchamia funkcje wtyczki.
	 *
	 * @return void
	 */
	public static function init() {
		if ( self::$initialized ) {
			return;
		}

		self::$initialized = true;

		AdiNet_Updater::init();
		self::maybe_upgrade();
		self::maybe_disable_wp_cron();
		self::maybe_disallow_file_edit();
		AdiNet_Debug_Control::init();
		AdiNet_Cron_Health::init();

		add_action( 'init', array( __CLASS__, 'load_textdomain' ), 0 );
		add_filter( 'plugin_action_links_' . plugin_basename( ADINET_FILE ), array( __CLASS__, 'add_action_links' ) );

		AdiNet_Snippets::init();
		AdiNet_Year_Shortcode::init();
		AdiNet_Footer_Shortcode::init();
		AdiNet_Update_Emails::init();
		AdiNet_Login_URL::init();
		AdiNet_Comments_Control::init();
		AdiNet_Revisions_Control::init();
		AdiNet_Admin::init();
		AdiNet_Billing::init();
		AdiNet_Dashboard::init();
		AdiNet_Plugin_Installer::init();
		AdiNet_Plugin_Updates::init();
		AdiNet_404_Monitor::init();
		AdiNet_Admin_Log::init();
		AdiNet_Audit::init();
		AdiNet_Htaccess::init();
	}

	/**
	 * Ustawia bezpieczne wartości domyślne przy pierwszej aktywacji.
	 *
	 * @return void
	 */
	public static function activate() {
		self::install_defaults();
	}

	/**
	 * Uzupełnia brakujące wartości przy migracji i aktualizacji wtyczki.
	 *
	 * @return void
	 */
	private static function maybe_upgrade() {
		$installed_version = get_option( AdiNet_Options::PLUGIN_VERSION, '' );

		if ( ADINET_VERSION !== $installed_version ) {
			self::install_defaults();
		}
	}

	/**
	 * Dodaje wyłącznie brakujące opcje i nie nadpisuje danych z wersji motywowej.
	 *
	 * @return void
	 */
	private static function install_defaults() {
		add_option( AdiNet_Options::UPDATE_EMAIL_MODE, AdiNet_Options::EMAIL_MODE_FAILURES );
		add_option( AdiNet_Options::ADMIN_NOTE, '' );
		add_option( AdiNet_Options::DISABLE_WP_CRON, 0 );
		add_option( AdiNet_Options::LOGIN_URL_ENABLED, 0 );
		add_option( AdiNet_Options::LOGIN_SLUG, AdiNet_Options::DEFAULT_LOGIN_SLUG );
		add_option( AdiNet_Options::SITE_LAUNCH_DATE, '' );
		add_option( AdiNet_Options::MAINTENANCE_MONTH, '' );
		add_option( AdiNet_Options::DEBUG_DISPLAY_MODE, AdiNet_Options::DEBUG_MODE_INHERIT );
		add_option( AdiNet_Options::DEBUG_LOG_MODE, AdiNet_Options::DEBUG_MODE_INHERIT );
		add_option( AdiNet_Options::DISABLE_COMMENTS, 0 );
		add_option( AdiNet_Options::DISALLOW_FILE_EDIT, 0 );
		add_option( AdiNet_Options::REVISION_LIMIT, AdiNet_Options::DEFAULT_REVISION_LIMIT );
		add_option( AdiNet_Options::REVISION_MAX_AGE, AdiNet_Options::DEFAULT_REVISION_MAX_AGE );
		add_option( AdiNet_Options::MONITOR_404_ENABLED, 0 );
		add_option( AdiNet_Options::MONITOR_404_STARTED_AT, 0, '', false );
		add_option( AdiNet_Options::MONITOR_404_ENDS_AT, 0, '', false );
		add_option( AdiNet_Options::ADMIN_LOG_ENABLED, 0 );
		add_option( AdiNet_Options::ADMIN_LOG_STARTED_AT, 0, '', false );
		add_option( AdiNet_Options::ADMIN_LOG_LAST_CLEANUP, 0, '', false );
		add_option( AdiNet_Options::LAST_AUDIT, array(), '', false );
		add_option( AdiNet_Options::HTACCESS_RULES, array(), '', false );
		AdiNet_404_Monitor::install_table();
		AdiNet_Admin_Log::install_table();
		AdiNet_Billing::install_table();
		AdiNet_Snippets::install_table();
		update_option( AdiNet_Options::PLUGIN_VERSION, ADINET_VERSION, false );
	}

	/**
	 * Wyłącza uruchamianie WP-Cron przez wejścia na stronę, jeśli wybrano tę opcję.
	 * Bezpośrednie wywołanie wp-cron.php przez zadanie serwerowe pozostaje dostępne.
	 *
	 * Ustawienie z wp-config.php jest ładowane wcześniej i zawsze ma pierwszeństwo.
	 *
	 * @return void
	 */
	private static function maybe_disable_wp_cron() {
		if ( ! AdiNet_Options::should_disable_wp_cron() || defined( 'DISABLE_WP_CRON' ) ) {
			return;
		}

		define( 'DISABLE_WP_CRON', true );
		define( 'ADINET_CONTROLS_WP_CRON', true );
	}

	/**
	 * Wyłącza edytory plików motywów i wtyczek, jeśli wybrano tę opcję.
	 * Wcześniejsza definicja z wp-config.php lub innej wtyczki ma pierwszeństwo.
	 *
	 * @return void
	 */
	private static function maybe_disallow_file_edit() {
		$all_file_mods_disabled = defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS;

		if ( ! AdiNet_Options::should_disallow_file_edit() || defined( 'DISALLOW_FILE_EDIT' ) || $all_file_mods_disabled ) {
			return;
		}

		define( 'DISALLOW_FILE_EDIT', true );
		define( 'ADINET_CONTROLS_FILE_EDIT', true );
	}

	/**
	 * Ładuje ewentualne tłumaczenia wtyczki.
	 *
	 * @return void
	 */
	public static function load_textdomain() {
		load_plugin_textdomain(
			'adinet-panel',
			false,
			dirname( plugin_basename( ADINET_FILE ) ) . '/languages'
		);
	}

	/**
	 * Dodaje skrót do panelu AdiNet na ekranie wtyczek.
	 *
	 * @param string[] $links Istniejące odnośniki akcji wtyczki.
	 * @return string[]
	 */
	public static function add_action_links( $links ) {
		$settings_link = sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url( admin_url( 'admin.php?page=' . AdiNet_Admin::PAGE_SLUG ) ),
			esc_html__( 'Panel AdiNet', 'adinet-panel' )
		);

		array_unshift( $links, $settings_link );

		return $links;
	}
}
