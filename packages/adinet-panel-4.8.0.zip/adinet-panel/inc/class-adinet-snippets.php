<?php
/**
 * Własne snippety PHP i biblioteka gotowych funkcji.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Snippets {
	const PAGE_SLUG = 'adinet-snippets';
	const ACTION = 'adinet_snippet_action';
	const BUILTINS_OPTION = 'adinet_snippet_builtins';
	const HISTORY_LIMIT = 3;
	const CODE_LIMIT = 65536;
	private static $page_hook = '';
	private static $running = array();
	private static $failed = array();
	private static $executed = array();
	private static $memory_reserve = '';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 30 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_action' ) );
		add_action( 'plugins_loaded', array( __CLASS__, 'run_early' ), 20 );
		add_action( 'wp', array( __CLASS__, 'run_front' ), 0 );
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'adinet_snippets';
	}

	public static function install_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = self::table();
		$collate = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			title varchar(190) NOT NULL,
			description text NOT NULL,
			code longtext NOT NULL,
			scope varchar(20) NOT NULL DEFAULT 'front',
			enabled tinyint(1) NOT NULL DEFAULT 0,
			revision bigint(20) unsigned NOT NULL DEFAULT 1,
			history longtext NOT NULL,
			last_error text NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY enabled_scope (enabled, scope)
		) {$collate};" );
	}

	/** All administrators may edit this module, including non-owner accounts. */
	public static function can_manage() {
		return current_user_can( 'manage_options' );
	}

	public static function builtin_enabled( $key ) {
		$options = get_option( self::BUILTINS_OPTION, array() );
		return ! is_array( $options ) || ! isset( $options[ $key ] ) || ! empty( $options[ $key ] );
	}

	public static function add_menu() {
		self::$page_hook = add_submenu_page( AdiNet_Admin::PAGE_SLUG, __( 'Snippety — AdiNet', 'adinet-panel' ), __( 'Snippety', 'adinet-panel' ), 'manage_options', self::PAGE_SLUG, array( __CLASS__, 'render_page' ) );
		add_action( 'load-' . self::$page_hook, array( 'AdiNet_Admin', 'suppress_external_admin_notices' ) );
	}

	public static function enqueue_assets( $hook ) {
		if ( self::$page_hook !== $hook ) {
			return;
		}
		wp_enqueue_style( 'adinet-admin', ADINET_URL . 'assets/css/admin.css', array(), ADINET_VERSION );
		wp_enqueue_script( 'adinet-admin', ADINET_URL . 'assets/js/admin.js', array(), ADINET_VERSION, true );
		$editor = wp_enqueue_code_editor( array( 'type' => 'text/x-php', 'codemirror' => array( 'mode' => array( 'name' => 'php', 'startOpen' => true ), 'lineNumbers' => true, 'indentUnit' => 4, 'indentWithTabs' => true ) ) );
		wp_enqueue_script( 'adinet-snippets', ADINET_URL . 'assets/js/snippets.js', $editor ? array( 'jquery', 'code-editor' ) : array( 'jquery' ), ADINET_VERSION, true );
		wp_localize_script( 'adinet-snippets', 'adinetSnippetEditor', array( 'settings' => $editor ) );
	}

	public static function get_item( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ), ARRAY_A );
	}

	public static function get_items( $active_only = false ) {
		global $wpdb;
		return (array) $wpdb->get_results( 'SELECT * FROM ' . self::table() . ( $active_only ? ' WHERE enabled = 1' : '' ) . ' ORDER BY id ASC', ARRAY_A );
	}

	private static function post( $key, $default = '' ) {
		return isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : $default;
	}

	/** Accept PHP with or without its outer tags, but never mixed HTML. */
	public static function normalize_code( $code ) {
		if ( ! is_string( $code ) || strlen( $code ) > self::CODE_LIMIT ) {
			return new WP_Error( 'code_size', __( 'Kod może mieć maksymalnie 64 KB.', 'adinet-panel' ) );
		}
		$code = trim( $code );
		$code = preg_replace( '/^<\?php\s/', '', $code );
		$code = preg_replace( '/\?>$/', '', $code );
		$code = trim( $code );
		if ( '' === $code || ! function_exists( 'token_get_all' ) ) {
			return new WP_Error( 'code_empty', __( 'Wklej kod PHP. Serwer musi udostępniać rozszerzenie Tokenizer.', 'adinet-panel' ) );
		}
		try {
			$tokens = token_get_all( "<?php\n" . $code, TOKEN_PARSE );
			foreach ( $tokens as $index => $token ) {
				if ( is_array( $token ) && ( T_INLINE_HTML === $token[0] || T_CLOSE_TAG === $token[0] || T_OPEN_TAG_WITH_ECHO === $token[0] || ( T_OPEN_TAG === $token[0] && 0 !== $index ) ) ) {
					return new WP_Error( 'php_only', __( 'Wklej wyłącznie PHP, bez przeplatania kodu z HTML.', 'adinet-panel' ) );
				}
			}
		} catch ( Throwable $error ) {
			return new WP_Error( 'syntax', sprintf( __( 'Błąd składni PHP: %s', 'adinet-panel' ), $error->getMessage() ) );
		}
		return $code;
	}

	/** Optimistic locking prevents simultaneous edits from overwriting history. */
	private static function update_item( $item, $data ) {
		global $wpdb;
		$data['revision'] = (int) $item['revision'] + 1;
		$data['updated_at'] = current_time( 'mysql', true );
		return 1 === $wpdb->update( self::table(), $data, array( 'id' => (int) $item['id'], 'revision' => (int) $item['revision'] ) );
	}

	private static function history( $item, $code, $scope ) {
		$history = json_decode( $item['history'], true );
		$history = is_array( $history ) ? $history : array();
		if ( $item['code'] !== $code || $item['scope'] !== $scope ) {
			array_unshift( $history, array( 'code' => $item['code'], 'scope' => $item['scope'], 'at' => $item['updated_at'] ) );
		}
		return wp_json_encode( array_slice( $history, 0, self::HISTORY_LIMIT ) );
	}

	public static function handle_action() {
		global $wpdb;
		if ( ! self::can_manage() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do zarządzania snippetami.', 'adinet-panel' ) );
		}
		check_admin_referer( self::ACTION );
		$operation = self::post( 'operation' );
		if ( 'builtins' === $operation ) {
			$options = array( 'year' => '1' === self::post( 'year' ), 'footer' => '1' === self::post( 'footer' ) );
			$old = get_option( self::BUILTINS_OPTION, array() );
			if ( $old !== $options && ! update_option( self::BUILTINS_OPTION, $options, false ) ) {
				self::redirect( 'error' );
			}
			self::log( 'Zapisano przełączniki gotowych shortcode’ów AdiNet.' );
			self::redirect( 'saved', 0, 'builtins' );
		}
		$id = absint( self::post( 'id' ) );
		$item = $id ? self::get_item( $id ) : null;
		if ( $id && ( ! $item || (int) $item['revision'] !== absint( self::post( 'revision' ) ) ) ) {
			self::redirect( 'conflict' );
		}
		if ( 'save' === $operation ) {
			$title = sanitize_text_field( self::post( 'title' ) );
			$description = sanitize_textarea_field( self::post( 'description' ) );
			$scope = self::post( 'scope' );
			$code = self::normalize_code( self::post( 'code' ) );
			if ( '' === $title || wp_html_excerpt( $title, 190, '' ) !== $title || wp_html_excerpt( $description, 5000, '' ) !== $description || ! isset( self::scopes()[ $scope ] ) ) {
				wp_die( esc_html__( 'Podaj tytuł (do 190 znaków), poprawny zakres i opis do 5000 znaków. Wróć do formularza, aby poprawić dane.', 'adinet-panel' ), '', array( 'back_link' => true ) );
			}
			if ( is_wp_error( $code ) ) {
				wp_die( esc_html( $code->get_error_message() ), '', array( 'back_link' => true ) );
			}
			$data = array( 'title' => $title, 'description' => $description, 'scope' => $scope, 'code' => $code, 'enabled' => 'activate' === self::post( 'save_mode' ) ? 1 : 0, 'last_error' => '', 'history' => $item ? self::history( $item, $code, $scope ) : '[]' );
			if ( $item ) {
				$ok = self::update_item( $item, $data );
			} else {
				$data['revision'] = 1;
				$data['updated_at'] = current_time( 'mysql', true );
				$ok = false !== $wpdb->insert( self::table(), $data );
				$id = (int) $wpdb->insert_id;
			}
			if ( ! $ok ) {
				self::redirect( 'error' );
			}
			self::log( sprintf( 'Zapisano snippet #%d: %s (%s).', $id, $title, $data['enabled'] ? 'aktywny' : 'wyłączony' ) );
			self::redirect( 'saved', $id );
		}
		if ( ! $item ) {
			self::redirect( 'conflict' );
		}
		if ( 'delete' === $operation ) {
			$ok = 1 === $wpdb->delete( self::table(), array( 'id' => $id, 'revision' => (int) $item['revision'] ) );
		} elseif ( 'toggle' === $operation ) {
			if ( empty( $item['enabled'] ) && is_wp_error( self::normalize_code( $item['code'] ) ) ) {
				self::redirect( 'invalid' );
			}
			$ok = self::update_item( $item, array( 'enabled' => empty( $item['enabled'] ) ? 1 : 0, 'last_error' => '' ) );
		} elseif ( 'restore' === $operation ) {
			$history = json_decode( $item['history'], true );
			$index = absint( self::post( 'history_index' ) );
			if ( ! is_array( $history ) || ! isset( $history[ $index ] ) ) {
				self::redirect( 'conflict' );
			}
			$previous = $history[ $index ];
			$code = self::normalize_code( $previous['code'] );
			if ( is_wp_error( $code ) || ! isset( self::scopes()[ $previous['scope'] ] ) ) {
				self::redirect( 'invalid' );
			}
			$ok = self::update_item( $item, array( 'code' => $code, 'scope' => $previous['scope'], 'enabled' => 0, 'last_error' => '', 'history' => self::history( $item, $code, $previous['scope'] ) ) );
		} else {
			self::redirect( 'invalid' );
		}
		if ( ! $ok ) {
			self::redirect( 'error' );
		}
		self::log( sprintf( 'Snippet #%d: %s — %s.', $id, $item['title'], $operation ) );
		self::redirect( 'delete' === $operation ? 'deleted' : 'saved', 'delete' === $operation ? 0 : $id );
	}

	private static function log( $message ) {
		AdiNet_Admin_Log::record( 'snippet_change', AdiNet_Admin_Log::LEVEL_WARNING, $message, array( 'is_change' => true ) );
	}

	private static function redirect( $notice, $id = 0, $tab = 'mine' ) {
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'notice' => $notice, 'edit' => $id, 'tab' => $tab ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function scopes() {
		return array( 'front' => __( 'Tylko front', 'adinet-panel' ), 'all' => __( 'Wszędzie', 'adinet-panel' ), 'admin' => __( 'Tylko panel', 'adinet-panel' ) );
	}

	/** Recovery screen skips custom PHP before it can register callbacks. */
	public static function bypass() {
		if ( defined( 'ADINET_SNIPPETS_DISABLED' ) && ADINET_SNIPPETS_DISABLED ) {
			return true;
		}
		if ( ! is_admin() || ! self::can_manage() ) {
			return false;
		}
		$page = isset( $_GET['page'] ) && is_string( $_GET['page'] ) ? $_GET['page'] : '';
		$action = isset( $_POST['action'] ) && is_string( $_POST['action'] ) ? $_POST['action'] : '';
		return self::PAGE_SLUG === $page || self::ACTION === $action;
	}

	public static function run_early() {
		self::run_scope( 'all' );
		if ( is_admin() && ! wp_doing_ajax() && ! wp_doing_cron() ) {
			self::run_scope( 'admin' );
		}
	}

	public static function run_front() {
		if ( ! is_admin() && ! wp_doing_ajax() && ! wp_doing_cron() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			self::run_scope( 'front' );
		}
	}

	private static function run_scope( $scope ) {
		if ( self::bypass() ) {
			return;
		}
		foreach ( self::get_items( true ) as $item ) {
			$id = (int) $item['id'];
			if ( $scope !== $item['scope'] || isset( self::$executed[ $id ] ) ) {
				continue;
			}
			self::$executed[ $id ] = true;
			self::guard( $item, static function () use ( $item ) {
				// Deliberately execute administrator-supplied PHP in an isolated local scope.
				// This is not a sandbox: PHP has the same privileges as the WordPress process.
				return eval( $item['code'] ); // phpcs:ignore Squiz.PHP.Eval.Discouraged
			} );
		}
	}

	/** Snapshot callbacks so deferred WordPress filters receive the same protection. */
	private static function hook_snapshot() {
		global $wp_filter;
		$snapshot = array();
		foreach ( (array) $wp_filter as $hook => $object ) {
			if ( $object instanceof WP_Hook ) {
				foreach ( $object->callbacks as $priority => $callbacks ) {
					foreach ( $callbacks as $key => $callback ) {
						$snapshot[ $hook ][ $priority ][ $key ] = $callback['function'];
					}
				}
			}
		}
		return $snapshot;
	}

	private static function guard( $item, $callback, $args = array() ) {
		$id = (int) $item['id'];
		$fallback = isset( $args[0] ) ? $args[0] : null;
		if ( isset( self::$failed[ $id ] ) ) {
			return $fallback;
		}
		if ( '' === self::$memory_reserve ) {
			self::$memory_reserve = str_repeat( ' ', 65536 );
			register_shutdown_function( array( __CLASS__, 'shutdown' ) );
		}
		$before = self::hook_snapshot();
		self::$running[] = $item;
		try {
			$result = call_user_func_array( $callback, $args );
		} catch ( Throwable $error ) {
			self::fail( $item, $error->getMessage() );
			$result = $fallback;
		} finally {
			array_pop( self::$running );
			self::wrap_new_hooks( $before, $item );
		}
		return $result;
	}

	private static function wrap_new_hooks( $before, $item ) {
		global $wp_filter;
		foreach ( (array) $wp_filter as $hook => $object ) {
			if ( ! ( $object instanceof WP_Hook ) ) {
				continue;
			}
			foreach ( $object->callbacks as $priority => $callbacks ) {
				foreach ( $callbacks as $key => $callback ) {
					if ( isset( $before[ $hook ][ $priority ][ $key ] ) && $before[ $hook ][ $priority ][ $key ] === $callback['function'] ) {
						continue;
					}
					$original = $callback['function'];
					$accepted = (int) $callback['accepted_args'];
					// Keep WP's original key: remove_filter($hook, $original) still works.
					$object->callbacks[ $priority ][ $key ]['accepted_args'] = max( 1, $accepted );
					$object->callbacks[ $priority ][ $key ]['function'] = static function ( ...$args ) use ( $item, $original, $accepted ) {
						return self::guard( $item, static function ( ...$values ) use ( $original, $accepted ) {
							return call_user_func_array( $original, array_slice( $values, 0, $accepted ) );
						}, $args );
					};
				}
			}
		}
	}

	private static function fail( $item, $message ) {
		self::$failed[ (int) $item['id'] ] = true;
		$message = wp_html_excerpt( sanitize_text_field( $message ), 1000, '' );
		$ok = self::update_item( $item, array( 'enabled' => 0, 'last_error' => $message ) );
		self::log( sprintf( 'Błąd snippetu #%d: %s. %s', $item['id'], $item['title'], $ok ? 'Automatycznie wyłączono kod.' : 'Nie zapisano wyłączenia — użyj trybu awaryjnego.' ) );
	}

	public static function shutdown() {
		self::$memory_reserve = '';
		$error = error_get_last();
		if ( self::$running && $error && in_array( $error['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ), true ) ) {
			self::fail( end( self::$running ), $error['message'] );
		}
	}

	private static function action_fields( $operation, $item = null ) {
		wp_nonce_field( self::ACTION );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION ) . '"><input type="hidden" name="operation" value="' . esc_attr( $operation ) . '">';
		if ( $item ) {
			echo '<input type="hidden" name="id" value="' . esc_attr( $item['id'] ) . '"><input type="hidden" name="revision" value="' . esc_attr( $item['revision'] ) . '">';
		}
	}

	public static function render_page() {
		if ( ! self::can_manage() ) {
			return;
		}
		$base = admin_url( 'admin.php?page=' . self::PAGE_SLUG );
		$builtins = isset( $_GET['tab'] ) && 'builtins' === $_GET['tab'];
		$edit_id = isset( $_GET['edit'] ) && is_scalar( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0;
		$item = $edit_id ? self::get_item( $edit_id ) : null;
		$notices = array( 'saved' => 'Zapisano zmiany.', 'deleted' => 'Usunięto snippet wraz z historią.', 'conflict' => 'Dane zmieniły się w innym żądaniu lub wpis już nie istnieje. Odśwież stronę.', 'invalid' => 'Niepoprawna operacja lub kod. Popraw snippet przed włączeniem.', 'error' => 'Nie udało się zapisać zmian. Odśwież stronę i spróbuj ponownie.' );
		$notice = isset( $_GET['notice'] ) && is_string( $_GET['notice'] ) ? $_GET['notice'] : '';
		?>
		<div class="wrap adinet-admin adinet-snippets">
			<header class="adinet-monitor-hero"><div><p class="adinet-eyebrow"><?php esc_html_e( 'Narzędzia programistyczne AdiNet', 'adinet-panel' ); ?></p><h1><?php esc_html_e( 'Snippety PHP', 'adinet-panel' ); ?></h1><p><?php esc_html_e( 'Własne funkcje WordPressa i gotowe shortcode’y w jednym miejscu.', 'adinet-panel' ); ?></p></div></header>
			<div class="notice notice-warning"><p><?php esc_html_e( 'Funkcja zalecana tylko dla zaawansowanych użytkowników. PHP może zmienić działanie całej witryny. Używaj zaufanego kodu i sprawdzaj go najpierw na stronie testowej.', 'adinet-panel' ); ?></p></div>
			<?php if ( isset( $notices[ $notice ] ) ) : ?><div class="notice <?php echo in_array( $notice, array( 'saved', 'deleted' ), true ) ? 'notice-success' : 'notice-error'; ?>"><p><?php echo esc_html( $notices[ $notice ] ); ?></p></div><?php endif; ?>
			<?php if ( defined( 'ADINET_SNIPPETS_DISABLED' ) && ADINET_SNIPPETS_DISABLED ) : ?><div class="notice notice-error"><p><?php esc_html_e( 'Tryb awaryjny: wszystkie własne snippety są pomijane przez ADINET_SNIPPETS_DISABLED.', 'adinet-panel' ); ?></p></div><?php endif; ?>
			<nav class="nav-tab-wrapper"><a class="nav-tab <?php echo $builtins ? '' : 'nav-tab-active'; ?>" href="<?php echo esc_url( $base ); ?>"><?php esc_html_e( 'Moje snippety', 'adinet-panel' ); ?></a><a class="nav-tab <?php echo $builtins ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'tab', 'builtins', $base ) ); ?>"><?php esc_html_e( 'Gotowe funkcje AdiNet', 'adinet-panel' ); ?></a></nav>
			<?php if ( $builtins ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="adinet-snippet-builtins">
					<?php self::action_fields( 'builtins' ); ?>
					<p><label><input type="checkbox" name="year" value="1" <?php checked( self::builtin_enabled( 'year' ) ); ?>> <?php esc_html_e( 'Włącz shortcode [year]', 'adinet-panel' ); ?></label></p>
					<p><label><input type="checkbox" name="footer" value="1" <?php checked( self::builtin_enabled( 'footer' ) ); ?>> <?php esc_html_e( 'Włącz shortcode [adinet_footer]', 'adinet-panel' ); ?></label></p>
					<p><?php esc_html_e( 'Po wyłączeniu shortcode może pozostać widoczny w treści jako tekst. Przełączniki nie zmieniają wcześniej wklejonej stopki Divi.', 'adinet-panel' ); ?></p>
					<?php submit_button( __( 'Zapisz przełączniki', 'adinet-panel' ) ); ?>
				</form>
				<?php require ADINET_PATH . 'inc/templates/snippet-builtins.php'; ?>
			<?php else : ?>
				<p><?php esc_html_e( 'Na tej podstronie i podczas zapisu własne snippety nie są wykonywane. Możesz tutaj poprawić lub wyłączyć błędny kod.', 'adinet-panel' ); ?></p>
				<div class="adinet-snippet-table-scroll"><table class="widefat striped adinet-snippet-list"><thead><tr><th><?php esc_html_e( 'Tytuł / opis', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Zakres', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Status', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Akcje', 'adinet-panel' ); ?></th></tr></thead><tbody>
				<?php $items = self::get_items(); foreach ( $items as $row ) : ?>
					<tr><td><a href="<?php echo esc_url( add_query_arg( 'edit', $row['id'], $base ) ); ?>"><strong><?php echo esc_html( $row['title'] ); ?></strong></a><p><?php echo nl2br( esc_html( $row['description'] ) ); ?></p><?php if ( $row['last_error'] ) : ?><p class="adinet-snippet-error"><?php echo esc_html( $row['last_error'] ); ?></p><?php endif; ?></td><td><?php echo esc_html( self::scopes()[ $row['scope'] ] ?? $row['scope'] ); ?></td><td><?php echo esc_html( $row['enabled'] ? __( 'Aktywny', 'adinet-panel' ) : __( 'Wyłączony', 'adinet-panel' ) ); ?></td><td>
						<a class="button" href="<?php echo esc_url( add_query_arg( 'edit', $row['id'], $base ) ); ?>"><?php esc_html_e( 'Edytuj', 'adinet-panel' ); ?></a>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php self::action_fields( 'toggle', $row ); ?><button class="button"><?php echo esc_html( $row['enabled'] ? __( 'Wyłącz', 'adinet-panel' ) : __( 'Włącz', 'adinet-panel' ) ); ?></button></form>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-confirm-form="<?php esc_attr_e( 'Usunąć snippet i jego trzy poprzednie wersje?', 'adinet-panel' ); ?>"><?php self::action_fields( 'delete', $row ); ?><button class="button button-link-delete"><?php esc_html_e( 'Usuń', 'adinet-panel' ); ?></button></form>
					</td></tr>
				<?php endforeach; if ( ! $items ) : ?><tr><td colspan="4"><?php esc_html_e( 'Nie dodano jeszcze snippetów.', 'adinet-panel' ); ?></td></tr><?php endif; ?>
				</tbody></table></div>
				<section class="adinet-card adinet-snippet-editor"><h2><?php echo esc_html( $item ? __( 'Edytuj snippet', 'adinet-panel' ) : __( 'Dodaj snippet PHP', 'adinet-panel' ) ); ?></h2>
					<?php if ( $item ) : ?><a href="<?php echo esc_url( $base ); ?>"><?php esc_html_e( 'Dodaj nowy zamiast edytować', 'adinet-panel' ); ?></a><?php endif; ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="adinet-snippet-form">
						<?php self::action_fields( 'save', $item ); ?>
						<p><label for="snippet-title"><?php esc_html_e( 'Tytuł', 'adinet-panel' ); ?></label><input id="snippet-title" name="title" class="large-text" required maxlength="190" value="<?php echo esc_attr( $item['title'] ?? '' ); ?>"></p>
						<p><label for="snippet-description"><?php esc_html_e( 'Opis / komentarz', 'adinet-panel' ); ?></label><textarea id="snippet-description" name="description" class="large-text" rows="3"><?php echo esc_textarea( $item['description'] ?? '' ); ?></textarea></p>
						<p><label for="snippet-scope"><?php esc_html_e( 'Zakres działania', 'adinet-panel' ); ?></label> <select id="snippet-scope" name="scope"><?php foreach ( self::scopes() as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>" <?php selected( $item['scope'] ?? 'front', $key ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></p>
						<p class="description"><?php esc_html_e( 'Tylko front: zwykłe strony po rozpoznaniu zapytania (hook wp); można używać is_singular(). Tylko panel: bez AJAX. Wszędzie: od plugins_loaded, również AJAX, REST i WP-Cron. Każdy zakres pomija tę zakładkę i jej zapis.', 'adinet-panel' ); ?></p>
						<p><label for="snippet-code"><?php esc_html_e( 'Kod PHP (bez znaczników <?php i ?>, maksymalnie 64 KB)', 'adinet-panel' ); ?></label><textarea id="snippet-code" name="code" class="large-text code" rows="18" required spellcheck="false"><?php echo esc_textarea( $item['code'] ?? '' ); ?></textarea></p>
						<p><?php esc_html_e( 'Sprawdzenie składni nie potwierdza poprawności działania. „Zapisz jako wyłączony” wyłącza również aktualnie aktywny snippet.', 'adinet-panel' ); ?></p>
						<button class="button" name="save_mode" value="disabled"><?php esc_html_e( 'Zapisz jako wyłączony', 'adinet-panel' ); ?></button> <button class="button button-primary" name="save_mode" value="activate"><?php esc_html_e( 'Zapisz i włącz', 'adinet-panel' ); ?></button>
					</form>
					<?php if ( $item ) : $history = json_decode( $item['history'], true ); ?>
						<h3><?php esc_html_e( 'Historia — maksymalnie 3 poprzednie wersje', 'adinet-panel' ); ?></h3>
						<?php foreach ( (array) $history as $index => $previous ) : ?><details><summary><?php echo esc_html( $previous['at'] . ' UTC — ' . ( self::scopes()[ $previous['scope'] ] ?? '' ) ); ?></summary><pre><?php echo esc_html( $previous['code'] ); ?></pre><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php self::action_fields( 'restore', $item ); ?><input type="hidden" name="history_index" value="<?php echo esc_attr( $index ); ?>"><button class="button"><?php esc_html_e( 'Przywróć jako wyłączony', 'adinet-panel' ); ?></button></form></details><?php endforeach; ?>
					<?php endif; ?>
				</section>
				<p><?php esc_html_e( 'Awaryjne wyłączenie wszystkich własnych snippetów: dodaj w wp-config.php przed ładowaniem WordPressa:', 'adinet-panel' ); ?> <code>define( 'ADINET_SNIPPETS_DISABLED', true );</code></p>
			<?php endif; ?>
		</div>
		<?php
	}
}
