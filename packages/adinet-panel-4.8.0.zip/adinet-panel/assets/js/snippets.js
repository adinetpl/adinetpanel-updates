( function ( $ ) {
	'use strict';
	$( function () {
		var field = document.getElementById( 'snippet-code' );
		var form = document.getElementById( 'adinet-snippet-form' );
		var editor;
		var config = window.adinetSnippetEditor;
		if ( ! field || ! form ) { return; }
		if ( config && config.settings && window.wp && wp.codeEditor ) {
			editor = wp.codeEditor.initialize( field, config.settings );
			// Native required validation cannot focus the textarea hidden by CodeMirror.
			field.required = false;
		}
		form.addEventListener( 'submit', function ( event ) {
			if ( editor ) { editor.codemirror.save(); }
			if ( ! field.value.trim() ) {
				event.preventDefault();
				if ( editor ) { editor.codemirror.focus(); } else { field.focus(); }
			}
		} );
	} );
} )( jQuery );
