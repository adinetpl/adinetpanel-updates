(function () {
	'use strict';
	var form = document.querySelector('.adinet-plugin-updates-form');
	if (!form) return;
	var all = form.querySelector('[data-adinet-select-all]');
	var items = Array.from(form.querySelectorAll('input[name="plugins[]"]'));
	if (!all) return;
	all.addEventListener('change', function () {
		items.forEach(function (item) { item.checked = all.checked; });
	});
	items.forEach(function (item) {
		item.addEventListener('change', function () {
			var selected = items.filter(function (checkbox) { return checkbox.checked; }).length;
			all.checked = selected === items.length;
			all.indeterminate = selected > 0 && selected < items.length;
		});
	});
}());
