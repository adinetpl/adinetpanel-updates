<?php
/**
 * Katalog źródeł i pól informacyjnych profili projektu.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Resource_Catalog {
	public static function categories() {
		return array( 'icons' => __( 'Ikony', 'adinet-panel' ), 'photos' => __( 'Zdjęcia i grafiki', 'adinet-panel' ), 'fonts' => __( 'Fonty', 'adinet-panel' ), 'generators' => __( 'Generatory', 'adinet-panel' ), 'tools' => __( 'Narzędzia', 'adinet-panel' ), 'other' => __( 'Inne zasoby', 'adinet-panel' ) );
	}

	private static function choice( $label, $choices, $default, $condition = array() ) {
		return array( 'label' => $label, 'type' => 'select', 'choices' => $choices, 'default' => $default, 'condition' => $condition );
	}

	private static function number( $label, $default, $min, $max, $step = 1, $condition = array() ) {
		return array( 'label' => $label, 'type' => 'number', 'default' => $default, 'min' => $min, 'max' => $max, 'step' => $step, 'condition' => $condition );
	}

	public static function providers() {
		$outline = array( 'outline' => 'Outline', 'filled' => 'Filled' );
		return array(
			'magnific' => array(
				'name' => 'Magnific', 'url' => 'https://magnific.com/', 'category' => 'generators', 'access' => __( 'Generowanie obrazów AI', 'adinet-panel' ),
				'description' => __( 'Profile modeli, proporcji, rozdzielczości i jakości. Prompt wzorcowy, referencje i ustawienia Cinematic.', 'adinet-panel' ),
				'help' => __( 'Wybierz dokładny model i wersję. Auto może dobierać różne modele. Lista ustawień pochodzi z katalogu Magnific z 17.11.2026; dostępność w Twoim interfejsie może zależeć od konta. Nowe modele i dodatkowe ustawienia możesz opisać ręcznie.', 'adinet-panel' ),
				'fields' => AdiNet_Magnific_Profiles::fields(),
			),
			'flaticon' => array(
				'name' => 'Flaticon', 'url' => 'https://www.flaticon.com/', 'access' => __( 'Dostęp Premium według Twojej subskrypcji', 'adinet-panel' ),
				'description' => __( 'Wiele rodzin i autorów. Dla spójności zapisz konkretny styl oraz link do rodziny lub paczki.', 'adinet-panel' ),
				'help' => __( 'Obrys można edytować w ikonach z edytowalnymi liniami. Dodatkowe ustawienia zapisz w parametrach własnych.', 'adinet-panel' ),
				'fields' => array(
					'variant' => self::choice( __( 'Rodzaj ikon', 'adinet-panel' ), array( 'outline' => 'Outline / Lineal', 'filled' => 'Filled / Solid', 'color' => __( 'Kolorowe', 'adinet-panel' ), 'other' => __( 'Inny — opisz w notatce', 'adinet-panel' ) ), 'outline' ),
					'editable_stroke' => self::choice( __( 'Edytowalny obrys', 'adinet-panel' ), array( 'no' => __( 'Nie / nie dotyczy', 'adinet-panel' ), 'yes' => __( 'Tak', 'adinet-panel' ) ), 'no' ),
					'stroke' => self::number( __( 'Obrys w edytorze', 'adinet-panel' ), '', 0.01, 100, 0.01, array( 'editable_stroke' => array( 'yes' ) ) ),
				),
			),
			'lucide' => array(
				'name' => 'Lucide', 'url' => 'https://lucide.dev/icons/', 'access' => __( 'Bezpłatne · ISC', 'adinet-panel' ),
				'description' => __( 'Spójne ikony obrysowe. Regulowany obrys 0,5–3 co 0,25, rozmiar i kolor.', 'adinet-panel' ),
				'help' => __( 'Rozmiar eksportu jest niezależny od rozmiaru wyświetlania. Zapisz również sposób skalowania obrysu.', 'adinet-panel' ),
				'fields' => array(
					'size' => self::number( __( 'Rozmiar eksportu SVG', 'adinet-panel' ), '24', 16, 256, 4 ),
					'stroke' => self::number( __( 'Obrys (Stroke width)', 'adinet-panel' ), '2', 0.5, 3, 0.25 ),
					'non_scaling' => self::choice( __( 'Non-scaling stroke', 'adinet-panel' ), array( 'no' => __( 'Wyłączone — obrys skaluje się z ikoną', 'adinet-panel' ), 'yes' => __( 'Włączone — stała grubość obrysu', 'adinet-panel' ) ), 'no' ),
				),
			),
			'tabler' => array(
				'name' => 'Tabler', 'url' => 'https://tabler.io/icons', 'access' => __( 'Bezpłatne · MIT', 'adinet-panel' ),
				'description' => __( 'Outline i Filled. Obrys Outline: 1, 1,25, 1,5, 1,75 lub 2.', 'adinet-panel' ),
				'help' => __( 'Wariant Filled nie korzysta z ustawienia obrysu. Rozmiar SVG zapisz według ustawienia w serwisie.', 'adinet-panel' ),
				'fields' => array(
					'variant' => self::choice( __( 'Styl', 'adinet-panel' ), $outline, 'outline' ),
					'size' => self::number( __( 'Rozmiar eksportu SVG', 'adinet-panel' ), '32', 1, 4096 ),
					'stroke' => self::choice( __( 'Obrys (Stroke)', 'adinet-panel' ), array( '1' => '1', '1.25' => '1,25', '1.5' => '1,5', '1.75' => '1,75', '2' => '2' ), '2', array( 'variant' => array( 'outline' ) ) ),
				),
			),
			'iconoir' => array(
				'name' => 'Iconoir', 'url' => 'https://iconoir.com/', 'access' => __( 'Bezpłatne · MIT', 'adinet-panel' ),
				'description' => __( 'Regular i wybrane ikony Solid. Obrys 0,5–3 co 0,1; rozmiar 16–64.', 'adinet-panel' ),
				'help' => __( 'Nie każda ikona ma wariant Solid. Bazowy obrys Regular wynosi 1,5.', 'adinet-panel' ),
				'fields' => array(
					'variant' => self::choice( __( 'Styl', 'adinet-panel' ), array( 'regular' => 'Regular', 'solid' => 'Solid' ), 'regular' ),
					'size' => self::number( __( 'Rozmiar eksportu SVG', 'adinet-panel' ), '24', 16, 64 ),
					'stroke' => self::number( __( 'Obrys (Stroke)', 'adinet-panel' ), '1.5', 0.5, 3, 0.1, array( 'variant' => array( 'regular' ) ) ),
				),
			),
			'phosphor' => array(
				'name' => 'Phosphor', 'url' => 'https://phosphoricons.com/', 'access' => __( 'Bezpłatne · MIT', 'adinet-panel' ),
				'description' => __( 'Sześć wariantów: Thin, Light, Regular, Bold, Fill i Duotone.', 'adinet-panel' ),
				'help' => __( 'Grubość wybierasz przez gotowy wariant. Wygląd Duotone po imporcie sprawdź w docelowym narzędziu.', 'adinet-panel' ),
				'fields' => array(
					'variant' => self::choice( __( 'Wariant / grubość', 'adinet-panel' ), array( 'thin' => 'Thin', 'light' => 'Light', 'regular' => 'Regular', 'bold' => 'Bold', 'fill' => 'Fill', 'duotone' => 'Duotone' ), 'regular' ),
					'size' => self::number( __( 'Rozmiar eksportu SVG', 'adinet-panel' ), '32', 16, 96, 4 ),
				),
			),
			'google' => array(
				'name' => 'Google Fonts — ikony', 'url' => 'https://fonts.google.com/icons', 'access' => __( 'Bezpłatne · Apache 2.0', 'adinet-panel' ),
				'description' => __( 'Material Symbols i klasyczne Material Icons, rodziny Outlined, Rounded i Sharp.', 'adinet-panel' ),
				'help' => __( 'Optical size wpływa na rysunek i nie oznacza rozmiaru wyświetlania. Zapisuj wartości dostępne przy pobieraniu wybranego SVG; zakres fontu może być szerszy.', 'adinet-panel' ),
				'fields' => array(
					'set' => self::choice( __( 'Zestaw', 'adinet-panel' ), array( 'symbols' => 'Material Symbols', 'icons' => 'Material Icons (klasyczne)' ), 'symbols' ),
					'symbols_family' => self::choice( __( 'Rodzina Material Symbols', 'adinet-panel' ), array( 'outlined' => 'Outlined', 'rounded' => 'Rounded', 'sharp' => 'Sharp' ), 'outlined', array( 'set' => array( 'symbols' ) ) ),
					'icons_family' => self::choice( __( 'Rodzina Material Icons', 'adinet-panel' ), array( 'outlined' => 'Outlined', 'filled' => 'Filled', 'rounded' => 'Rounded', 'sharp' => 'Sharp', 'two-tone' => 'Two tone' ), 'outlined', array( 'set' => array( 'icons' ) ) ),
					'fill' => self::choice( __( 'Wypełnienie (Fill)', 'adinet-panel' ), array( '0' => __( '0 — bez wypełnienia', 'adinet-panel' ), '1' => __( '1 — wypełnione', 'adinet-panel' ) ), '0', array( 'set' => array( 'symbols' ) ) ),
					'weight' => self::choice( 'Weight', array_combine( range( 100, 700, 100 ), range( 100, 700, 100 ) ), '400', array( 'set' => array( 'symbols' ) ) ),
					'grade' => self::number( 'Grade', '0', -50, 200, 1, array( 'set' => array( 'symbols' ) ) ),
					'optical_size' => self::number( 'Optical size', '24', 20, 48, 1, array( 'set' => array( 'symbols' ) ) ),
					'size' => self::number( __( 'Rozmiar eksportu SVG', 'adinet-panel' ), '24', 1, 4096 ),
				),
			),
		);
	}

	public static function provider_category( $provider ) {
		return $provider['category'] ?? 'icons';
	}

	public static function fields( $provider, $values = array() ) {
		if ( 'magnific' === $provider ) {
			$model = isset( $values['model'] ) && is_string( $values['model'] ) ? $values['model'] : 'custom';
			return AdiNet_Magnific_Profiles::fields( $model );
		}
		$providers = self::providers();
		return $providers[ $provider ]['fields'] ?? array();
	}

	public static function field_visible( $field, $values ) {
		foreach ( $field['condition'] as $key => $allowed ) {
			if ( ! isset( $values[ $key ] ) || ! in_array( (string) $values[ $key ], $allowed, true ) ) {
				return false;
			}
		}
		return true;
	}
}
