(function () {
	function placeWidePanel() {
		var panel = document.getElementById('adinet_welcome_wide');
		var widgets = document.getElementById('dashboard-widgets-wrap');

		if (panel && widgets && widgets.parentNode) {
			widgets.parentNode.insertBefore(panel, widgets);
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', placeWidePanel);
	} else {
		placeWidePanel();
	}
}());
