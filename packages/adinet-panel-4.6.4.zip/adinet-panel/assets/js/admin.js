( function () {
	'use strict';

	function copyText( text ) {
		if ( navigator.clipboard && window.isSecureContext ) {
			return navigator.clipboard.writeText( text );
		}

		return new Promise( function ( resolve, reject ) {
			var textarea = document.createElement( 'textarea' );

			textarea.value = text;
			textarea.setAttribute( 'readonly', '' );
			textarea.style.position = 'fixed';
			textarea.style.opacity = '0';
			document.body.appendChild( textarea );
			textarea.select();

			try {
				if ( document.execCommand( 'copy' ) ) {
					resolve();
				} else {
					reject( new Error( 'Copy command failed.' ) );
				}
			} catch ( error ) {
				reject( error );
			}

			document.body.removeChild( textarea );
		} );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		var copyButtons = document.querySelectorAll( '.adinet-copy-button' );
		var copyStatus = document.getElementById( 'adinet-copy-status' );
		var confirmLinks = document.querySelectorAll( '[data-confirm]' );
		var confirmForms = document.querySelectorAll( '[data-confirm-form]' );
		var settingsForm = document.querySelector( '.adinet-settings-form' );
		var readOnlyForms = document.querySelectorAll( '[data-adinet-readonly="1"]' );
		var billingSelectAll = document.querySelector( '.adinet-billing-select-all' );
		var billingRowCheckboxes = document.querySelectorAll( '.adinet-billing-row-checkbox' );
		var billingBulkSubmits = document.querySelectorAll( '.adinet-billing-bulk-submit' );
		var billingSelectionCount = document.querySelector( '.adinet-billing-selection-count' );
		var renewalPlusYear = document.querySelector( '.adinet-renewal-plus-year' );
		var orderedSections;

		if ( settingsForm ) {
			orderedSections = Array.prototype.filter.call( settingsForm.children, function ( child ) {
				return child.hasAttribute( 'data-adinet-order' );
			} );
			orderedSections.sort( function ( first, second ) {
				return Number( first.dataset.adinetOrder ) - Number( second.dataset.adinetOrder );
			} );
			orderedSections.forEach( function ( section ) {
				settingsForm.appendChild( section );
			} );
		}

		if ( settingsForm && settingsForm.dataset.adinetReadonly !== '1' ) {
			var initialSettings = new URLSearchParams( new FormData( settingsForm ) ).toString();
			var dirty = false;
			var leaving = false;
			var saveStatus = document.getElementById( 'adinet-save-status' );
			function updateDirty() {
				dirty = new URLSearchParams( new FormData( settingsForm ) ).toString() !== initialSettings;
				if ( saveStatus ) { saveStatus.textContent = dirty ? 'Masz niezapisane zmiany' : 'Brak nowych zmian'; }
				settingsForm.classList.toggle( 'has-unsaved-changes', dirty );
			}
			settingsForm.addEventListener( 'input', updateDirty );
			settingsForm.addEventListener( 'change', updateDirty );
			settingsForm.addEventListener( 'submit', function () { leaving = true; } );
			window.addEventListener( 'beforeunload', function ( event ) {
				if ( dirty && ! leaving ) { event.preventDefault(); event.returnValue = ''; }
			} );
			var htaccessForm = document.querySelector( '.adinet-htaccess-form' );
			if ( htaccessForm ) {
				htaccessForm.addEventListener( 'submit', function ( event ) {
					if ( dirty && ! window.confirm( 'Masz niezapisane ustawienia panelu. Zapis .htaccess ich nie zachowa. Kontynuować i utracić te zmiany?' ) ) {
						event.preventDefault();
					} else { leaving = true; }
				} );
			}
		}

		Array.prototype.forEach.call( readOnlyForms, function ( form ) {
			var editableControls = form.querySelectorAll( 'input:not([type="hidden"]), select, textarea, button[type="submit"]' );

			Array.prototype.forEach.call( editableControls, function ( control ) {
				control.disabled = true;
			} );
		} );

		function updateBillingSelection() {
			var selectedCount = Array.prototype.filter.call( billingRowCheckboxes, function ( checkbox ) {
				return checkbox.checked;
			} ).length;

			if ( billingSelectAll ) {
				billingSelectAll.checked = billingRowCheckboxes.length > 0 && selectedCount === billingRowCheckboxes.length;
				billingSelectAll.indeterminate = selectedCount > 0 && selectedCount < billingRowCheckboxes.length;
			}

			Array.prototype.forEach.call( billingBulkSubmits, function ( button ) {
				button.disabled = 0 === selectedCount;
			} );

			if ( billingSelectionCount ) {
				billingSelectionCount.textContent = selectedCount > 0 ? 'Zaznaczono: ' + selectedCount : 'Nie zaznaczono pozycji';
			}
		}

		if ( billingSelectAll ) {
			billingSelectAll.addEventListener( 'change', function () {
				Array.prototype.forEach.call( billingRowCheckboxes, function ( checkbox ) {
					checkbox.checked = billingSelectAll.checked;
				} );
				updateBillingSelection();
			} );
		}

		Array.prototype.forEach.call( billingRowCheckboxes, function ( checkbox ) {
			checkbox.addEventListener( 'change', updateBillingSelection );
		} );

		updateBillingSelection();

		if ( renewalPlusYear ) {
			renewalPlusYear.addEventListener( 'click', function () {
				var form = renewalPlusYear.closest( '.adinet-billing-form' );
				var renewal = form.querySelector( '[name="renewal_date"]' );
				var purchase = form.querySelector( '[name="purchase_date"]' );
				var source = renewal.value || purchase.value;
				var parts;
				var base;
				var year;
				var month;
				var day;

				if ( source ) {
					parts = source.split( '-' ).map( Number );
					base = new Date( parts[ 0 ], parts[ 1 ] - 1, parts[ 2 ] );
				} else {
					base = new Date();
				}

				year = base.getFullYear() + 1;
				month = base.getMonth();
				day = Math.min( base.getDate(), new Date( year, month + 1, 0 ).getDate() );
				renewal.value = [ year, String( month + 1 ).padStart( 2, '0' ), String( day ).padStart( 2, '0' ) ].join( '-' );
				renewal.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			} );
		}

		Array.prototype.forEach.call( copyButtons, function ( copyButton ) {
			copyButton.addEventListener( 'click', function () {
				var defaultLabel = copyButton.dataset.defaultLabel || 'Kopiuj';
				var copiedLabel = copyButton.dataset.copiedLabel || 'Skopiowano';

				copyText( copyButton.dataset.copy || '' ).then( function () {
					copyButton.textContent = copiedLabel;

					if ( copyStatus ) {
						copyStatus.textContent = copiedLabel;
					}

					window.setTimeout( function () {
						copyButton.textContent = defaultLabel;
					}, 1800 );
				} ).catch( function () {
					copyButton.textContent = defaultLabel;
				} );
			} );
		} );

		Array.prototype.forEach.call( confirmLinks, function ( link ) {
			link.addEventListener( 'click', function ( event ) {
				var confirmation = link.dataset.confirm || '';

				if ( confirmation && ! window.confirm( confirmation ) ) {
					event.preventDefault();
				}
			} );
		} );

		Array.prototype.forEach.call( confirmForms, function ( form ) {
			form.addEventListener( 'submit', function ( event ) {
				var confirmation = form.dataset.confirmForm || '';

				if ( confirmation && ! window.confirm( confirmation ) ) {
					event.preventDefault();
				}
			} );
		} );

	} );
}() );
