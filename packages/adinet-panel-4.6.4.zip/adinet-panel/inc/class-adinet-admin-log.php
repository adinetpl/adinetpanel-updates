<?php
/**
 * Lekki dziennik istotnych zdarzeń administracyjnych.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Admin_Log {
	const PAGE_SLUG       = 'adinet-admin-log';
	const RETENTION_DAYS  = 30;
	const MAX_RECORDS     = 10000;
	const PER_PAGE        = 50;
	const LEVEL_STANDARD  = 'standard';
	const LEVEL_WARNING   = 'warning';
	const LEVEL_CRITICAL  = 'critical';
	const USER_META_DATE  = 'adinet_last_admin_activity_gmt';
	const USER_META_ACTION = 'adinet_last_admin_activity_action';

	/**
	 * Hook podstrony administracyjnej.
	 *
	 * @var string
	 */
	private static $page_hook = '';

	/**
	 * Zdarzenia zapisane w bieżącym żądaniu.
	 *
	 * @var bool[]
	 */
	private static $request_events = array();

	/**
	 * Treści, dla których zapisano już zmianę statusu.
	 *
	 * @var bool[]
	 */
	private static $status_changes = array();

	/**
	 * Nazwy wtyczek odczytane jeszcze przed usunięciem ich plików.
	 *
	 * @var string[]
	 */
	private static $plugins_pending_deletion = array();

	/**
	 * Uruchamia panel i — po włączeniu funkcji — rejestrowanie zdarzeń.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_submenu_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_adinet_clear_admin_log', array( __CLASS__, 'clear_data' ) );

		if ( ! self::is_enabled() ) {
			return;
		}

		self::maybe_cleanup();

		add_action( 'wp_login', array( __CLASS__, 'log_login' ), 10, 2 );
		add_action( 'wp_login_failed', array( __CLASS__, 'log_login_failed' ), 10, 2 );
		add_action( 'wp_logout', array( __CLASS__, 'log_logout' ), 10, 1 );
		add_action( 'user_register', array( __CLASS__, 'log_user_registered' ), 10, 1 );
		add_action( 'profile_update', array( __CLASS__, 'log_user_updated' ), 10, 2 );
		add_action( 'set_user_role', array( __CLASS__, 'log_role_set' ), 10, 3 );
		add_action( 'add_user_role', array( __CLASS__, 'log_role_added' ), 10, 2 );
		add_action( 'remove_user_role', array( __CLASS__, 'log_role_removed' ), 10, 2 );
		add_action( 'deleted_user', array( __CLASS__, 'log_user_deleted' ), 10, 3 );

		add_action( 'transition_post_status', array( __CLASS__, 'log_post_status' ), 10, 3 );
		add_action( 'post_updated', array( __CLASS__, 'log_post_updated' ), 10, 3 );
		add_action( 'before_delete_post', array( __CLASS__, 'log_post_deleted' ), 10, 2 );

		add_action( 'activated_plugin', array( __CLASS__, 'log_plugin_activated' ), 10, 2 );
		add_action( 'deactivated_plugin', array( __CLASS__, 'log_plugin_deactivated' ), 10, 2 );
		add_action( 'delete_plugin', array( __CLASS__, 'capture_plugin_before_delete' ), 10, 1 );
		add_action( 'deleted_plugin', array( __CLASS__, 'log_plugin_deleted' ), 10, 2 );
		add_action( 'deleted_theme', array( __CLASS__, 'log_theme_deleted' ), 10, 2 );
		add_action( 'switch_theme', array( __CLASS__, 'log_theme_switched' ), 10, 3 );
		AdiNet_Update_Log::init();

		add_action( 'updated_option', array( __CLASS__, 'log_option_updated' ), 10, 3 );
		add_action( 'wp_update_nav_menu', array( __CLASS__, 'log_menu_updated' ), 10, 2 );
		add_action( 'customize_save_after', array( __CLASS__, 'log_customizer_saved' ), 10, 1 );
	}

	/**
	 * Tworzy lub aktualizuje tabelę logu.
	 *
	 * @return void
	 */
	public static function install_table() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table_name      = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();
		$sql             = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			occurred_at datetime NOT NULL,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			username varchar(100) NOT NULL DEFAULT '',
			level varchar(12) NOT NULL DEFAULT 'standard',
			event_type varchar(50) NOT NULL DEFAULT '',
			action varchar(255) NOT NULL DEFAULT '',
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			ip varchar(45) NOT NULL DEFAULT '',
			is_change tinyint(1) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY occurred_at (occurred_at),
			KEY user_date (user_id, occurred_at),
			KEY level_date (level, occurred_at),
			KEY change_date (is_change, occurred_at),
			KEY event_ip_date (event_type, ip, occurred_at)
		) {$charset_collate};";

		dbDelta( $sql );
	}

	/**
	 * Obsługuje przełącznik logu na głównej stronie panelu.
	 *
	 * @param mixed $value Wartość pola wyboru.
	 * @return int
	 */
	public static function sanitize_enabled( $value ) {
		$enabled = empty( $value ) ? 0 : 1;

		if ( $enabled ) {
			self::install_table();

			if ( 0 === absint( get_option( AdiNet_Options::ADMIN_LOG_STARTED_AT, 0 ) ) ) {
				update_option( AdiNet_Options::ADMIN_LOG_STARTED_AT, time(), false );
			}
		}

		return $enabled;
	}

	/**
	 * Czy dziennik może zapisywać zdarzenia.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return 1 === absint( get_option( AdiNet_Options::ADMIN_LOG_ENABLED, 0 ) );
	}

	/**
	 * Adres podstrony dziennika.
	 *
	 * @return string
	 */
	public static function get_page_url() {
		return admin_url( 'admin.php?page=' . self::PAGE_SLUG );
	}

	/**
	 * Rejestruje podstronę dziennika.
	 *
	 * @return void
	 */
	public static function add_submenu_page() {
		self::$page_hook = add_submenu_page(
			AdiNet_Admin::PAGE_SLUG,
			esc_html__( 'Log administracyjny — AdiNet', 'adinet-panel' ),
			esc_html__( 'Log administracyjny', 'adinet-panel' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Ładuje style wyłącznie na podstronie logu.
	 *
	 * @param string $hook_suffix Identyfikator ekranu.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( self::$page_hook !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style( 'adinet-admin', ADINET_URL . 'assets/css/admin.css', array(), ADINET_VERSION );
		wp_enqueue_script( 'adinet-admin', ADINET_URL . 'assets/js/admin.js', array(), ADINET_VERSION, true );
	}

	/**
	 * Zapisuje jedno oczyszczone zdarzenie.
	 *
	 * @param string $event_type Techniczny rodzaj zdarzenia.
	 * @param string $level      Poziom zdarzenia.
	 * @param string $action     Opis działania.
	 * @param array  $args       Dodatkowe dane zdarzenia.
	 * @return bool
	 */
	public static function record( $event_type, $level, $action, $args = array() ) {
		if ( ! self::is_enabled() ) {
			return false;
		}

		$allowed_levels = array( self::LEVEL_STANDARD, self::LEVEL_WARNING, self::LEVEL_CRITICAL );
		$level          = sanitize_key( $level );
		$level          = in_array( $level, $allowed_levels, true ) ? $level : self::LEVEL_STANDARD;
		$event_type     = sanitize_key( $event_type );
		$action         = sanitize_text_field( $action );
		$action         = function_exists( 'wp_html_excerpt' ) ? wp_html_excerpt( $action, 255, '' ) : substr( $action, 0, 255 );

		$current_user = wp_get_current_user();
		$user_id      = isset( $args['user_id'] ) ? absint( $args['user_id'] ) : absint( $current_user->ID );
		$username     = isset( $args['username'] ) ? sanitize_text_field( $args['username'] ) : '';

		if ( '' === $username && $user_id > 0 ) {
			$user     = get_userdata( $user_id );
			$username = $user instanceof WP_User ? $user->user_login : '';
		}

		if ( '' === $username ) {
			$username = __( 'System', 'adinet-panel' );
		}

		$username  = function_exists( 'wp_html_excerpt' ) ? wp_html_excerpt( $username, 100, '' ) : substr( $username, 0, 100 );
		$is_change = ! empty( $args['is_change'] ) ? 1 : 0;
		$ip        = isset( $args['ip'] ) ? self::sanitize_ip( $args['ip'] ) : self::get_client_ip();

		global $wpdb;

		$inserted = $wpdb->insert(
			self::get_table_name(),
			array(
				'occurred_at' => current_time( 'mysql', true ),
				'user_id'     => $user_id,
				'username'    => $username,
				'level'       => $level,
				'event_type'  => $event_type,
				'action'      => $action,
				'object_id'   => isset( $args['object_id'] ) ? absint( $args['object_id'] ) : 0,
				'ip'          => $ip,
				'is_change'   => $is_change,
			),
			array( '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%d' )
		);

		if ( false === $inserted ) {
			return false;
		}

		self::enforce_record_limit( absint( $wpdb->insert_id ) );

		if ( $is_change && $user_id > 0 && user_can( $user_id, 'manage_options' ) ) {
			update_user_meta( $user_id, self::USER_META_DATE, current_time( 'mysql', true ) );
			update_user_meta( $user_id, self::USER_META_ACTION, $action );
		}

		return true;
	}

	/**
	 * Zapisuje zdarzenie najwyżej raz podczas jednego żądania.
	 *
	 * @param string $key        Klucz deduplikacji.
	 * @param string $event_type Rodzaj zdarzenia.
	 * @param string $level      Poziom.
	 * @param string $action     Opis.
	 * @param array  $args       Dane dodatkowe.
	 * @return void
	 */
	private static function record_once( $key, $event_type, $level, $action, $args = array() ) {
		if ( isset( self::$request_events[ $key ] ) ) {
			return;
		}

		self::$request_events[ $key ] = true;
		self::record( $event_type, $level, $action, $args );
	}

	/**
	 * Rejestruje prawidłowe logowanie.
	 *
	 * @param string  $user_login Login użytkownika.
	 * @param WP_User $user       Użytkownik.
	 * @return void
	 */
	public static function log_login( $user_login, $user ) {
		self::record(
			'login_success',
			self::LEVEL_STANDARD,
			sprintf( __( 'Prawidłowe logowanie użytkownika „%s”.', 'adinet-panel' ), $user_login ),
			array( 'user_id' => $user instanceof WP_User ? $user->ID : 0, 'username' => $user_login )
		);
	}

	/**
	 * Rejestruje błędne logowanie bez treści błędu i bez hasła.
	 *
	 * @param string   $username Podana nazwa użytkownika.
	 * @param WP_Error $error    Błąd logowania.
	 * @return void
	 */
	public static function log_login_failed( $username, $error = null ) {
		unset( $error );
		$username = sanitize_text_field( (string) $username );
		$user     = get_user_by( 'login', $username );
		$ip       = self::get_client_ip();

		if ( ! $user && is_email( $username ) ) {
			$user = get_user_by( 'email', $username );
		}

		self::record(
			'login_failed',
			self::LEVEL_WARNING,
			sprintf( __( 'Błędna próba logowania jako „%s”.', 'adinet-panel' ), '' !== $username ? $username : __( 'brak nazwy', 'adinet-panel' ) ),
			array(
				'user_id'  => $user instanceof WP_User ? $user->ID : 0,
				'username' => '' !== $username ? $username : __( 'Nieznany użytkownik', 'adinet-panel' ),
				'ip'       => $ip,
			)
		);

		self::maybe_log_failed_login_burst( $ip );
	}

	/**
	 * Rejestruje wylogowanie.
	 *
	 * @param int $user_id Identyfikator użytkownika.
	 * @return void
	 */
	public static function log_logout( $user_id ) {
		$user = get_userdata( $user_id );

		self::record(
			'logout',
			self::LEVEL_STANDARD,
			__( 'Użytkownik wylogował się.', 'adinet-panel' ),
			array( 'user_id' => $user_id, 'username' => $user instanceof WP_User ? $user->user_login : '' )
		);
	}

	/**
	 * Rejestruje utworzenie użytkownika.
	 *
	 * @param int $user_id Identyfikator użytkownika.
	 * @return void
	 */
	public static function log_user_registered( $user_id ) {
		$user     = get_userdata( $user_id );
		$is_admin = $user instanceof WP_User && in_array( 'administrator', (array) $user->roles, true );
		$name     = $user instanceof WP_User ? $user->user_login : '#' . absint( $user_id );

		self::record(
			'user_created',
			$is_admin ? self::LEVEL_CRITICAL : self::LEVEL_WARNING,
			sprintf( $is_admin ? __( 'Utworzono nowe konto administratora „%s”.', 'adinet-panel' ) : __( 'Utworzono konto użytkownika „%s”.', 'adinet-panel' ), $name ),
			array( 'object_id' => $user_id, 'is_change' => true )
		);
	}

	/**
	 * Rejestruje zmianę profilu lub roli użytkownika.
	 *
	 * @param int     $user_id       Identyfikator użytkownika.
	 * @param WP_User $old_user_data Dane sprzed zmiany.
	 * @return void
	 */
	public static function log_user_updated( $user_id, $old_user_data ) {
		$user = get_userdata( $user_id );
		$name = $user instanceof WP_User ? $user->user_login : '#' . absint( $user_id );
		if ( isset( self::$request_events[ 'role_' . $user_id ] ) ) { return; }
		self::record( 'user_profile_updated', self::LEVEL_WARNING, sprintf( __( 'Zmieniono profil użytkownika „%s”.', 'adinet-panel' ), $name ), array( 'object_id' => $user_id, 'is_change' => true ) );
	}

	public static function log_role_set( $user_id, $role, $old_roles ) {
		self::record_role_change( $user_id, $role, $old_roles );
	}

	public static function log_role_added( $user_id, $role ) {
		// set_role emituje również add/remove; jeden kompletny wpis powstaje w set_user_role.
		if ( self::inside_set_role() ) { return; }
		self::record_role_change( $user_id, $role, array(), 'added' );
	}

	public static function log_role_removed( $user_id, $role ) {
		if ( self::inside_set_role() ) { return; }
		self::record_role_change( $user_id, '', array( $role ), 'removed' );
	}

	private static function inside_set_role() {
		foreach ( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 12 ) as $frame ) {
			if ( isset( $frame['class'], $frame['function'] ) && 'WP_User' === $frame['class'] && 'set_role' === $frame['function'] ) { return true; }
		}
		return false;
	}

	private static function record_role_change( $user_id, $role, $old_roles, $operation = 'set' ) {
		$user = get_userdata( $user_id );
		$name = $user instanceof WP_User ? $user->user_login : '#' . absint( $user_id );
		$critical = 'administrator' === $role && ! in_array( 'administrator', (array) $old_roles, true );
		$description = 'added' === $operation
			? sprintf( __( 'Dodano rolę „%1$s” użytkownikowi „%2$s”.', 'adinet-panel' ), $role, $name )
			: ( 'removed' === $operation
				? sprintf( __( 'Odebrano rolę „%1$s” użytkownikowi „%2$s”.', 'adinet-panel' ), implode( ', ', $old_roles ), $name )
				: sprintf( __( 'Zmieniono role użytkownika „%1$s”: %2$s → %3$s.', 'adinet-panel' ), $name, implode( ', ', $old_roles ), $role ?: __( 'brak', 'adinet-panel' ) ) );
		self::$request_events[ 'role_' . $user_id ] = true;
		self::record( 'user_role_changed', $critical ? self::LEVEL_CRITICAL : self::LEVEL_WARNING, $description, array( 'object_id' => $user_id, 'is_change' => true ) );
	}

	/**
	 * Rejestruje usunięcie użytkownika.
	 *
	 * @param int          $user_id Identyfikator użytkownika.
	 * @param int|null     $reassign Identyfikator przejmującego treści.
	 * @param WP_User|null $user    Usuwany użytkownik.
	 * @return void
	 */
	public static function log_user_deleted( $user_id, $reassign = null, $user = null ) {
		unset( $reassign );
		$name = $user instanceof WP_User ? $user->user_login : '#' . absint( $user_id );

		self::record(
			'user_deleted',
			self::LEVEL_CRITICAL,
			sprintf( __( 'Usunięto konto użytkownika „%s”.', 'adinet-panel' ), $name ),
			array( 'object_id' => $user_id, 'is_change' => true )
		);
	}

	/**
	 * Rejestruje utworzenie treści i zmianę jej statusu.
	 *
	 * @param string  $new_status Nowy status.
	 * @param string  $old_status Poprzedni status.
	 * @param WP_Post $post       Treść.
	 * @return void
	 */
	public static function log_post_status( $new_status, $old_status, $post ) {
		if ( ! self::should_log_post( $post ) || $new_status === $old_status || 'auto-draft' === $new_status ) {
			return;
		}

		self::$status_changes[ $post->ID ] = true;
		$subject  = self::get_post_subject( $post );
		$level    = self::is_theme_builder_post( $post ) ? self::LEVEL_WARNING : self::LEVEL_STANDARD;
		$is_new   = 'new' === $old_status || 'auto-draft' === $old_status;

		if ( $is_new ) {
			$action = 'publish' === $new_status
				? sprintf( __( 'Dodano i opublikowano %s.', 'adinet-panel' ), $subject )
				: sprintf( __( 'Utworzono %s.', 'adinet-panel' ), $subject );
		} elseif ( 'trash' === $new_status ) {
			$action = sprintf( __( 'Przeniesiono do kosza %s.', 'adinet-panel' ), $subject );
			$level  = self::LEVEL_WARNING;
		} elseif ( 'publish' === $new_status ) {
			$action = sprintf( __( 'Opublikowano %s.', 'adinet-panel' ), $subject );
		} else {
			$action = sprintf( __( 'Zmieniono status %1$s na „%2$s”.', 'adinet-panel' ), $subject, $new_status );
		}

		self::record( 'content_status', $level, $action, array( 'object_id' => $post->ID, 'is_change' => true ) );
	}

	/**
	 * Rejestruje merytoryczną edycję istniejącej treści.
	 *
	 * @param int     $post_id     Identyfikator treści.
	 * @param WP_Post $post_after  Stan po zmianie.
	 * @param WP_Post $post_before Stan przed zmianą.
	 * @return void
	 */
	public static function log_post_updated( $post_id, $post_after, $post_before ) {
		if ( isset( self::$status_changes[ $post_id ] ) || ! self::should_log_post( $post_after ) ) {
			return;
		}

		$fields  = array( 'post_title', 'post_content', 'post_excerpt', 'post_parent', 'menu_order', 'post_name', 'comment_status', 'ping_status' );
		$changed = false;

		foreach ( $fields as $field ) {
			if ( $post_before->$field !== $post_after->$field ) {
				$changed = true;
				break;
			}
		}

		if ( ! $changed ) {
			return;
		}

		self::record(
			'content_updated',
			self::is_theme_builder_post( $post_after ) ? self::LEVEL_WARNING : self::LEVEL_STANDARD,
			sprintf( __( 'Edytowano %s.', 'adinet-panel' ), self::get_post_subject( $post_after ) ),
			array( 'object_id' => $post_id, 'is_change' => true )
		);
	}

	/**
	 * Rejestruje trwałe usunięcie treści.
	 *
	 * @param int     $post_id Identyfikator treści.
	 * @param WP_Post $post    Usuwana treść.
	 * @return void
	 */
	public static function log_post_deleted( $post_id, $post ) {
		if ( ! self::should_log_post( $post ) ) {
			return;
		}

		self::record(
			'content_deleted',
			self::LEVEL_WARNING,
			sprintf( __( 'Trwale usunięto %s.', 'adinet-panel' ), self::get_post_subject( $post ) ),
			array( 'object_id' => $post_id, 'is_change' => true )
		);
	}

	/**
	 * Rejestruje aktywację wtyczki.
	 *
	 * @param string $plugin       Plik wtyczki.
	 * @param bool   $network_wide Czy aktywowano sieciowo.
	 * @return void
	 */
	public static function log_plugin_activated( $plugin, $network_wide = false ) {
		unset( $network_wide );
		self::record( 'plugin_activated', self::LEVEL_WARNING, sprintf( __( 'Aktywowano wtyczkę „%s”.', 'adinet-panel' ), self::get_plugin_label( $plugin ) ), array( 'is_change' => true ) );
	}

	/**
	 * Rejestruje wyłączenie wtyczki.
	 *
	 * @param string $plugin       Plik wtyczki.
	 * @param bool   $network_wide Czy wyłączono sieciowo.
	 * @return void
	 */
	public static function log_plugin_deactivated( $plugin, $network_wide = false ) {
		unset( $network_wide );
		self::record( 'plugin_deactivated', self::LEVEL_WARNING, sprintf( __( 'Wyłączono wtyczkę „%s”.', 'adinet-panel' ), self::get_plugin_label( $plugin ) ), array( 'is_change' => true ) );
	}

	/**
	 * Zachowuje nazwę i identyfikator wtyczki, zanim WordPress usunie jej pliki.
	 *
	 * @param string $plugin Plik wtyczki względem katalogu plugins.
	 * @return void
	 */
	public static function capture_plugin_before_delete( $plugin ) {
		$plugin = self::normalize_plugin_file( $plugin );

		if ( '' !== $plugin ) {
			self::$plugins_pending_deletion[ $plugin ] = self::get_plugin_label( $plugin );
		}
	}

	/**
	 * Rejestruje usunięcie wtyczki.
	 *
	 * @param string $plugin  Plik wtyczki.
	 * @param bool   $deleted Wynik operacji.
	 * @return void
	 */
	public static function log_plugin_deleted( $plugin, $deleted ) {
		$plugin = self::normalize_plugin_file( $plugin );
		$label  = isset( self::$plugins_pending_deletion[ $plugin ] )
			? self::$plugins_pending_deletion[ $plugin ]
			: self::get_plugin_label( $plugin );

		unset( self::$plugins_pending_deletion[ $plugin ] );

		if ( $deleted ) {
			self::record( 'plugin_deleted', self::LEVEL_CRITICAL, sprintf( __( 'Usunięto wtyczkę „%s”.', 'adinet-panel' ), $label ), array( 'is_change' => true ) );
		}
	}

	/**
	 * Rejestruje usunięcie motywu.
	 *
	 * @param string $stylesheet Katalog motywu.
	 * @param bool   $deleted    Wynik operacji.
	 * @return void
	 */
	public static function log_theme_deleted( $stylesheet, $deleted ) {
		if ( $deleted ) {
			self::record( 'theme_deleted', self::LEVEL_CRITICAL, sprintf( __( 'Usunięto motyw „%s”.', 'adinet-panel' ), $stylesheet ), array( 'is_change' => true ) );
		}
	}

	/**
	 * Rejestruje zmianę aktywnego motywu.
	 *
	 * @param string   $new_name  Nazwa nowego motywu.
	 * @param WP_Theme $new_theme Nowy motyw.
	 * @param WP_Theme $old_theme Poprzedni motyw.
	 * @return void
	 */
	public static function log_theme_switched( $new_name, $new_theme = null, $old_theme = null ) {
		unset( $new_theme, $old_theme );
		self::record( 'theme_switched', self::LEVEL_CRITICAL, sprintf( __( 'Włączono motyw „%s”.', 'adinet-panel' ), $new_name ), array( 'is_change' => true ) );
	}

	/**
	 * Rejestruje wybrane grupy ustawień bez zapisywania ich wartości.
	 *
	 * @param string $option    Nazwa opcji.
	 * @param mixed  $old_value Poprzednia wartość.
	 * @param mixed  $value     Nowa wartość.
	 * @return void
	 */
	public static function log_option_updated( $option, $old_value, $value ) {
		unset( $old_value, $value );
		$option = sanitize_key( $option );

		$ignored = array(
			AdiNet_Options::PLUGIN_VERSION,
			AdiNet_Options::ADMIN_LOG_STARTED_AT,
			AdiNet_Options::ADMIN_LOG_LAST_CLEANUP,
			AdiNet_Cron_Health::LAST_RUN,
			AdiNet_Cron_Health::SCHEDULE_ERROR,
		);

		if ( in_array( $option, $ignored, true ) ) {
			return;
		}

		$critical_options = array( 'siteurl', 'home', 'admin_email', 'users_can_register', 'default_role' );
		if ( in_array( $option, $critical_options, true ) ) {
			self::record_once( 'core_security_settings', 'security_settings_updated', self::LEVEL_CRITICAL, __( 'Zmieniono krytyczne ustawienia adresu, administratora lub rejestracji użytkowników.', 'adinet-panel' ), array( 'is_change' => true ) );
			return;
		}

		$core_options = array(
			'blogname', 'blogdescription', 'timezone_string', 'date_format', 'time_format', 'permalink_structure',
			'show_on_front', 'page_on_front', 'page_for_posts', 'posts_per_page',
			'default_comment_status', 'comment_registration',
		);

		if ( in_array( $option, $core_options, true ) ) {
			self::record_once( 'core_settings', 'settings_updated', self::LEVEL_WARNING, __( 'Zmieniono ustawienia WordPressa.', 'adinet-panel' ), array( 'is_change' => true ) );
			return;
		}

		if ( 0 === strpos( $option, 'adinet_' ) ) {
			self::record_once( 'adinet_settings', 'adinet_settings_updated', self::LEVEL_WARNING, __( 'Zmieniono ustawienia panelu AdiNet.', 'adinet-panel' ), array( 'is_change' => true ) );
			return;
		}

		if ( 'sidebars_widgets' === $option || 0 === strpos( $option, 'widget_' ) ) {
			self::record_once( 'widgets', 'widgets_updated', self::LEVEL_WARNING, __( 'Zmieniono widżety witryny.', 'adinet-panel' ), array( 'is_change' => true ) );
			return;
		}

		if ( false !== strpos( $option, 'theme_builder' ) || false !== strpos( $option, 'themebuilder' ) ) {
			self::record_once( 'divi_theme_builder', 'divi_theme_builder_updated', self::LEVEL_WARNING, __( 'Zmieniono konfigurację Divi Theme Builder.', 'adinet-panel' ), array( 'is_change' => true ) );
			return;
		}

		$divi_options = array( 'et_divi', 'et_pb_options', 'et_global_presets', 'et_pb_global_presets', 'theme_mods_divi' );
		if ( in_array( $option, $divi_options, true ) || 0 === strpos( $option, 'et_divi_' ) ) {
			self::record_once( 'divi_settings', 'divi_settings_updated', self::LEVEL_WARNING, __( 'Zmieniono ustawienia motywu lub kreatora Divi.', 'adinet-panel' ), array( 'is_change' => true ) );
		}
	}

	/**
	 * Rejestruje zmianę menu.
	 *
	 * @param int   $menu_id   Identyfikator menu.
	 * @param array $menu_data Dane menu.
	 * @return void
	 */
	public static function log_menu_updated( $menu_id, $menu_data = array() ) {
		$name = ! empty( $menu_data['menu-name'] ) ? sanitize_text_field( $menu_data['menu-name'] ) : '#' . absint( $menu_id );
		self::record_once( 'menu_' . absint( $menu_id ), 'menu_updated', self::LEVEL_WARNING, sprintf( __( 'Zmieniono menu „%s”.', 'adinet-panel' ), $name ), array( 'object_id' => $menu_id, 'is_change' => true ) );
	}

	/**
	 * Rejestruje zapis zmian w Personalizacji motywu.
	 *
	 * @param WP_Customize_Manager $manager Menedżer personalizacji.
	 * @return void
	 */
	public static function log_customizer_saved( $manager = null ) {
		unset( $manager );
		self::record_once( 'theme_customizer', 'theme_customizer_updated', self::LEVEL_WARNING, __( 'Zapisano zmiany w Personalizacji motywu.', 'adinet-panel' ), array( 'is_change' => true ) );
	}

	/**
	 * Usuwa szczegółowe rekordy, zachowując daty aktywności administratorów.
	 *
	 * @return void
	 */
	public static function clear_data() {
		if ( ! AdiNet_Admin::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do usunięcia logu administracyjnego.', 'adinet-panel' ) );
		}

		check_admin_referer( 'adinet_clear_admin_log' );

		global $wpdb;
		$result = $wpdb->query( 'DELETE FROM ' . self::get_table_name() );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'              => self::PAGE_SLUG,
					'adinet-log-notice' => false !== $result ? 'cleared' : 'error',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Renderuje dziennik, statystyki i listę administratorów.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! AdiNet_Admin::can_view_panel() ) {
			return;
		}

		self::install_table();
		self::maybe_cleanup();
		$filters     = self::get_filters();
		$current_page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$events      = self::get_events( $filters, $current_page );
		$stats       = self::get_statistics();
		$admins      = self::get_administrators();
		$users       = self::get_filter_users();
		$notice_code = isset( $_GET['adinet-log-notice'] ) ? sanitize_key( wp_unslash( $_GET['adinet-log-notice'] ) ) : '';
		$can_manage  = AdiNet_Admin::can_manage_panel();
		?>
		<div class="wrap adinet-admin adinet-admin-log-page">
			<header class="adinet-monitor-hero">
				<div>
					<p class="adinet-eyebrow"><?php esc_html_e( 'Bezpieczeństwo i odpowiedzialność', 'adinet-panel' ); ?></p>
					<h1><?php esc_html_e( 'Log administracyjny', 'adinet-panel' ); ?></h1>
					<p><?php esc_html_e( 'Najważniejsze logowania i zmiany wykonane w WordPressie oraz Divi.', 'adinet-panel' ); ?></p>
				</div>
				<span class="adinet-status <?php echo self::is_enabled() ? 'is-active' : 'is-neutral'; ?>">
					<?php echo self::is_enabled() ? esc_html__( 'Log aktywny', 'adinet-panel' ) : esc_html__( 'Log nieaktywny', 'adinet-panel' ); ?>
				</span>
			</header>

			<?php if ( 'cleared' === $notice_code ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Szczegółowe rekordy logu zostały usunięte. Daty ostatniej aktywności administratorów zachowano.', 'adinet-panel' ); ?></p></div>
			<?php elseif ( 'error' === $notice_code ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Nie udało się wyczyścić logu administracyjnego.', 'adinet-panel' ); ?></p></div>
			<?php endif; ?>

			<div class="adinet-admin-log-stats">
				<?php self::render_stat_card( __( 'Ostatnie 24 godziny', 'adinet-panel' ), number_format_i18n( $stats['day'] ), __( 'wszystkich zdarzeń', 'adinet-panel' ) ); ?>
				<?php self::render_stat_card( __( 'Ostatnie 7 dni', 'adinet-panel' ), number_format_i18n( $stats['week'] ), __( 'wszystkich zdarzeń', 'adinet-panel' ) ); ?>
				<?php self::render_stat_card( __( 'Ostatnie 30 dni', 'adinet-panel' ), number_format_i18n( $stats['month'] ), sprintf( __( 'ostrzeżenia: %1$s · krytyczne: %2$s', 'adinet-panel' ), number_format_i18n( $stats['warnings'] ), number_format_i18n( $stats['critical'] ) ) ); ?>
				<?php self::render_stat_card( __( 'Najaktywniejszy użytkownik', 'adinet-panel' ), $stats['top_name'], sprintf( __( 'zmiany w ciągu 30 dni: %s', 'adinet-panel' ), number_format_i18n( $stats['top_count'] ) ) ); ?>
			</div>

			<section class="adinet-admin-log-section" aria-labelledby="adinet-admin-activity-title">
				<div class="adinet-monitor-results__header">
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Konta z rolą administratora', 'adinet-panel' ); ?></p>
						<h2 id="adinet-admin-activity-title"><?php esc_html_e( 'Ostatnia aktywność administratorów', 'adinet-panel' ); ?></h2>
					</div>
					<a href="<?php echo esc_url( admin_url( 'users.php?role=administrator' ) ); ?>" class="button"><?php esc_html_e( 'Zarządzaj użytkownikami', 'adinet-panel' ); ?></a>
				</div>
				<div class="adinet-monitor-table-wrap">
					<table class="widefat striped adinet-monitor-table">
						<thead><tr><th><?php esc_html_e( 'Administrator', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Ostatnia zmiana', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Ostatnie działanie', 'adinet-panel' ); ?></th></tr></thead>
						<tbody>
							<?php foreach ( $admins as $admin ) : ?>
								<tr>
									<td><strong><?php echo esc_html( $admin['display_name'] ); ?></strong><br><small><?php echo esc_html( $admin['user_login'] ); ?></small></td>
									<td><?php echo esc_html( $admin['last_date'] ); ?></td>
									<td><?php echo esc_html( $admin['last_action'] ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</section>

			<section class="adinet-admin-log-section" aria-labelledby="adinet-admin-events-title">
				<div class="adinet-monitor-results__header">
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Maksymalnie 10 000 rekordów', 'adinet-panel' ); ?></p>
						<h2 id="adinet-admin-events-title"><?php esc_html_e( 'Zdarzenia administracyjne', 'adinet-panel' ); ?></h2>
					</div>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . AdiNet_Admin::PAGE_SLUG ) ); ?>" class="button"><?php esc_html_e( 'Ustawienia logu', 'adinet-panel' ); ?></a>
				</div>

				<form method="get" class="adinet-admin-log-filters">
					<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>">
					<label><span><?php esc_html_e( 'Użytkownik', 'adinet-panel' ); ?></span><select name="log_user"><option value="all"><?php esc_html_e( 'Wszyscy', 'adinet-panel' ); ?></option><?php foreach ( $users as $user_id => $label ) : ?><option value="<?php echo esc_attr( $user_id ); ?>" <?php selected( (string) $filters['user'], (string) $user_id ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
					<label><span><?php esc_html_e( 'Poziom', 'adinet-panel' ); ?></span><select name="log_level"><option value="all"><?php esc_html_e( 'Wszystkie', 'adinet-panel' ); ?></option><option value="standard" <?php selected( $filters['level'], 'standard' ); ?>><?php esc_html_e( 'Standardowe', 'adinet-panel' ); ?></option><option value="warning" <?php selected( $filters['level'], 'warning' ); ?>><?php esc_html_e( 'Ostrzeżenia', 'adinet-panel' ); ?></option><option value="critical" <?php selected( $filters['level'], 'critical' ); ?>><?php esc_html_e( 'Krytyczne', 'adinet-panel' ); ?></option></select></label>
					<label><span><?php esc_html_e( 'Okres', 'adinet-panel' ); ?></span><select name="log_period"><option value="1" <?php selected( $filters['period'], 1 ); ?>><?php esc_html_e( '24 godziny', 'adinet-panel' ); ?></option><option value="7" <?php selected( $filters['period'], 7 ); ?>><?php esc_html_e( '7 dni', 'adinet-panel' ); ?></option><option value="30" <?php selected( $filters['period'], 30 ); ?>><?php esc_html_e( '30 dni', 'adinet-panel' ); ?></option></select></label>
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Filtruj', 'adinet-panel' ); ?></button>
					<a href="<?php echo esc_url( self::get_page_url() ); ?>" class="button"><?php esc_html_e( 'Wyczyść filtry', 'adinet-panel' ); ?></a>
				</form>

				<?php if ( ! empty( $events['rows'] ) ) : ?>
					<div class="adinet-monitor-table-wrap">
						<table class="widefat striped adinet-monitor-table adinet-admin-log-table">
							<thead><tr><th><?php esc_html_e( 'Data i godzina', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Użytkownik', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Poziom', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Działanie', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'IP', 'adinet-panel' ); ?></th></tr></thead>
							<tbody>
								<?php foreach ( $events['rows'] as $row ) : ?>
									<tr>
										<td><time datetime="<?php echo esc_attr( $row['occurred_at'] ); ?>"><?php echo esc_html( self::format_mysql_gmt( $row['occurred_at'] ) ); ?></time></td>
										<td><strong><?php echo esc_html( $row['username'] ); ?></strong></td>
										<td><?php self::render_level_badge( $row['level'] ); ?></td>
										<td><?php echo esc_html( $row['action'] ); ?></td>
										<td><?php echo '' !== $row['ip'] ? '<code>' . esc_html( $row['ip'] ) . '</code>' : '<span aria-label="' . esc_attr__( 'Brak adresu IP', 'adinet-panel' ) . '">—</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<?php self::render_pagination( $events['total'], $current_page, $filters ); ?>
				<?php else : ?>
					<div class="adinet-monitor-empty"><span class="dashicons dashicons-shield-alt" aria-hidden="true"></span><p><?php esc_html_e( 'Brak zdarzeń spełniających wybrane filtry.', 'adinet-panel' ); ?></p></div>
				<?php endif; ?>
			</section>

			<section class="adinet-monitor-cleanup">
				<div><h2><?php esc_html_e( 'Czyszczenie danych', 'adinet-panel' ); ?></h2><p><?php esc_html_e( 'Rekordy starsze niż 30 dni są usuwane automatycznie. Ręczne czyszczenie nie usuwa dat ostatniej aktywności administratorów.', 'adinet-panel' ); ?></p></div>
				<?php if ( $can_manage ) : ?>
				<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" data-confirm-form="<?php echo esc_attr__( 'Czy na pewno chcesz usunąć wszystkie szczegółowe rekordy logu?', 'adinet-panel' ); ?>">
					<input type="hidden" name="action" value="adinet_clear_admin_log"><?php wp_nonce_field( 'adinet_clear_admin_log' ); ?><button type="submit" class="button button-link-delete"><?php esc_html_e( 'Wyczyść log', 'adinet-panel' ); ?></button>
				</form>
				<?php endif; ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Renderuje kartę statystyki.
	 *
	 * @param string $label Etykieta.
	 * @param string $value Wartość.
	 * @param string $detail Szczegół.
	 * @return void
	 */
	private static function render_stat_card( $label, $value, $detail ) {
		?>
		<section><small><?php echo esc_html( $label ); ?></small><strong><?php echo esc_html( $value ); ?></strong><span><?php echo esc_html( $detail ); ?></span></section>
		<?php
	}

	/**
	 * Renderuje kolorową etykietę poziomu.
	 *
	 * @param string $level Poziom.
	 * @return void
	 */
	private static function render_level_badge( $level ) {
		$labels = array(
			self::LEVEL_STANDARD => __( 'Standardowe', 'adinet-panel' ),
			self::LEVEL_WARNING  => __( 'Ostrzeżenie', 'adinet-panel' ),
			self::LEVEL_CRITICAL => __( 'Krytyczne', 'adinet-panel' ),
		);
		$level = isset( $labels[ $level ] ) ? $level : self::LEVEL_STANDARD;
		?>
		<span class="adinet-event-level is-<?php echo esc_attr( $level ); ?>"><span aria-hidden="true"></span><?php echo esc_html( $labels[ $level ] ); ?></span>
		<?php
	}

	/**
	 * Renderuje paginację wyników.
	 *
	 * @param int   $total        Liczba wyników.
	 * @param int   $current_page Bieżąca strona.
	 * @param array $filters      Filtry.
	 * @return void
	 */
	private static function render_pagination( $total, $current_page, $filters ) {
		$total_pages = (int) ceil( $total / self::PER_PAGE );

		if ( $total_pages <= 1 ) {
			return;
		}

		$base = add_query_arg(
			array(
				'page'       => self::PAGE_SLUG,
				'log_user'   => $filters['user'],
				'log_level'  => $filters['level'],
				'log_period' => $filters['period'],
				'paged'      => '%#%',
			),
			admin_url( 'admin.php' )
		);
		?>
		<div class="tablenav"><div class="tablenav-pages"><?php echo wp_kses_post( paginate_links( array( 'base' => $base, 'format' => '', 'current' => $current_page, 'total' => $total_pages, 'type' => 'list' ) ) ); ?></div></div>
		<?php
	}

	/**
	 * Zwraca filtry przekazane w adresie.
	 *
	 * @return array{user:string|int,level:string,period:int}
	 */
	private static function get_filters() {
		$user_raw = isset( $_GET['log_user'] ) ? sanitize_text_field( wp_unslash( $_GET['log_user'] ) ) : 'all';
		$user     = 'all' === $user_raw ? 'all' : absint( $user_raw );
		$level    = isset( $_GET['log_level'] ) ? sanitize_key( wp_unslash( $_GET['log_level'] ) ) : 'all';
		$period   = isset( $_GET['log_period'] ) ? absint( $_GET['log_period'] ) : 30;

		if ( ! in_array( $level, array( 'all', self::LEVEL_STANDARD, self::LEVEL_WARNING, self::LEVEL_CRITICAL ), true ) ) {
			$level = 'all';
		}

		if ( ! in_array( $period, array( 1, 7, 30 ), true ) ) {
			$period = 30;
		}

		return array( 'user' => $user, 'level' => $level, 'period' => $period );
	}

	/**
	 * Pobiera stronę przefiltrowanych zdarzeń.
	 *
	 * @param array $filters Filtry.
	 * @param int   $page    Numer strony.
	 * @return array{rows:array,total:int}
	 */
	private static function get_events( $filters, $page ) {
		global $wpdb;

		$where = array( 'occurred_at >= %s' );
		$args  = array( gmdate( 'Y-m-d H:i:s', time() - ( $filters['period'] * DAY_IN_SECONDS ) ) );

		if ( 'all' !== $filters['user'] ) {
			$where[] = 'user_id = %d';
			$args[]  = absint( $filters['user'] );
		}

		if ( 'all' !== $filters['level'] ) {
			$where[] = 'level = %s';
			$args[]  = $filters['level'];
		}

		$where_sql = implode( ' AND ', $where );
		$table     = self::get_table_name();
		$total     = absint( $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}", $args ) ) );
		$offset    = ( max( 1, $page ) - 1 ) * self::PER_PAGE;
		$row_args  = array_merge( $args, array( self::PER_PAGE, $offset ) );
		$rows      = $wpdb->get_results(
			$wpdb->prepare( "SELECT id, occurred_at, user_id, username, level, action, ip FROM {$table} WHERE {$where_sql} ORDER BY occurred_at DESC, id DESC LIMIT %d OFFSET %d", $row_args ),
			ARRAY_A
		);

		return array( 'rows' => is_array( $rows ) ? $rows : array(), 'total' => $total );
	}

	/**
	 * Oblicza krótkie statystyki.
	 *
	 * @return array
	 */
	private static function get_statistics() {
		global $wpdb;

		$table    = self::get_table_name();
		$day      = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		$week     = gmdate( 'Y-m-d H:i:s', time() - ( 7 * DAY_IN_SECONDS ) );
		$month    = gmdate( 'Y-m-d H:i:s', time() - ( self::RETENTION_DAYS * DAY_IN_SECONDS ) );
		$summary  = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT SUM(occurred_at >= %s) AS day_count, SUM(occurred_at >= %s) AS week_count, COUNT(*) AS month_count, SUM(level = %s) AS warning_count, SUM(level = %s) AS critical_count FROM {$table} WHERE occurred_at >= %s",
				$day,
				$week,
				self::LEVEL_WARNING,
				self::LEVEL_CRITICAL,
				$month
			),
			ARRAY_A
		);
		$users_table = $wpdb->users;
		$top_user = $wpdb->get_row(
			$wpdb->prepare( "SELECT COALESCE(users.user_login, MAX(log.username)) AS username, COUNT(*) AS event_count FROM {$table} AS log LEFT JOIN {$users_table} AS users ON users.ID = log.user_id WHERE log.occurred_at >= %s AND log.user_id > 0 AND log.is_change = 1 GROUP BY log.user_id, users.user_login ORDER BY event_count DESC, MAX(log.occurred_at) DESC LIMIT 1", $month ),
			ARRAY_A
		);

		return array(
			'day'       => is_array( $summary ) ? absint( $summary['day_count'] ) : 0,
			'week'      => is_array( $summary ) ? absint( $summary['week_count'] ) : 0,
			'month'     => is_array( $summary ) ? absint( $summary['month_count'] ) : 0,
			'warnings'  => is_array( $summary ) ? absint( $summary['warning_count'] ) : 0,
			'critical'  => is_array( $summary ) ? absint( $summary['critical_count'] ) : 0,
			'top_name'  => is_array( $top_user ) ? sanitize_text_field( $top_user['username'] ) : __( 'Brak danych', 'adinet-panel' ),
			'top_count' => is_array( $top_user ) ? absint( $top_user['event_count'] ) : 0,
		);
	}

	/**
	 * Zwraca bieżących administratorów i ich trwałe daty aktywności.
	 *
	 * @return array
	 */
	private static function get_administrators() {
		$users   = get_users( array( 'role' => 'administrator', 'orderby' => 'display_name', 'order' => 'ASC' ) );
		$results = array();
		$started = absint( get_option( AdiNet_Options::ADMIN_LOG_STARTED_AT, 0 ) );

		foreach ( $users as $user ) {
			$date   = (string) get_user_meta( $user->ID, self::USER_META_DATE, true );
			$action = (string) get_user_meta( $user->ID, self::USER_META_ACTION, true );
			$results[] = array(
				'display_name' => $user->display_name,
				'user_login'   => $user->user_login,
				'last_date'    => '' !== $date ? self::format_mysql_gmt( $date ) : ( $started > 0 ? __( 'Brak zmian od uruchomienia logu', 'adinet-panel' ) : __( 'Log nie został jeszcze uruchomiony', 'adinet-panel' ) ),
				'last_action'  => '' !== $action ? $action : '—',
			);
		}

		return $results;
	}

	/**
	 * Zwraca użytkowników do prostego filtra.
	 *
	 * @return string[]
	 */
	private static function get_filter_users() {
		$users   = get_users( array( 'orderby' => 'display_name', 'order' => 'ASC' ) );
		$options = array( '0' => __( 'System / niezalogowany', 'adinet-panel' ) );

		foreach ( $users as $user ) {
			$options[ (string) $user->ID ] = sprintf( '%1$s (%2$s)', $user->display_name, $user->user_login );
		}

		return $options;
	}

	/**
	 * Czy podany wpis jest właściwą treścią, a nie rewizją lub autosave.
	 *
	 * @param mixed $post Treść.
	 * @return bool
	 */
	private static function should_log_post( $post ) {
		return $post instanceof WP_Post
			&& ! wp_is_post_revision( $post->ID )
			&& ! wp_is_post_autosave( $post->ID )
			&& ! in_array( $post->post_status, array( 'inherit', 'auto-draft' ), true )
			&& ! in_array( $post->post_type, array( 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset' ), true );
	}

	/**
	 * Buduje krótki, czytelny opis obiektu treści.
	 *
	 * @param WP_Post $post Treść.
	 * @return string
	 */
	private static function get_post_subject( $post ) {
		$title = '' !== trim( $post->post_title ) ? $post->post_title : __( '(bez tytułu)', 'adinet-panel' );

		if ( self::is_theme_builder_post( $post ) ) {
			return sprintf( __( 'szablon Divi Theme Builder „%s”', 'adinet-panel' ), $title );
		}

		if ( 'et_pb_layout' === $post->post_type ) {
			return sprintf( __( 'element Biblioteki Divi „%s”', 'adinet-panel' ), $title );
		}

		$type_object = get_post_type_object( $post->post_type );
		$type_name   = $type_object && ! empty( $type_object->labels->singular_name ) ? strtolower( $type_object->labels->singular_name ) : __( 'treść', 'adinet-panel' );
		$divi_label  = self::is_divi_post( $post ) ? __( ' w Divi', 'adinet-panel' ) : '';

		return sprintf( '%1$s „%2$s”%3$s', $type_name, $title, $divi_label );
	}

	/**
	 * Rozpoznaje treści edytowane przez Divi bez analizy różnic modułów.
	 *
	 * @param WP_Post $post Treść.
	 * @return bool
	 */
	private static function is_divi_post( $post ) {
		if ( self::is_theme_builder_post( $post ) || 'et_pb_layout' === $post->post_type ) {
			return true;
		}

		$builder_enabled = get_post_meta( $post->ID, '_et_pb_use_builder', true );
		$content         = (string) $post->post_content;

		$is_divi = in_array( $builder_enabled, array( 'on', '1', 1, true ), true )
			|| false !== strpos( $content, '[et_pb_' )
			|| false !== strpos( $content, '<!-- wp:divi/' );

		return (bool) apply_filters( 'adinet_admin_log_is_divi_post', $is_divi, $post );
	}

	/**
	 * Rozpoznaje techniczne typy treści Theme Buildera.
	 *
	 * @param WP_Post $post Treść.
	 * @return bool
	 */
	private static function is_theme_builder_post( $post ) {
		$post_type = (string) $post->post_type;

		$is_theme_builder = false !== strpos( $post_type, 'theme_builder' )
			|| false !== strpos( $post_type, 'themebuilder' )
			|| '' !== (string) get_post_meta( $post->ID, '_et_theme_builder_template_type', true )
			|| '' !== (string) get_post_meta( $post->ID, '_et_theme_builder_template_id', true )
			|| '' !== (string) get_post_meta( $post->ID, '_et_theme_builder_layout_type', true );

		return (bool) apply_filters( 'adinet_admin_log_is_theme_builder_post', $is_theme_builder, $post );
	}

	/**
	 * Zwraca nazwę wtyczki wraz z jednoznacznym plikiem głównym.
	 *
	 * @param string $plugin Plik albo katalog wtyczki.
	 * @return string
	 */
	public static function get_plugin_label( $plugin ) {
		$plugin = self::normalize_plugin_file( $plugin );

		if ( '' === $plugin ) {
			return __( 'nieustalona wtyczka', 'adinet-panel' );
		}

		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		$file = WP_PLUGIN_DIR . '/' . $plugin;
		if ( is_dir( $file ) ) {
			$plugins = get_plugins( '/' . trim( $plugin, '/' ) );
			if ( ! empty( $plugins ) ) {
				$plugin_files = array_keys( $plugins );
				$plugin       = trim( $plugin, '/' ) . '/' . $plugin_files[0];
				$file         = WP_PLUGIN_DIR . '/' . $plugin;
			}
		}

		if ( file_exists( $file ) ) {
			$data = get_plugin_data( $file, false, false );
			if ( ! empty( $data['Name'] ) ) {
				return sprintf( '%1$s (%2$s)', sanitize_text_field( $data['Name'] ), $plugin );
			}
		}

		return $plugin;
	}

	/**
	 * Odczytuje identyfikator nowo zainstalowanej wtyczki z obiektu instalatora.
	 *
	 * Przy pojedynczej instalacji WordPress nie przekazuje nazwy w hook_extra,
	 * ale Plugin_Upgrader udostępnia ją przez plugin_info() i wynik operacji.
	 *
	 * @param WP_Upgrader $upgrader Obiekt instalatora.
	 * @return string
	 */
	public static function get_plugin_file_from_upgrader( $upgrader ) {
		if ( is_object( $upgrader ) && is_callable( array( $upgrader, 'plugin_info' ) ) ) {
			$plugin = $upgrader->plugin_info();
			if ( is_string( $plugin ) && '' !== $plugin ) {
				return self::normalize_plugin_file( $plugin );
			}
		}

		if ( ! is_object( $upgrader ) || ! isset( $upgrader->result ) || ! is_array( $upgrader->result ) ) {
			return '';
		}

		foreach ( array( 'destination_name', 'destination' ) as $result_key ) {
			if ( ! empty( $upgrader->result[ $result_key ] ) ) {
				$plugin = self::normalize_plugin_file( $upgrader->result[ $result_key ] );
				if ( '' !== $plugin ) {
					return $plugin;
				}
			}
		}

		return '';
	}

	/**
	 * Normalizuje pełną lub względną ścieżkę wtyczki.
	 *
	 * @param mixed $plugin Ścieżka wejściowa.
	 * @return string
	 */
	private static function normalize_plugin_file( $plugin ) {
		$plugin     = wp_normalize_path( sanitize_text_field( (string) $plugin ) );
		$plugin_dir = trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) );

		if ( 0 === strpos( $plugin, $plugin_dir ) ) {
			$plugin = substr( $plugin, strlen( $plugin_dir ) );
		}

		return ltrim( $plugin, '/' );
	}

	/**
	 * Automatycznie usuwa dane starsze niż 30 dni, nie częściej niż raz dziennie.
	 *
	 * @return void
	 */
	private static function maybe_cleanup() {
		$last_cleanup = absint( get_option( AdiNet_Options::ADMIN_LOG_LAST_CLEANUP, 0 ) );

		if ( $last_cleanup > time() - DAY_IN_SECONDS ) {
			return;
		}

		global $wpdb;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( self::RETENTION_DAYS * DAY_IN_SECONDS ) );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::get_table_name() . ' WHERE occurred_at < %s', $cutoff ) );
		update_option( AdiNet_Options::ADMIN_LOG_LAST_CLEANUP, time(), false );
	}

	/**
	 * Utrzymuje twardy limit 10 000 najnowszych identyfikatorów.
	 *
	 * @param int $insert_id Identyfikator właśnie dodanego rekordu.
	 * @return void
	 */
	private static function enforce_record_limit( $insert_id ) {
		$threshold = absint( $insert_id ) - self::MAX_RECORDS;

		if ( $threshold <= 0 ) {
			return;
		}

		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::get_table_name() . ' WHERE id <= %d', $threshold ) );
	}

	/**
	 * Oznacza serię dziesięciu prób logowania z jednego IP jako krytyczną.
	 *
	 * Kolejny alert powstaje dopiero przy 20, 30 itd. próbach w ciągu 15 minut,
	 * dzięki czemu sam alert nie zalewa tabeli.
	 *
	 * @param string $ip Adres źródłowy.
	 * @return void
	 */
	private static function maybe_log_failed_login_burst( $ip ) {
		if ( '' === $ip ) {
			return;
		}

		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - ( 15 * MINUTE_IN_SECONDS ) );
		$count = absint(
			$wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM ' . self::get_table_name() . ' WHERE event_type = %s AND ip = %s AND occurred_at >= %s',
					'login_failed',
					$ip,
					$since
				)
			)
		);

		if ( $count >= 10 && 0 === $count % 10 ) {
			self::record(
				'login_attack',
				self::LEVEL_CRITICAL,
				sprintf( __( 'Wykryto serię %1$d błędnych logowań z adresu %2$s w ciągu 15 minut.', 'adinet-panel' ), $count, $ip ),
				array( 'username' => __( 'Niezalogowany', 'adinet-panel' ), 'ip' => $ip )
			);
		}
	}

	/**
	 * Pobiera i waliduje adres klienta.
	 *
	 * @return string
	 */
	private static function get_client_ip() {
		$ip = AdiNet_Client_IP::normalize( apply_filters( 'adinet_admin_log_client_ip', AdiNet_Client_IP::get_ip() ) );
		return $ip;
	}

	/**
	 * Waliduje IPv4 lub IPv6.
	 *
	 * @param mixed $ip Adres.
	 * @return string
	 */
	private static function sanitize_ip( $ip ) {
		$ip = trim( (string) $ip );

		return false !== filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	/**
	 * Formatuje datę UTC w strefie witryny.
	 *
	 * @param string $date_gmt Data MySQL UTC.
	 * @return string
	 */
	private static function format_mysql_gmt( $date_gmt ) {
		return '' !== $date_gmt ? get_date_from_gmt( $date_gmt, 'd.m.Y H:i' ) : '';
	}

	/**
	 * Zwraca nazwę tabeli dla bieżącej instalacji.
	 *
	 * @return string
	 */
	private static function get_table_name() {
		global $wpdb;

		return $wpdb->prefix . 'adinet_admin_log';
	}
}
