<?php
/** Wspólne rozpoznawanie IP z weryfikacją zaufanego proxy. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Client_IP {
	/** Oficjalne zakresy Cloudflare, zweryfikowane 2026-09-09. */
	public static function get_ip() {
		$remote = self::normalize( isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '' );
		$ranges = array(
			'173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
			'141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
			'197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
			'104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22', '2400:cb00::/32',
			'2606:4700::/32', '2803:f800::/32', '2405:b500::/32', '2405:8100::/32',
			'2a06:98c0::/29', '2c0f:f248::/32',
		);
		// Dodatkowe proxy muszą usuwać nagłówki klienta i ustawiać własne CF-Connecting-IP.
		$ranges = apply_filters( 'adinet_trusted_proxy_ranges', $ranges );
		foreach ( is_array( $ranges ) ? $ranges : array() as $range ) {
			if ( self::in_range( $remote, $range ) ) {
				$ip = self::normalize( isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ? $_SERVER['HTTP_CF_CONNECTING_IP'] : '' );
				// CF-Connecting-IPv6 ma znaczenie tylko przy Pseudo IPv4 / Overwrite Headers.
				// Nie pozwalamy dodatkowym nagłówkiem nadpisać zwykłego CF-Connecting-IP.
				if ( self::in_range( $ip, '240.0.0.0/4' ) ) {
					$ipv6 = self::normalize( isset( $_SERVER['HTTP_CF_CONNECTING_IPV6'] ) ? $_SERVER['HTTP_CF_CONNECTING_IPV6'] : '' );
					if ( false !== filter_var( $ipv6, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) { return $ipv6; }
				}
				if ( '' !== $ip ) { return $ip; }
				break;
			}
		}
		// Hosting z mod_remoteip dostarcza tutaj już rzeczywiste IP; nie ufamy ponownie nagłówkom.
		return $remote;
	}

	public static function normalize( $ip ) {
		if ( ! is_string( $ip ) || false === filter_var( trim( $ip ), FILTER_VALIDATE_IP ) ) {
			return '';
		}
		return inet_ntop( inet_pton( trim( $ip ) ) );
	}

	public static function in_range( $ip, $range ) {
		if ( ! is_string( $range ) || '' === $ip ) {
			return false;
		}
		$parts = explode( '/', $range );
		$network = self::normalize( $parts[0] );
		if ( '' === $network || count( $parts ) > 2 ) {
			return false;
		}
		$address = inet_pton( $ip );
		$network = inet_pton( $network );
		$bits = isset( $parts[1] ) && ctype_digit( $parts[1] ) ? (int) $parts[1] : ( isset( $parts[1] ) ? -1 : strlen( $network ) * 8 );
		if ( false === $address || strlen( $address ) !== strlen( $network ) || $bits < 0 || $bits > strlen( $network ) * 8 ) {
			return false;
		}
		$bytes = intdiv( $bits, 8 );
		$rest = $bits % 8;
		return substr( $address, 0, $bytes ) === substr( $network, 0, $bytes )
			&& ( 0 === $rest || ( ord( $address[ $bytes ] ) & ( 255 << ( 8 - $rest ) ) ) === ( ord( $network[ $bytes ] ) & ( 255 << ( 8 - $rest ) ) ) );
	}
}
