<?php
/**
 * Nazwy i obsługa opcji wtyczki.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Options {
	const PLUGIN_VERSION    = 'adinet_plugin_version';
	const UPDATE_CHANNEL    = 'adinet_update_channel';
	const UPDATE_EMAIL_MODE = 'adinet_update_email_mode';
	const ADMIN_NOTE         = 'adinet_admin_note';
	const DISABLE_WP_CRON    = 'adinet_disable_wp_cron';
	const LOGIN_URL_ENABLED  = 'adinet_login_url_enabled';
	const LOGIN_SLUG         = 'adinet_login_slug';
	const SITE_LAUNCH_DATE   = 'adinet_site_launch_date';
	const MAINTENANCE_MONTH  = 'adinet_maintenance_month';
	const DEBUG_DISPLAY_MODE = 'adinet_debug_display_mode';
	const DEBUG_LOG_MODE     = 'adinet_debug_log_mode';
	const DEBUG_DISPLAY_UNTIL = 'adinet_debug_display_until';
	const DEBUG_LOG_UNTIL = 'adinet_debug_log_until';
	const DISABLE_COMMENTS   = 'adinet_disable_comments';
	const DISALLOW_FILE_EDIT = 'adinet_disallow_file_edit';
	const REVISION_LIMIT     = 'adinet_revision_limit';
	const REVISION_MAX_AGE   = 'adinet_revision_max_age_days';
	const MONITOR_404_ENABLED    = 'adinet_404_monitor_enabled';
	const MONITOR_404_STARTED_AT = 'adinet_404_monitor_started_at';
	const MONITOR_404_ENDS_AT    = 'adinet_404_monitor_ends_at';
	const ADMIN_LOG_ENABLED      = 'adinet_admin_log_enabled';
	const ADMIN_LOG_STARTED_AT   = 'adinet_admin_log_started_at';
	const ADMIN_LOG_LAST_CLEANUP = 'adinet_admin_log_last_cleanup';
	const LAST_AUDIT         = 'adinet_last_audit';
	const HTACCESS_RULES     = 'adinet_htaccess_rules';

	const EMAIL_MODE_ALL      = 'all';
	const EMAIL_MODE_FAILURES = 'failures';
	const EMAIL_MODE_NONE     = 'none';

	const DEBUG_MODE_INHERIT  = 'inherit';
	const DEBUG_MODE_ENABLED  = 'enabled';
	const DEBUG_MODE_DISABLED = 'disabled';
	const DEFAULT_LOGIN_SLUG  = 'logowanie';
	const DEFAULT_REVISION_LIMIT   = 10;
	const DEFAULT_REVISION_MAX_AGE = 370;

	public static function get_update_channel() {
		return self::sanitize_update_channel( get_option( self::UPDATE_CHANNEL, 'stable' ) );
	}

	public static function sanitize_update_channel( $value ) {
		return 'beta' === $value ? 'beta' : 'stable';
	}

	/**
	 * Zwraca dozwolone tryby obsługi e-maili aktualizacyjnych.
	 *
	 * @return string[]
	 */
	public static function get_email_modes() {
		return array(
			self::EMAIL_MODE_ALL,
			self::EMAIL_MODE_FAILURES,
			self::EMAIL_MODE_NONE,
		);
	}

	/**
	 * Zwraca bezpieczną, aktualnie wybraną wartość trybu.
	 *
	 * @return string
	 */
	public static function get_update_email_mode() {
		$mode = get_option( self::UPDATE_EMAIL_MODE, self::EMAIL_MODE_FAILURES );

		if ( ! is_string( $mode ) || ! in_array( $mode, self::get_email_modes(), true ) ) {
			return self::EMAIL_MODE_FAILURES;
		}

		return $mode;
	}

	/**
	 * Waliduje wartość pola wyboru trybu e-maili.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return string
	 */
	public static function sanitize_update_email_mode( $value ) {
		$value = sanitize_key( (string) $value );

		return in_array( $value, self::get_email_modes(), true )
			? $value
			: self::EMAIL_MODE_FAILURES;
	}

	/**
	 * Czyści notatkę administratora. Notatki są celowo zwykłym tekstem.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return string
	 */
	public static function sanitize_admin_note( $value ) {
		return sanitize_textarea_field( (string) $value );
	}

	/**
	 * Zamienia wartość pola wyboru na 0 albo 1.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return int
	 */
	public static function sanitize_boolean( $value ) {
		return empty( $value ) ? 0 : 1;
	}

	/**
	 * Waliduje włączenie własnego adresu i nie pozwala go aktywować z błędnym slugiem.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return int
	 */
	public static function sanitize_login_url_enabled( $value ) {
		$enabled = self::sanitize_boolean( $value );

		if ( ! $enabled ) {
			return 0;
		}

		$posted_slug = isset( $_POST[ self::LOGIN_SLUG ] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			? wp_unslash( $_POST[ self::LOGIN_SLUG ] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			: self::get_login_slug();
		$validation = self::validate_login_slug( $posted_slug );

		if ( true !== $validation ) {
			return self::is_login_url_enabled() ? 1 : 0;
		}

		return 1;
	}

	/**
	 * Czy własny adres logowania jest włączony.
	 *
	 * @return bool
	 */
	public static function is_login_url_enabled() {
		return 1 === absint( get_option( self::LOGIN_URL_ENABLED, 0 ) );
	}

	/**
	 * Czyści i waliduje slug własnego adresu logowania.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return string
	 */
	public static function sanitize_login_slug( $value ) {
		$slug           = self::normalize_login_slug( $value );
		$will_be_active = isset( $_POST[ self::LOGIN_URL_ENABLED ] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			? ! empty( $_POST[ self::LOGIN_URL_ENABLED ] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			: self::is_login_url_enabled();
		$validation     = self::validate_login_slug( $value, $will_be_active );

		if ( true === $validation ) {
			return $slug;
		}

		add_settings_error( self::LOGIN_SLUG, 'adinet_invalid_login_slug', $validation, 'error' );

		$old_slug = self::normalize_login_slug( get_option( self::LOGIN_SLUG, self::DEFAULT_LOGIN_SLUG ) );

		return '' !== $old_slug ? $old_slug : self::DEFAULT_LOGIN_SLUG;
	}

	/**
	 * Zwraca zawsze niepusty i oczyszczony slug logowania.
	 *
	 * @return string
	 */
	public static function get_login_slug() {
		$slug = self::normalize_login_slug( get_option( self::LOGIN_SLUG, self::DEFAULT_LOGIN_SLUG ) );

		return '' !== $slug ? $slug : self::DEFAULT_LOGIN_SLUG;
	}

	/**
	 * Sprawdza wymagania i kolizje własnego adresu logowania.
	 *
	 * @param mixed $value            Sprawdzana wartość.
	 * @param bool  $check_collisions Czy sprawdzać kolizję z istniejącą treścią.
	 * @return true|string
	 */
	private static function validate_login_slug( $value, $check_collisions = true ) {
		$slug = self::normalize_login_slug( $value );

		if ( '' === $slug ) {
			return __( 'Własny adres logowania nie może być pusty.', 'adinet-panel' );
		}

		if ( $slug !== trim( strtolower( (string) $value ), "/ \t\n\r\0\x0B" ) ) {
			return __( 'Adres logowania może zawierać tylko małe litery, cyfry i łączniki.', 'adinet-panel' );
		}

		if ( strlen( $slug ) < 3 || strlen( $slug ) > 80 ) {
			return __( 'Adres logowania musi mieć od 3 do 80 znaków.', 'adinet-panel' );
		}

		$reserved = array(
			'wp-admin',
			'wp-login',
			'wp-login.php',
			'wp-json',
			'wp-content',
			'wp-includes',
			'xmlrpc.php',
			'admin',
			'login',
			'feed',
			'404',
		);

		if ( in_array( $slug, $reserved, true ) ) {
			return __( 'Wybrany adres jest zarezerwowany przez WordPress lub AdiNet. Wpisz inny.', 'adinet-panel' );
		}

		if ( ! $check_collisions ) {
			return true;
		}

		$existing_page = get_page_by_path( $slug, OBJECT, array( 'page', 'post' ) );

		if ( $existing_page instanceof WP_Post ) {
			return __( 'Pod tym adresem istnieje już strona lub wpis. Wpisz inny adres logowania.', 'adinet-panel' );
		}

		return true;
	}

	/**
	 * Normalizuje slug bez zezwalania na ścieżki zagnieżdżone.
	 *
	 * @param mixed $value Wartość wejściowa.
	 * @return string
	 */
	private static function normalize_login_slug( $value ) {
		return sanitize_title( trim( (string) $value, "/ \t\n\r\0\x0B" ) );
	}

	/**
	 * Waliduje datę zapisaną w formacie ISO używanym przez pole date.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return string
	 */
	public static function sanitize_site_launch_date( $value ) {
		$value = sanitize_text_field( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		$date   = DateTime::createFromFormat( '!Y-m-d', $value );
		$errors = DateTime::getLastErrors();

		if (
			false === $date
			|| ( is_array( $errors ) && ( $errors['warning_count'] > 0 || $errors['error_count'] > 0 ) )
			|| $date->format( 'Y-m-d' ) !== $value
		) {
			add_settings_error(
				self::SITE_LAUNCH_DATE,
				'adinet_invalid_launch_date',
				__( 'Data publikacji nie została zapisana, ponieważ ma nieprawidłowy format.', 'adinet-panel' ),
				'error'
			);

			$old_value = get_option( self::SITE_LAUNCH_DATE, '' );

			return is_string( $old_value ) ? $old_value : '';
		}

		return $value;
	}

	/**
	 * Waliduje miesiąc rozliczenia. Pusta wartość oznacza brak terminu.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return int|string
	 */
	public static function sanitize_maintenance_month( $value ) {
		if ( '' === (string) $value ) {
			return '';
		}

		$month = absint( $value );

		return $month >= 1 && $month <= 12 ? (string) $month : '';
	}

	/**
	 * Czy panel AdiNet ma wyłączać uruchamianie WP-Cron przez ruch na stronie.
	 *
	 * @return bool
	 */
	public static function should_disable_wp_cron() {
		return 1 === absint( get_option( self::DISABLE_WP_CRON, 0 ) );
	}

	/**
	 * Czy komentarze, pingbacki i trackbacki mają być wyłączone w całej witrynie.
	 *
	 * @return bool
	 */
	public static function are_comments_disabled() {
		return 1 === absint( get_option( self::DISABLE_COMMENTS, 0 ) );
	}

	/**
	 * Czy AdiNet ma wyłączyć edytory plików motywów i wtyczek.
	 *
	 * @return bool
	 */
	public static function should_disallow_file_edit() {
		return 1 === absint( get_option( self::DISALLOW_FILE_EDIT, 0 ) );
	}

	/**
	 * Waliduje maksymalną liczbę rewizji przechowywanych dla jednej treści.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return int
	 */
	public static function sanitize_revision_limit( $value ) {
		return self::sanitize_positive_integer_option(
			$value,
			self::REVISION_LIMIT,
			self::DEFAULT_REVISION_LIMIT,
			1000,
			__( 'Limit rewizji musi być liczbą całkowitą od 1 do 1000.', 'adinet-panel' )
		);
	}

	/**
	 * Waliduje maksymalny wiek rewizji podany w dniach.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return int
	 */
	public static function sanitize_revision_max_age( $value ) {
		return self::sanitize_positive_integer_option(
			$value,
			self::REVISION_MAX_AGE,
			self::DEFAULT_REVISION_MAX_AGE,
			36500,
			__( 'Okres przechowywania rewizji musi być liczbą całkowitą od 1 do 36500 dni.', 'adinet-panel' )
		);
	}

	/**
	 * Zwraca zapisany limit liczby rewizji.
	 *
	 * @return int
	 */
	public static function get_revision_limit() {
		return self::sanitize_revision_limit( get_option( self::REVISION_LIMIT, self::DEFAULT_REVISION_LIMIT ) );
	}

	/**
	 * Zwraca zapisany maksymalny wiek rewizji w dniach.
	 *
	 * @return int
	 */
	public static function get_revision_max_age() {
		return self::sanitize_revision_max_age( get_option( self::REVISION_MAX_AGE, self::DEFAULT_REVISION_MAX_AGE ) );
	}

	/**
	 * Wspólna walidacja dodatnich ustawień liczbowych.
	 *
	 * @param mixed  $value        Wartość przekazana przez formularz.
	 * @param string $option_name  Nazwa opcji.
	 * @param int    $default      Wartość domyślna.
	 * @param int    $maximum      Największa dozwolona wartość.
	 * @param string $error_message Komunikat walidacji.
	 * @return int
	 */
	private static function sanitize_positive_integer_option( $value, $option_name, $default, $maximum, $error_message ) {
		$raw_value = trim( (string) $value );
		$is_valid  = '' !== $raw_value && ctype_digit( $raw_value );
		$number    = $is_valid ? (int) $raw_value : 0;

		if ( $is_valid && $number >= 1 && $number <= $maximum ) {
			return $number;
		}

		add_settings_error( $option_name, 'adinet_invalid_' . $option_name, $error_message, 'error' );

		$old_value = get_option( $option_name, $default );
		$old_value = is_numeric( $old_value ) ? (int) $old_value : $default;

		return $old_value >= 1 && $old_value <= $maximum ? $old_value : $default;
	}

	/**
	 * Zwraca dozwolone tryby sterowania diagnostyką PHP.
	 *
	 * @return string[]
	 */
	public static function get_debug_modes() {
		return array(
			self::DEBUG_MODE_INHERIT,
			self::DEBUG_MODE_ENABLED,
			self::DEBUG_MODE_DISABLED,
		);
	}

	/**
	 * Waliduje tryb wyświetlania lub logowania błędów.
	 *
	 * @param mixed $value Wartość przekazana przez formularz.
	 * @return string
	 */
	public static function sanitize_debug_mode( $value ) {
		$value = sanitize_key( (string) $value );

		return in_array( $value, self::get_debug_modes(), true )
			? $value
			: self::DEBUG_MODE_INHERIT;
	}

	/**
	 * Zwraca bezpieczny tryb wybranego ustawienia diagnostycznego.
	 *
	 * @param string $option_name Nazwa opcji.
	 * @return string
	 */
	public static function get_debug_mode( $option_name ) {
		$allowed_options = array( self::DEBUG_DISPLAY_MODE, self::DEBUG_LOG_MODE );

		if ( ! in_array( $option_name, $allowed_options, true ) ) {
			return self::DEBUG_MODE_INHERIT;
		}

		return self::sanitize_debug_mode( get_option( $option_name, self::DEBUG_MODE_INHERIT ) );
	}
}
