<?php
/**
 * Rozliczenia usług przypisanych do bieżącej witryny.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Billing {
	const PAGE_SLUG           = 'adinet-billing';
	const SETTINGS_GROUP      = 'adinet_billing_settings';
	const MANAGE_CAPABILITY   = 'adinet_manage_billing';
	const DEFAULT_OWNER_EMAIL = 'kontakt@adinet.pl';
	const STATUS_PENDING      = 'pending';
	const STATUS_INVOICED     = 'invoiced';
	const STATUS_SETTLED      = 'settled';

	/**
	 * Hook podstrony administracyjnej.
	 *
	 * @var string
	 */
	private static $page_hook = '';

	/**
	 * Rejestruje podstronę, ustawienia i chronione akcje.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_submenu_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_adinet_save_billing_item', array( __CLASS__, 'save_item' ) );
		add_action( 'admin_post_adinet_delete_billing_item', array( __CLASS__, 'delete_item' ) );
		add_action( 'admin_post_adinet_bulk_update_billing_status', array( __CLASS__, 'bulk_update_status' ) );
		add_action( 'admin_post_adinet_bulk_update_billing_invoice', array( __CLASS__, 'bulk_update_invoice' ) );
		add_filter( 'map_meta_cap', array( __CLASS__, 'map_manage_capability' ), 10, 4 );
		add_filter( 'option_page_capability_' . self::SETTINGS_GROUP, array( __CLASS__, 'filter_settings_capability' ) );
	}

	/**
	 * Tworzy lub aktualizuje tabelę rozliczeń.
	 *
	 * @return void
	 */
	public static function install_table() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table_name      = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();
		$sql             = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			service_name varchar(190) NOT NULL,
			price decimal(12,2) DEFAULT NULL,
			purchase_date date DEFAULT NULL,
			renewal_date date DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			invoice_number varchar(100) NOT NULL DEFAULT '',
			description text NOT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY renewal_date (renewal_date)
		) {$charset_collate};";

		dbDelta( $sql );
	}

	/**
	 * Zwraca nazwę tabeli właściwą dla bieżącej instalacji.
	 *
	 * @return string
	 */
	public static function get_table_name() {
		global $wpdb;

		return $wpdb->prefix . 'adinet_billing_items';
	}

	/**
	 * Zwraca adres e-mail właściciela rozliczeń.
	 *
	 * @return string
	 */
	public static function get_owner_email() {
		$owner_email = defined( 'ADINET_PANEL_OWNER_EMAIL' ) ? ADINET_PANEL_OWNER_EMAIL : self::DEFAULT_OWNER_EMAIL;

		return is_string( $owner_email ) ? sanitize_email( $owner_email ) : self::DEFAULT_OWNER_EMAIL;
	}

	/**
	 * Sprawdza prawo do modyfikowania rozliczeń.
	 *
	 * @return bool
	 */
	public static function can_manage() {
		return current_user_can( self::MANAGE_CAPABILITY );
	}

	/**
	 * Przyznaje zapis loginowi właściciela albo kontu z adresem AdiNet.
	 *
	 * @param string[] $caps    Wymagane uprawnienia.
	 * @param string   $cap     Sprawdzane uprawnienie.
	 * @param int      $user_id Identyfikator użytkownika.
	 * @param mixed[]  $args    Dodatkowe argumenty.
	 * @return string[]
	 */
	public static function map_manage_capability( $caps, $cap, $user_id, $args ) {
		unset( $args );

		if ( self::MANAGE_CAPABILITY !== $cap ) {
			return $caps;
		}

		$user = get_userdata( $user_id );

		if ( ! $user || ! user_can( $user, 'manage_options' ) ) {
			return array( 'do_not_allow' );
		}

		$login_matches = AdiNet_Admin::get_owner_login() === $user->user_login;
		$email_matches = isset( $user->user_email )
			&& '' !== self::get_owner_email()
			&& 0 === strcasecmp( self::get_owner_email(), sanitize_email( $user->user_email ) );

		return $login_matches || $email_matches
			? array( 'manage_options' )
			: array( 'do_not_allow' );
	}

	/**
	 * Wymusza uprawnienie właściciela przy zapisie metryki projektu.
	 *
	 * @return string
	 */
	public static function filter_settings_capability() {
		return self::MANAGE_CAPABILITY;
	}

	/**
	 * Rejestruje ustawienia metryki przeniesione z głównego panelu.
	 *
	 * @return void
	 */
	public static function register_settings() {
		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::SITE_LAUNCH_DATE,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_site_launch_date' ),
				'default'           => '',
			)
		);

		register_setting(
			self::SETTINGS_GROUP,
			AdiNet_Options::MAINTENANCE_MONTH,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'AdiNet_Options', 'sanitize_maintenance_month' ),
				'default'           => '',
			)
		);
	}

	/**
	 * Dodaje podstronę Rozliczenia w menu AdiNet.
	 *
	 * @return void
	 */
	public static function add_submenu_page() {
		self::$page_hook = add_submenu_page(
			AdiNet_Admin::PAGE_SLUG,
			esc_html__( 'Rozliczenia — AdiNet', 'adinet-panel' ),
			esc_html__( 'Rozliczenia', 'adinet-panel' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);

		add_action( 'load-' . self::$page_hook, array( 'AdiNet_Admin', 'suppress_external_admin_notices' ) );
	}

	/**
	 * Ładuje wspólne zasoby wyłącznie na podstronie rozliczeń.
	 *
	 * @param string $hook_suffix Identyfikator ekranu.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( self::$page_hook !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style( 'adinet-admin', ADINET_URL . 'assets/css/admin.css', array(), ADINET_VERSION );
		wp_enqueue_script( 'adinet-admin', ADINET_URL . 'assets/js/admin.js', array(), ADINET_VERSION, true );
	}

	/**
	 * Zwraca obsługiwane statusy.
	 *
	 * @return array<string,string>
	 */
	public static function get_statuses() {
		return array(
			self::STATUS_PENDING  => __( 'Oczekuje na rozliczenie', 'adinet-panel' ),
			self::STATUS_INVOICED => __( 'Wezwano do zapłaty', 'adinet-panel' ),
			self::STATUS_SETTLED  => __( 'Rozliczono', 'adinet-panel' ),
		);
	}

	/**
	 * Normalizuje cenę. Pusta wartość oznacza „Do wyliczenia”.
	 *
	 * @param mixed $value Wartość formularza.
	 * @return string|null|false
	 */
	public static function normalize_price( $value ) {
		$value = trim( str_replace( array( "\xc2\xa0", ' ' ), '', (string) $value ) );

		if ( '' === $value ) {
			return null;
		}

		$value = str_replace( ',', '.', $value );

		if ( ! preg_match( '/^\d{1,10}(?:\.\d{1,2})?$/', $value ) ) {
			return false;
		}

		$price = number_format( (float) $value, 2, '.', '' );

		return (float) $price <= 9999999999.99 ? $price : false;
	}

	/**
	 * Normalizuje opcjonalną datę ISO.
	 *
	 * @param mixed $value Wartość formularza.
	 * @return string|null|false
	 */
	public static function normalize_date( $value ) {
		$value = sanitize_text_field( (string) $value );

		if ( '' === $value ) {
			return null;
		}

		$date   = DateTimeImmutable::createFromFormat( '!Y-m-d', $value );
		$errors = DateTimeImmutable::getLastErrors();

		if ( false === $date || ( is_array( $errors ) && ( $errors['warning_count'] > 0 || $errors['error_count'] > 0 ) ) ) {
			return false;
		}

		return $date->format( 'Y-m-d' ) === $value ? $value : false;
	}

	/**
	 * Normalizuje status.
	 *
	 * @param mixed $value Wartość formularza.
	 * @return string
	 */
	public static function normalize_status( $value ) {
		$value    = sanitize_key( (string) $value );
		$statuses = self::get_statuses();

		return isset( $statuses[ $value ] ) ? $value : self::STATUS_PENDING;
	}

	/**
	 * Normalizuje listę identyfikatorów wybranych pozycji.
	 *
	 * @param mixed $value Wartość formularza.
	 * @return int[]
	 */
	public static function normalize_item_ids( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$item_ids = array_map( 'absint', $value );
		$item_ids = array_values( array_unique( array_filter( $item_ids ) ) );

		return array_slice( $item_ids, 0, 1000 );
	}

	/**
	 * Zapisuje nową pozycję albo aktualizuje istniejącą.
	 *
	 * @return void
	 */
	public static function save_item() {
		if ( ! self::can_manage() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do zmiany rozliczeń.', 'adinet-panel' ) );
		}

		check_admin_referer( 'adinet_save_billing_item' );

		$item_id        = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
		$service_name   = isset( $_POST['service_name'] ) ? sanitize_text_field( wp_unslash( $_POST['service_name'] ) ) : '';
		$price          = self::normalize_price( isset( $_POST['price'] ) ? wp_unslash( $_POST['price'] ) : '' );
		$purchase_date  = self::normalize_date( isset( $_POST['purchase_date'] ) ? wp_unslash( $_POST['purchase_date'] ) : '' );
		$renewal_date   = self::normalize_date( isset( $_POST['renewal_date'] ) ? wp_unslash( $_POST['renewal_date'] ) : '' );
		$status         = self::normalize_status( isset( $_POST['status'] ) ? wp_unslash( $_POST['status'] ) : '' );
		$invoice_number = isset( $_POST['invoice_number'] ) ? sanitize_text_field( wp_unslash( $_POST['invoice_number'] ) ) : '';
		$description    = isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '';

		$service_name   = self::limit_text( $service_name, 190 );
		$invoice_number = self::limit_text( $invoice_number, 100 );
		$description    = self::limit_text( $description, 5000 );

		if ( '' === $service_name ) {
			self::redirect_with_notice( 'invalid-name' );
		}

		if ( false === $price ) {
			self::redirect_with_notice( 'invalid-price' );
		}

		if ( false === $purchase_date || false === $renewal_date ) {
			self::redirect_with_notice( 'invalid-date' );
		}

		global $wpdb;
		$now  = current_time( 'mysql' );
		$data = array(
			'service_name'   => $service_name,
			'price'          => $price,
			'purchase_date'  => $purchase_date,
			'renewal_date'   => $renewal_date,
			'status'         => $status,
			'invoice_number' => $invoice_number,
			'description'    => $description,
			'updated_at'     => $now,
		);
		$formats = array( '%s', '%f', '%s', '%s', '%s', '%s', '%s', '%s' );

		if ( $item_id > 0 ) {
			if ( null === self::get_item( $item_id ) ) {
				self::redirect_with_notice( 'not-found' );
			}

			$result = $wpdb->update( self::get_table_name(), $data, array( 'id' => $item_id ), $formats, array( '%d' ) );
			self::redirect_with_notice( false === $result ? 'error' : 'updated' );
		}

		$data['created_at'] = $now;
		$formats[]          = '%s';
		$result             = $wpdb->insert( self::get_table_name(), $data, $formats );

		self::redirect_with_notice( false === $result ? 'error' : 'added' );
	}

	/**
	 * Trwale usuwa pojedynczą pozycję po potwierdzeniu.
	 *
	 * @return void
	 */
	public static function delete_item() {
		if ( ! self::can_manage() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do usunięcia tej pozycji.', 'adinet-panel' ) );
		}

		$item_id = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
		check_admin_referer( 'adinet_delete_billing_item_' . $item_id );

		if ( $item_id < 1 ) {
			self::redirect_with_notice( 'not-found' );
		}

		global $wpdb;
		$result = $wpdb->delete( self::get_table_name(), array( 'id' => $item_id ), array( '%d' ) );

		if ( false === $result ) {
			self::redirect_with_notice( 'error' );
		}

		self::redirect_with_notice( 0 === $result ? 'not-found' : 'deleted' );
	}

	/**
	 * Zmienia status wielu zaznaczonych pozycji jednym zapytaniem.
	 *
	 * @return void
	 */
	public static function bulk_update_status() {
		if ( ! self::can_manage() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do zbiorczej zmiany rozliczeń.', 'adinet-panel' ) );
		}

		check_admin_referer( 'adinet_bulk_update_billing_status' );

		$item_ids = self::normalize_item_ids( isset( $_POST['item_ids'] ) ? wp_unslash( $_POST['item_ids'] ) : array() );
		$status   = isset( $_POST['bulk_status'] ) ? sanitize_key( wp_unslash( $_POST['bulk_status'] ) ) : '';
		$statuses = self::get_statuses();

		if ( empty( $item_ids ) ) {
			self::redirect_with_notice( 'bulk-empty' );
		}

		if ( ! isset( $statuses[ $status ] ) ) {
			self::redirect_with_notice( 'invalid-status' );
		}

		global $wpdb;
		$placeholders = implode( ', ', array_fill( 0, count( $item_ids ), '%d' ) );
		$sql          = 'UPDATE ' . self::get_table_name() . " SET status = %s, updated_at = %s WHERE id IN ({$placeholders})";
		$args         = array_merge( array( $status, current_time( 'mysql' ) ), $item_ids );
		$result       = $wpdb->query( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		self::redirect_with_notice( false === $result ? 'error' : 'bulk-updated' );
	}

	/**
	 * Zmienia numer faktury wyłącznie w zaznaczonych pozycjach.
	 *
	 * @return void
	 */
	public static function bulk_update_invoice() {
		if ( ! self::can_manage() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do zbiorczej zmiany rozliczeń.', 'adinet-panel' ) );
		}

		check_admin_referer( 'adinet_bulk_update_billing_invoice', 'adinet_invoice_nonce' );

		$item_ids = self::normalize_item_ids( isset( $_POST['item_ids'] ) ? wp_unslash( $_POST['item_ids'] ) : array() );
		$raw_number = isset( $_POST['bulk_invoice_number'] ) ? wp_unslash( $_POST['bulk_invoice_number'] ) : '';
		$invoice_number = is_string( $raw_number ) ? sanitize_text_field( $raw_number ) : '';

		if ( empty( $item_ids ) ) {
			self::redirect_with_notice( 'bulk-empty' );
		}

		if ( 1 !== preg_match( '/^.{1,100}$/us', $invoice_number ) ) {
			self::redirect_with_notice( 'invalid-invoice' );
		}

		global $wpdb;
		$placeholders = implode( ', ', array_fill( 0, count( $item_ids ), '%d' ) );
		$sql          = 'UPDATE ' . self::get_table_name() . " SET invoice_number = %s, updated_at = %s WHERE id IN ({$placeholders})";
		$args         = array_merge( array( $invoice_number, current_time( 'mysql' ) ), $item_ids );
		$result       = $wpdb->query( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		self::redirect_with_notice( false === $result ? 'error' : 'bulk-invoice-updated' );
	}

	/**
	 * Renderuje metrykę projektu, formularz i tabelę rozliczeń.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! AdiNet_Admin::can_view_panel() ) {
			return;
		}

		self::install_table();

		$can_manage       = self::can_manage();
		$launch_date      = get_option( AdiNet_Options::SITE_LAUNCH_DATE, '' );
		$launch_date      = is_string( $launch_date ) ? $launch_date : '';
		$site_age         = self::get_site_age( $launch_date );
		$maintenance_month = get_option( AdiNet_Options::MAINTENANCE_MONTH, '' );
		$maintenance_month = '' === $maintenance_month ? '' : absint( $maintenance_month );
		$items            = self::get_items();
		$summary          = self::get_summary( $items );
		$notice_code      = isset( $_GET['adinet-billing-notice'] ) ? sanitize_key( wp_unslash( $_GET['adinet-billing-notice'] ) ) : '';
		$editing_id       = $can_manage && isset( $_GET['adinet-edit'] ) ? absint( $_GET['adinet-edit'] ) : 0;
		$editing_item     = $editing_id > 0 ? self::get_item( $editing_id ) : null;
		$form_item        = self::get_empty_item();

		if ( is_array( $editing_item ) ) {
			$form_item = $editing_item;
		} else {
			$editing_id = 0;
		}
		?>
		<div class="wrap adinet-admin adinet-billing-page">
			<header class="adinet-monitor-hero adinet-billing-hero">
				<div>
					<p class="adinet-eyebrow"><?php esc_html_e( 'Koszty konkretnej witryny', 'adinet-panel' ); ?></p>
					<h1><?php esc_html_e( 'Rozliczenia', 'adinet-panel' ); ?></h1>
					<p><?php esc_html_e( 'Usługi opłacane dla klienta, terminy przedłużeń i stan rozliczenia.', 'adinet-panel' ); ?></p>
				</div>
				<span class="adinet-status is-neutral"><?php echo esc_html( sprintf( __( 'Pozycji: %s', 'adinet-panel' ), number_format_i18n( count( $items ) ) ) ); ?></span>
			</header>

			<?php settings_errors(); ?>
			<?php self::render_notice( $notice_code ); ?>

			<?php if ( ! $can_manage ) : ?>
				<div class="notice notice-info"><p><?php esc_html_e( 'Rozliczenia są dostępne tylko do odczytu. Zmiany może wprowadzać wyłącznie konto serwisowe AdiNet.', 'adinet-panel' ); ?></p></div>
			<?php endif; ?>

			<div class="adinet-section-heading adinet-section-heading--project">
				<div>
					<p class="adinet-eyebrow"><?php esc_html_e( 'Metryka strony', 'adinet-panel' ); ?></p>
					<h2><?php esc_html_e( 'Informacje o projekcie', 'adinet-panel' ); ?></h2>
				</div>
				<p><?php esc_html_e( 'Data publikacji i wspólny miesiąc rocznego rozliczenia.', 'adinet-panel' ); ?></p>
			</div>

			<form action="options.php" method="post" class="adinet-billing-project-form<?php echo $can_manage ? '' : ' is-readonly'; ?>" data-adinet-readonly="<?php echo $can_manage ? '0' : '1'; ?>">
				<?php settings_fields( self::SETTINGS_GROUP ); ?>
				<section class="adinet-card adinet-card--project-dates" aria-labelledby="adinet-project-dates-title">
					<h3 id="adinet-project-dates-title" class="screen-reader-text"><?php esc_html_e( 'Daty projektu', 'adinet-panel' ); ?></h3>
					<div class="adinet-project-fields">
						<div class="adinet-project-field">
							<label for="adinet-site-launch-date"><?php esc_html_e( 'Data opublikowania strony', 'adinet-panel' ); ?></label>
							<input type="date" id="adinet-site-launch-date" name="<?php echo esc_attr( AdiNet_Options::SITE_LAUNCH_DATE ); ?>" value="<?php echo esc_attr( $launch_date ); ?>">
							<p class="adinet-help"><?php esc_html_e( 'Dzień oficjalnego opublikowania projektu.', 'adinet-panel' ); ?></p>
						</div>
						<div class="adinet-project-summary">
							<span class="dashicons dashicons-flag" aria-hidden="true"></span>
							<div><small><?php esc_html_e( 'Wiek strony', 'adinet-panel' ); ?></small><strong><?php echo '' !== $site_age ? esc_html( $site_age ) : esc_html__( 'Uzupełnij datę publikacji', 'adinet-panel' ); ?></strong></div>
						</div>
						<div class="adinet-project-field">
							<label for="adinet-maintenance-month"><?php esc_html_e( 'Miesiąc rocznego rozliczenia', 'adinet-panel' ); ?></label>
							<select id="adinet-maintenance-month" name="<?php echo esc_attr( AdiNet_Options::MAINTENANCE_MONTH ); ?>">
								<option value=""><?php esc_html_e( '— Nie ustawiono —', 'adinet-panel' ); ?></option>
								<?php for ( $month = 1; $month <= 12; $month++ ) : ?>
									<option value="<?php echo esc_attr( $month ); ?>" <?php selected( $maintenance_month, $month ); ?>><?php echo esc_html( self::get_month_name( $month ) ); ?></option>
								<?php endfor; ?>
							</select>
							<p class="adinet-help"><?php esc_html_e( 'Miesiąc wspólnego rozliczenia usług klienta.', 'adinet-panel' ); ?></p>
						</div>
						<div class="adinet-project-summary is-billing">
							<span class="dashicons dashicons-money-alt" aria-hidden="true"></span>
							<div><small><?php esc_html_e( 'Najbliższy cykl rozliczeniowy', 'adinet-panel' ); ?></small><strong><?php echo '' !== $maintenance_month ? esc_html( self::get_month_name( $maintenance_month ) ) : esc_html__( 'Uzupełnij miesiąc', 'adinet-panel' ); ?></strong></div>
						</div>
					</div>
					<?php if ( $can_manage ) : ?>
						<div class="adinet-billing-project-actions"><?php submit_button( __( 'Zapisz informacje o projekcie', 'adinet-panel' ), 'secondary', 'submit', false ); ?></div>
					<?php endif; ?>
				</section>
			</form>

			<?php if ( $can_manage ) : ?>
				<section class="adinet-billing-form-section" aria-labelledby="adinet-billing-form-title">
					<div class="adinet-monitor-results__header">
						<div>
							<p class="adinet-eyebrow"><?php echo $editing_id > 0 ? esc_html__( 'Zmiana zapisanej pozycji', 'adinet-panel' ) : esc_html__( 'Nowy koszt klienta', 'adinet-panel' ); ?></p>
							<h2 id="adinet-billing-form-title"><?php echo $editing_id > 0 ? esc_html__( 'Edytuj usługę', 'adinet-panel' ) : esc_html__( 'Dodaj usługę', 'adinet-panel' ); ?></h2>
						</div>
						<?php if ( $editing_id > 0 ) : ?><a href="<?php echo esc_url( self::get_page_url() ); ?>" class="button"><?php esc_html_e( 'Anuluj edycję', 'adinet-panel' ); ?></a><?php endif; ?>
					</div>
					<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" class="adinet-billing-form">
						<input type="hidden" name="action" value="adinet_save_billing_item">
						<input type="hidden" name="item_id" value="<?php echo esc_attr( $form_item['id'] ); ?>">
						<?php wp_nonce_field( 'adinet_save_billing_item' ); ?>

						<label class="adinet-billing-field adinet-billing-field--wide"><span><?php esc_html_e( 'Nazwa usługi', 'adinet-panel' ); ?> *</span><input type="text" name="service_name" value="<?php echo esc_attr( $form_item['service_name'] ); ?>" maxlength="190" required placeholder="<?php echo esc_attr__( 'Np. Complianz PRO', 'adinet-panel' ); ?>"></label>
						<label class="adinet-billing-field"><span><?php esc_html_e( 'Cena', 'adinet-panel' ); ?></span><div class="adinet-billing-price"><input type="text" inputmode="decimal" name="price" value="<?php echo esc_attr( self::price_for_input( $form_item['price'] ) ); ?>" pattern="[0-9]+([,.][0-9]{1,2})?" placeholder="<?php echo esc_attr__( 'Do wyliczenia', 'adinet-panel' ); ?>"><span>zł</span></div><small><?php esc_html_e( 'Pozostaw puste, jeśli kwota nie jest jeszcze znana.', 'adinet-panel' ); ?></small></label>
						<label class="adinet-billing-field"><span><?php esc_html_e( 'Data zakupu', 'adinet-panel' ); ?></span><input type="date" name="purchase_date" value="<?php echo esc_attr( $form_item['purchase_date'] ); ?>"></label>
						<div class="adinet-billing-field"><label for="adinet-renewal-date"><?php esc_html_e( 'Data kolejnego przedłużenia', 'adinet-panel' ); ?></label><div class="adinet-billing-date"><input type="date" id="adinet-renewal-date" name="renewal_date" value="<?php echo esc_attr( $form_item['renewal_date'] ); ?>"><button type="button" class="button adinet-renewal-plus-year"><?php esc_html_e( '+1 rok', 'adinet-panel' ); ?></button></div><small><?php esc_html_e( 'Przycisk liczy rok od tej daty, daty zakupu albo od dziś. Możesz też wpisać rok bezpośrednio w polu. Dla usługi jednorazowej pozostaw puste.', 'adinet-panel' ); ?></small></div>
						<label class="adinet-billing-field"><span><?php esc_html_e( 'Status', 'adinet-panel' ); ?></span><select name="status"><?php foreach ( self::get_statuses() as $status => $label ) : ?><option value="<?php echo esc_attr( $status ); ?>" <?php selected( $form_item['status'], $status ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
						<label class="adinet-billing-field"><span><?php esc_html_e( 'Numer faktury', 'adinet-panel' ); ?></span><input type="text" name="invoice_number" value="<?php echo esc_attr( $form_item['invoice_number'] ); ?>" maxlength="100" placeholder="<?php echo esc_attr__( 'Opcjonalnie', 'adinet-panel' ); ?>"></label>
						<label class="adinet-billing-field adinet-billing-field--full"><span><?php esc_html_e( 'Opis lub komentarz', 'adinet-panel' ); ?></span><textarea name="description" rows="4" maxlength="5000" placeholder="<?php echo esc_attr__( 'Co to jest i do czego służy klientowi?', 'adinet-panel' ); ?>"><?php echo esc_textarea( $form_item['description'] ); ?></textarea></label>
						<div class="adinet-billing-form-actions"><button type="submit" class="button button-primary"><?php echo $editing_id > 0 ? esc_html__( 'Zapisz zmiany', 'adinet-panel' ) : esc_html__( 'Dodaj usługę', 'adinet-panel' ); ?></button></div>
					</form>
				</section>
			<?php endif; ?>

			<div class="adinet-billing-summary">
				<?php self::render_summary_card( self::STATUS_PENDING, $summary[ self::STATUS_PENDING ] ); ?>
				<?php self::render_summary_card( self::STATUS_INVOICED, $summary[ self::STATUS_INVOICED ] ); ?>
				<?php self::render_summary_card( self::STATUS_SETTLED, $summary[ self::STATUS_SETTLED ] ); ?>
			</div>

			<section class="adinet-billing-list" aria-labelledby="adinet-billing-list-title">
				<div class="adinet-monitor-results__header">
					<div><p class="adinet-eyebrow"><?php esc_html_e( 'Historia i bieżące koszty', 'adinet-panel' ); ?></p><h2 id="adinet-billing-list-title"><?php esc_html_e( 'Usługi klienta', 'adinet-panel' ); ?></h2></div>
				</div>

				<?php if ( empty( $items ) ) : ?>
					<div class="adinet-monitor-empty"><span class="dashicons dashicons-money-alt" aria-hidden="true"></span><p><?php esc_html_e( 'Nie dodano jeszcze żadnej usługi.', 'adinet-panel' ); ?></p></div>
				<?php else : ?>
					<?php if ( $can_manage ) : ?>
						<?php self::render_bulk_form(); ?>
					<?php endif; ?>
					<div class="adinet-monitor-table-wrap">
						<table class="widefat striped adinet-monitor-table adinet-billing-table">
							<thead><tr><?php if ( $can_manage ) : ?><td class="check-column"><input type="checkbox" class="adinet-billing-select-all" aria-label="<?php echo esc_attr__( 'Zaznacz wszystkie pozycje', 'adinet-panel' ); ?>"></td><?php endif; ?><th><?php esc_html_e( 'Usługa', 'adinet-panel' ); ?></th><th class="adinet-billing-nowrap"><?php esc_html_e( 'Cena', 'adinet-panel' ); ?></th><th class="adinet-billing-nowrap"><?php esc_html_e( 'Zakup', 'adinet-panel' ); ?></th><th class="adinet-billing-nowrap"><?php esc_html_e( 'Kolejne przedłużenie', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Status', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Faktura', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Opis', 'adinet-panel' ); ?></th><?php if ( $can_manage ) : ?><th><?php esc_html_e( 'Akcje', 'adinet-panel' ); ?></th><?php endif; ?></tr></thead>
							<tbody>
								<?php foreach ( $items as $item ) : ?>
									<tr>
										<?php if ( $can_manage ) : ?><th scope="row" class="check-column"><input type="checkbox" class="adinet-billing-row-checkbox" name="item_ids[]" value="<?php echo esc_attr( $item['id'] ); ?>" form="adinet-billing-bulk-form" aria-label="<?php echo esc_attr( sprintf( __( 'Zaznacz usługę: %s', 'adinet-panel' ), $item['service_name'] ) ); ?>"></th><?php endif; ?>
										<td><strong><?php echo esc_html( $item['service_name'] ); ?></strong></td>
										<td class="adinet-billing-nowrap"><?php echo null === $item['price'] ? '<span class="adinet-billing-unpriced">' . esc_html__( 'Do wyliczenia', 'adinet-panel' ) . '</span>' : esc_html( self::format_price( $item['price'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
										<td class="adinet-billing-nowrap"><?php echo esc_html( self::format_date( $item['purchase_date'] ) ); ?></td>
										<td class="adinet-billing-nowrap"><?php echo esc_html( self::format_date( $item['renewal_date'] ) ); ?></td>
										<td><?php self::render_status_badge( $item['status'] ); ?></td>
										<td><?php echo '' !== $item['invoice_number'] ? esc_html( $item['invoice_number'] ) : '<span aria-hidden="true">—</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
										<td><div class="adinet-billing-description"><?php echo '' !== $item['description'] ? esc_html( $item['description'] ) : '<span aria-hidden="true">—</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></td>
										<?php if ( $can_manage ) : ?>
											<td><div class="adinet-monitor-table__actions"><a class="button button-small" href="<?php echo esc_url( self::get_edit_url( $item['id'] ) ); ?>"><span class="dashicons dashicons-edit" aria-hidden="true"></span><?php esc_html_e( 'Edytuj', 'adinet-panel' ); ?></a><form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" data-confirm-form="<?php echo esc_attr__( 'Czy na pewno chcesz trwale usunąć tę pozycję?', 'adinet-panel' ); ?>"><input type="hidden" name="action" value="adinet_delete_billing_item"><input type="hidden" name="item_id" value="<?php echo esc_attr( $item['id'] ); ?>"><?php wp_nonce_field( 'adinet_delete_billing_item_' . $item['id'] ); ?><button type="submit" class="button button-small button-link-delete adinet-billing-delete"><span class="dashicons dashicons-trash" aria-hidden="true"></span><?php esc_html_e( 'Usuń', 'adinet-panel' ); ?></button></form></div></td>
										<?php endif; ?>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endif; ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Renderuje wspólne zaznaczenie dla niezależnych operacji zbiorczych.
	 *
	 * @return void
	 */
	private static function render_bulk_form() {
		?>
		<form id="adinet-billing-bulk-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" class="adinet-billing-bulk-form">
			<?php wp_nonce_field( 'adinet_bulk_update_billing_status' ); ?>
			<?php wp_nonce_field( 'adinet_bulk_update_billing_invoice', 'adinet_invoice_nonce', false ); ?>
			<div class="adinet-billing-bulk-row">
				<strong><?php esc_html_e( 'Zbiorcza zmiana statusu', 'adinet-panel' ); ?></strong>
				<label class="screen-reader-text" for="adinet-billing-bulk-status"><?php esc_html_e( 'Nowy status zaznaczonych pozycji', 'adinet-panel' ); ?></label>
				<select id="adinet-billing-bulk-status" name="bulk_status">
					<option value=""><?php esc_html_e( 'Wybierz nowy status…', 'adinet-panel' ); ?></option>
					<?php foreach ( self::get_statuses() as $bulk_status => $bulk_label ) : ?><option value="<?php echo esc_attr( $bulk_status ); ?>"><?php echo esc_html( $bulk_label ); ?></option><?php endforeach; ?>
				</select>
				<button type="submit" name="action" value="adinet_bulk_update_billing_status" class="button button-primary adinet-billing-bulk-submit"><?php esc_html_e( 'Zmień status', 'adinet-panel' ); ?></button>
			</div>
			<div class="adinet-billing-bulk-row">
				<strong><?php esc_html_e( 'Zbiorcza zmiana numeru faktury', 'adinet-panel' ); ?></strong>
				<label class="screen-reader-text" for="adinet-billing-bulk-invoice"><?php esc_html_e( 'Nowy numer faktury zaznaczonych pozycji', 'adinet-panel' ); ?></label>
				<input type="text" id="adinet-billing-bulk-invoice" name="bulk_invoice_number" maxlength="100" placeholder="<?php echo esc_attr__( 'Wpisz nowy numer faktury…', 'adinet-panel' ); ?>">
				<button type="submit" name="action" value="adinet_bulk_update_billing_invoice" class="button button-primary adinet-billing-bulk-submit"><?php esc_html_e( 'Zmień numer faktury', 'adinet-panel' ); ?></button>
			</div>
			<span class="adinet-billing-selection-count" role="status" aria-live="polite"><?php esc_html_e( 'Nie zaznaczono pozycji', 'adinet-panel' ); ?></span>
		</form>
		<?php
	}

	/**
	 * Zwraca wszystkie pozycje w kolejności roboczej, a następnie historycznej.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function get_items() {
		global $wpdb;

		$sql = 'SELECT * FROM ' . self::get_table_name() . " ORDER BY CASE status WHEN 'pending' THEN 1 WHEN 'invoiced' THEN 2 ELSE 3 END, CASE WHEN renewal_date IS NULL THEN 1 ELSE 0 END, renewal_date ASC, id DESC";
		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		return is_array( $rows ) ? array_map( array( __CLASS__, 'normalize_item_row' ), $rows ) : array();
	}

	/**
	 * Wyznacza najbliższy roczny miesiąc rozliczenia w strefie witryny.
	 * Bieżący miesiąc traktujemy jako rozpoczęty cykl, więc następny jest za rok.
	 *
	 * @param int                    $month Miesiąc 1–12.
	 * @param DateTimeImmutable|null $now   Data do testów; domyślnie bieżąca.
	 * @return string Pusty ciąg, gdy miesiąc nie jest ustawiony.
	 */
	public static function get_next_billing_period( $month, $now = null ) {
		$month = absint( $month );

		if ( $month < 1 || $month > 12 ) {
			return '';
		}

		$now  = $now instanceof DateTimeImmutable ? $now : new DateTimeImmutable( 'now', wp_timezone() );
		$year = (int) $now->format( 'Y' ) + ( $month <= (int) $now->format( 'n' ) ? 1 : 0 );

		return self::get_month_name( $month ) . ' ' . $year;
	}

	/**
	 * Szacuje znaną część rocznego kosztu bez dublowania historycznych wpisów.
	 * Cena jest używana tylko z najnowszego wpisu danej usługi z datą odnowienia.
	 *
	 * @param array<int,array<string,mixed>> $items Pozycje rozliczeń.
	 * @return array{amount_cents:int,priced:int,unpriced:int}
	 */
	public static function estimate_renewal_cost( $items ) {
		$latest = array();

		foreach ( $items as $item ) {
			$name = isset( $item['service_name'] ) ? trim( (string) $item['service_name'] ) : '';

			if ( '' === $name ) {
				continue;
			}

			if ( ! isset( $latest[ $name ] ) || (int) $item['id'] > (int) $latest[ $name ]['id'] ) {
				$latest[ $name ] = $item;
			}
		}

		$result = array( 'amount_cents' => 0, 'priced' => 0, 'unpriced' => 0 );

		foreach ( $latest as $item ) {
			if ( empty( $item['renewal_date'] ) || false === self::normalize_date( $item['renewal_date'] ) ) {
				continue;
			}

			if ( null === $item['price'] || '' === $item['price'] ) {
				$result['unpriced']++;
			} else {
				$result['priced']++;
				$result['amount_cents'] += (int) round( (float) $item['price'] * 100 );
			}
		}

		return $result;
	}

	/**
	 * Udostępnia dane szacunku dla kokpitu.
	 *
	 * @return array{period:string,amount_cents:int,priced:int,unpriced:int}
	 */
	public static function get_dashboard_estimate() {
		$month    = get_option( AdiNet_Options::MAINTENANCE_MONTH, '' );
		$period   = self::get_next_billing_period( $month );
		$estimate = '' === $period
			? array( 'amount_cents' => 0, 'priced' => 0, 'unpriced' => 0 )
			: self::estimate_renewal_cost( self::get_items() );

		return array_merge( array( 'period' => $period ), $estimate );
	}

	/**
	 * Udostępnia bieżące należności i osobny szacunek odnowień dla kokpitu.
	 *
	 * @return array Dane rozliczeń, pozycji do zapłaty i prognozy.
	 */
	public static function get_dashboard_billing() {
		$items = self::get_items();
		$due_items = array_values( array_filter( $items, static function ( $item ) {
			return self::STATUS_INVOICED === $item['status'];
		} ) );
		$month = get_option( AdiNet_Options::MAINTENANCE_MONTH, '' );

		return array(
			'summary'   => self::get_summary( $items ),
			'due_items' => $due_items,
			'period'    => self::get_next_billing_period( $month ),
			'estimate'  => self::estimate_renewal_cost( $items ),
		);
	}

	/**
	 * Zwraca pojedynczą pozycję.
	 *
	 * @param int $item_id Identyfikator.
	 * @return array<string,mixed>|null
	 */
	private static function get_item( $item_id ) {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . self::get_table_name() . ' WHERE id = %d', $item_id ), // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			ARRAY_A
		);

		return is_array( $row ) ? self::normalize_item_row( $row ) : null;
	}

	/**
	 * Ujednolica typy danych wiersza z bazy.
	 *
	 * @param array<string,mixed> $row Wiersz.
	 * @return array<string,mixed>
	 */
	private static function normalize_item_row( $row ) {
		$row['id']             = isset( $row['id'] ) ? absint( $row['id'] ) : 0;
		$row['service_name']   = isset( $row['service_name'] ) ? (string) $row['service_name'] : '';
		$row['price']          = isset( $row['price'] ) && '' !== $row['price'] ? (string) $row['price'] : null;
		$row['purchase_date']  = isset( $row['purchase_date'] ) ? (string) $row['purchase_date'] : '';
		$row['renewal_date']   = isset( $row['renewal_date'] ) ? (string) $row['renewal_date'] : '';
		$row['status']         = self::normalize_status( isset( $row['status'] ) ? $row['status'] : '' );
		$row['invoice_number'] = isset( $row['invoice_number'] ) ? (string) $row['invoice_number'] : '';
		$row['description']    = isset( $row['description'] ) ? (string) $row['description'] : '';

		return $row;
	}

	/**
	 * Zwraca pusty model formularza.
	 *
	 * @return array<string,mixed>
	 */
	private static function get_empty_item() {
		return array(
			'id'             => 0,
			'service_name'   => '',
			'price'          => null,
			'purchase_date'  => '',
			'renewal_date'   => '',
			'status'         => self::STATUS_PENDING,
			'invoice_number' => '',
			'description'    => '',
		);
	}

	/**
	 * Liczy kwoty i braki cen osobno dla każdego statusu.
	 *
	 * @param array<int,array<string,mixed>> $items Pozycje.
	 * @return array<string,array{amount_cents:int,unpriced:int,count:int}>
	 */
	private static function get_summary( $items ) {
		$summary = array();

		foreach ( self::get_statuses() as $status => $label ) {
			unset( $label );
			$summary[ $status ] = array( 'amount_cents' => 0, 'unpriced' => 0, 'count' => 0 );
		}

		foreach ( $items as $item ) {
			$status = self::normalize_status( $item['status'] );
			$summary[ $status ]['count']++;

			if ( null === $item['price'] ) {
				$summary[ $status ]['unpriced']++;
			} else {
				$summary[ $status ]['amount_cents'] += (int) round( (float) $item['price'] * 100 );
			}
		}

		return $summary;
	}

	/**
	 * Renderuje kartę podsumowania statusu.
	 *
	 * @param string                                    $status Status.
	 * @param array{amount_cents:int,unpriced:int,count:int} $data Dane.
	 * @return void
	 */
	private static function render_summary_card( $status, $data ) {
		$statuses = self::get_statuses();
		$value    = self::format_price( $data['amount_cents'] / 100 );

		if ( $data['unpriced'] > 0 ) {
			$value .= ' + ' . sprintf( __( '%s do wyliczenia', 'adinet-panel' ), number_format_i18n( $data['unpriced'] ) );
		}
		?>
		<section class="is-<?php echo esc_attr( $status ); ?>"><small><?php echo esc_html( $statuses[ $status ] ); ?></small><strong><?php echo esc_html( $value ); ?></strong><span><?php echo esc_html( sprintf( __( 'Liczba pozycji: %s', 'adinet-panel' ), number_format_i18n( $data['count'] ) ) ); ?></span></section>
		<?php
	}

	/**
	 * Renderuje etykietę statusu.
	 *
	 * @param string $status Status.
	 * @return void
	 */
	private static function render_status_badge( $status ) {
		$statuses = self::get_statuses();
		$status   = self::normalize_status( $status );
		?>
		<span class="adinet-billing-status is-<?php echo esc_attr( $status ); ?>"><span aria-hidden="true"></span><?php echo esc_html( $statuses[ $status ] ); ?></span>
		<?php
	}

	/**
	 * Renderuje komunikat po akcji.
	 *
	 * @param string $code Kod komunikatu.
	 * @return void
	 */
	private static function render_notice( $code ) {
		$notices = array(
			'added'         => array( 'notice-success', __( 'Usługa została dodana.', 'adinet-panel' ) ),
			'updated'       => array( 'notice-success', __( 'Zmiany w usłudze zostały zapisane.', 'adinet-panel' ) ),
			'deleted'       => array( 'notice-success', __( 'Pozycja została trwale usunięta.', 'adinet-panel' ) ),
			'invalid-name'  => array( 'notice-error', __( 'Podaj nazwę usługi.', 'adinet-panel' ) ),
			'invalid-price' => array( 'notice-error', __( 'Cena ma nieprawidłowy format. Wpisz np. 127,40 albo pozostaw pole puste.', 'adinet-panel' ) ),
			'invalid-date'  => array( 'notice-error', __( 'Jedna z dat ma nieprawidłowy format.', 'adinet-panel' ) ),
			'invalid-status' => array( 'notice-error', __( 'Wybierz prawidłowy status.', 'adinet-panel' ) ),
			'bulk-empty'     => array( 'notice-warning', __( 'Zaznacz co najmniej jedną pozycję.', 'adinet-panel' ) ),
			'bulk-updated'   => array( 'notice-success', __( 'Status zaznaczonych pozycji został zmieniony.', 'adinet-panel' ) ),
			'bulk-invoice-updated' => array( 'notice-success', __( 'Numer faktury zaznaczonych pozycji został zmieniony.', 'adinet-panel' ) ),
			'invalid-invoice' => array( 'notice-error', __( 'Podaj numer faktury (maksymalnie 100 znaków).', 'adinet-panel' ) ),
			'not-found'     => array( 'notice-error', __( 'Nie znaleziono wskazanej pozycji.', 'adinet-panel' ) ),
			'error'         => array( 'notice-error', __( 'Nie udało się zapisać zmiany w bazie danych.', 'adinet-panel' ) ),
		);

		if ( ! isset( $notices[ $code ] ) ) {
			return;
		}
		?>
		<div class="notice <?php echo esc_attr( $notices[ $code ][0] ); ?> is-dismissible"><p><?php echo esc_html( $notices[ $code ][1] ); ?></p></div>
		<?php
	}

	/**
	 * Przekierowuje do podstrony z komunikatem.
	 *
	 * @param string $notice Kod komunikatu.
	 * @return void
	 */
	private static function redirect_with_notice( $notice ) {
		wp_safe_redirect( add_query_arg( 'adinet-billing-notice', $notice, self::get_page_url() ) );
		exit;
	}

	/**
	 * Zwraca adres podstrony rozliczeń.
	 *
	 * @return string
	 */
	public static function get_page_url() {
		return admin_url( 'admin.php?page=' . self::PAGE_SLUG );
	}

	/**
	 * Zwraca adres edycji pozycji.
	 *
	 * @param int $item_id Identyfikator.
	 * @return string
	 */
	private static function get_edit_url( $item_id ) {
		return add_query_arg( 'adinet-edit', absint( $item_id ), self::get_page_url() );
	}

	/**
	 * Formatuje cenę w PLN.
	 *
	 * @param mixed $price Cena.
	 * @return string
	 */
	private static function format_price( $price ) {
		return number_format_i18n( (float) $price, 2 ) . ' zł';
	}

	/**
	 * Formatuje cenę do pola edycji.
	 *
	 * @param mixed $price Cena.
	 * @return string
	 */
	private static function price_for_input( $price ) {
		return null === $price || '' === $price ? '' : str_replace( '.', ',', number_format( (float) $price, 2, '.', '' ) );
	}

	/**
	 * Formatuje opcjonalną datę.
	 *
	 * @param mixed $date Data ISO.
	 * @return string
	 */
	private static function format_date( $date ) {
		if ( empty( $date ) || '0000-00-00' === $date ) {
			return '—';
		}

		$parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $date );

		return false === $parsed ? '—' : $parsed->format( 'd.m.Y' );
	}

	/**
	 * Ogranicza tekst bez psucia znaków wielobajtowych.
	 *
	 * @param string $value Tekst.
	 * @param int    $length Maksymalna długość.
	 * @return string
	 */
	private static function limit_text( $value, $length ) {
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $length ) : substr( $value, 0, $length );
	}

	/**
	 * Zwraca odmienioną jednostkę czasu.
	 *
	 * @param int    $number Liczba.
	 * @param string $unit   year albo month.
	 * @return string
	 */
	private static function format_polish_time_unit( $number, $unit ) {
		$number   = absint( $number );
		$last_two = $number % 100;
		$last_one = $number % 10;
		$is_few   = $last_one >= 2 && $last_one <= 4 && ( $last_two < 12 || $last_two > 14 );

		if ( 'year' === $unit ) {
			$word = 1 === $number ? __( 'rok', 'adinet-panel' ) : ( $is_few ? __( 'lata', 'adinet-panel' ) : __( 'lat', 'adinet-panel' ) );
		} else {
			$word = 1 === $number ? __( 'miesiąc', 'adinet-panel' ) : ( $is_few ? __( 'miesiące', 'adinet-panel' ) : __( 'miesięcy', 'adinet-panel' ) );
		}

		return number_format_i18n( $number ) . ' ' . $word;
	}

	/**
	 * Oblicza wiek strony na podstawie daty publikacji.
	 *
	 * @param string $date_string Data ISO.
	 * @return string
	 */
	private static function get_site_age( $date_string ) {
		if ( '' === $date_string ) {
			return '';
		}

		$launch = DateTimeImmutable::createFromFormat( '!Y-m-d', $date_string, wp_timezone() );
		$now    = new DateTimeImmutable( 'now', wp_timezone() );

		if ( false === $launch ) {
			return '';
		}

		if ( $launch > $now ) {
			return __( 'Data publikacji jest w przyszłości.', 'adinet-panel' );
		}

		$difference = $launch->diff( $now );

		if ( 0 === $difference->y && 0 === $difference->m ) {
			return __( 'Mniej niż miesiąc', 'adinet-panel' );
		}

		$parts = array();

		if ( $difference->y > 0 ) {
			$parts[] = self::format_polish_time_unit( $difference->y, 'year' );
		}

		if ( $difference->m > 0 ) {
			$parts[] = self::format_polish_time_unit( $difference->m, 'month' );
		}

		return implode( ' i ', $parts );
	}

	/**
	 * Zwraca lokalną nazwę miesiąca.
	 *
	 * @param int $month Numer miesiąca.
	 * @return string
	 */
	private static function get_month_name( $month ) {
		global $wp_locale;

		$month = absint( $month );

		if ( $month < 1 || $month > 12 || ! isset( $wp_locale ) ) {
			return '';
		}

		return (string) $wp_locale->get_month( zeroise( $month, 2 ) );
	}
}
