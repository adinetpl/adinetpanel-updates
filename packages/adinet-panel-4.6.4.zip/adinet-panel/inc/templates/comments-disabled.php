<?php
/**
 * Pusty szablon używany, gdy komentarze są globalnie wyłączone.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
