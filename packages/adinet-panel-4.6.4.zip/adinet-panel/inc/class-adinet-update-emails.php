<?php
/**
 * Kontrola powiadomień o automatycznych aktualizacjach.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Update_Emails {
	/**
	 * Rejestruje filtry WordPressa.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'auto_core_update_send_email', array( __CLASS__, 'filter_core_email' ), 10, 4 );
		add_filter( 'auto_plugin_update_send_email', array( __CLASS__, 'filter_plugin_theme_email' ), 10, 2 );
		add_filter( 'auto_theme_update_send_email', array( __CLASS__, 'filter_plugin_theme_email' ), 10, 2 );
	}

	/**
	 * Filtruje wiadomości o automatycznych aktualizacjach rdzenia.
	 *
	 * @param bool   $send        Czy WordPress zamierza wysłać wiadomość.
	 * @param string $type        Typ wiadomości: success, fail lub critical.
	 * @param object $core_update Obiekt aktualizacji rdzenia.
	 * @param mixed  $result      Wynik aktualizacji.
	 * @return bool
	 */
	public static function filter_core_email( $send, $type, $core_update, $result ) {
		unset( $core_update, $result );

		$mode = AdiNet_Options::get_update_email_mode();

		if ( AdiNet_Options::EMAIL_MODE_NONE === $mode ) {
			return false;
		}

		if ( AdiNet_Options::EMAIL_MODE_FAILURES === $mode ) {
			return (bool) $send && in_array( $type, array( 'fail', 'critical' ), true );
		}

		return (bool) $send;
	}

	/**
	 * Filtruje wiadomości o automatycznych aktualizacjach wtyczek i motywów.
	 *
	 * W trybie „tylko błędy” pozwala wysłać zbiorczą wiadomość, jeśli co najmniej
	 * jedna aktualizacja nie zakończyła się wartością true.
	 *
	 * @param bool  $enabled        Czy WordPress zamierza wysłać wiadomość.
	 * @param array $update_results Wyniki aktualizacji.
	 * @return bool
	 */
	public static function filter_plugin_theme_email( $enabled, $update_results ) {
		$mode = AdiNet_Options::get_update_email_mode();

		if ( AdiNet_Options::EMAIL_MODE_NONE === $mode ) {
			return false;
		}

		if ( AdiNet_Options::EMAIL_MODE_FAILURES === $mode ) {
			return (bool) $enabled && self::contains_failure( $update_results );
		}

		return (bool) $enabled;
	}

	/**
	 * Sprawdza, czy zbiór wyników zawiera błąd.
	 *
	 * Przy nieoczekiwanej strukturze zwraca true, aby nie wyciszyć potencjalnie
	 * ważnego komunikatu po zmianie formatu danych przez WordPressa.
	 *
	 * @param mixed $update_results Wyniki aktualizacji.
	 * @return bool
	 */
	private static function contains_failure( $update_results ) {
		if ( ! is_array( $update_results ) || empty( $update_results ) ) {
			return true;
		}

		foreach ( $update_results as $update_result ) {
			if ( is_object( $update_result ) && property_exists( $update_result, 'result' ) ) {
				if ( true !== $update_result->result ) {
					return true;
				}

				continue;
			}

			if ( is_array( $update_result ) && array_key_exists( 'result', $update_result ) ) {
				if ( true !== $update_result['result'] ) {
					return true;
				}

				continue;
			}

			return true;
		}

		return false;
	}
}
