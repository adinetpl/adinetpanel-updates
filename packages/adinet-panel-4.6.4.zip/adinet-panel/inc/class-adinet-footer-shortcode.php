<?php
/**
 * Shortcode kompletnej stopki AdiNet.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Footer_Shortcode {
	/**
	 * Rejestruje hook inicjujący shortcode.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Rejestruje shortcode [adinet_footer].
	 *
	 * @return void
	 */
	public static function register() {
		add_shortcode( 'adinet_footer', array( __CLASS__, 'render' ) );
	}

	/**
	 * Zwraca gotową treść stopki z aktualnym rokiem i domeną witryny.
	 *
	 * @return string
	 */
	public static function render() {
		return sprintf(
			'© %1$s %2$s | %3$s <a href="%4$s">AdiNet</a>',
			esc_html( wp_date( 'Y' ) ),
			esc_html( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ),
			esc_html__( 'Stworzone i obsługiwane przez', 'adinet-panel' ),
			esc_url( 'https://adinet.pl' )
		);
	}
}
