<?php
/**
 * Globalne wyłączanie komentarzy, pingbacków i trackbacków.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Comments_Control {
	/**
	 * Rejestruje blokady wyłącznie po włączeniu funkcji w panelu AdiNet.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! AdiNet_Options::are_comments_disabled() ) {
			return;
		}

		add_filter( 'comments_open', '__return_false', PHP_INT_MAX );
		add_filter( 'pings_open', '__return_false', PHP_INT_MAX );
		add_filter( 'pre_comment_approved', array( __CLASS__, 'block_comment_insertion' ), PHP_INT_MAX, 2 );
		add_filter( 'option_default_comment_status', array( __CLASS__, 'return_closed' ), PHP_INT_MAX );
		add_filter( 'option_default_ping_status', array( __CLASS__, 'return_closed' ), PHP_INT_MAX );
		add_filter( 'comments_pre_query', array( __CLASS__, 'hide_public_comments' ), PHP_INT_MAX, 2 );
		add_filter( 'get_comments_number', array( __CLASS__, 'hide_public_comment_count' ), PHP_INT_MAX, 2 );
		add_filter( 'comments_template', array( __CLASS__, 'use_empty_comments_template' ), PHP_INT_MAX );
		add_filter( 'pre_render_block', array( __CLASS__, 'hide_comment_blocks' ), PHP_INT_MAX, 2 );
		add_filter( 'feed_links_show_comments_feed', '__return_false', PHP_INT_MAX );
		add_filter( 'feed_links_extra_show_post_comments_feed', '__return_false', PHP_INT_MAX );
		add_filter( 'wp_headers', array( __CLASS__, 'remove_pingback_header' ), PHP_INT_MAX );
		add_filter( 'xmlrpc_methods', array( __CLASS__, 'remove_pingback_methods' ), PHP_INT_MAX );

		add_action( 'init', array( __CLASS__, 'remove_post_type_support' ), PHP_INT_MAX );
		add_action( 'admin_menu', array( __CLASS__, 'remove_admin_menu_items' ), PHP_INT_MAX );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'remove_dashboard_widget' ), PHP_INT_MAX );
		add_action( 'admin_bar_menu', array( __CLASS__, 'remove_admin_bar_node' ), PHP_INT_MAX );
	}

	/**
	 * Zwraca status wymagany przez opcje WordPressa.
	 *
	 * @return string
	 */
	public static function return_closed() {
		return 'closed';
	}

	/**
	 * Zatrzymuje zapis przez centralny mechanizm wp_new_comment().
	 *
	 * @param int|string|WP_Error $approved    Wyliczony status komentarza.
	 * @param array               $commentdata Dane komentarza.
	 * @return WP_Error
	 */
	public static function block_comment_insertion( $approved, $commentdata ) {
		unset( $approved, $commentdata );

		return new WP_Error(
			'adinet_comments_disabled',
			__( 'Komentarze są wyłączone w tej witrynie.', 'adinet-panel' )
		);
	}

	/**
	 * Nie udostępnia zapisanych komentarzy na publicznej stronie ani przez REST API.
	 * Panel administracyjny nadal może odczytać dane po wejściu bezpośrednim.
	 *
	 * @param array|int|null   $comments Wynik przekazany przez wcześniejszy filtr.
	 * @param WP_Comment_Query $query    Bieżące zapytanie o komentarze.
	 * @return array|int|null
	 */
	public static function hide_public_comments( $comments, $query ) {
		if ( is_admin() ) {
			return $comments;
		}

		$query->found_comments = 0;
		$query->max_num_pages  = 0;

		if ( ! empty( $query->query_vars['count'] ) ) {
			return 0;
		}

		return array();
	}

	/**
	 * Ukrywa publiczne liczniki komentarzy bez zmiany danych w bazie.
	 *
	 * @param int|string $count   Liczba komentarzy.
	 * @param int        $post_id Identyfikator treści.
	 * @return int|string
	 */
	public static function hide_public_comment_count( $count, $post_id ) {
		unset( $post_id );

		return is_admin() ? $count : 0;
	}

	/**
	 * Zastępuje szablon komentarzy pustym plikiem wtyczki.
	 *
	 * @param string $template Ścieżka do szablonu motywu.
	 * @return string
	 */
	public static function use_empty_comments_template( $template ) {
		unset( $template );

		return ADINET_PATH . 'inc/templates/comments-disabled.php';
	}

	/**
	 * Usuwa bloki komentarzy z motywów blokowych.
	 *
	 * @param string|null $pre_render   Wstępnie przygotowany HTML bloku.
	 * @param array       $parsed_block Dane przetwarzanego bloku.
	 * @return string|null
	 */
	public static function hide_comment_blocks( $pre_render, $parsed_block ) {
		$block_name     = isset( $parsed_block['blockName'] ) ? $parsed_block['blockName'] : '';
		$comment_blocks = array(
			'core/comments',
			'core/post-comments',
			'core/post-comments-form',
		);

		return in_array( $block_name, $comment_blocks, true ) ? '' : $pre_render;
	}

	/**
	 * Usuwa wsparcie komentarzy i trackbacków z każdego zarejestrowanego typu treści.
	 *
	 * @return void
	 */
	public static function remove_post_type_support() {
		$post_types = get_post_types( array(), 'names' );

		foreach ( $post_types as $post_type ) {
			remove_post_type_support( $post_type, 'comments' );
			remove_post_type_support( $post_type, 'trackbacks' );
		}
	}

	/**
	 * Ukrywa nieużywane ekrany komentarzy i dyskusji w menu panelu.
	 * Nie blokuje bezpośredniego wejścia administratora do starych komentarzy.
	 *
	 * @return void
	 */
	public static function remove_admin_menu_items() {
		remove_menu_page( 'edit-comments.php' );
		remove_submenu_page( 'options-general.php', 'options-discussion.php' );
	}

	/**
	 * Usuwa widżet ostatnich komentarzy z kokpitu.
	 *
	 * @return void
	 */
	public static function remove_dashboard_widget() {
		remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
	}

	/**
	 * Usuwa licznik komentarzy z górnego paska administracyjnego.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar Pasek administracyjny WordPressa.
	 * @return void
	 */
	public static function remove_admin_bar_node( $wp_admin_bar ) {
		$wp_admin_bar->remove_node( 'comments' );
	}

	/**
	 * Usuwa nagłówek ujawniający adres XML-RPC do pingbacków.
	 *
	 * @param array $headers Nagłówki odpowiedzi.
	 * @return array
	 */
	public static function remove_pingback_header( $headers ) {
		unset( $headers['X-Pingback'] );

		return $headers;
	}

	/**
	 * Wyłącza metody XML-RPC odpowiedzialne za dodawanie i odczyt pingbacków.
	 *
	 * @param array $methods Metody XML-RPC.
	 * @return array
	 */
	public static function remove_pingback_methods( $methods ) {
		unset( $methods['pingback.ping'], $methods['pingback.extensions.getPingbacks'] );

		return $methods;
	}
}
