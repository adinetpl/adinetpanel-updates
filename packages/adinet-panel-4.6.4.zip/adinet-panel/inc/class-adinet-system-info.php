<?php
/**
 * Odczyt informacji technicznych prezentowanych w panelu AdiNet.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_System_Info {
	/**
	 * Rozpoznaje konto hostingowe na podstawie ścieżki instalacji WordPressa.
	 *
	 * @return array{account:string,provider:string,path:string,detected:bool}
	 */
	public static function get_hosting() {
		$path     = wp_normalize_path( ABSPATH );
		$account  = '';
		$provider = '';

		if ( preg_match( '#^/home/[^/]+\.dhosting\.pl/([^/]+)(?:/|$)#i', $path, $matches ) ) {
			$account  = sanitize_text_field( $matches[1] );
			$provider = 'dhosting';
		}

		/**
		 * Pozwala dopisać regułę dla innej struktury hostingu bez modyfikacji klasy.
		 *
		 * @param array  $hosting Rozpoznane dane.
		 * @param string $path    Znormalizowana ścieżka ABSPATH.
		 */
		$hosting = apply_filters(
			'adinet_hosting_info',
			array(
				'account'  => $account,
				'provider' => $provider,
				'path'     => $path,
				'detected' => '' !== $account,
			),
			$path
		);

		return wp_parse_args(
			is_array( $hosting ) ? $hosting : array(),
			array(
				'account'  => '',
				'provider' => '',
				'path'     => $path,
				'detected' => false,
			)
		);
	}

	/**
	 * Zwraca wersję PHP wraz z oceną zgodności.
	 *
	 * @return array{version:string,status:string,label:string,detail:string}
	 */
	public static function get_php() {
		$version = PHP_VERSION;

		if ( version_compare( $version, '8.2', '<' ) ) {
			return array(
				'version' => $version,
				'status'  => 'danger',
				'label'   => __( 'Wymaga pilnej aktualizacji', 'adinet-panel' ),
				'detail'  => __( 'Ta gałąź PHP nie jest już objęta oficjalnym wsparciem bezpieczeństwa.', 'adinet-panel' ),
			);
		}

		if ( version_compare( $version, '8.3', '<' ) ) {
			return array(
				'version' => $version,
				'status'  => 'warning',
				'label'   => __( 'Warto zaplanować aktualizację', 'adinet-panel' ),
				'detail'  => __( 'Wersja jest jeszcze wspierana bezpieczeństwa, ale WordPress rekomenduje PHP 8.3 lub nowsze.', 'adinet-panel' ),
			);
		}

		return array(
			'version' => $version,
			'status'  => 'good',
			'label'   => __( 'Wersja aktualna', 'adinet-panel' ),
			'detail'  => __( 'Spełnia aktualne zalecenie WordPressa: PHP 8.3 lub nowsze.', 'adinet-panel' ),
		);
	}

	/**
	 * Zwraca silnik i wersję serwera bazy danych wraz z oceną zgodności.
	 *
	 * @return array{engine:string,version:string,raw:string,status:string,label:string,detail:string}
	 */
	public static function get_database() {
		global $wpdb;

		$raw = '';

		if ( isset( $wpdb ) && method_exists( $wpdb, 'db_server_info' ) ) {
			$raw = (string) $wpdb->db_server_info();
		}

		if ( '' === $raw && isset( $wpdb ) ) {
			$raw = (string) $wpdb->get_var( 'SELECT VERSION()' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		}

		$is_mariadb = false !== stripos( $raw, 'mariadb' );
		$engine     = $is_mariadb ? 'MariaDB' : 'MySQL';
		$normalized = preg_replace( '/^5\.5\.5-/', '', $raw );
		$version    = '';

		if ( is_string( $normalized ) && preg_match( '/(\d+\.\d+(?:\.\d+)?)/', $normalized, $matches ) ) {
			$version = $matches[1];
		}

		if ( '' === $version ) {
			return array(
				'engine'  => __( 'Baza danych', 'adinet-panel' ),
				'version' => __( 'Nieznana', 'adinet-panel' ),
				'raw'     => $raw,
				'status'  => 'neutral',
				'label'   => __( 'Nie udało się ocenić', 'adinet-panel' ),
				'detail'  => __( 'Serwer nie zwrócił informacji o wersji bazy danych.', 'adinet-panel' ),
			);
		}

		$recommended = $is_mariadb ? '10.11' : '8.0';

		if ( version_compare( $version, $recommended, '<' ) ) {
			return array(
				'engine'  => $engine,
				'version' => $version,
				'raw'     => $raw,
				'status'  => 'danger',
				'label'   => __( 'Wymaga aktualizacji', 'adinet-panel' ),
				'detail'  => $is_mariadb
					? __( 'WordPress rekomenduje MariaDB 10.11 lub nowszą.', 'adinet-panel' )
					: __( 'WordPress rekomenduje MySQL 8.0 lub nowszy.', 'adinet-panel' ),
			);
		}

		return array(
			'engine'  => $engine,
			'version' => $version,
			'raw'     => $raw,
			'status'  => 'good',
			'label'   => __( 'Wersja aktualna', 'adinet-panel' ),
			'detail'  => $is_mariadb
				? __( 'Spełnia aktualne zalecenie WordPressa: MariaDB 10.11 lub nowsza.', 'adinet-panel' )
				: __( 'Spełnia aktualne zalecenie WordPressa: MySQL 8.0 lub nowszy.', 'adinet-panel' ),
		);
	}

	/**
	 * Odczytuje niewielki początek drop-inu cache, bez ładowania jego kodu.
	 *
	 * @param string $path Ścieżka pliku.
	 * @return string
	 */
	private static function read_dropin_header( $path ) {
		if ( ! is_readable( $path ) ) {
			return '';
		}

		$content = file_get_contents( $path, false, null, 0, 65536 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		return is_string( $content ) ? strtolower( $content ) : '';
	}

	/**
	 * Zwraca aktywne wtyczki, również te włączone sieciowo.
	 *
	 * @return string[]
	 */
	private static function get_active_plugins() {
		$plugins = get_option( 'active_plugins', array() );
		$plugins = is_array( $plugins ) ? $plugins : array();

		if ( is_multisite() ) {
			$network_plugins = get_site_option( 'active_sitewide_plugins', array() );

			if ( is_array( $network_plugins ) ) {
				$plugins = array_merge( $plugins, array_keys( $network_plugins ) );
			}
		}

		return array_unique( array_map( 'strtolower', $plugins ) );
	}

	/**
	 * Wykrywa cache całych stron na podstawie konfiguracji i znanych wtyczek.
	 *
	 * @return array{label:string,status:string,detail:string}
	 */
	public static function get_page_cache() {
		$dropin_path = WP_CONTENT_DIR . '/advanced-cache.php';
		$dropin      = self::read_dropin_header( $dropin_path );
		$plugins     = self::get_active_plugins();
		$name        = '';

		$signatures = array(
			'LiteSpeed Cache' => array( 'litespeed-cache', 'litespeed cache' ),
			'WP Rocket'       => array( 'wp-rocket', 'wp rocket' ),
			'W3 Total Cache'  => array( 'w3-total-cache', 'w3 total cache' ),
			'WP Super Cache'  => array( 'wp-super-cache', 'wp super cache' ),
			'Cache Enabler'   => array( 'cache-enabler', 'cache enabler' ),
			'Breeze'          => array( 'breeze/breeze.php', 'breeze cache' ),
			'SiteGround Optimizer' => array( 'sg-cachepress', 'siteground optimizer' ),
			'WP Fastest Cache'      => array( 'wp-fastest-cache', 'wp fastest cache' ),
		);

		foreach ( $signatures as $cache_name => $needles ) {
			foreach ( $needles as $needle ) {
				if ( false !== strpos( $dropin, $needle ) || self::plugin_list_contains( $plugins, $needle ) ) {
					$name = $cache_name;
					break 2;
				}
			}
		}

		$wp_cache_enabled = defined( 'WP_CACHE' ) && WP_CACHE;
		$has_dropin       = file_exists( $dropin_path );

		if ( $wp_cache_enabled && $has_dropin ) {
			return array(
				'label'  => '' !== $name ? $name : __( 'Cache stron WordPress', 'adinet-panel' ),
				'status' => 'good',
				'detail' => __( 'WP_CACHE jest aktywny i wykryto plik advanced-cache.php.', 'adinet-panel' ),
			);
		}

		if ( '' !== $name || $has_dropin || $wp_cache_enabled ) {
			return array(
				'label'  => '' !== $name ? $name : __( 'Częściowa konfiguracja cache', 'adinet-panel' ),
				'status' => 'warning',
				'detail' => __( 'Wykryto element mechanizmu cache, ale nie jednocześnie WP_CACHE i advanced-cache.php. Warto sprawdzić konfigurację wtyczki.', 'adinet-panel' ),
			);
		}

		return array(
			'label'  => __( 'Nie wykryto w WordPressie', 'adinet-panel' ),
			'status' => 'neutral',
			'detail' => __( 'Cache serwera, hostingu lub CDN może działać niezależnie i nie zawsze jest widoczny z poziomu WordPressa.', 'adinet-panel' ),
		);
	}

	/**
	 * Sprawdza, czy lista wtyczek zawiera fragment ścieżki.
	 *
	 * @param string[] $plugins Lista wtyczek.
	 * @param string   $needle  Szukany fragment.
	 * @return bool
	 */
	private static function plugin_list_contains( $plugins, $needle ) {
		foreach ( $plugins as $plugin ) {
			if ( false !== strpos( $plugin, strtolower( $needle ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Wykrywa trwały object cache oraz dostępne rozszerzenia PHP.
	 *
	 * @return array{label:string,status:string,detail:string,extensions:string[]}
	 */
	public static function get_object_cache() {
		$dropin_path  = WP_CONTENT_DIR . '/object-cache.php';
		$dropin       = self::read_dropin_header( $dropin_path );
		$has_dropin   = file_exists( $dropin_path );
		$active       = function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
		$plugins      = self::get_active_plugins();
		$object_class = isset( $GLOBALS['wp_object_cache'] ) && is_object( $GLOBALS['wp_object_cache'] ) ? get_class( $GLOBALS['wp_object_cache'] ) : '';
		$type         = self::detect_object_cache_type( $dropin, $plugins, $object_class );

		$extensions = array();

		foreach ( array( 'redis' => 'Redis', 'memcached' => 'Memcached', 'memcache' => 'Memcache' ) as $extension => $label ) {
			if ( extension_loaded( $extension ) ) {
				$extensions[] = $label;
			}
		}

		if ( $active ) {
			return array(
				'label'      => '' !== $type ? $type : __( 'Trwały object cache', 'adinet-panel' ),
				'status'     => 'good',
				'detail'     => '' !== $type
					? sprintf(
						/* translators: %s: detected persistent object-cache backend. */
						__( 'WordPress aktywnie używa trwałego object cache: %s.', 'adinet-panel' ),
						$type
					)
					: __( 'Mechanizm jest aktywnie używany przez WordPress, ale jego backendu nie udało się jednoznacznie rozpoznać.', 'adinet-panel' ),
				'extensions' => $extensions,
			);
		}

		if ( ! empty( $extensions ) ) {
			return array(
				'label'      => __( 'Dostępny, ale nieaktywny', 'adinet-panel' ),
				'status'     => 'warning',
				'detail'     => sprintf(
					/* translators: %s: comma-separated PHP extension names. */
					__( 'Rozszerzenia PHP dostępne na serwerze: %s. WordPress nie zgłasza aktywnego trwałego object cache.', 'adinet-panel' ),
					implode( ', ', $extensions )
				),
				'extensions' => $extensions,
			);
		}

		if ( $has_dropin ) {
			return array(
				'label'      => '' !== $type ? $type : __( 'Nieaktywny drop-in object-cache.php', 'adinet-panel' ),
				'status'     => 'warning',
				'detail'     => __( 'Plik object-cache.php istnieje, ale WordPress nie zgłasza aktywnego trwałego object cache. Warto sprawdzić konfigurację.', 'adinet-panel' ),
				'extensions' => $extensions,
			);
		}

		return array(
			'label'      => __( 'Nie wykryto', 'adinet-panel' ),
			'status'     => 'neutral',
			'detail'     => __( 'WordPress nie korzysta z trwałego object cache, a rozszerzenia Redis/Memcached nie są widoczne dla PHP.', 'adinet-panel' ),
			'extensions' => $extensions,
		);
	}

	/**
	 * Rozpoznaje backend trwałego object cache bez wykonywania kodu drop-inu.
	 *
	 * Samo rozszerzenie PHP nie jest tu sygnałem: może być zainstalowane,
	 * choć żadna witryna z niego nie korzysta.
	 *
	 * @param string   $dropin       Początek pliku object-cache.php.
	 * @param string[] $plugins      Aktywne wtyczki.
	 * @param string   $object_class Klasa aktywnego obiektu cache.
	 * @return string
	 */
	private static function detect_object_cache_type( $dropin, $plugins, $object_class ) {
		$signals = strtolower( $dropin . ' ' . implode( ' ', $plugins ) . ' ' . $object_class );
		$types   = array(
			'Redis'            => array( 'redis-cache', 'redis object cache', 'predis', 'wp redis' ),
			'Memcached'        => array( 'memcached', 'memcached-redux' ),
			'Memcache'         => array( 'memcache' ),
			'Object Cache Pro' => array( 'object-cache-pro', 'objectcachepro', 'object cache pro' ),
			'Docket Cache'     => array( 'docket-cache', 'docket cache' ),
			'Relay'            => array( 'relay' ),
			'APCu'              => array( 'apcu' ),
		);

		foreach ( $types as $type => $needles ) {
			foreach ( $needles as $needle ) {
				if ( false !== strpos( $signals, $needle ) ) {
					return $type;
				}
			}
		}

		return '';
	}
}
