<?php
/**
 * Instalator wybranych wtyczek z biblioteki AdiNet.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Plugin_Installer {
	const PAGE_SLUG          = 'adinet-plugins';
	const LIBRARY_URL        = 'https://adinet.pl/adinet-panel/wtyczki/';
	const LIBRARY_INDEX_URL  = 'https://adinet.pl/adinet-panel/wtyczki/?format=json';
	const OPTION_PACKAGE_MAP = 'adinet_plugin_library_map';

	/**
	 * Hook podstrony administracyjnej.
	 *
	 * @var string
	 */
	private static $page_hook = '';

	/**
	 * Rejestruje podstronę i chronione akcje.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_submenu_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_adinet_install_library_plugin', array( __CLASS__, 'install_plugin' ) );
		add_action( 'admin_post_adinet_activate_library_plugin', array( __CLASS__, 'activate_plugin' ) );
	}

	/**
	 * Dodaje podstronę Wtyczki w menu AdiNet.
	 *
	 * @return void
	 */
	public static function add_submenu_page() {
		self::$page_hook = add_submenu_page(
			AdiNet_Admin::PAGE_SLUG,
			esc_html__( 'Wtyczki — AdiNet', 'adinet-panel' ),
			esc_html__( 'Wtyczki', 'adinet-panel' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);

		add_action( 'load-' . self::$page_hook, array( 'AdiNet_Admin', 'suppress_external_admin_notices' ) );
	}

	/**
	 * Ładuje wspólny arkusz wyłącznie na podstronie instalatora.
	 *
	 * @param string $hook_suffix Identyfikator ekranu.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( self::$page_hook !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style( 'adinet-admin', ADINET_URL . 'assets/css/admin.css', array(), ADINET_VERSION );
	}

	/**
	 * Sprawdza pełne prawo do instalowania paczek z biblioteki.
	 *
	 * @return bool
	 */
	public static function can_install() {
		return AdiNet_Admin::can_manage_panel() && current_user_can( 'install_plugins' );
	}

	/**
	 * Sprawdza pełne prawo do aktywowania paczek z biblioteki.
	 *
	 * @return bool
	 */
	public static function can_activate() {
		return AdiNet_Admin::can_manage_panel() && current_user_can( 'activate_plugins' );
	}

	/**
	 * Pobiera prostą listę plików ZIP z serwera AdiNet.
	 *
	 * @return string[]|WP_Error
	 */
	public static function get_packages() {
		$response = wp_remote_get(
			self::LIBRARY_INDEX_URL,
			array(
				'timeout'             => 12,
				'redirection'         => 2,
				'limit_response_size' => 131072,
				'headers'             => array( 'Accept' => 'application/json' ),
				'user-agent'          => 'AdiNet Panel/' . ADINET_VERSION . '; ' . home_url( '/' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'adinet_plugin_library_unavailable', __( 'Nie udało się połączyć z biblioteką wtyczek AdiNet.', 'adinet-panel' ) );
		}

		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'adinet_plugin_library_http_error', __( 'Biblioteka wtyczek AdiNet zwróciła nieprawidłową odpowiedź.', 'adinet-panel' ) );
		}

		$body = wp_remote_retrieve_body( $response );

		if ( ! is_string( $body ) || strlen( $body ) > 131072 ) {
			return new WP_Error( 'adinet_plugin_library_invalid_body', __( 'Odpowiedź biblioteki wtyczek jest nieprawidłowa.', 'adinet-panel' ) );
		}

		$data = json_decode( $body, true );

		if ( ! is_array( $data ) || ! isset( $data['packages'] ) || ! is_array( $data['packages'] ) ) {
			return new WP_Error( 'adinet_plugin_library_invalid_json', __( 'Lista wtyczek ma nieprawidłowy format.', 'adinet-panel' ) );
		}

		$packages = array();

		foreach ( array_slice( $data['packages'], 0, 200 ) as $item ) {
			$file = is_array( $item ) && isset( $item['file'] ) ? self::normalize_package_file( $item['file'] ) : '';

			if ( '' !== $file ) {
				$packages[ $file ] = $file;
			}
		}

		natcasesort( $packages );

		return array_values( $packages );
	}

	/**
	 * Waliduje samą nazwę pliku paczki, bez przyjmowania ścieżki ani URL-a.
	 *
	 * @param mixed $file Nazwa z serwera albo formularza.
	 * @return string
	 */
	public static function normalize_package_file( $file ) {
		if ( ! is_string( $file ) ) {
			return '';
		}

		$file = trim( $file );

		if (
			'' === $file
			|| strlen( $file ) < 5
			|| strlen( $file ) > 240
			|| basename( $file ) !== $file
			|| 0 !== validate_file( $file )
			|| preg_match( '/[\x00-\x1F\x7F]/', $file )
			|| 0 !== substr_compare( strtolower( $file ), '.zip', -4 )
		) {
			return '';
		}

		return $file;
	}

	/**
	 * Instaluje wybraną paczkę przez standardowy instalator WordPressa.
	 *
	 * @return void
	 */
	public static function install_plugin() {
		self::guard_action( 'install_plugins', __( 'Tylko konto serwisowe AdiNet może instalować wtyczki.', 'adinet-panel' ) );
		check_admin_referer( 'adinet_install_library_plugin' );

		if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
			self::redirect_with_notice( 'file-mods-disabled' );
		}

		$package_file = isset( $_POST['package'] ) ? self::normalize_package_file( wp_unslash( $_POST['package'] ) ) : '';
		$packages     = self::get_packages();

		if ( is_wp_error( $packages ) ) {
			self::redirect_with_notice( 'library-error' );
		}

		if ( '' === $package_file || ! in_array( $package_file, $packages, true ) ) {
			self::redirect_with_notice( 'package-not-found' );
		}

		$installed_plugins = self::get_installed_plugins();
		$package_map       = self::get_package_map();
		$mapped_plugin     = isset( $package_map[ $package_file ] ) ? $package_map[ $package_file ] : '';

		if ( '' !== $mapped_plugin && isset( $installed_plugins[ $mapped_plugin ] ) ) {
			self::redirect_with_notice( 'already-installed' );
		}

		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		$skin     = new Automatic_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		$result   = $upgrader->install( self::get_package_url( $package_file ) );

		if ( is_wp_error( $result ) ) {
			if ( 'folder_exists' === $result->get_error_code() && self::remember_existing_plugin( $package_file, $result ) ) {
				self::redirect_with_notice( 'already-installed' );
			}

			self::redirect_with_notice( self::get_install_error_notice( $result ) );
		}

		if ( true !== $result ) {
			$skin_errors = method_exists( $skin, 'get_errors' ) ? $skin->get_errors() : null;
			self::redirect_with_notice( is_wp_error( $skin_errors ) && $skin_errors->has_errors() ? self::get_install_error_notice( $skin_errors ) : 'filesystem-error' );
		}

		$plugin_file = $upgrader->plugin_info();

		if ( ! self::remember_plugin( $package_file, $plugin_file ) ) {
			self::redirect_with_notice( 'installed-unmapped' );
		}

		self::redirect_with_notice( 'installed' );
	}

	/**
	 * Aktywuje wcześniej zainstalowaną paczkę.
	 *
	 * @return void
	 */
	public static function activate_plugin() {
		self::guard_action( 'activate_plugins', __( 'Tylko konto serwisowe AdiNet może aktywować wtyczki.', 'adinet-panel' ) );
		check_admin_referer( 'adinet_activate_library_plugin' );

		$package_file = isset( $_POST['package'] ) ? self::normalize_package_file( wp_unslash( $_POST['package'] ) ) : '';
		$package_map  = self::get_package_map();
		$plugin_file  = '' !== $package_file && isset( $package_map[ $package_file ] ) ? $package_map[ $package_file ] : '';
		$plugins      = self::get_installed_plugins();

		if ( '' === $plugin_file || ! isset( $plugins[ $plugin_file ] ) ) {
			self::redirect_with_notice( 'plugin-not-found' );
		}

		if ( self::is_plugin_active( $plugin_file ) ) {
			self::redirect_with_notice( 'already-active' );
		}

		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$result = activate_plugin( $plugin_file, '', false, false );

		self::redirect_with_notice( is_wp_error( $result ) ? 'activation-error' : 'activated' );
	}

	/**
	 * Renderuje stronę instalatora.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! AdiNet_Admin::can_view_panel() ) {
			return;
		}

		$packages_result = self::get_packages();
		$packages        = is_wp_error( $packages_result ) ? array() : $packages_result;
		$package_map     = self::get_package_map();
		$plugins         = self::get_installed_plugins();
		$can_manage      = AdiNet_Admin::can_manage_panel();
		$can_install     = self::can_install();
		$can_activate    = self::can_activate();
		$notice_code     = isset( $_GET['adinet-plugin-notice'] ) ? sanitize_key( wp_unslash( $_GET['adinet-plugin-notice'] ) ) : '';
		?>
		<div class="wrap adinet-admin adinet-plugin-installer-page">
			<header class="adinet-monitor-hero">
				<div>
					<p class="adinet-eyebrow"><?php esc_html_e( 'Biblioteka serwisowa AdiNet', 'adinet-panel' ); ?></p>
					<h1><?php esc_html_e( 'Wtyczki', 'adinet-panel' ); ?></h1>
					<p><?php esc_html_e( 'Szybka instalacja sprawdzonych paczek ZIP przechowywanych na serwerze AdiNet.', 'adinet-panel' ); ?></p>
				</div>
				<span class="adinet-status is-neutral"><?php echo esc_html( sprintf( __( 'Pakietów: %s', 'adinet-panel' ), number_format_i18n( count( $packages ) ) ) ); ?></span>
			</header>

			<?php self::render_notice( $notice_code ); ?>

			<?php if ( ! $can_manage ) : ?>
				<div class="notice notice-info"><p><?php esc_html_e( 'Lista jest dostępna tylko do odczytu. Instalować i aktywować wtyczki może wyłącznie konto serwisowe AdiNet.', 'adinet-panel' ); ?></p></div>
			<?php elseif ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Instalowanie wtyczek jest zablokowane przez DISALLOW_FILE_MODS w konfiguracji WordPressa.', 'adinet-panel' ); ?></p></div>
			<?php elseif ( ! $can_install || ! $can_activate ) : ?>
				<div class="notice notice-warning"><p><?php esc_html_e( 'Konto AdiNet nie ma jednego z wymaganych uprawnień WordPressa: install_plugins lub activate_plugins.', 'adinet-panel' ); ?></p></div>
			<?php endif; ?>

			<section class="adinet-plugin-library" aria-labelledby="adinet-plugin-library-title">
				<div class="adinet-monitor-results__header">
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Paczki na serwerze', 'adinet-panel' ); ?></p>
						<h2 id="adinet-plugin-library-title"><?php esc_html_e( 'Dostępne wtyczki', 'adinet-panel' ); ?></h2>
					</div>
					<a class="button" href="<?php echo esc_url( self::get_page_url() ); ?>"><?php esc_html_e( 'Odśwież listę', 'adinet-panel' ); ?></a>
				</div>

				<?php if ( is_wp_error( $packages_result ) ) : ?>
					<div class="notice notice-error inline"><p><?php echo esc_html( $packages_result->get_error_message() ); ?></p></div>
				<?php elseif ( empty( $packages ) ) : ?>
					<div class="adinet-monitor-empty"><span class="dashicons dashicons-admin-plugins" aria-hidden="true"></span><p><?php esc_html_e( 'Na serwerze nie ma obecnie żadnych paczek ZIP.', 'adinet-panel' ); ?></p></div>
				<?php else : ?>
					<div class="adinet-monitor-table-wrap">
						<table class="widefat striped adinet-monitor-table adinet-plugin-library-table">
							<thead><tr><th><?php esc_html_e( 'Pakiet ZIP', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Stan na stronie', 'adinet-panel' ); ?></th><th><?php esc_html_e( 'Akcja', 'adinet-panel' ); ?></th></tr></thead>
							<tbody>
								<?php foreach ( $packages as $package_file ) : ?>
									<?php
									$plugin_file = isset( $package_map[ $package_file ] ) ? $package_map[ $package_file ] : '';
									$installed   = '' !== $plugin_file && isset( $plugins[ $plugin_file ] );
									$active      = $installed && self::is_plugin_active( $plugin_file );
									$plugin_name = $installed && ! empty( $plugins[ $plugin_file ]['Name'] ) ? $plugins[ $plugin_file ]['Name'] : '';
									?>
									<tr>
										<td><strong><?php echo esc_html( $package_file ); ?></strong><?php if ( '' !== $plugin_name ) : ?><small class="adinet-plugin-library-name"><?php echo esc_html( $plugin_name ); ?></small><?php endif; ?></td>
										<td>
											<?php if ( $active ) : ?><span class="adinet-status is-good"><?php esc_html_e( 'Aktywna', 'adinet-panel' ); ?></span>
											<?php elseif ( $installed ) : ?><span class="adinet-status is-warning"><?php esc_html_e( 'Zainstalowana, nieaktywna', 'adinet-panel' ); ?></span>
											<?php else : ?><span class="adinet-status is-neutral"><?php esc_html_e( 'Nie zainstalowano', 'adinet-panel' ); ?></span><?php endif; ?>
										</td>
										<td><div class="adinet-monitor-table__actions">
											<?php if ( ! $installed && $can_install ) : ?>
												<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="adinet_install_library_plugin"><input type="hidden" name="package" value="<?php echo esc_attr( $package_file ); ?>"><?php wp_nonce_field( 'adinet_install_library_plugin' ); ?><button type="submit" class="button button-primary"><span class="dashicons dashicons-download" aria-hidden="true"></span><?php esc_html_e( 'Zainstaluj', 'adinet-panel' ); ?></button></form>
											<?php elseif ( $installed && ! $active && $can_activate ) : ?>
												<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="adinet_activate_library_plugin"><input type="hidden" name="package" value="<?php echo esc_attr( $package_file ); ?>"><?php wp_nonce_field( 'adinet_activate_library_plugin' ); ?><button type="submit" class="button button-primary"><span class="dashicons dashicons-controls-play" aria-hidden="true"></span><?php esc_html_e( 'Aktywuj', 'adinet-panel' ); ?></button></form>
											<?php else : ?><span class="adinet-plugin-library-no-action">—</span><?php endif; ?>
										</div></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endif; ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Wymaga właściciela panelu i natywnego uprawnienia WordPressa.
	 *
	 * @param string $capability Wymagane uprawnienie WordPressa.
	 * @param string $message    Komunikat odmowy.
	 * @return void
	 */
	private static function guard_action( $capability, $message ) {
		if ( ! AdiNet_Admin::can_manage_panel() || ! current_user_can( $capability ) ) {
			wp_die( esc_html( $message ), '', array( 'response' => 403 ) );
		}
	}

	/**
	 * Buduje adres paczki wyłącznie z zaakceptowanej nazwy pliku.
	 *
	 * @param string $package_file Nazwa paczki.
	 * @return string
	 */
	private static function get_package_url( $package_file ) {
		return self::LIBRARY_URL . rawurlencode( $package_file );
	}

	/**
	 * Zwraca wszystkie zainstalowane wtyczki.
	 *
	 * @return array<string,array<string,string>>
	 */
	private static function get_installed_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins();

		return is_array( $plugins ) ? $plugins : array();
	}

	/**
	 * Sprawdza aktywność wtyczki również w sieci witryn.
	 *
	 * @param string $plugin_file Plik główny wtyczki.
	 * @return bool
	 */
	private static function is_plugin_active( $plugin_file ) {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return is_plugin_active( $plugin_file )
			|| ( function_exists( 'is_plugin_active_for_network' ) && is_plugin_active_for_network( $plugin_file ) );
	}

	/**
	 * Odczytuje i oczyszcza zapamiętane powiązania paczek z plikami wtyczek.
	 *
	 * @return array<string,string>
	 */
	private static function get_package_map() {
		$stored = get_option( self::OPTION_PACKAGE_MAP, array() );
		$map    = array();

		if ( ! is_array( $stored ) ) {
			return $map;
		}

		foreach ( $stored as $package_file => $plugin_file ) {
			$package_file = self::normalize_package_file( $package_file );
			$plugin_file  = is_string( $plugin_file ) ? plugin_basename( trim( $plugin_file ) ) : '';

			if ( '' !== $package_file && '' !== $plugin_file && 0 === validate_file( $plugin_file ) ) {
				$map[ $package_file ] = $plugin_file;
			}
		}

		return $map;
	}

	/**
	 * Zapamiętuje plik główny poprawnie zainstalowanej wtyczki.
	 *
	 * @param string $package_file Nazwa paczki.
	 * @param mixed  $plugin_file  Plik zwrócony przez Plugin_Upgrader.
	 * @return bool
	 */
	private static function remember_plugin( $package_file, $plugin_file ) {
		$package_file = self::normalize_package_file( $package_file );
		$plugin_file  = is_string( $plugin_file ) ? plugin_basename( trim( $plugin_file ) ) : '';

		if ( '' === $package_file || '' === $plugin_file || 0 !== validate_file( $plugin_file ) ) {
			return false;
		}

		$plugins = self::get_installed_plugins();

		if ( ! isset( $plugins[ $plugin_file ] ) ) {
			return false;
		}

		$map                  = self::get_package_map();
		$map[ $package_file ] = $plugin_file;
		update_option( self::OPTION_PACKAGE_MAP, $map, false );

		return true;
	}

	/**
	 * Przy błędzie folder_exists rozpoznaje już istniejącą wtyczkę w tym folderze.
	 *
	 * @param string   $package_file Nazwa paczki.
	 * @param WP_Error $error        Błąd instalatora.
	 * @return bool
	 */
	private static function remember_existing_plugin( $package_file, $error ) {
		$destination = $error->get_error_data();

		if ( ! is_string( $destination ) || '' === $destination ) {
			return false;
		}

		$directory = basename( untrailingslashit( wp_normalize_path( $destination ) ) );

		if ( '' === $directory || 0 !== validate_file( $directory ) ) {
			return false;
		}

		$plugins = get_plugins( '/' . $directory );

		if ( ! is_array( $plugins ) || empty( $plugins ) ) {
			return false;
		}

		$plugin_files = array_keys( $plugins );

		return self::remember_plugin( $package_file, $directory . '/' . $plugin_files[0] );
	}

	/**
	 * Zamienia techniczny błąd instalatora na bezpieczny komunikat panelu.
	 *
	 * @param WP_Error $error Błąd instalatora.
	 * @return string
	 */
	private static function get_install_error_notice( $error ) {
		$code = $error->get_error_code();

		if ( in_array( $code, array( 'download_failed', 'http_no_url', 'http_404' ), true ) ) {
			return 'download-error';
		}

		if ( 'folder_exists' === $code ) {
			return 'folder-exists';
		}

		if ( in_array( $code, array( 'incompatible_php_required_version', 'incompatible_wp_required_version' ), true ) ) {
			return 'incompatible';
		}

		if ( in_array( $code, array( 'fs_unavailable', 'fs_error', 'mkdir_failed', 'copy_failed' ), true ) ) {
			return 'filesystem-error';
		}

		return 'install-error';
	}

	/**
	 * Renderuje komunikat po akcji instalatora.
	 *
	 * @param string $code Kod komunikatu.
	 * @return void
	 */
	private static function render_notice( $code ) {
		$notices = array(
			'installed'           => array( 'notice-success', __( 'Wtyczka została zainstalowana. Możesz ją teraz aktywować.', 'adinet-panel' ) ),
			'activated'           => array( 'notice-success', __( 'Wtyczka została aktywowana.', 'adinet-panel' ) ),
			'already-installed'   => array( 'notice-info', __( 'Ta wtyczka jest już zainstalowana. Jeżeli jest nieaktywna, użyj przycisku Aktywuj.', 'adinet-panel' ) ),
			'already-active'      => array( 'notice-info', __( 'Ta wtyczka jest już aktywna.', 'adinet-panel' ) ),
			'installed-unmapped'  => array( 'notice-warning', __( 'Paczka została zainstalowana, ale nie udało się rozpoznać jej głównego pliku. Aktywuj ją na standardowym ekranie Wtyczki.', 'adinet-panel' ) ),
			'library-error'       => array( 'notice-error', __( 'Nie udało się pobrać aktualnej listy paczek z serwera AdiNet.', 'adinet-panel' ) ),
			'package-not-found'   => array( 'notice-error', __( 'Wybranej paczki nie ma już w bibliotece AdiNet.', 'adinet-panel' ) ),
			'plugin-not-found'    => array( 'notice-error', __( 'Nie znaleziono zainstalowanej wtyczki powiązanej z tą paczką.', 'adinet-panel' ) ),
			'file-mods-disabled'  => array( 'notice-error', __( 'Instalowanie wtyczek jest zablokowane przez DISALLOW_FILE_MODS.', 'adinet-panel' ) ),
			'download-error'      => array( 'notice-error', __( 'Nie udało się pobrać paczki ZIP z serwera AdiNet.', 'adinet-panel' ) ),
			'folder-exists'       => array( 'notice-warning', __( 'Folder tej wtyczki już istnieje, ale nie udało się jednoznacznie rozpoznać jej głównego pliku.', 'adinet-panel' ) ),
			'incompatible'        => array( 'notice-error', __( 'Wtyczka wymaga innej wersji PHP albo WordPressa.', 'adinet-panel' ) ),
			'filesystem-error'    => array( 'notice-error', __( 'WordPress nie może zapisać plików wtyczki. Sprawdź uprawnienia systemu plików lub dane FTP/SSH.', 'adinet-panel' ) ),
			'install-error'       => array( 'notice-error', __( 'Instalacja wtyczki nie powiodła się.', 'adinet-panel' ) ),
			'activation-error'    => array( 'notice-error', __( 'Nie udało się aktywować wtyczki. Sprawdź jej wymagania na standardowym ekranie Wtyczki.', 'adinet-panel' ) ),
		);

		if ( ! isset( $notices[ $code ] ) ) {
			return;
		}
		?>
		<div class="notice <?php echo esc_attr( $notices[ $code ][0] ); ?> is-dismissible"><p><?php echo esc_html( $notices[ $code ][1] ); ?></p></div>
		<?php
	}

	/**
	 * Przekierowuje do podstrony z komunikatem.
	 *
	 * @param string $notice Kod komunikatu.
	 * @return void
	 */
	private static function redirect_with_notice( $notice ) {
		wp_safe_redirect( add_query_arg( 'adinet-plugin-notice', $notice, self::get_page_url() ) );
		exit;
	}

	/**
	 * Zwraca adres podstrony instalatora.
	 *
	 * @return string
	 */
	private static function get_page_url() {
		return admin_url( 'admin.php?page=' . self::PAGE_SLUG );
	}
}
