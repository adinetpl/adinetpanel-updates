<?php
/**
 * Aktualizacje AdiNet Panel spoza repozytorium WordPress.org.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Updater {
	/**
	 * Adres identyfikujący prywatne źródło aktualizacji.
	 */
	const UPDATE_URI = 'https://adinet.pl/adinet-panel/';

	/**
	 * Publiczny plik z informacjami o bieżącym wydaniu.
	 */
	const METADATA_URL = 'https://raw.githubusercontent.com/adinetpl/adinetpanel-updates/main/channels/';
	const PACKAGE_URL = 'https://raw.githubusercontent.com/adinetpl/adinetpanel-updates/main/packages/';

	/**
	 * Dane wydania pobrane w bieżącym żądaniu.
	 *
	 * @var array<string, mixed>|WP_Error|null
	 */
	private static $metadata = null;

	/**
	 * Rejestruje integrację ze standardowym systemem aktualizacji WordPressa.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'update_plugins_adinet.pl', array( __CLASS__, 'check_update' ), 10, 4 );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_information' ), 20, 3 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'download_verified_package' ), 99, 4 );
	}

	public static function clear_update_cache() {
		self::$metadata = null;
		delete_site_transient( 'update_plugins' );
	}

	/**
	 * Weryfikuje ZIP przed rozpakowaniem także przy aktualizacji w tle.
	 */
	public static function download_verified_package( $reply, $package, $upgrader, $hook_extra ) {
		if ( ! $upgrader instanceof Plugin_Upgrader || plugin_basename( ADINET_FILE ) !== ( $hook_extra['plugin'] ?? '' ) ) {
			return $reply;
		}

		// Cache WordPressa może jeszcze wskazywać poprzedni kanał albo wydanie.
		self::$metadata = null;
		$metadata = self::get_metadata();
		if ( is_wp_error( $metadata ) ) {
			return $metadata;
		}
		if ( $metadata['package'] !== $package || ! version_compare( $metadata['version'], ADINET_VERSION, '>' ) ) {
			return new WP_Error( 'adinet_update_stale', 'Wydanie zmieniło się. Sprawdź ponownie dostępność aktualizacji.' );
		}

		$download = download_url( $package, 60 );
		if ( is_wp_error( $download ) ) {
			return $download;
		}
		$hash = hash_file( 'sha256', $download );
		if ( false === $hash || ! hash_equals( $metadata['sha256'], $hash ) ) {
			wp_delete_file( $download );
			return new WP_Error( 'adinet_update_bad_hash', 'Pobrana paczka AdiNet Panel ma nieprawidłową sumę SHA-256.' );
		}
		return $download;
	}

	/**
	 * Zwraca WordPressowi informację o dostępnej wersji.
	 *
	 * @param array|false $update      Dotychczasowa odpowiedź dla źródła aktualizacji.
	 * @param array       $plugin_data Nagłówki wtyczki.
	 * @param string      $plugin_file Plik wtyczki względem katalogu plugins.
	 * @param string[]    $locales     Języki instalacji.
	 * @return array|false
	 */
	public static function check_update( $update, $plugin_data, $plugin_file, $locales ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
		if ( plugin_basename( ADINET_FILE ) !== $plugin_file ) {
			return $update;
		}

		$metadata = self::get_metadata();

		if ( is_wp_error( $metadata ) ) {
			return $update;
		}

		return array(
			'slug'         => 'adinet-panel',
			'version'      => $metadata['version'],
			'url'          => $metadata['homepage'],
			'package'      => $metadata['package'],
			'requires'     => $metadata['requires'],
			'tested'       => $metadata['tested'],
			'requires_php' => $metadata['requires_php'],
			'icons'        => $metadata['icons'],
		);
	}

	/**
	 * Uzupełnia standardowe okno „Szczegóły wersji”.
	 *
	 * @param false|object|array $result Dotychczasowy wynik API wtyczek.
	 * @param string             $action Rodzaj zapytania.
	 * @param object             $args   Argumenty zapytania.
	 * @return false|object|array
	 */
	public static function plugin_information( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! is_object( $args ) || empty( $args->slug ) || 'adinet-panel' !== $args->slug ) {
			return $result;
		}

		$metadata = self::get_metadata();

		if ( is_wp_error( $metadata ) ) {
			return $result;
		}

		return (object) array(
			'name'          => 'AdiNet Panel',
			'slug'          => 'adinet-panel',
			'version'       => $metadata['version'],
			'author'        => '<a href="https://adinet.pl">AdiNet Hubert Rosiński</a>',
			'homepage'      => $metadata['homepage'],
			'requires'      => $metadata['requires'],
			'tested'        => $metadata['tested'],
			'requires_php'  => $metadata['requires_php'],
			'last_updated'  => $metadata['last_updated'],
			'sections'      => $metadata['sections'],
			'icons'         => $metadata['icons'],
			'download_link' => $metadata['package'],
			'external'      => true,
		);
	}

	/**
	 * Pobiera i sprawdza dane bieżącego wydania.
	 *
	 * Brak odpowiedzi serwera nie wpływa na działanie zainstalowanej wtyczki.
	 * WordPress po prostu nie pokaże wtedy nowej aktualizacji.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	private static function get_metadata() {
		if ( null !== self::$metadata ) {
			return self::$metadata;
		}

		$channel      = AdiNet_Options::get_update_channel();
		$metadata_url = self::METADATA_URL . $channel . '.json';

		$response = wp_safe_remote_get(
			$metadata_url,
			array(
				'timeout'     => 5,
				'limit_response_size' => 65537,
				'redirection' => 2,
				'headers'     => array(
					'Accept' => 'application/json',
				),
				'user-agent'  => 'AdiNet Panel/' . ADINET_VERSION,
			)
		);

		if ( is_wp_error( $response ) ) {
			self::$metadata = $response;
			return self::$metadata;
		}

		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			self::$metadata = new WP_Error( 'adinet_update_http_error', 'Serwer aktualizacji AdiNet zwrócił nieprawidłową odpowiedź.' );
			return self::$metadata;
		}

		$body = wp_remote_retrieve_body( $response );

		if ( strlen( $body ) > 65536 ) {
			self::$metadata = new WP_Error( 'adinet_update_metadata_too_large', 'Plik informacji o aktualizacji jest zbyt duży.' );
			return self::$metadata;
		}

		$envelope  = json_decode( $body, true );
		$payload   = is_string( $envelope['payload'] ?? null ) ? base64_decode( $envelope['payload'], true ) : false;
		$signature = is_string( $envelope['signature'] ?? null ) ? base64_decode( $envelope['signature'], true ) : false;
		$key       = file_get_contents( ADINET_PATH . 'inc/adinet-release-public.pem' );
		if ( false === $payload || false === $signature || false === $key || ! function_exists( 'openssl_verify' )
			|| 1 !== openssl_verify( $payload, $signature, $key, OPENSSL_ALGO_SHA256 ) ) {
			self::$metadata = new WP_Error( 'adinet_update_bad_signature', 'Podpis manifestu AdiNet Panel jest nieprawidłowy lub nie można go sprawdzić.' );
			return self::$metadata;
		}

		$data = json_decode( $payload, true );

		if (
			! is_array( $data )
			|| $channel !== ( $data['channel'] ?? '' )
			|| 'adinet-panel' !== ( $data['slug'] ?? '' )
			|| ! is_string( $data['sha256'] ?? null )
			|| ! preg_match( '/^[a-f0-9]{64}$/D', $data['sha256'] )
			|| empty( $data['version'] )
			|| ! is_string( $data['version'] )
			|| empty( $data['package'] )
			|| ! is_string( $data['package'] )
		) {
			self::$metadata = new WP_Error( 'adinet_update_invalid_metadata', 'Plik informacji o aktualizacji ma nieprawidłowy format.' );
			return self::$metadata;
		}

		$version = sanitize_text_field( $data['version'] );
		$package = esc_url_raw( $data['package'], array( 'https' ) );

		if ( ! preg_match( '/^[0-9]+(?:\.[0-9]+){1,3}(?:[-+][0-9A-Za-z.-]+)?$/', $version ) || $package !== self::PACKAGE_URL . 'adinet-panel-' . $version . '.zip' ) {
			self::$metadata = new WP_Error( 'adinet_update_invalid_release', 'Dane wydania AdiNet Panel nie przeszły weryfikacji.' );
			return self::$metadata;
		}

		$sections = array();
		$icons    = array();

		if ( isset( $data['sections'] ) && is_array( $data['sections'] ) ) {
			foreach ( $data['sections'] as $section_name => $section_content ) {
				if ( is_string( $section_name ) && is_string( $section_content ) ) {
					$sections[ sanitize_key( $section_name ) ] = wp_kses_post( $section_content );
				}
			}
		}

		if ( isset( $data['icons'] ) && is_array( $data['icons'] ) ) {
			foreach ( $data['icons'] as $icon_size => $icon_url ) {
				if ( is_string( $icon_size ) && is_string( $icon_url ) && self::is_allowed_url( $icon_url ) ) {
					$icons[ sanitize_key( $icon_size ) ] = esc_url_raw( $icon_url );
				}
			}
		}

		self::$metadata = array(
			'version'      => $version,
			'sha256'       => $data['sha256'],
			'package'      => $package,
			'homepage'     => isset( $data['homepage'] ) && is_string( $data['homepage'] ) && self::is_allowed_url( $data['homepage'] ) ? esc_url_raw( $data['homepage'] ) : self::UPDATE_URI,
			'requires'     => isset( $data['requires'] ) && is_string( $data['requires'] ) ? sanitize_text_field( $data['requires'] ) : '6.0',
			'tested'       => isset( $data['tested'] ) && is_string( $data['tested'] ) ? sanitize_text_field( $data['tested'] ) : '',
			'requires_php' => isset( $data['requires_php'] ) && is_string( $data['requires_php'] ) ? sanitize_text_field( $data['requires_php'] ) : '7.4',
			'last_updated' => isset( $data['last_updated'] ) && is_string( $data['last_updated'] ) ? sanitize_text_field( $data['last_updated'] ) : '',
			'sections'     => $sections,
			'icons'        => $icons,
		);

		return self::$metadata;
	}

	/**
	 * Akceptuje wyłącznie zasoby HTTPS z docelowego hosta aktualizacji.
	 *
	 * @param string $url Sprawdzany adres.
	 * @return bool
	 */
	private static function is_allowed_url( $url ) {
		$url_parts = wp_parse_url( esc_url_raw( $url, array( 'https' ) ) );

		return is_array( $url_parts )
			&& isset( $url_parts['scheme'], $url_parts['host'], $url_parts['path'] )
			&& 'https' === strtolower( $url_parts['scheme'] )
			&& 'adinet.pl' === strtolower( $url_parts['host'] )
			&& 0 === strpos( $url_parts['path'], '/adinet-panel/' );
	}
}
