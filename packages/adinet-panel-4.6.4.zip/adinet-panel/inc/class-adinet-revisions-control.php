<?php
/**
 * Sterowanie liczbą i wiekiem rewizji treści.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Revisions_Control {
	/**
	 * Rejestruje filtry i akcje modułu.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'wp_revisions_to_keep', array( __CLASS__, 'filter_revisions_to_keep' ), 99, 2 );
		add_action( 'save_post', array( __CLASS__, 'delete_expired_revisions' ), 100, 3 );
	}

	/**
	 * Ustawia maksymalną liczbę rewizji dla każdego typu treści, który je obsługuje.
	 *
	 * @param int     $number Dotychczasowy limit.
	 * @param WP_Post $post   Zapisywana treść.
	 * @return int
	 */
	public static function filter_revisions_to_keep( $number, $post ) {
		if ( ! $post instanceof WP_Post || ! post_type_supports( $post->post_type, 'revisions' ) ) {
			return $number;
		}

		return AdiNet_Options::get_revision_limit();
	}

	/**
	 * Po zapisaniu treści usuwa jej rewizje starsze niż wybrany okres.
	 *
	 * @param int     $post_id Identyfikator zapisanej treści.
	 * @param WP_Post $post    Zapisana treść.
	 * @param bool    $update  Czy aktualizowano istniejącą treść.
	 * @return void
	 */
	public static function delete_expired_revisions( $post_id, $post, $update ) {
		unset( $update );

		if (
			! $post instanceof WP_Post
			|| 'revision' === $post->post_type
			|| wp_is_post_autosave( $post_id )
			|| wp_is_post_revision( $post_id )
			|| ! post_type_supports( $post->post_type, 'revisions' )
		) {
			return;
		}

		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( AdiNet_Options::get_revision_max_age() * DAY_IN_SECONDS ) );
		$expired_revisions = wp_get_post_revisions(
			$post_id,
			array(
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'date_query'     => array(
					array(
						'column'    => 'post_date_gmt',
						'before'    => $cutoff,
						'inclusive' => false,
					),
				),
			)
		);

		foreach ( $expired_revisions as $revision_id ) {
			if ( wp_is_post_autosave( $revision_id ) ) {
				continue;
			}

			wp_delete_post_revision( $revision_id );
		}
	}
}
