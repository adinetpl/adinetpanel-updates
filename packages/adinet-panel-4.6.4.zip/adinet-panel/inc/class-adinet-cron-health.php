<?php
/** Kontrola rzeczywistego wykonania WP-Cron; jeden nadpisywany rekord. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Cron_Health {
	const HOOK = 'adinet_cron_health_check';
	const LAST_RUN = 'adinet_cron_last_run';
	const SCHEDULE_ERROR = 'adinet_cron_schedule_error';

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		add_action( self::HOOK, array( __CLASS__, 'record_run' ) );
		add_action( 'init', array( __CLASS__, 'ensure_scheduled' ) );
	}

	public static function schedules( $schedules ) {
		$schedules['adinet_fifteen_minutes'] = array( 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'AdiNet: co 15 minut' );
		return $schedules;
	}

	public static function ensure_scheduled() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			$result = wp_schedule_event( time() + MINUTE_IN_SECONDS, 'adinet_fifteen_minutes', self::HOOK, array(), true );
			update_option( self::SCHEDULE_ERROR, is_wp_error( $result ) || ! $result ? 1 : 0, false );
		}
	}

	public static function record_run() {
		update_option( self::LAST_RUN, time(), false );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::HOOK );
		delete_option( self::LAST_RUN );
		delete_option( self::SCHEDULE_ERROR );
	}

	public static function get_state() {
		$last = absint( get_option( self::LAST_RUN, 0 ) );
		$next = wp_next_scheduled( self::HOOK );
		$status = 'neutral';
		$label = __( 'Oczekiwanie na pierwsze wykonanie', 'adinet-panel' );
		if ( ! $next || get_option( self::SCHEDULE_ERROR, 0 ) ) {
			$status = 'danger';
			$label = __( 'Nie udało się zaplanować kontroli', 'adinet-panel' );
		} elseif ( ( $last && time() - $last > 45 * MINUTE_IN_SECONDS ) || ( ! $last && $next < time() - 30 * MINUTE_IN_SECONDS ) ) {
			$status = 'warning';
			$label = __( 'Brak wykonania w oczekiwanym czasie', 'adinet-panel' );
		} elseif ( $last ) {
			$status = 'good';
			$label = __( 'Zadanie kontrolne działa', 'adinet-panel' );
		}
		return array( 'last' => $last, 'next' => $next, 'status' => $status, 'label' => $label );
	}
}
