<?php
/**
 * Obsługa daty ostatniego audytu technicznego.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Audit {
	/**
	 * Rejestruje akcje panelu.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_adinet_mark_audit', array( __CLASS__, 'mark_audit' ) );
		add_action( 'admin_post_adinet_clear_audit', array( __CLASS__, 'clear_audit' ) );
	}

	/**
	 * Zapisuje bieżącą datę i administratora wykonującego audyt.
	 *
	 * @return void
	 */
	public static function mark_audit() {
		self::authorize_action( 'adinet_mark_audit' );

		update_option(
			AdiNet_Options::LAST_AUDIT,
			array(
				'date'    => wp_date( 'Y-m-d' ),
				'user_id' => get_current_user_id(),
			),
			false
		);

		self::redirect( 'audit-marked' );
	}

	/**
	 * Usuwa zapisaną datę audytu.
	 *
	 * @return void
	 */
	public static function clear_audit() {
		self::authorize_action( 'adinet_clear_audit' );
		delete_option( AdiNet_Options::LAST_AUDIT );
		self::redirect( 'audit-cleared' );
	}

	/**
	 * Sprawdza uprawnienia i nonce akcji.
	 *
	 * @param string $nonce_action Nazwa akcji nonce.
	 * @return void
	 */
	private static function authorize_action( $nonce_action ) {
		if ( ! AdiNet_Admin::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do zmiany daty audytu.', 'adinet-panel' ) );
		}

		check_admin_referer( $nonce_action );
	}

	/**
	 * Wraca do panelu AdiNet z kodem komunikatu.
	 *
	 * @param string $notice Kod komunikatu.
	 * @return void
	 */
	private static function redirect( $notice ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'          => AdiNet_Admin::PAGE_SLUG,
					'adinet-notice' => $notice,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Zwraca bezpieczne dane ostatniego audytu.
	 *
	 * Starsze dane z polem timestamp są odczytywane dla zgodności z wersją 2.2.
	 *
	 * @return array{date:string,user_id:int,user_name:string,formatted:string}
	 */
	public static function get_last_audit() {
		$stored  = get_option( AdiNet_Options::LAST_AUDIT, array() );
		$date    = is_array( $stored ) && isset( $stored['date'] ) ? sanitize_text_field( (string) $stored['date'] ) : '';
		$user_id = is_array( $stored ) && isset( $stored['user_id'] ) ? absint( $stored['user_id'] ) : 0;
		$user    = $user_id > 0 ? get_userdata( $user_id ) : false;

		if ( '' === $date && is_array( $stored ) && ! empty( $stored['timestamp'] ) ) {
			$date = wp_date( 'Y-m-d', absint( $stored['timestamp'] ), wp_timezone() );
		}

		$parsed = '' !== $date
			? DateTimeImmutable::createFromFormat( '!Y-m-d', $date, wp_timezone() )
			: false;

		if ( false === $parsed || $parsed->format( 'Y-m-d' ) !== $date ) {
			$date   = '';
			$parsed = false;
		}

		return array(
			'date'      => $date,
			'user_id'   => $user_id,
			'user_name' => $user ? $user->display_name : '',
			'formatted' => false !== $parsed
				? wp_date( get_option( 'date_format' ), $parsed->getTimestamp(), wp_timezone() )
				: '',
		);
	}

	/**
	 * Buduje zabezpieczony URL akcji audytu.
	 *
	 * @param string $action mark albo clear.
	 * @return string
	 */
	public static function get_action_url( $action ) {
		$is_clear     = 'clear' === $action;
		$admin_action = $is_clear ? 'adinet_clear_audit' : 'adinet_mark_audit';

		return wp_nonce_url(
			add_query_arg( 'action', $admin_action, admin_url( 'admin-post.php' ) ),
			$admin_action
		);
	}
}
