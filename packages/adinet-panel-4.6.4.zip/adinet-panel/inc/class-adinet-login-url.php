<?php
/**
 * Opcjonalny własny adres strony logowania WordPressa.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Login_URL {
	/**
	 * Czy bieżące żądanie dotyczy ukrytego standardowego adresu logowania.
	 *
	 * @var bool
	 */
	private static $blocked_login_request = false;

	/**
	 * Czy bieżące żądanie dotyczy własnego adresu logowania.
	 *
	 * @var bool
	 */
	private static $custom_login_request = false;

	/**
	 * Zapobiega ujawnieniu własnego adresu przez odnośniki w szablonie 404.
	 *
	 * @var bool
	 */
	private static $rendering_404 = false;

	/**
	 * Rejestruje mechanizm tylko po świadomym włączeniu opcji.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! AdiNet_Options::is_login_url_enabled() ) {
			return;
		}

		add_action( 'plugins_loaded', array( __CLASS__, 'inspect_request' ), 9999 );
		add_action( 'wp_loaded', array( __CLASS__, 'handle_request' ) );
		add_filter( 'site_url', array( __CLASS__, 'filter_site_url' ), 10, 4 );
		add_filter( 'network_site_url', array( __CLASS__, 'filter_network_site_url' ), 10, 3 );
		add_filter( 'wp_redirect', array( __CLASS__, 'filter_redirect' ), 10, 2 );
	}

	/**
	 * Rozpoznaje standardowy i własny adres zanim WordPress sparsuje zapytanie.
	 *
	 * @return void
	 */
	public static function inspect_request() {
		global $pagenow;

		$request_uri  = isset( $_SERVER['REQUEST_URI'] ) ? rawurldecode( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		$request_path = (string) wp_parse_url( $request_uri, PHP_URL_PATH );
		$request_path = '/' . ltrim( $request_path, '/' );
		$site_base     = untrailingslashit( (string) get_option( 'siteurl', '' ) );
		$login_path    = (string) wp_parse_url( $site_base . '/wp-login.php', PHP_URL_PATH );
		$register_path = (string) wp_parse_url( $site_base . '/wp-register.php', PHP_URL_PATH );

		if ( self::is_post_password_request() ) {
			return;
		}

		if ( self::paths_match( $request_path, $login_path ) || self::paths_match( $request_path, $register_path ) ) {
			self::$blocked_login_request = true;
			self::hide_current_request( $pagenow );

			return;
		}

		if ( self::is_custom_login_request( $request_path ) ) {
			self::$custom_login_request = true;
			$_SERVER['SCRIPT_NAME']      = '/' . AdiNet_Options::get_login_slug();
			$pagenow                    = 'wp-login.php';
		}
	}

	/**
	 * Wyświetla 404 dla adresów domyślnych albo uruchamia wp-login.php pod nowym adresem.
	 *
	 * @return void
	 */
	public static function handle_request() {
		global $pagenow, $error, $interim_login, $action, $user_login;

		if ( self::$blocked_login_request ) {
			self::render_404();
		}

		if ( self::should_block_admin() ) {
			self::render_admin_404();
		}

		if ( ! self::$custom_login_request || 'wp-login.php' !== $pagenow ) {
			return;
		}

		if ( is_user_logged_in() && ! isset( $_REQUEST['action'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			wp_safe_redirect( admin_url() );
			exit;
		}

		require_once ABSPATH . 'wp-login.php';
		exit;
	}

	/**
	 * Zmienia adresy wp-login.php generowane przez site_url().
	 *
	 * @param string   $url     Wygenerowany URL.
	 * @param string   $path    Ścieżka przekazana do site_url().
	 * @param string   $scheme  Schemat URL.
	 * @param int|null $blog_id Identyfikator witryny.
	 * @return string
	 */
	public static function filter_site_url( $url, $path, $scheme, $blog_id ) {
		unset( $path, $blog_id );

		return self::replace_login_url( $url, $scheme );
	}

	/**
	 * Zmienia adresy wp-login.php generowane przez network_site_url().
	 *
	 * @param string $url    Wygenerowany URL.
	 * @param string $path   Ścieżka przekazana do network_site_url().
	 * @param string $scheme Schemat URL.
	 * @return string
	 */
	public static function filter_network_site_url( $url, $path, $scheme ) {
		unset( $path );

		return self::replace_login_url( $url, $scheme );
	}

	/**
	 * Poprawia przekierowania wtyczek, które podały standardowy adres bez użycia API.
	 *
	 * @param string $location Adres przekierowania.
	 * @param int    $status   Kod odpowiedzi.
	 * @return string
	 */
	public static function filter_redirect( $location, $status ) {
		unset( $status );

		return self::replace_login_url( $location );
	}

	/**
	 * Zwraca pełny skonfigurowany adres logowania do użycia w panelu i filtrach.
	 *
	 * @param string|null $scheme Opcjonalny schemat WordPressa.
	 * @return string
	 */
	public static function get_login_url( $scheme = null ) {
		$slug = AdiNet_Options::get_login_slug();

		if ( get_option( 'permalink_structure' ) ) {
			return home_url( user_trailingslashit( $slug, 'single' ), $scheme );
		}

		return add_query_arg( $slug, '', home_url( '/', $scheme ) );
	}

	/**
	 * Podmienia wyłącznie lokalne odwołania do wp-login.php, zachowując parametry.
	 *
	 * @param string      $url    Sprawdzany URL.
	 * @param string|null $scheme Opcjonalny schemat WordPressa.
	 * @return string
	 */
	private static function replace_login_url( $url, $scheme = null ) {
		if ( ! is_string( $url ) || false === stripos( $url, 'wp-login.php' ) || self::is_post_password_url( $url ) ) {
			return $url;
		}

		if ( self::$rendering_404 ) {
			return '#';
		}

		$parts     = wp_parse_url( $url );
		$site_host = (string) wp_parse_url( site_url( '/' ), PHP_URL_HOST );

		if ( false === $parts || ( ! empty( $parts['host'] ) && 0 !== strcasecmp( (string) $parts['host'], $site_host ) ) ) {
			return $url;
		}

		$path = isset( $parts['path'] ) ? rawurldecode( (string) $parts['path'] ) : '';

		if ( ! preg_match( '#(?:^|/)wp-login\.php$#i', untrailingslashit( $path ) ) ) {
			return $url;
		}

		$new_url = self::get_login_url( $scheme );

		if ( ! empty( $parts['query'] ) ) {
			parse_str( (string) $parts['query'], $query_args );
			$new_url = add_query_arg( $query_args, $new_url );
		}

		if ( ! empty( $parts['fragment'] ) ) {
			$new_url .= '#' . rawurlencode( (string) $parts['fragment'] );
		}

		return $new_url;
	}

	/**
	 * Czy bieżący request wskazuje skonfigurowany adres logowania.
	 *
	 * @param string $request_path Ścieżka bieżącego żądania.
	 * @return bool
	 */
	private static function is_custom_login_request( $request_path ) {
		$custom_path = (string) wp_parse_url( home_url( '/' . AdiNet_Options::get_login_slug() . '/' ), PHP_URL_PATH );

		if ( self::paths_match( $request_path, $custom_path ) ) {
			return true;
		}

		if ( get_option( 'permalink_structure' ) ) {
			return false;
		}

		$slug = AdiNet_Options::get_login_slug();

		return isset( $_GET[ $slug ] ) && '' === (string) wp_unslash( $_GET[ $slug ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Porównuje ścieżki niezależnie od końcowego ukośnika.
	 *
	 * @param string $first  Pierwsza ścieżka.
	 * @param string $second Druga ścieżka.
	 * @return bool
	 */
	private static function paths_match( $first, $second ) {
		return '' !== $second && untrailingslashit( $first ) === untrailingslashit( $second );
	}

	/**
	 * Nie blokuje obsługi haseł chroniących pojedyncze wpisy.
	 *
	 * @return bool
	 */
	private static function is_post_password_request() {
		return isset( $_GET['action'], $_POST['post_password'] )
			&& 'postpass' === (string) wp_unslash( $_GET['action'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Rozpoznaje adres formularza hasła chroniącego wpis.
	 *
	 * @param string $url Sprawdzany URL.
	 * @return bool
	 */
	private static function is_post_password_url( $url ) {
		return false !== strpos( $url, 'wp-login.php?action=postpass' );
	}

	/**
	 * Czy niezalogowany użytkownik próbuje otworzyć właściwy ekran wp-admin.
	 *
	 * @return bool
	 */
	private static function should_block_admin() {
		global $pagenow;

		if ( ! is_admin() || is_user_logged_in() || self::is_technical_request() ) {
			return false;
		}

		return ! in_array( $pagenow, array( 'admin-ajax.php', 'admin-post.php', 'async-upload.php' ), true );
	}

	/**
	 * Pozostawia dostępne techniczne żądania WordPressa i WP-CLI.
	 *
	 * @return bool
	 */
	private static function is_technical_request() {
		return ( defined( 'WP_CLI' ) && WP_CLI )
			|| ( defined( 'DOING_AJAX' ) && DOING_AJAX )
			|| ( defined( 'DOING_CRON' ) && DOING_CRON );
	}

	/**
	 * Ukrywa oryginalny adres przed parserem zapytań WordPressa.
	 *
	 * @param string $pagenow Nazwa aktualnego pliku przekazana przez referencję.
	 * @return void
	 */
	private static function hide_current_request( &$pagenow ) {
		$_SERVER['REQUEST_URI'] = '/' . str_repeat( '-/', 10 );
		$pagenow               = 'index.php';
	}

	/**
	 * Zwraca prawdziwą odpowiedź 404 z szablonu aktywnego motywu.
	 *
	 * @return void
	 */
	private static function render_404() {
		global $pagenow;

		self::$rendering_404 = true;
		self::hide_current_request( $pagenow );

		if ( ! defined( 'WP_USE_THEMES' ) ) {
			define( 'WP_USE_THEMES', true );
		}

		wp();
		status_header( 404 );
		nocache_headers();
		require ABSPATH . WPINC . '/template-loader.php';
		exit;
	}

	/**
	 * Zwraca bezpieczne 404 dla wp-admin bez uruchamiania motywu na niegotowym zapleczu.
	 *
	 * Podczas akcji wp_loaded plik wp-admin/admin.php nie zdążył jeszcze załadować
	 * wszystkich funkcji ekranu administracyjnego. Uruchomienie template-loader.php
	 * w tym miejscu może więc wywołać błąd krytyczny w motywie korzystającym np.
	 * z get_current_screen().
	 *
	 * @return void
	 */
	private static function render_admin_404() {
		self::$rendering_404 = true;

		wp_die(
			esc_html__( 'Nie znaleziono strony.', 'adinet-panel' ),
			esc_html__( 'Błąd 404', 'adinet-panel' ),
			array(
				'response'  => 404,
				'back_link' => false,
			)
		);
	}
}
