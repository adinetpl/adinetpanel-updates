<?php
/**
 * Czasowy monitoring błędów 404 grupowanych według adresu IP.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_404_Monitor {
	const PAGE_SLUG      = 'adinet-404-monitor';
	const DURATION       = 7 * DAY_IN_SECONDS;
	const MAX_UNIQUE_IPS = 5000;

	/**
	 * Hook podstrony administracyjnej.
	 *
	 * @var string
	 */
	private static $page_hook = '';

	/**
	 * Uruchamia monitoring i akcje administracyjne.
	 *
	 * @return void
	 */
	public static function init() {
		self::expire_if_needed();

		add_action( 'admin_menu', array( __CLASS__, 'add_submenu_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_adinet_start_404_monitor', array( __CLASS__, 'start_monitoring' ) );
		add_action( 'admin_post_adinet_clear_404_monitor', array( __CLASS__, 'clear_data' ) );
		add_action( 'admin_post_adinet_remove_404_ip', array( __CLASS__, 'remove_ip' ) );

		if ( self::is_active() ) {
			add_action( 'template_redirect', array( __CLASS__, 'maybe_log_404' ), 999 );
		}
	}

	/**
	 * Tworzy lub aktualizuje małą tabelę statystyk IP.
	 *
	 * @return void
	 */
	public static function install_table() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table_name      = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();
		$sql             = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			ip varchar(45) NOT NULL,
			hits bigint(20) unsigned NOT NULL DEFAULT 1,
			first_seen datetime NOT NULL,
			last_seen datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY ip (ip),
			KEY hits (hits),
			KEY last_seen (last_seen)
		) {$charset_collate};";

		dbDelta( $sql );
	}

	/**
	 * Obsługuje włączenie monitoringu z ustawień lub podstrony raportu.
	 *
	 * Ponowne zapisanie aktywnego ustawienia nie przedłuża okresu. Nowe siedem
	 * dni rozpoczyna się dopiero po ponownym włączeniu zakończonego monitoringu.
	 *
	 * @param mixed $value Wartość pola wyboru.
	 * @return int
	 */
	public static function sanitize_enabled( $value ) {
		$should_enable = empty( $value ) ? 0 : 1;

		$was_active = self::is_active();

		if ( $should_enable && ! $was_active ) {
			self::install_table();
			global $wpdb;
			if ( false === $wpdb->query( 'DELETE FROM ' . self::get_table_name() ) ) {
				add_settings_error( AdiNet_Options::MONITOR_404_ENABLED, 'adinet_404_restart_failed', __( 'Nie uruchomiono monitoringu: nie udało się usunąć poprzednich wyników.', 'adinet-panel' ) );
				return 0;
			}

			$now = time();
			update_option( AdiNet_Options::MONITOR_404_STARTED_AT, $now, false );
			update_option( AdiNet_Options::MONITOR_404_ENDS_AT, $now + self::DURATION, false );
		}

		if ( ! $should_enable && $was_active ) {
			update_option( AdiNet_Options::MONITOR_404_ENDS_AT, time(), false );
		}

		return $should_enable;
	}

	/**
	 * Czy monitoring aktualnie może zapisywać dane.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$enabled = 1 === absint( get_option( AdiNet_Options::MONITOR_404_ENABLED, 0 ) );

		if ( ! $enabled ) {
			return false;
		}

		$ends_at = absint( get_option( AdiNet_Options::MONITOR_404_ENDS_AT, 0 ) );

		return $ends_at > time();
	}

	/**
	 * Zwraca bieżący stan wraz z okresem zbierania danych.
	 *
	 * @return array{active:bool,started_at:int,ends_at:int,has_period:bool,status:string}
	 */
	public static function get_state() {
		self::expire_if_needed();

		$started_at = absint( get_option( AdiNet_Options::MONITOR_404_STARTED_AT, 0 ) );
		$ends_at    = absint( get_option( AdiNet_Options::MONITOR_404_ENDS_AT, 0 ) );

		$active     = self::is_active();
		$has_period = $started_at > 0 && $ends_at >= $started_at;

		return array(
			'active'     => $active,
			'started_at' => $started_at,
			'ends_at'    => $ends_at,
			'has_period' => $has_period,
			'status'     => $active ? 'active' : ( $has_period ? 'finished' : 'inactive' ),
		);
	}

	/**
	 * Czytelna etykieta bieżącego stanu monitoringu.
	 *
	 * @param array $state Stan zwrócony przez get_state().
	 * @param bool  $long  Czy zwrócić pełną etykietę dla nagłówka podstrony.
	 * @return string
	 */
	public static function get_status_label( $state, $long = false ) {
		if ( 'active' === $state['status'] ) {
			return $long ? __( 'Monitoring aktywny', 'adinet-panel' ) : __( 'Aktywny', 'adinet-panel' );
		}

		if ( 'finished' === $state['status'] ) {
			return $long ? __( 'Monitoring zakończony', 'adinet-panel' ) : __( 'Zakończony', 'adinet-panel' );
		}

		return $long ? __( 'Monitoring nieuruchomiony', 'adinet-panel' ) : __( 'Nieuruchomiony', 'adinet-panel' );
	}

	/**
	 * Formatuje zapisany znacznik czasu w strefie witryny.
	 *
	 * @param int $timestamp Znacznik czasu UTC.
	 * @return string
	 */
	public static function format_timestamp( $timestamp ) {
		$timestamp = absint( $timestamp );

		return $timestamp > 0
			? wp_date( 'd.m.Y H:i', $timestamp, wp_timezone() )
			: '';
	}

	/**
	 * Adres podstrony wyników.
	 *
	 * @return string
	 */
	public static function get_page_url() {
		return admin_url( 'admin.php?page=' . self::PAGE_SLUG );
	}

	/**
	 * Rejestruje podstronę w menu AdiNet.
	 *
	 * @return void
	 */
	public static function add_submenu_page() {
		self::$page_hook = add_submenu_page(
			AdiNet_Admin::PAGE_SLUG,
			esc_html__( 'Monitoring 404 — AdiNet', 'adinet-panel' ),
			esc_html__( 'Monitoring 404', 'adinet-panel' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Ładuje wspólne zasoby panelu wyłącznie na podstronie monitoringu.
	 *
	 * @param string $hook_suffix Identyfikator ekranu administracyjnego.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( self::$page_hook !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'adinet-admin',
			ADINET_URL . 'assets/css/admin.css',
			array(),
			ADINET_VERSION
		);

		wp_enqueue_script(
			'adinet-admin',
			ADINET_URL . 'assets/js/admin.js',
			array(),
			ADINET_VERSION,
			true
		);
	}

	/**
	 * Zapisuje pojedynczy wynik 404 jako atomowe zwiększenie licznika IP.
	 *
	 * @return void
	 */
	public static function maybe_log_404() {
		if ( ! is_404() || is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}

		$ip = self::get_client_ip();

		if ( '' === $ip ) {
			return;
		}

		global $wpdb;

		$table_name = self::get_table_name();
		$now        = current_time( 'mysql', true );
		$updated    = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table_name} SET hits = hits + 1, last_seen = %s WHERE ip = %s",
				$now,
				$ip
			)
		);

		if ( 0 !== $updated ) {
			return;
		}

		$unique_count = absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" ) );

		if ( $unique_count >= self::MAX_UNIQUE_IPS ) {
			return;
		}

		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$table_name} (ip, hits, first_seen, last_seen) VALUES (%s, 1, %s, %s) ON DUPLICATE KEY UPDATE hits = hits + 1, last_seen = %s",
				$ip,
				$now,
				$now,
				$now
			)
		);
	}

	/**
	 * Uruchamia nową sesję bezpośrednio z podstrony raportu.
	 *
	 * @return void
	 */
	public static function start_monitoring() {
		if ( ! AdiNet_Admin::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do uruchomienia monitoringu 404.', 'adinet-panel' ) );
		}

		check_admin_referer( 'adinet_start_404_monitor' );

		if ( self::is_active() ) {
			$notice = 'already-active';
		} else {
			// Zarejestrowany w admin_init sanitizer ustawia okres i czyści stare wyniki.
			update_option( AdiNet_Options::MONITOR_404_ENABLED, 1, true );
			$notice = self::is_active() ? 'started' : 'start-error';
		}

		wp_safe_redirect( add_query_arg( 'adinet-404-notice', $notice, self::get_page_url() ) );
		exit;
	}

	/**
	 * Usuwa wyłącznie dane z tabeli monitoringu po autoryzowanej akcji.
	 *
	 * @return void
	 */
	public static function clear_data() {
		if ( ! AdiNet_Admin::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do usunięcia danych monitoringu 404.', 'adinet-panel' ) );
		}

		check_admin_referer( 'adinet_clear_404_monitor' );

		global $wpdb;

		$result = $wpdb->query( 'DELETE FROM ' . self::get_table_name() );

		if ( false !== $result ) {
			if ( self::is_active() ) {
				update_option( AdiNet_Options::MONITOR_404_STARTED_AT, time(), false );
			} else {
				delete_option( AdiNet_Options::MONITOR_404_STARTED_AT );
				delete_option( AdiNet_Options::MONITOR_404_ENDS_AT );
			}
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'              => self::PAGE_SLUG,
					'adinet-404-notice' => false !== $result ? 'cleared' : 'error',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Usuwa z wyników pojedynczy adres po ręcznym zablokowaniu go poza wtyczką.
	 *
	 * @return void
	 */
	public static function remove_ip() {
		if ( ! AdiNet_Admin::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do usunięcia adresu z monitoringu 404.', 'adinet-panel' ) );
		}

		check_admin_referer( 'adinet_remove_404_ip' );

		$ip = isset( $_POST['ip'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['ip'] ) ) ) : '';

		if ( false === filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			$result = false;
		} else {
			global $wpdb;

			$result = $wpdb->query(
				$wpdb->prepare(
					'DELETE FROM ' . self::get_table_name() . ' WHERE ip = %s LIMIT 1',
					$ip
				)
			);
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'              => self::PAGE_SLUG,
					'adinet-404-notice' => false !== $result && $result > 0 ? 'ip-removed' : 'ip-error',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Renderuje stronę wyników monitoringu.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! AdiNet_Admin::can_view_panel() ) {
			return;
		}

		$state       = self::get_state();
		$summary     = self::get_summary();
		$top_ips     = self::get_top_ips();
		$can_clear   = $state['has_period'] || $summary['unique_ips'] > 0;
		$can_manage  = AdiNet_Admin::can_manage_panel();
		$notice_code = isset( $_GET['adinet-404-notice'] )
			? sanitize_key( wp_unslash( $_GET['adinet-404-notice'] ) )
			: '';
		?>
		<div class="wrap adinet-admin adinet-monitor-page">
			<header class="adinet-monitor-hero">
				<div>
					<p class="adinet-eyebrow"><?php esc_html_e( 'Bezpieczeństwo i diagnostyka', 'adinet-panel' ); ?></p>
					<h1><?php esc_html_e( 'Monitoring 404', 'adinet-panel' ); ?></h1>
					<p><?php esc_html_e( 'Zestawienie adresów IP najczęściej wywołujących błędy 404.', 'adinet-panel' ); ?></p>
				</div>
				<span class="adinet-status <?php echo $state['active'] ? 'is-active' : 'is-neutral'; ?>">
					<?php echo esc_html( self::get_status_label( $state, true ) ); ?>
				</span>
			</header>

			<?php if ( 'started' === $notice_code ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Monitoring 404 został uruchomiony na 7 dni.', 'adinet-panel' ); ?></p></div>
			<?php elseif ( 'already-active' === $notice_code ) : ?>
				<div class="notice notice-info is-dismissible"><p><?php esc_html_e( 'Monitoring 404 jest już aktywny. Zachowano wyniki i termin zakończenia.', 'adinet-panel' ); ?></p></div>
			<?php elseif ( 'start-error' === $notice_code ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Nie udało się uruchomić monitoringu 404. Spróbuj ponownie.', 'adinet-panel' ); ?></p></div>
			<?php elseif ( 'cleared' === $notice_code ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Dane monitoringu 404 zostały wyczyszczone.', 'adinet-panel' ); ?></p></div>
			<?php elseif ( 'error' === $notice_code ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Nie udało się wyczyścić danych monitoringu 404.', 'adinet-panel' ); ?></p></div>
			<?php elseif ( 'ip-removed' === $notice_code ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Adres IP oznaczony jako zablokowany został usunięty z wyników.', 'adinet-panel' ); ?></p></div>
			<?php elseif ( 'ip-error' === $notice_code ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Nie udało się usunąć adresu IP z wyników.', 'adinet-panel' ); ?></p></div>
			<?php endif; ?>

			<?php if ( ! $state['active'] && $can_manage ) : ?>
				<section class="adinet-monitor-cleanup">
					<div>
						<h2><?php esc_html_e( 'Rozpocznij zbieranie danych', 'adinet-panel' ); ?></h2>
						<p><?php esc_html_e( 'Monitoring będzie zbierał błędy 404 przez 7 dni. Nowe uruchomienie usuwa poprzednie wyniki monitoringu.', 'adinet-panel' ); ?></p>
					</div>
					<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"<?php if ( $can_clear ) : ?> data-confirm-form="<?php echo esc_attr__( 'Uruchomić monitoring na 7 dni i usunąć poprzednie wyniki 404?', 'adinet-panel' ); ?>"<?php endif; ?>>
						<input type="hidden" name="action" value="adinet_start_404_monitor">
						<?php wp_nonce_field( 'adinet_start_404_monitor' ); ?>
						<button type="submit" class="button button-primary"><?php esc_html_e( 'Uruchom monitoring na 7 dni', 'adinet-panel' ); ?></button>
					</form>
				</section>
			<?php endif; ?>

			<div class="adinet-monitor-summary">
				<section>
					<small><?php esc_html_e( 'Okres zbierania danych', 'adinet-panel' ); ?></small>
					<?php if ( $state['has_period'] ) : ?>
						<strong><?php echo esc_html( self::format_timestamp( $state['started_at'] ) ); ?></strong>
						<span><?php echo esc_html( sprintf( __( 'do %s', 'adinet-panel' ), self::format_timestamp( $state['ends_at'] ) ) ); ?></span>
					<?php else : ?>
						<strong><?php esc_html_e( 'Brak zapisanego okresu', 'adinet-panel' ); ?></strong>
						<span><?php echo $can_manage ? esc_html__( 'Uruchom monitoring przyciskiem powyżej.', 'adinet-panel' ) : esc_html__( 'Monitoring może uruchomić opiekun strony.', 'adinet-panel' ); ?></span>
					<?php endif; ?>
				</section>
				<section>
					<small><?php esc_html_e( 'Zapisane wywołania 404', 'adinet-panel' ); ?></small>
					<strong><?php echo esc_html( number_format_i18n( $summary['hits'] ) ); ?></strong>
					<span><?php echo esc_html( sprintf( __( 'Liczba unikalnych IP: %s', 'adinet-panel' ), number_format_i18n( $summary['unique_ips'] ) ) ); ?></span>
				</section>
				<section>
					<small><?php esc_html_e( 'Rzeczywiste zdarzenia w tabeli', 'adinet-panel' ); ?></small>
					<?php if ( '' !== $summary['first_seen'] ) : ?>
						<strong><?php echo esc_html( self::format_mysql_gmt( $summary['first_seen'] ) ); ?></strong>
						<span><?php echo esc_html( sprintf( __( 'ostatnie: %s', 'adinet-panel' ), self::format_mysql_gmt( $summary['last_seen'] ) ) ); ?></span>
					<?php else : ?>
						<strong><?php esc_html_e( 'Brak błędów 404', 'adinet-panel' ); ?></strong>
						<span><?php esc_html_e( 'Tabela jest obecnie pusta.', 'adinet-panel' ); ?></span>
					<?php endif; ?>
				</section>
			</div>

			<section class="adinet-monitor-results" aria-labelledby="adinet-monitor-results-title">
				<div class="adinet-monitor-results__header">
					<div>
						<p class="adinet-eyebrow"><?php esc_html_e( 'Najwięcej wywołań', 'adinet-panel' ); ?></p>
						<h2 id="adinet-monitor-results-title"><?php esc_html_e( '5 najaktywniejszych adresów IP', 'adinet-panel' ); ?></h2>
					</div>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . AdiNet_Admin::PAGE_SLUG ) ); ?>" class="button"><?php esc_html_e( 'Ustawienia monitoringu', 'adinet-panel' ); ?></a>
				</div>

				<?php if ( ! empty( $top_ips ) ) : ?>
					<div class="adinet-monitor-table-wrap">
						<table class="widefat striped adinet-monitor-table">
							<thead>
								<tr>
									<th scope="col"><?php esc_html_e( 'Adres IP', 'adinet-panel' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Liczba 404', 'adinet-panel' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Pierwsze wejście', 'adinet-panel' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Ostatnie wejście', 'adinet-panel' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Akcje', 'adinet-panel' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $top_ips as $row ) : ?>
									<tr>
										<td><code><?php echo esc_html( $row['ip'] ); ?></code></td>
										<td><strong><?php echo esc_html( number_format_i18n( $row['hits'] ) ); ?></strong></td>
										<td><?php echo esc_html( self::format_mysql_gmt( $row['first_seen'] ) ); ?></td>
										<td><?php echo esc_html( self::format_mysql_gmt( $row['last_seen'] ) ); ?></td>
										<td class="adinet-monitor-table__actions">
											<button
												type="button"
												class="button button-small adinet-copy-button"
												data-copy="<?php echo esc_attr( $row['ip'] ); ?>"
												data-default-label="<?php echo esc_attr__( 'Kopiuj', 'adinet-panel' ); ?>"
												data-copied-label="<?php echo esc_attr__( 'Skopiowano', 'adinet-panel' ); ?>"
												aria-describedby="adinet-copy-status"
											><?php esc_html_e( 'Kopiuj', 'adinet-panel' ); ?></button>
											<a href="<?php echo esc_url( 'https://www.abuseipdb.com/check/' . rawurlencode( $row['ip'] ) ); ?>" class="button button-small button-primary" target="_blank" rel="noopener noreferrer">AbuseIPDB</a>
											<a href="<?php echo esc_url( 'https://viz.greynoise.io/ip/' . rawurlencode( $row['ip'] ) ); ?>" class="button button-small" target="_blank" rel="noopener noreferrer">GreyNoise</a>
											<?php if ( $can_manage ) : ?>
												<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" data-confirm-form="<?php echo esc_attr__( 'Usunąć ten adres z wyników? Użyj tej opcji dopiero po ręcznym dodaniu blokady w Cloudflare.', 'adinet-panel' ); ?>">
													<input type="hidden" name="action" value="adinet_remove_404_ip">
													<input type="hidden" name="ip" value="<?php echo esc_attr( $row['ip'] ); ?>">
													<?php wp_nonce_field( 'adinet_remove_404_ip' ); ?>
													<button type="submit" class="button button-small adinet-monitor-blocked-button"><?php esc_html_e( 'Zablokowane', 'adinet-panel' ); ?></button>
												</form>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<p class="screen-reader-text" id="adinet-copy-status" aria-live="polite"></p>
				<?php else : ?>
					<div class="adinet-monitor-empty">
						<span class="dashicons dashicons-shield-alt" aria-hidden="true"></span>
						<p><?php esc_html_e( 'Nie zapisano jeszcze żadnych błędów 404.', 'adinet-panel' ); ?></p>
					</div>
				<?php endif; ?>

				<?php if ( $summary['unique_ips'] >= self::MAX_UNIQUE_IPS ) : ?>
					<p class="adinet-help adinet-help--warning"><?php echo esc_html( sprintf( __( 'Osiągnięto limit %s unikalnych adresów IP. Istniejące liczniki są nadal aktualizowane, ale nowe adresy nie są dopisywane.', 'adinet-panel' ), number_format_i18n( self::MAX_UNIQUE_IPS ) ) ); ?></p>
				<?php endif; ?>
			</section>

			<section class="adinet-monitor-cleanup">
				<div>
					<h2><?php esc_html_e( 'Czyszczenie danych', 'adinet-panel' ); ?></h2>
					<p><?php esc_html_e( 'Dane nie są usuwane automatycznie po zakończeniu monitoringu. Po analizie usuń je ręcznie.', 'adinet-panel' ); ?></p>
				</div>
				<?php if ( $can_manage ) : ?>
				<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" data-confirm-form="<?php echo esc_attr__( 'Czy na pewno chcesz bezpowrotnie usunąć wszystkie dane monitoringu 404?', 'adinet-panel' ); ?>">
					<input type="hidden" name="action" value="adinet_clear_404_monitor">
					<?php wp_nonce_field( 'adinet_clear_404_monitor' ); ?>
					<button type="submit" class="button button-link-delete" <?php disabled( false, $can_clear ); ?>><?php esc_html_e( 'Wyczyść dane', 'adinet-panel' ); ?></button>
				</form>
				<?php endif; ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Zwraca pięć adresów z największą liczbą błędów.
	 *
	 * @return array<int,array{ip:string,hits:int,first_seen:string,last_seen:string}>
	 */
	private static function get_top_ips() {
		global $wpdb;

		$rows = $wpdb->get_results(
			'SELECT ip, hits, first_seen, last_seen FROM ' . self::get_table_name() . ' ORDER BY hits DESC, last_seen DESC LIMIT 5',
			ARRAY_A
		);

		if ( ! is_array( $rows ) ) {
			return array();
		}

		foreach ( $rows as &$row ) {
			$row['ip']         = sanitize_text_field( (string) $row['ip'] );
			$row['hits']       = absint( $row['hits'] );
			$row['first_seen'] = sanitize_text_field( (string) $row['first_seen'] );
			$row['last_seen']  = sanitize_text_field( (string) $row['last_seen'] );
		}
		unset( $row );

		return $rows;
	}

	/**
	 * Zwraca podsumowanie całej tabeli.
	 *
	 * @return array{unique_ips:int,hits:int,first_seen:string,last_seen:string}
	 */
	private static function get_summary() {
		global $wpdb;

		$row = $wpdb->get_row(
			'SELECT COUNT(*) AS unique_ips, COALESCE(SUM(hits), 0) AS hits, MIN(first_seen) AS first_seen, MAX(last_seen) AS last_seen FROM ' . self::get_table_name(),
			ARRAY_A
		);

		return array(
			'unique_ips' => is_array( $row ) ? absint( $row['unique_ips'] ) : 0,
			'hits'       => is_array( $row ) ? absint( $row['hits'] ) : 0,
			'first_seen' => is_array( $row ) && ! empty( $row['first_seen'] ) ? sanitize_text_field( (string) $row['first_seen'] ) : '',
			'last_seen'  => is_array( $row ) && ! empty( $row['last_seen'] ) ? sanitize_text_field( (string) $row['last_seen'] ) : '',
		);
	}

	/**
	 * Formatuje datę UTC zapisaną w tabeli MySQL.
	 *
	 * @param string $date_gmt Data w formacie MySQL UTC.
	 * @return string
	 */
	private static function format_mysql_gmt( $date_gmt ) {
		if ( '' === $date_gmt ) {
			return '';
		}

		return get_date_from_gmt( $date_gmt, 'd.m.Y H:i' );
	}

	/**
	 * Odczytuje publiczny adres klienta przez wspólną walidację zaufanego proxy.
	 *
	 * @return string
	 */
	private static function get_client_ip() {
		$ip = AdiNet_Client_IP::normalize( apply_filters( 'adinet_404_client_ip', AdiNet_Client_IP::get_ip() ) );
		return false !== filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ? $ip : '';
	}

	/**
	 * Wyłącza zapis po upływie zaplanowanych siedmiu dni, bez kasowania danych.
	 *
	 * @return void
	 */
	private static function expire_if_needed() {
		$enabled = 1 === absint( get_option( AdiNet_Options::MONITOR_404_ENABLED, 0 ) );

		if ( ! $enabled ) {
			return;
		}

		$ends_at = absint( get_option( AdiNet_Options::MONITOR_404_ENDS_AT, 0 ) );

		if ( $ends_at > 0 && $ends_at <= time() ) {
			update_option( AdiNet_Options::MONITOR_404_ENABLED, 0, true );
		}
	}

	/**
	 * Zwraca nazwę tabeli ograniczoną do prefiksu bieżącej witryny.
	 *
	 * @return string
	 */
	private static function get_table_name() {
		global $wpdb;

		return $wpdb->prefix . 'adinet_404_ip_stats';
	}
}
