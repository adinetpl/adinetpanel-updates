<?php
/**
 * Bezpieczne zarządzanie wydzielonym blokiem reguł .htaccess.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Htaccess {
	const MARKER = 'AdiNet';

	const PROTECT_HTACCESS = 'protect_htaccess';
	const PROTECT_WP_CONFIG = 'protect_wp_config';
	const BLOCK_XMLRPC      = 'block_xmlrpc';
	const BLOCK_AUTHORS     = 'block_authors';
	const LITESPEED_LOGIN   = 'litespeed_login';
	const FORCE_HTTPS       = 'force_https';
	const HIDE_PHP_ERRORS   = 'hide_php_errors';

	/**
	 * Rejestruje akcję zapisu reguł.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_adinet_save_htaccess', array( __CLASS__, 'save_rules' ) );
	}

	/**
	 * Zwraca opisy reguł do panelu.
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function get_definitions() {
		return array(
			self::PROTECT_HTACCESS => array(
				'label'       => __( 'Blokuj dostęp do .htaccess', 'adinet-panel' ),
				'description' => __( 'Zwraca 403 przy próbie odczytania pliku .htaccess przez WWW.', 'adinet-panel' ),
				'level'       => 'recommended',
			),
			self::PROTECT_WP_CONFIG => array(
				'label'       => __( 'Blokuj dostęp do wp-config.php', 'adinet-panel' ),
				'description' => __( 'Dodaje dodatkową blokadę HTTP pliku z konfiguracją i danymi bazy.', 'adinet-panel' ),
				'level'       => 'recommended',
			),
			self::BLOCK_XMLRPC => array(
				'label'       => __( 'Blokuj xmlrpc.php', 'adinet-panel' ),
				'description' => __( 'Odcina XML-RPC. Może wyłączyć zdalne publikowanie, aplikację WordPress i część integracji, np. Jetpack.', 'adinet-panel' ),
				'level'       => 'warning',
			),
			self::BLOCK_AUTHORS => array(
				'label'       => __( 'Blokuj skanowanie autorów', 'adinet-panel' ),
				'description' => __( 'Zwraca 403 dla zapytań typu ?author=1 używanych do odgadywania loginów.', 'adinet-panel' ),
				'level'       => 'recommended',
			),
			self::LITESPEED_LOGIN => array(
				'label'       => __( 'Ogranicz próby logowania w LiteSpeed', 'adinet-panel' ),
				'description' => __( 'Ustawia WordPressProtect throttle, 5. Reguła działa tylko na serwerach LiteSpeed i może podlegać ustawieniom hostingu.', 'adinet-panel' ),
				'level'       => 'neutral',
			),
			self::FORCE_HTTPS => array(
				'label'       => __( 'Wymuszaj przekierowanie HTTPS', 'adinet-panel' ),
				'description' => __( 'Przekierowuje HTTP na kanoniczną domenę HTTPS i uwzględnia nagłówek X-Forwarded-Proto używany przez proxy.', 'adinet-panel' ),
				'level'       => 'warning',
			),
			self::HIDE_PHP_ERRORS => array(
				'label'       => __( 'Wyłącz wyświetlanie błędów PHP', 'adinet-panel' ),
				'description' => __( 'Dodaje php_flag display_errors Off oraz display_startup_errors Off. Działa tylko na zgodnych konfiguracjach Apache/LiteSpeed; przy PHP-FPM lub FastCGI może spowodować błąd 500.', 'adinet-panel' ),
				'level'       => 'warning',
			),
		);
	}

	/**
	 * Czyści tablicę zaznaczonych reguł.
	 *
	 * @param mixed $value Dane formularza.
	 * @return array<string,bool>
	 */
	public static function sanitize_selection( $value ) {
		$value       = is_array( $value ) ? $value : array();
		$definitions = self::get_definitions();
		$selected    = array();

		foreach ( array_keys( $definitions ) as $rule_id ) {
			$selected[ $rule_id ] = isset( $value[ $rule_id ] ) && '1' === (string) $value[ $rule_id ];
		}

		return $selected;
	}

	/**
	 * Zwraca zapisany wybór reguł z kompletem kluczy.
	 *
	 * @return array<string,bool>
	 */
	public static function get_selected_rules() {
		return self::sanitize_selection( get_option( AdiNet_Options::HTACCESS_RULES, array() ) );
	}

	/**
	 * Obsługuje osobny formularz modyfikacji .htaccess.
	 *
	 * @return void
	 */
	public static function save_rules() {
		if ( ! AdiNet_Admin::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do zmiany pliku .htaccess.', 'adinet-panel' ) );
		}

		check_admin_referer( 'adinet_save_htaccess' );

		$posted   = isset( $_POST['adinet_htaccess_rules'] ) ? wp_unslash( $_POST['adinet_htaccess_rules'] ) : array();
		$selected = self::sanitize_selection( $posted );
		$written  = self::write_managed_block( $selected );

		if ( $written ) {
			update_option( AdiNet_Options::HTACCESS_RULES, $selected, false );
			self::redirect( 'htaccess-saved' );
		}

		self::redirect( 'htaccess-error' );
	}

	/**
	 * Zapisuje wyłącznie blok pomiędzy markerami AdiNet.
	 *
	 * @param array<string,bool> $selected Wybrane reguły.
	 * @return bool
	 */
	private static function write_managed_block( $selected ) {
		$path = self::get_path();
		if ( '' === $path || is_link( $path ) || is_link( $path . '.adinet-backup' ) ) {
			return false;
		}
		$existed = file_exists( $path );
		$handle = @fopen( $path, 'c+b' );
		if ( ! $handle ) {
			return false;
		}
		if ( ! flock( $handle, LOCK_EX ) ) {
			fclose( $handle );
			return false;
		}
		$content = stream_get_contents( $handle );
		$new_content = is_string( $content ) ? self::compose_content( $content, $selected ) : false;
		$ok = false;
		if ( false !== $new_content && $content === $new_content ) {
			$ok = true;
		} elseif ( false !== $new_content && ( ! $existed || self::backup( $path, $content ) ) ) {
			$ok = self::write_handle( $handle, $new_content );
			if ( ! $ok ) {
				// Kopia na FTP pozostaje dostępna także przy nieudanym odtworzeniu.
				self::write_handle( $handle, $content );
			}
		}
		flock( $handle, LOCK_UN );
		fclose( $handle );
		return $ok;
	}

	/** Zapis w całości, skrócenie i odczyt kontrolny pod tą samą blokadą. */
	private static function write_handle( $handle, $content ) {
		rewind( $handle );
		$offset = 0;
		while ( $offset < strlen( $content ) ) {
			$written = fwrite( $handle, substr( $content, $offset ) );
			if ( false === $written || 0 === $written ) {
				return false;
			}
			$offset += $written;
		}
		if ( ! ftruncate( $handle, strlen( $content ) ) || ! fflush( $handle ) ) {
			return false;
		}
		rewind( $handle );
		return stream_get_contents( $handle ) === $content;
	}

	/** Jedna ostatnia kopia, identyczna bajt w bajt, dostępna przez FTP. */
	private static function backup( $path, $content ) {
		$temp = @tempnam( dirname( $path ), '.htaccess-adinet-' );
		if ( false === $temp ) {
			return false;
		}
		@chmod( $temp, 0600 );
		$ok = strlen( $content ) === @file_put_contents( $temp, $content, LOCK_EX )
			&& @file_get_contents( $temp ) === $content
			&& @rename( $temp, $path . '.adinet-backup' );
		if ( file_exists( $temp ) ) {
			@unlink( $temp );
		}
		return $ok;
	}

	/** Zwraca granice jednej kompletnej pary; false oznacza niejednoznaczny plik. */
	private static function locate_block( $content ) {
		preg_match_all( '/^# (BEGIN|END) AdiNet[	 ]*\r?$/m', $content, $matches, PREG_OFFSET_CAPTURE );
		// Także fragment markera w komentarzu wymaga ręcznego uporządkowania.
		if ( substr_count( $content, '# BEGIN AdiNet' ) + substr_count( $content, '# END AdiNet' ) !== count( $matches[0] ) ) {
			return false;
		}
		if ( 0 === count( $matches[0] ) ) {
			return array();
		}
		if ( 2 !== count( $matches[0] ) || 'BEGIN' !== $matches[1][0][0] || 'END' !== $matches[1][1][0] ) {
			return false;
		}
		$start = $matches[0][0][1];
		$end = $matches[0][1][1] + strlen( $matches[0][1][0] );
		$block = substr( $content, $start, $end - $start );
		if ( preg_match( '/^# (?:BEGIN|END) (?!AdiNet\b)/m', $block ) ) {
			return false;
		}
		// Nie przenosimy bloku z wnętrza innego zarządzanego bloku.
		$before = substr( $content, 0, $start );
		preg_match_all( '/^# (BEGIN|END) ([^\r\n]+)$/m', $before, $outer );
		$stack = array();
		foreach ( $outer[1] as $i => $kind ) {
			if ( 'BEGIN' === $kind ) { $stack[] = trim( $outer[2][$i] ); }
			elseif ( ! empty( $stack ) && end( $stack ) === trim( $outer[2][$i] ) ) { array_pop( $stack ); }
		}
		if ( ! empty( $stack ) ) {
			return false;
		}
		return array( 'start' => $start, 'end' => $end, 'block' => $block );
	}

	private static function compose_content( $content, $selected ) {
		$location = self::locate_block( $content );
		if ( false === $location ) {
			return false;
		}
		$newline = false !== strpos( $content, "\r\n" ) ? "\r\n" : "\n";
		$block = '# BEGIN AdiNet' . $newline . implode( $newline, self::build_rules( $selected ) ) . $newline . '# END AdiNet';
		$wp_offset = preg_match( '/^# BEGIN WordPress[	 ]*\r?$/m', $content, $wp, PREG_OFFSET_CAPTURE ) ? $wp[0][1] : false;
		if ( ! empty( $location ) && ( false === $wp_offset || $location['start'] < $wp_offset ) ) {
			return substr( $content, 0, $location['start'] ) . $block . substr( $content, $location['end'] );
		}
		if ( ! empty( $location ) ) {
			$content = substr( $content, 0, $location['start'] ) . substr( $content, $location['end'] );
		}
		$offset = 0 === strncmp( $content, "\xEF\xBB\xBF", 3 ) ? 3 : 0;
		if ( preg_match( '/^# BEGIN WordPress[	 ]*\r?$/m', $content, $wp, PREG_OFFSET_CAPTURE ) ) {
			$offset = $wp[0][1];
		}
		return substr( $content, 0, $offset ) . $block . $newline . substr( $content, $offset );
	}

	/**
	 * Generuje dyrektywy wyłącznie z zamkniętej listy reguł.
	 *
	 * @param array<string,bool> $selected Wybrane reguły.
	 * @return string[]
	 */
	private static function build_rules( $selected ) {
		$lines = array(
			'# AdiNet: ochrona kopii FTP (pozostaje także po odznaczeniu reguł)',
			'<FilesMatch "^\.htaccess(?:\.adinet-backup|-adinet-.*)$">',
			'<IfModule mod_authz_core.c>', 'Require all denied', '</IfModule>',
			'<IfModule !mod_authz_core.c>', 'Order allow,deny', 'Deny from all', '</IfModule>',
			'</FilesMatch>', '',
		);

		if ( ! empty( $selected[ self::PROTECT_HTACCESS ] ) ) {
			$lines = array_merge(
				$lines,
				array(
					'# AdiNet: ochrona pliku .htaccess',
					'<FilesMatch "^\.([Hh][Tt][Aa][Cc][Cc][Ee][Ss][Ss])$">',
					'<IfModule mod_authz_core.c>',
					'Require all denied',
					'</IfModule>',
					'<IfModule !mod_authz_core.c>',
					'Order allow,deny',
					'Deny from all',
					'</IfModule>',
					'</FilesMatch>',
					'',
				)
			);
		}

		if ( ! empty( $selected[ self::PROTECT_WP_CONFIG ] ) ) {
			$lines = array_merge(
				$lines,
				array(
					'# AdiNet: ochrona pliku wp-config.php',
					'<Files "wp-config.php">',
					'<IfModule mod_authz_core.c>',
					'Require all denied',
					'</IfModule>',
					'<IfModule !mod_authz_core.c>',
					'Order allow,deny',
					'Deny from all',
					'</IfModule>',
					'</Files>',
					'',
				)
			);
		}

		if ( ! empty( $selected[ self::BLOCK_XMLRPC ] ) ) {
			$lines = array_merge(
				$lines,
				array(
					'# AdiNet: blokada XML-RPC',
					'<Files "xmlrpc.php">',
					'<IfModule mod_authz_core.c>',
					'Require all denied',
					'</IfModule>',
					'<IfModule !mod_authz_core.c>',
					'Order deny,allow',
					'Deny from all',
					'</IfModule>',
					'</Files>',
					'',
				)
			);
		}

		if ( ! empty( $selected[ self::BLOCK_AUTHORS ] ) ) {
			$lines = array_merge(
				$lines,
				array(
					'# AdiNet: blokada skanowania autorow WordPressa',
					'<IfModule mod_rewrite.c>',
					'RewriteEngine On',
					'RewriteCond %{QUERY_STRING} (^|&)author=[0-9]+(&|$) [NC]',
					'RewriteRule ^ - [F,L]',
					'</IfModule>',
					'',
				)
			);
		}

		if ( ! empty( $selected[ self::LITESPEED_LOGIN ] ) ) {
			$lines = array_merge(
				$lines,
				array(
					'# AdiNet: ograniczenie prob logowania LiteSpeed',
					'<IfModule Litespeed>',
					'WordPressProtect throttle, 5',
					'</IfModule>',
					'',
				)
			);
		}

		if ( ! empty( $selected[ self::FORCE_HTTPS ] ) ) {
			$lines = array_merge(
				$lines,
				array(
					'# AdiNet: kanoniczne przekierowanie HTTPS',
					'<IfModule mod_rewrite.c>',
					'RewriteEngine On',
					'RewriteCond %{HTTPS} !=on',
					'RewriteCond %{HTTP:X-Forwarded-Proto} !https [NC]',
					'RewriteRule ^ https://' . self::get_canonical_host() . '%{REQUEST_URI} [L,R=301,NE]',
					'</IfModule>',
					'',
				)
			);
		}

		if ( ! empty( $selected[ self::HIDE_PHP_ERRORS ] ) ) {
			$lines = array_merge(
				$lines,
				array(
					'# Wyświetlanie błędów PHP',
					'php_flag display_errors Off',
					'php_flag display_startup_errors Off',
					'',
				)
			);
		}

		while ( ! empty( $lines ) && '' === end( $lines ) ) {
			array_pop( $lines );
		}

		return $lines;
	}

	/**
	 * Zwraca host z konfiguracji WordPressa do reguły HTTPS.
	 *
	 * @return string
	 */
	private static function get_canonical_host() {
		$host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$port = absint( wp_parse_url( home_url( '/' ), PHP_URL_PORT ) );

		if ( '' === $host || ! preg_match( '/^[a-z0-9.-]+$/i', $host ) ) {
			return '%{HTTP_HOST}';
		}

		if ( $port > 0 && 443 !== $port ) {
			$host .= ':' . $port;
		}

		return $host;
	}

	/**
	 * Zwraca ścieżkę głównego pliku .htaccess.
	 *
	 * @return string
	 */
	public static function get_path() {
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$home_path = get_home_path();

		return is_string( $home_path ) && '' !== $home_path
			? trailingslashit( $home_path ) . '.htaccess'
			: '';
	}

	/**
	 * Zwraca stan pliku i środowiska serwera.
	 *
	 * @return array<string,mixed>
	 */
	public static function get_status() {
		$path       = self::get_path();
		$exists     = '' !== $path && file_exists( $path );
		$writable   = '' !== $path && ( $exists ? is_writable( $path ) : is_writable( dirname( $path ) ) );
		$content    = $exists && is_readable( $path ) ? @file_get_contents( $path ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$software   = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '';
		$is_apache  = false !== stripos( $software, 'apache' );
		$is_litespeed = false !== stripos( $software, 'litespeed' );

		$block = is_string( $content ) ? self::locate_block( $content ) : false;
		$expected = implode( "\n", self::build_rules( self::get_selected_rules() ) );
		$actual = ! empty( $block ) ? preg_replace( '/^# (?:BEGIN|END) AdiNet[	 ]*\r?$/m', '', $block['block'] ) : '';
		$matches = is_string( $actual ) && trim( str_replace( "\r\n", "\n", $actual ) ) === trim( $expected );
		$ordered = empty( $block ) || ! preg_match( '/^# BEGIN WordPress[	 ]*\r?$/m', substr( (string) $content, 0, $block['start'] ) );
		return array(
			'block_valid' => false !== $block,
			'rules_match' => $matches && $ordered,
			'backup_path' => $path . '.adinet-backup',
			'backup_exists' => file_exists( $path . '.adinet-backup' ),
			'path'          => $path,
			'exists'        => $exists,
			'writable'      => $writable,
			'marker_exists' => is_string( $content ) && false !== strpos( $content, '# BEGIN ' . self::MARKER ),
			'server'        => $software,
			'compatible'    => $is_apache || $is_litespeed,
			'is_litespeed'  => $is_litespeed,
		);
	}

	/**
	 * Wraca do panelu z wynikiem zapisu.
	 *
	 * @param string $notice Kod komunikatu.
	 * @return void
	 */
	private static function redirect( $notice ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'          => AdiNet_Admin::PAGE_SLUG,
					'adinet-notice' => $notice,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}
