<?php
/**
 * Powitalny panel AdiNet na kokpicie WordPressa.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Dashboard {
	/**
	 * Rejestruje panel dla użytkowników kokpitu.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'render_wide_panel' ) );
	}

	/**
	 * Ładuje style wyłącznie na głównym kokpicie.
	 *
	 * @param string $hook_suffix Identyfikator ekranu.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'index.php' === $hook_suffix ) {
			wp_enqueue_style( 'adinet-dashboard', ADINET_URL . 'assets/css/dashboard.css', array(), ADINET_VERSION );
			wp_enqueue_script( 'adinet-dashboard', ADINET_URL . 'assets/js/dashboard.js', array(), ADINET_VERSION, true );
		}
	}

	/**
	 * Pokazuje panel powitalny nad kolumnami kokpitu.
	 *
	 * @return void
	 */
	public static function render_wide_panel() {
		$screen = get_current_screen();
		if ( ! $screen || 'dashboard' !== $screen->id ) {
			return;
		}
		?>
		<section id="adinet_welcome_wide" class="adinet-welcome-wide" aria-labelledby="adinet-welcome-wide-title">
			<div class="adinet-welcome-wide__header">
				<h2 id="adinet-welcome-wide-title"><?php esc_html_e( 'Twoja strona pod opieką AdiNet', 'adinet-panel' ); ?></h2>
			</div>
			<?php self::render_content(); ?>
		</section>
		<?php
	}

	/**
	 * Wyświetla treść panelu powitalnego.
	 *
	 * @return void
	 */
	private static function render_content() {
		$user     = wp_get_current_user();
		$name     = $user && ! empty( $user->first_name ) ? $user->first_name : ( $user && ! empty( $user->display_name ) ? $user->display_name : '' );
		$billing  = AdiNet_Billing::get_dashboard_billing();
		$estimate = $billing['estimate'];
		$due      = $billing['summary'][ AdiNet_Billing::STATUS_INVOICED ];
		$pending  = $billing['summary'][ AdiNet_Billing::STATUS_PENDING ];
		$settled  = $billing['summary'][ AdiNet_Billing::STATUS_SETTLED ];
		$invoices = array();
		foreach ( $billing['due_items'] as $item ) {
			if ( '' !== $item['invoice_number'] ) {
				$invoices[] = $item['invoice_number'];
			}
		}
		$invoices = array_values( array_unique( $invoices ) );
		?>
		<div class="adinet-welcome">
			<div class="adinet-welcome__hero">
				<span class="adinet-welcome__eyebrow"><?php esc_html_e( 'Wsparcie Twojej strony', 'adinet-panel' ); ?></span>
				<h3><?php echo '' !== $name ? esc_html( sprintf( __( 'Cześć, %s!', 'adinet-panel' ), $name ) ) : esc_html__( 'Cześć!', 'adinet-panel' ); ?></h3>
				<p><?php esc_html_e( 'Twoją stroną opiekuje się Hubert Rosiński z AdiNet. Tutaj znajdziesz kontakt, szybkie wskazówki i termin rozliczenia.', 'adinet-panel' ); ?></p>
			</div>
			<div class="adinet-welcome__body">
				<section class="adinet-welcome__contact" aria-labelledby="adinet-welcome-contact-title">
					<div class="adinet-welcome__section-heading">
						<span class="dashicons dashicons-sos" aria-hidden="true"></span>
						<div><h4 id="adinet-welcome-contact-title"><?php esc_html_e( 'Potrzebujesz pomocy?', 'adinet-panel' ); ?></h4><p><?php esc_html_e( 'Jeśli coś przestało działać albo nie wiesz, jak wykonać zmianę, napisz do mnie.', 'adinet-panel' ); ?></p></div>
					</div>
					<div class="adinet-welcome__contact-actions">
						<a class="button button-primary" href="mailto:kontakt@adinet.pl"><?php esc_html_e( 'Napisz do opiekuna strony', 'adinet-panel' ); ?></a>
						<span><?php esc_html_e( 'E-mail to preferowana forma kontaktu', 'adinet-panel' ); ?></span>
					</div>
					<div class="adinet-welcome__contact-details">
						<a href="mailto:kontakt@adinet.pl">kontakt@adinet.pl</a>
						<span><?php esc_html_e( 'Pilne sprawy:', 'adinet-panel' ); ?> <a href="tel:+48793032998">+48 793 032 998</a></span>
					</div>
					<p class="adinet-welcome__hint"><?php esc_html_e( 'Gdy coś pójdzie nie tak, napisz, co próbujesz zmienić, i dołącz zrzut ekranu.', 'adinet-panel' ); ?></p>
				</section>
				<section class="adinet-welcome__quick" aria-labelledby="adinet-welcome-quick-title">
					<h4 id="adinet-welcome-quick-title"><?php esc_html_e( 'Co chcesz zrobić?', 'adinet-panel' ); ?></h4>
					<div class="adinet-welcome__links">
						<a href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>"><span class="dashicons dashicons-admin-users" aria-hidden="true"></span><?php esc_html_e( 'Zmień swoje hasło', 'adinet-panel' ); ?></a>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>"><span class="dashicons dashicons-admin-page" aria-hidden="true"></span><?php esc_html_e( 'Strony do edycji', 'adinet-panel' ); ?></a>
						<a href="https://dpoczta.pl" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-email-alt" aria-hidden="true"></span><?php esc_html_e( 'Otwórz dPocztę', 'adinet-panel' ); ?></a>
						<a href="https://wiki.adinet.pl/" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-book" aria-hidden="true"></span><?php esc_html_e( 'Więcej porad', 'adinet-panel' ); ?></a>
					</div>
				</section>
				<section class="adinet-welcome__billing" aria-labelledby="adinet-welcome-billing-title">
					<div class="adinet-welcome__section-heading">
						<span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span>
						<div><h4 id="adinet-welcome-billing-title"><?php esc_html_e( 'Twoje rozliczenia', 'adinet-panel' ); ?></h4></div>
					</div>
					<p><?php esc_html_e( 'Aktualnie do zapłaty', 'adinet-panel' ); ?></p>
					<p class="adinet-welcome__amount"><?php echo esc_html( self::format_summary_amount( $due ) ); ?></p>
					<?php if ( $due['count'] > 0 ) : ?>
						<ul class="adinet-welcome__due-items">
							<?php foreach ( $billing['due_items'] as $item ) : ?>
								<li><span><?php echo esc_html( $item['service_name'] ); ?><?php if ( count( $invoices ) > 1 && '' !== $item['invoice_number'] ) : ?><small><?php echo esc_html( sprintf( __( 'Faktura / pro forma: %s', 'adinet-panel' ), $item['invoice_number'] ) ); ?></small><?php endif; ?></span><strong><?php echo null === $item['price'] ? esc_html__( 'Do wyliczenia', 'adinet-panel' ) : esc_html( number_format_i18n( (float) $item['price'], 2 ) . ' zł' ); ?></strong></li>
							<?php endforeach; ?>
						</ul>
						<?php if ( 1 === count( $invoices ) ) : ?>
							<p class="adinet-welcome__fineprint"><?php echo esc_html( sprintf( __( 'Faktura / pro forma: %s', 'adinet-panel' ), $invoices[0] ) ); ?></p>
						<?php endif; ?>
					<?php elseif ( $settled['count'] > 0 && 0 === $pending['count'] ) : ?>
						<p><?php esc_html_e( 'Wszystko opłacone.', 'adinet-panel' ); ?></p>
					<?php else : ?>
						<p class="adinet-welcome__fineprint"><?php echo $pending['count'] > 0 ? esc_html__( 'Brak pozycji ze statusem „Wezwano do zapłaty”.', 'adinet-panel' ) : esc_html__( 'Nie dodano jeszcze rozliczeń.', 'adinet-panel' ); ?></p>
					<?php endif; ?>
					<?php if ( $pending['count'] > 0 ) : ?>
						<p class="adinet-welcome__pending"><?php echo esc_html( sprintf( __( 'Oczekuje na rozliczenie: %s. Liczba pozycji: %s.', 'adinet-panel' ), self::format_summary_amount( $pending ), number_format_i18n( $pending['count'] ) ) ); ?></p>
					<?php endif; ?>
					<?php if ( AdiNet_Admin::can_view_panel() ) : ?>
						<p><a class="button" href="<?php echo esc_url( AdiNet_Billing::get_page_url() ); ?>"><?php esc_html_e( 'Zobacz szczegóły rozliczeń', 'adinet-panel' ); ?></a></p>
					<?php endif; ?>
					<?php if ( '' !== $billing['period'] ) : ?>
						<details class="adinet-welcome__forecast">
						<summary><?php esc_html_e( 'Kolejne roczne rozliczenie — prognoza', 'adinet-panel' ); ?></summary>
						<p><?php echo esc_html( sprintf( __( 'Następne roczne rozliczenie: %s.', 'adinet-panel' ), $billing['period'] ) ); ?></p>
						<?php if ( $estimate['priced'] > 0 ) : ?>
							<p><?php echo esc_html( sprintf( __( 'Szacowany koszt odnowień: około %s zł.', 'adinet-panel' ), number_format_i18n( $estimate['amount_cents'] / 100, 2 ) ) ); ?></p>
							<p class="adinet-welcome__fineprint"><?php esc_html_e( 'To tylko orientacyjny szacunek na podstawie zapisanych cen usług odnawialnych. Nie musi obejmować wszystkich kosztów; ceny mogą się zmienić.', 'adinet-panel' ); ?></p>
						<?php else : ?>
							<p class="adinet-welcome__fineprint"><?php esc_html_e( 'Nie ma jeszcze danych do oszacowania kosztu.', 'adinet-panel' ); ?></p>
						<?php endif; ?>
						<?php if ( $estimate['unpriced'] > 0 ) : ?>
							<p class="adinet-welcome__fineprint"><?php esc_html_e( 'Część usług nie ma jeszcze podanej ceny.', 'adinet-panel' ); ?></p>
						<?php endif; ?>
						</details>
					<?php else : ?>
						<p class="adinet-welcome__fineprint"><?php esc_html_e( 'Termin kolejnego rozliczenia nie został jeszcze ustalony.', 'adinet-panel' ); ?></p>
					<?php endif; ?>
				</section>
			</div>
		</div>
		<?php
	}

	/**
	 * Formatuje znaną kwotę i osobno wskazuje pozycje bez ceny.
	 *
	 * @param array $data Podsumowanie statusu.
	 * @return string
	 */
	private static function format_summary_amount( $data ) {
		if ( $data['count'] > 0 && $data['count'] === $data['unpriced'] ) {
			return sprintf( __( 'Do wyliczenia — liczba pozycji: %s', 'adinet-panel' ), number_format_i18n( $data['unpriced'] ) );
		}

		$amount = number_format_i18n( $data['amount_cents'] / 100, 2 ) . ' zł';
		if ( $data['unpriced'] > 0 ) {
			$amount .= ' + ' . sprintf( __( '%s do wyliczenia', 'adinet-panel' ), number_format_i18n( $data['unpriced'] ) );
		}

		return $amount;
	}
}
