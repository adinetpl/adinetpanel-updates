<?php
/**
 * Kontrola wyświetlania i logowania błędów PHP.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdiNet_Debug_Control {
	/**
	 * Stosuje ustawienia możliwie wcześnie podczas ładowania wtyczki.
	 *
	 * @return void
	 */
	public static function init() {
		self::expire_modes();
		self::apply_log_mode();

		add_action( 'admin_post_adinet_download_php_log', array( __CLASS__, 'download_log' ) );
		add_action( 'admin_post_adinet_delete_php_log', array( __CLASS__, 'delete_log' ) );

		$display_mode = AdiNet_Options::get_debug_mode( AdiNet_Options::DEBUG_DISPLAY_MODE );

		if ( AdiNet_Options::DEBUG_MODE_DISABLED === $display_mode ) {
			self::set_display_errors( false );
		} elseif ( AdiNet_Options::DEBUG_MODE_ENABLED === $display_mode ) {
			add_action( 'template_redirect', array( __CLASS__, 'enable_frontend_display' ), 0 );
		}
	}

	/** Każdy jawnie włączony tryb działa maksymalnie cztery godziny. */
	public static function sanitize_display( $value ) {
		return self::sanitize_timed_mode( $value, AdiNet_Options::DEBUG_DISPLAY_MODE, AdiNet_Options::DEBUG_DISPLAY_UNTIL );
	}

	public static function sanitize_log( $value ) {
		return self::sanitize_timed_mode( $value, AdiNet_Options::DEBUG_LOG_MODE, AdiNet_Options::DEBUG_LOG_UNTIL );
	}

	private static function sanitize_timed_mode( $value, $option, $timer ) {
		$mode = AdiNet_Options::sanitize_debug_mode( $value );
		if ( AdiNet_Options::DEBUG_MODE_ENABLED === $mode ) {
			if ( AdiNet_Options::DEBUG_MODE_ENABLED !== get_option( $option ) || ! get_option( $timer, 0 ) ) {
				update_option( $timer, time() + 4 * HOUR_IN_SECONDS, false );
			}
		} else {
			delete_option( $timer );
		}
		return $mode;
	}

	public static function expire_modes() {
		foreach ( array( AdiNet_Options::DEBUG_DISPLAY_MODE => AdiNet_Options::DEBUG_DISPLAY_UNTIL, AdiNet_Options::DEBUG_LOG_MODE => AdiNet_Options::DEBUG_LOG_UNTIL ) as $option => $timer ) {
			if ( AdiNet_Options::DEBUG_MODE_ENABLED !== get_option( $option ) ) {
				continue;
			}
			$until = absint( get_option( $timer, 0 ) );
			if ( ! $until ) {
				// Migracja wcześniej aktywnej diagnostyki: również otrzymuje limit.
				update_option( $timer, time() + 4 * HOUR_IN_SECONDS, false );
			} elseif ( $until <= time() ) {
				update_option( $option, AdiNet_Options::DEBUG_DISPLAY_MODE === $option ? AdiNet_Options::DEBUG_MODE_DISABLED : AdiNet_Options::DEBUG_MODE_INHERIT );
				delete_option( $timer );
			}
		}
	}

	/**
	 * Włącza wyświetlanie błędów dopiero na publicznym froncie.
	 * REST, AJAX i panel administracyjny pozostają poza tym trybem.
	 *
	 * @return void
	 */
	public static function enable_frontend_display() {
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		if ( function_exists( 'error_reporting' ) ) {
			error_reporting( E_ALL ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_reporting_error_reporting
		}
		self::set_display_errors( true );
	}

	/**
	 * Ustawia wyświetlanie błędów na poziomie PHP dla bieżącego żądania.
	 *
	 * @param bool $enabled Czy wyświetlać błędy.
	 * @return void
	 */
	private static function set_display_errors( $enabled ) {
		if ( ! function_exists( 'ini_set' ) ) {
			return;
		}

		$value = $enabled ? '1' : '0';

		@ini_set( 'display_errors', $value ); // phpcs:ignore WordPress.PHP.IniSet.display_errors_Disallowed
		@ini_set( 'display_startup_errors', $value ); // phpcs:ignore WordPress.PHP.IniSet.display_startup_errors_Disallowed
	}

	/**
	 * Włącza albo wyłącza zapisywanie błędów w logu PHP.
	 *
	 * @return void
	 */
	private static function apply_log_mode() {
		$log_mode = AdiNet_Options::get_debug_mode( AdiNet_Options::DEBUG_LOG_MODE );

		if ( AdiNet_Options::DEBUG_MODE_INHERIT === $log_mode ) {
			return;
		}

		if ( AdiNet_Options::DEBUG_MODE_ENABLED === $log_mode ) {
			if ( function_exists( 'error_reporting' ) ) {
				error_reporting( E_ALL ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_reporting_error_reporting
			}

			if ( function_exists( 'ini_set' ) ) {
				@ini_set( 'log_errors', '1' ); // phpcs:ignore WordPress.PHP.IniSet.log_errors_Disallowed
			}

			return;
		}

		if ( function_exists( 'ini_set' ) ) {
			@ini_set( 'log_errors', '0' ); // phpcs:ignore WordPress.PHP.IniSet.log_errors_Disallowed
		}
	}

	/**
	 * Normalizuje tekstową wartość ustawienia php.ini do wartości logicznej.
	 *
	 * @param string|false $value Wartość php.ini.
	 * @return bool
	 */
	private static function ini_value_is_enabled( $value ) {
		if ( false === $value ) {
			return false;
		}

		return in_array( strtolower( trim( (string) $value ) ), array( '1', 'on', 'yes', 'true' ), true );
	}

	/**
	 * Zwraca ujawnione przez WordPressa i PHP lokalizacje logów błędów.
	 *
	 * Zarządzanie plikiem jest dozwolone wyłącznie dla istniejącego zwykłego
	 * pliku wewnątrz WP_CONTENT_DIR. Logi serwera pozostają tylko informacją.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function get_log_files() {
		$candidates = array();

		if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			$wp_debug_log = true === WP_DEBUG_LOG
				? trailingslashit( WP_CONTENT_DIR ) . 'debug.log'
				: (string) WP_DEBUG_LOG;

			self::add_log_candidate( $candidates, $wp_debug_log, 'WP_DEBUG_LOG' );
		}

		$error_log_path = function_exists( 'ini_get' ) ? ini_get( 'error_log' ) : '';
		if ( false !== $error_log_path && '' !== trim( (string) $error_log_path ) ) {
			self::add_log_candidate( $candidates, (string) $error_log_path, 'php.ini error_log' );
		}

		$logs = array();
		foreach ( $candidates as $candidate ) {
			$path       = $candidate['path'];
			$is_absolute = self::is_absolute_file_path( $path );
			$exists     = $is_absolute && is_file( $path ) && ! is_link( $path );

			if ( $exists ) {
				clearstatcache( true, $path );
			}

			$size     = $exists ? @filesize( $path ) : false;
			$modified = $exists ? @filemtime( $path ) : false;

			$logs[] = array(
				'id'         => substr( hash( 'sha256', $path ), 0, 16 ),
				'path'       => $path,
				'sources'    => $candidate['sources'],
				'exists'     => $exists,
				'readable'   => $exists && is_readable( $path ),
				'writable'   => $exists && is_writable( $path ),
				'deletable'  => $exists && is_writable( dirname( $path ) ),
				'size'       => false === $size ? 0 : (int) $size,
				'modified'   => false === $modified ? 0 : (int) $modified,
				'manageable' => $exists && self::is_manageable_log_path( $path ),
			);
		}

		return $logs;
	}

	/**
	 * Dodaje unikalną ścieżkę do listy kandydatów.
	 *
	 * @param array<string,array<string,mixed>> $candidates Lista kandydatów.
	 * @param string                           $path       Ścieżka pliku.
	 * @param string                           $source     Źródło konfiguracji.
	 * @return void
	 */
	private static function add_log_candidate( &$candidates, $path, $source ) {
		$path = trim( (string) $path );
		if ( '' === $path || in_array( strtolower( $path ), array( 'syslog', 'stderr' ), true ) || false !== strpos( $path, '://' ) ) {
			return;
		}

		$path = wp_normalize_path( $path );
		$key  = '\\' === DIRECTORY_SEPARATOR ? strtolower( $path ) : $path;

		if ( ! isset( $candidates[ $key ] ) ) {
			$candidates[ $key ] = array(
				'path'    => $path,
				'sources' => array(),
			);
		}

		if ( ! in_array( $source, $candidates[ $key ]['sources'], true ) ) {
			$candidates[ $key ]['sources'][] = $source;
		}
	}

	/**
	 * Sprawdza, czy ścieżka jest bezwzględną ścieżką systemu plików.
	 *
	 * @param string $path Ścieżka.
	 * @return bool
	 */
	private static function is_absolute_file_path( $path ) {
		return isset( $path[0] ) && ( '/' === $path[0] || 1 === preg_match( '#^[A-Za-z]:/#', $path ) );
	}

	/**
	 * Sprawdza po realnej ścieżce, czy plik leży wewnątrz wp-content.
	 *
	 * @param string $path Ścieżka pliku.
	 * @return bool
	 */
	private static function is_manageable_log_path( $path ) {
		if ( ! defined( 'WP_CONTENT_DIR' ) || is_link( $path ) ) {
			return false;
		}

		$file_real    = realpath( $path );
		$content_real = realpath( WP_CONTENT_DIR );

		if ( false === $file_real || false === $content_real || ! is_file( $file_real ) ) {
			return false;
		}

		$file_real    = wp_normalize_path( $file_real );
		$content_real = untrailingslashit( wp_normalize_path( $content_real ) );

		return 0 === strpos( $file_real, $content_real . '/' );
	}

	/**
	 * Buduje adres chronionej akcji pobierania albo usuwania logu.
	 *
	 * @param string $action Akcja: download lub delete.
	 * @param string $id     Identyfikator pliku.
	 * @return string
	 */
	public static function get_log_action_url( $action, $id ) {
		$action = sanitize_key( $action );
		$id     = sanitize_key( $id );

		if ( ! in_array( $action, array( 'download', 'delete' ), true ) || '' === $id ) {
			return '';
		}

		$url = add_query_arg(
			array(
				'action' => 'adinet_' . $action . '_php_log',
				'log'    => $id,
			),
			admin_url( 'admin-post.php' )
		);

		return wp_nonce_url( $url, 'adinet_php_log_' . $action . '_' . $id );
	}

	/**
	 * Zwraca zweryfikowany plik wskazany przez chronioną akcję administratora.
	 *
	 * @param string $action Akcja: download lub delete.
	 * @return array<string,mixed>|null
	 */
	private static function authorize_log_action( $action ) {
		if ( ! class_exists( 'AdiNet_Admin' ) || ! AdiNet_Admin::can_manage_panel() ) {
			wp_die( esc_html__( 'Nie masz uprawnień do tej operacji.', 'adinet-panel' ), '', array( 'response' => 403 ) );
			return null;
		}

		$id = isset( $_GET['log'] ) ? sanitize_key( wp_unslash( $_GET['log'] ) ) : '';
		check_admin_referer( 'adinet_php_log_' . $action . '_' . $id );

		foreach ( self::get_log_files() as $log ) {
			if ( $id !== $log['id'] || ! $log['manageable'] || ! $log['exists'] ) {
				continue;
			}

			if ( ( 'download' === $action && $log['readable'] ) || ( 'delete' === $action && $log['deletable'] ) ) {
				return $log;
			}
		}

		wp_die( esc_html__( 'Wybrany log nie jest dostępny albo nie może być bezpiecznie obsłużony przez wtyczkę.', 'adinet-panel' ), '', array( 'response' => 404 ) );
		return null;
	}

	/**
	 * Pobiera log jako załącznik bez ujawniania publicznego adresu pliku.
	 *
	 * @return void
	 */
	public static function download_log() {
		$log = self::authorize_log_action( 'download' );
		if ( ! $log ) {
			return;
		}

		$handle = @fopen( $log['path'], 'rb' );
		if ( false === $handle || ! @flock( $handle, LOCK_SH ) ) {
			if ( is_resource( $handle ) ) {
				fclose( $handle );
			}
			wp_die( esc_html__( 'Nie udało się odczytać logu PHP.', 'adinet-panel' ), '', array( 'response' => 500 ) );
			return;
		}

		while ( ob_get_level() ) {
			ob_end_clean();
		}

		nocache_headers();
		header( 'Content-Type: text/plain; charset=UTF-8' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Disposition: attachment; filename="adinet-php-log-' . gmdate( 'Ymd-His' ) . '.txt"' );

		$stat = fstat( $handle );
		if ( is_array( $stat ) && isset( $stat['size'] ) ) {
			header( 'Content-Length: ' . (int) $stat['size'] );
		}

		fpassthru( $handle );
		flock( $handle, LOCK_UN );
		fclose( $handle );
		exit;
	}

	/**
	 * Usuwa log i wraca do panelu z komunikatem.
	 *
	 * @return void
	 */
	public static function delete_log() {
		$log = self::authorize_log_action( 'delete' );
		if ( ! $log ) {
			return;
		}

		$notice = self::delete_log_file( $log['path'] ) ? 'php-log-deleted' : 'php-log-error';
		$url    = add_query_arg( 'adinet-notice', $notice, admin_url( 'admin.php?page=adinet' ) );

		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Usuwa istniejący log wewnątrz wp-content i sprawdza wynik operacji.
	 *
	 * @param string $path Ścieżka zweryfikowanego logu.
	 * @return bool
	 */
	private static function delete_log_file( $path ) {
		if ( ! self::is_manageable_log_path( $path ) ) {
			return false;
		}

		$deleted = @unlink( $path );
		clearstatcache( true, $path );

		return $deleted && ! file_exists( $path );
	}

	/**
	 * Zwraca stan konfiguracji debugowania widoczny w panelu.
	 *
	 * @return array<string,mixed>
	 */
	public static function get_state() {
		$wp_debug_display = defined( 'WP_DEBUG_DISPLAY' ) ? WP_DEBUG_DISPLAY : null;
		$wp_debug_log     = defined( 'WP_DEBUG_LOG' ) ? WP_DEBUG_LOG : null;
		$display_errors    = function_exists( 'ini_get' ) ? ini_get( 'display_errors' ) : false;
		$log_errors        = function_exists( 'ini_get' ) ? ini_get( 'log_errors' ) : false;
		$error_log_path    = function_exists( 'ini_get' ) ? ini_get( 'error_log' ) : '';

		return array(
			'display_until' => absint( get_option( AdiNet_Options::DEBUG_DISPLAY_UNTIL, 0 ) ),
			'log_until' => absint( get_option( AdiNet_Options::DEBUG_LOG_UNTIL, 0 ) ),
			'wp_debug'             => defined( 'WP_DEBUG' ) && WP_DEBUG,
			'wp_debug_display'     => $wp_debug_display,
			'wp_debug_log'         => $wp_debug_log,
			'php_display_errors'   => self::ini_value_is_enabled( $display_errors ),
			'php_log_errors'       => self::ini_value_is_enabled( $log_errors ),
			'php_error_log_path'   => (string) $error_log_path,
			'display_mode'         => AdiNet_Options::get_debug_mode( AdiNet_Options::DEBUG_DISPLAY_MODE ),
			'log_mode'             => AdiNet_Options::get_debug_mode( AdiNet_Options::DEBUG_LOG_MODE ),
		);
	}

	/**
	 * Formatuje wartość stałej debugowania do krótkiego opisu.
	 *
	 * @param mixed $value Wartość stałej albo null, jeśli nie została zdefiniowana.
	 * @return string
	 */
	public static function format_constant_value( $value ) {
		if ( null === $value ) {
			return __( 'nie zdefiniowano', 'adinet-panel' );
		}

		if ( is_bool( $value ) ) {
			return $value ? __( 'włączone', 'adinet-panel' ) : __( 'wyłączone', 'adinet-panel' );
		}

		return (string) $value;
	}
}
