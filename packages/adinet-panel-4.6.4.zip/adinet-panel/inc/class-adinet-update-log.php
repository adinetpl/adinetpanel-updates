<?php
/** Wyniki aktualizacji zbierane osobno dla każdego składnika. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class AdiNet_Update_Log {
	private static $items = array();
	private static $active = '';
	private static $offers = array();

	public static function init() {
		add_filter( 'site_transient_update_plugins', array( __CLASS__, 'capture_plugins' ) );
		add_filter( 'site_transient_update_themes', array( __CLASS__, 'capture_themes' ) );
		add_filter( 'upgrader_package_options', array( __CLASS__, 'start' ), PHP_INT_MAX );
		add_filter( 'upgrader_install_package_result', array( __CLASS__, 'result' ), PHP_INT_MAX, 2 );
		add_action( 'wp_error_added', array( __CLASS__, 'capture_error' ), 10, 4 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'complete' ), 10, 2 );
		add_action( 'shutdown', array( __CLASS__, 'flush' ), 20 );
	}

	public static function capture_plugins( $value ) { return self::capture_offers( $value, 'plugin' ); }
	public static function capture_themes( $value ) { return self::capture_offers( $value, 'theme' ); }
	private static function capture_offers( $value, $type ) {
		if ( is_object( $value ) && isset( $value->response ) ) {
			// Zachowaj oferty sprzed czyszczenia cache pod koniec aktualizacji.
			self::$offers[ $type ] = array_merge( isset( self::$offers[ $type ] ) ? self::$offers[ $type ] : array(), (array) $value->response );
		}
		return $value;
	}

	private static function identify( $extra ) {
		foreach ( array( 'plugin', 'theme' ) as $type ) {
			if ( ! empty( $extra[ $type ] ) && is_string( $extra[ $type ] ) ) {
				return array( $type, $extra[ $type ] );
			}
		}
		return array( isset( $extra['type'] ) ? $extra['type'] : '', '' );
	}

	public static function start( $options ) {
		$extra = isset( $options['hook_extra'] ) ? $options['hook_extra'] : array();
		list( $type, $item ) = self::identify( $extra );
		self::$active = '';
		if ( ! in_array( $type, array( 'plugin', 'theme', 'core' ), true ) ) { return $options; }
		$key = $type . ':' . $item;
		self::$active = $key;
		self::$items[ $key ] = array( 'type' => $type, 'item' => $item, 'action' => isset( $extra['action'] ) ? $extra['action'] : 'update', 'result' => null );
		return $options;
	}

	public static function result( $result, $extra ) {
		list( $type, $item ) = self::identify( $extra );
		$key = $type . ':' . $item;
		if ( isset( self::$items[ $key ] ) ) { self::$items[ $key ]['result'] = $result; }
		return $result;
	}

	/** Błędy pobierania/rozpakowania nie docierają do filtra wyniku instalacji. */
	public static function capture_error( $code, $message, $data, $error ) {
		if ( ! isset( self::$items[ self::$active ] ) ) { return; }
		foreach ( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 24 ) as $frame ) {
			if ( isset( $frame['class'] ) && is_a( $frame['class'], 'WP_Upgrader', true ) ) {
				self::$items[ self::$active ]['result'] = $error;
				break;
			}
		}
	}

	public static function complete( $upgrader, $extra ) {
		$type = isset( $extra['type'] ) ? $extra['type'] : '';
		$action = isset( $extra['action'] ) ? $extra['action'] : '';
		if ( ! in_array( $type, array( 'plugin', 'theme', 'core' ), true ) || ! in_array( $action, array( 'install', 'update' ), true ) ) { return; }
		$plural = 'plugin' === $type ? 'plugins' : 'themes';
		$bulk = ! empty( $extra['bulk'] ) && isset( $extra[ $plural ] );
		$items = $bulk ? (array) $extra[ $plural ] : array( isset( $extra[ $type ] ) ? $extra[ $type ] : '' );
		foreach ( $items as $item ) {
			$key = $type . ':' . $item;
			$entry = isset( self::$items[ $key ] ) ? self::$items[ $key ] : array( 'type' => $type, 'item' => $item, 'action' => $action, 'result' => null );
			if ( ! $bulk ) {
				if ( isset( $upgrader->skin->result ) ) { $entry['result'] = $upgrader->skin->result; }
				elseif ( isset( $upgrader->result ) ) { $entry['result'] = $upgrader->result; }
				if ( '' === $item && 'plugin' === $type ) { $entry['item'] = AdiNet_Admin_Log::get_plugin_file_from_upgrader( $upgrader ); }
			} elseif ( ! isset( self::$items[ $key ] ) ) {
				$offer = isset( self::$offers[ $type ][ $item ] ) ? (array) self::$offers[ $type ][ $item ] : null;
				if ( $offer && ! empty( $offer['requires_php'] ) && ! is_php_version_compatible( $offer['requires_php'] ) ) {
					$entry['result'] = new WP_Error( 'incompatible_php_required_version' );
				} elseif ( $offer && ! empty( $offer['requires'] ) && ! is_wp_version_compatible( $offer['requires'] ) ) {
					$entry['result'] = new WP_Error( 'incompatible_wp_required_version' );
				} elseif ( null === $offer && isset( self::$offers[ $type ] ) ) {
					$entry['result'] = 'up_to_date';
				}
			}
			self::write( $entry );
			unset( self::$items[ $key ] );
		}
		self::$active = '';
	}

	public static function flush() {
		foreach ( self::$items as $entry ) { self::write( $entry ); }
		self::$items = array();
		self::$active = '';
	}

	private static function write( $entry ) {
		$result = $entry['result'];
		$label = 'plugin' === $entry['type'] && '' !== $entry['item'] ? AdiNet_Admin_Log::get_plugin_label( $entry['item'] ) : $entry['type'] . ' ' . $entry['item'];
		$success = true === $result || ( is_array( $result ) && ! empty( $result['destination'] ) );
		if ( $success ) {
			$text = sprintf( 'install' === $entry['action'] ? __( 'Prawidłowo zainstalowano: %s.', 'adinet-panel' ) : __( 'Prawidłowo zaktualizowano: %s.', 'adinet-panel' ), $label );
			$level = AdiNet_Admin_Log::LEVEL_STANDARD;
		} elseif ( is_wp_error( $result ) || false === $result ) {
			$text = sprintf( __( 'Operacja nieudana: %1$s. Kod błędu: %2$s.', 'adinet-panel' ), $label, is_wp_error( $result ) ? $result->get_error_code() : 'filesystem_unavailable' );
			$level = AdiNet_Admin_Log::LEVEL_WARNING;
		} elseif ( 'up_to_date' === $result ) {
			$text = sprintf( __( 'Pominięto: %s — brak nowszej wersji.', 'adinet-panel' ), $label );
			$level = AdiNet_Admin_Log::LEVEL_STANDARD;
		} else {
			$text = sprintf( __( 'Nie potwierdzono wyniku operacji: %s. Sprawdź ekran aktualizacji.', 'adinet-panel' ), $label );
			$level = AdiNet_Admin_Log::LEVEL_WARNING;
		}
		AdiNet_Admin_Log::record( $entry['type'] . '_' . $entry['action'], $level, $text, array( 'is_change' => $success ) );
	}
}
