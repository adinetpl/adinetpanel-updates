<?php
/**
 * Teksty Divi Pixel i generator polityki prywatności.
 *
 * @package AdiNetPanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cookie_texts = require ADINET_PATH . 'inc/templates/cookie-consent-pl.php';
$policy_url   = get_privacy_policy_url();
$domain       = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
$services     = array(
	'hosting'    => array( 'Hosting i logi', 'Utrzymanie, diagnostyka i zabezpieczenie witryny.' ),
	'contact'    => array( 'Formularz kontaktowy', 'Obsługa zapytań przesłanych przez formularz.' ),
	'turnstile'  => array( 'Cloudflare Turnstile', 'Ochrona formularzy przed spamem i automatycznymi zgłoszeniami.', 'Cloudflare' ),
	'mail'       => array( 'Poczta elektroniczna', 'Obsługa korespondencji e-mail.' ),
	'newsletter' => array( 'Newsletter', 'Wysyłka newslettera i zarządzanie subskrypcją.' ),
	'analytics'  => array( 'Google Analytics', 'Pomiar ruchu i sposobu korzystania ze strony.' ),
	'youtube'    => array( 'YouTube', 'Wyświetlanie osadzonych filmów.' ),
	'maps'       => array( 'Mapy Google', 'Wyświetlanie osadzonych map.' ),
	'other'      => array( 'Inny cel lub usługa', '' ),
);
$service_fields = array(
	'purpose'   => 'Cel przetwarzania',
	'basis'     => 'Podstawa prawna (z uzasadnionym interesem, jeśli dotyczy)',
	'receiver'  => 'Odbiorcy danych',
	'retention' => 'Okres przechowywania lub sposób jego ustalenia',
);
$clearance_description = 'Zapamiętuje wynik weryfikacji bezpieczeństwa Cloudflare, aby ograniczyć ponowne wyświetlanie wyzwania.';
?>
<div class="adinet-privacy">
	<p><a href="#adinet-consent-texts">Teksty do Divi Pixel</a> · <a href="#adinet-policy-generator">Generator polityki</a></p>

	<section class="adinet-card" aria-labelledby="adinet-consent-texts">
		<h2 id="adinet-consent-texts">Polskie teksty do Divi Pixel</h2>
		<p>Skopiuj teksty do odpowiadających im pól w Cookie Consent w Divi Pixel 2.60.</p>
		<?php foreach ( $cookie_texts as $group => $fields ) : ?>
			<details class="adinet-privacy-group"<?php if ( 'Banner' === $group ) : ?> open<?php endif; ?>>
				<summary><?php echo esc_html( $group ); ?></summary>
				<?php foreach ( $fields as $label => $translation ) : ?>
					<div class="adinet-shortcode-feature">
						<strong class="adinet-shortcode-label"><?php echo esc_html( $label ); ?></strong>
						<div class="adinet-shortcode">
							<span class="adinet-privacy-text"><?php echo esc_html( $translation ); ?></span>
							<button type="button" class="button adinet-copy-button" data-copy="<?php echo esc_attr( $translation ); ?>" aria-label="<?php echo esc_attr( 'Kopiuj: ' . $group . ' – ' . $label ); ?>">Kopiuj</button>
						</div>
					</div>
				<?php endforeach; ?>
				<?php if ( 'Policy Links' === $group ) : ?>
					<p><label class="adinet-shortcode-label" for="adinet-policy-url">Adres opublikowanej strony polityki</label>
						<input id="adinet-policy-url" class="large-text" type="url" value="<?php echo esc_url( $policy_url ); ?>" placeholder="https://example.com/polityka-prywatnosci/"></p>
					<p class="description">Jeśli w WordPressie ustawiono stronę polityki prywatności, jej adres pojawi się tutaj. Na stagingu możesz wpisać adres docelowy.</p>
					<?php foreach ( array( 'privacy' => 'Privacy policy URL', 'cookies' => 'Cookie policy URL' ) as $type => $label ) : ?>
						<?php $field_id = 'adinet-policy-link-' . $type; ?>
						<label class="adinet-shortcode-label" for="<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $label ); ?></label>
						<div class="adinet-shortcode">
							<input id="<?php echo esc_attr( $field_id ); ?>" class="large-text" type="text" readonly>
							<button type="button" class="button adinet-copy-button" data-copy-field="<?php echo esc_attr( $field_id ); ?>" aria-label="<?php echo esc_attr( 'Kopiuj: ' . $label ); ?>" disabled>Kopiuj</button>
						</div>
					<?php endforeach; ?>
					<p id="adinet-policy-url-status" class="description" aria-live="polite"></p>
				<?php endif; ?>
			</details>
		<?php endforeach; ?>
		<p class="screen-reader-text" id="adinet-copy-status" aria-live="polite"></p>
	</section>

	<section class="adinet-card" aria-labelledby="adinet-policy-generator">
		<h2 id="adinet-policy-generator">Generator polityki prywatności i plików cookies</h2>
		<p>Wypełnij dane dla tej witryny. Formularz i wynik są dostępne w otwartej karcie. Aby zachować pracę, skopiuj HTML do strony WordPressa.</p>
		<noscript><p>Generator i podpowiedzi adresów wymagają JavaScriptu.</p></noscript>
		<form id="adinet-policy-form" autocomplete="off">
			<fieldset id="adinet-policy-fields" disabled>
				<legend class="screen-reader-text">Dane do polityki</legend>
				<h3>Administrator danych</h3>
				<div class="adinet-privacy-grid">
					<label>Nazwa administratora <input type="text" id="adinet-policy-controller" required></label>
					<label>Adres administratora <input type="text" id="adinet-policy-address" required></label>
					<label>E-mail kontaktowy <input type="email" id="adinet-policy-email" required></label>
					<label>Domena witryny <input type="text" id="adinet-policy-domain" value="<?php echo esc_attr( $domain ?? '' ); ?>" required></label>
					<label>Kontakt do inspektora ochrony danych, jeśli wyznaczono <input type="text" id="adinet-policy-dpo"></label>
				</div>
				<h3>Funkcje i usługi witryny</h3>
				<p class="description">Zaznacz używane usługi. Wpisz „Brak”, jeśli dla danego celu nie ma odbiorców danych.</p>
				<?php foreach ( $services as $key => list( $label, $purpose ) ) : ?>
					<div class="adinet-privacy-service" data-policy-service>
						<label><input type="checkbox" data-service-toggle aria-controls="<?php echo esc_attr( 'adinet-policy-service-' . $key ); ?>"> <strong><?php echo esc_html( $label ); ?></strong></label>
						<fieldset id="<?php echo esc_attr( 'adinet-policy-service-' . $key ); ?>" data-service-fields hidden disabled>
							<legend class="screen-reader-text"><?php echo esc_html( $label ); ?></legend>
							<div class="adinet-privacy-grid">
								<?php foreach ( $service_fields as $field => $field_label ) : ?>
									<?php $value = 'purpose' === $field ? $purpose : ( 'receiver' === $field ? ( $services[ $key ][2] ?? '' ) : '' ); ?>
									<label>
										<?php echo esc_html( $field_label ); ?>
										<input type="text" data-policy-field="<?php echo esc_attr( $field ); ?>" value="<?php echo esc_attr( $value ); ?>">
									</label>
								<?php endforeach; ?>
							</div>
							<?php if ( 'turnstile' === $key ) : ?>
								<p class="description">Opis uwzględni sygnały techniczne sprawdzane przez Turnstile. Dodaj wpis o <code>cf_clearance</code>, jeśli widzisz to cookie na docelowej stronie.</p>
							<?php endif; ?>
						</fieldset>
					</div>
				<?php endforeach; ?>
				<p><label class="adinet-shortcode-label" for="adinet-policy-other">Dodatkowe informacje o przetwarzaniu</label>
					<textarea id="adinet-policy-other" class="large-text" rows="3" placeholder="Np. przekazywanie danych poza EOG i stosowane zabezpieczenia, obowiązek podania danych i skutki ich niepodania."></textarea></p>

				<h3 id="adinet-policy-cookies-heading">Pliki cookies</h3>
				<p><label class="adinet-shortcode-label" for="adinet-policy-cookie-details">Opis cookies i ustawień prywatności na stronie</label>
					<textarea id="adinet-policy-cookie-details" class="large-text" rows="3" placeholder="Podaj używane cookies i ich okresy ważności albo opisz, jak użytkownik może zmienić wybór, jeśli wykaz pobierze Divi Pixel."></textarea></p>
				<p><label><input type="checkbox" id="adinet-policy-declaration"> Wstaw deklarację cookies Divi Pixel <code>[dipi_cookie_declaration]</code></label></p>
				<p><label><input type="checkbox" id="adinet-policy-clearance" aria-controls="adinet-policy-clearance-fields"> Witryna zapisuje <code>cf_clearance</code></label></p>
				<fieldset id="adinet-policy-clearance-fields" hidden disabled>
					<legend class="screen-reader-text">Dane cookie cf_clearance</legend>
					<label for="adinet-policy-clearance-duration">Rzeczywisty okres ważności cookie <code>cf_clearance</code></label>
					<input type="text" id="adinet-policy-clearance-duration" placeholder="Np. 30 minut">
				</fieldset>
				<div id="adinet-policy-clearance-divi" hidden>
					<p>Uzupełnij pozycję w <strong>Divi Pixel → Cookie List</strong>. Z tej listy shortcode pobierze dane do tabeli.</p>
					<div class="adinet-privacy-grid">
						<?php
						$clearance_fields = array(
							'name'        => array( 'Cookie', 'cf_clearance' ),
							'duration'    => array( 'Duration', '' ),
							'description' => array( 'Description', $clearance_description ),
						);
						foreach ( $clearance_fields as $key => list( $label, $value ) ) :
							$field_id = 'adinet-clearance-copy-' . $key;
							?>
							<div>
								<label class="adinet-shortcode-label" for="<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $label ); ?></label>
								<div class="adinet-shortcode">
									<input id="<?php echo esc_attr( $field_id ); ?>" class="large-text" type="text" value="<?php echo esc_attr( $value ); ?>" readonly>
									<button type="button" class="button adinet-copy-button" data-copy-field="<?php echo esc_attr( $field_id ); ?>" aria-label="<?php echo esc_attr( 'Kopiuj: ' . $label . ' cf_clearance' ); ?>"<?php disabled( '' === $value ); ?>>Kopiuj</button>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<p><button type="submit" class="button button-primary">Wygeneruj politykę</button></p>
			</fieldset>
		</form>
		<div id="adinet-policy-result" hidden>
			<h3 id="adinet-policy-preview-heading" tabindex="-1">Podgląd dokumentu</h3>
			<div id="adinet-policy-warnings" class="notice notice-warning inline" role="status" hidden>
				<p>Sprawdź te informacje przed publikacją:</p>
				<ul></ul>
			</div>
			<div id="adinet-policy-preview" class="adinet-policy-preview"></div>
			<p><label class="adinet-shortcode-label" for="adinet-policy-html">HTML polityki</label>
				<textarea class="large-text code" id="adinet-policy-html" rows="7" readonly></textarea></p>
			<p><button type="button" class="button button-primary adinet-copy-button" data-copy-field="adinet-policy-html" data-default-label="Kopiuj HTML">Kopiuj HTML</button></p>
			<p class="description">Na stronie „Polityka prywatności i plików cookies” wklej HTML w trybie Tekst modułu Tekst w Divi.</p>
		</div>
	</section>
</div>
