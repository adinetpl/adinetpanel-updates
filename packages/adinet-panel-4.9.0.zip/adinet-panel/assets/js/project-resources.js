( function () {
	'use strict';
	document.addEventListener( 'DOMContentLoaded', function () {
		var form = document.getElementById( 'adinet-resource-form' );
		var cards = Array.from( document.querySelectorAll( '[data-resource-category]' ) );
		var search = document.getElementById( 'resource-search' );
		var filter = document.getElementById( 'resource-filter-category' );
		var count = document.querySelector( '[data-resource-count]' );
		var noResults = document.querySelector( '[data-resource-no-results]' );

		function filterCards() {
			var term = search.value.toLocaleLowerCase().trim();
			var visible = 0;
			cards.forEach( function ( card ) {
				card.hidden = ( filter.value && card.dataset.resourceCategory !== filter.value ) || card.textContent.toLocaleLowerCase().indexOf( term ) === -1;
				if ( ! card.hidden ) { visible++; }
			} );
			count.textContent = 'Liczba profili: ' + visible + ' / ' + cards.length;
			noResults.hidden = visible > 0;
		}
		if ( search && filter ) {
			search.addEventListener( 'input', filterCards );
			filter.addEventListener( 'change', filterCards );
		}
		if ( ! form ) { return; }

		var category = form.querySelector( '[name="category"]' );
		var provider = form.querySelector( '[name="provider"]' );
		var customService = form.querySelector( '[data-custom-service]' );
		var providerGroups = Array.from( form.querySelectorAll( '[data-resource-provider]' ) );
		var iconUsage = form.querySelector( '[data-icon-usage]' );
		var parameters = form.querySelector( '[data-custom-parameters]' );
		var parameterTemplate = parameters.firstElementChild.cloneNode( true );
		var addParameter = form.querySelector( '[data-add-parameter]' );
		var status = form.querySelector( '[data-resource-save-status]' );
		var reference = document.getElementById( 'resource-reference-id' );
		var preview = form.querySelector( '[data-reference-preview]' );
		var initial;
		var dirty = false;
		var leaving = false;

		function toggleControls( group, enabled ) {
			group.hidden = ! enabled;
			group.querySelectorAll( 'input, select, textarea' ).forEach( function ( control ) { control.disabled = ! enabled; } );
		}
		function updateFields() {
			var icons = category.value === 'icons';
			if ( ! icons ) { provider.value = 'other'; }
			provider.querySelectorAll( 'option' ).forEach( function ( option ) { option.disabled = ! icons && option.value !== 'other'; } );
			toggleControls( customService, provider.value === 'other' );
			customService.querySelectorAll( 'input' ).forEach( function ( input ) { input.required = provider.value === 'other'; } );
			toggleControls( iconUsage, icons );
			providerGroups.forEach( function ( group ) {
				var active = icons && group.dataset.resourceProvider === provider.value;
				group.hidden = ! active;
				var values = {};
				group.querySelectorAll( '[data-setting-key]' ).forEach( function ( control ) { values[ control.dataset.settingKey ] = control.value; } );
				group.querySelectorAll( '[data-setting-condition]' ).forEach( function ( row ) {
					var condition = JSON.parse( row.dataset.settingCondition );
					var visible = Object.keys( condition ).every( function ( key ) { return condition[ key ].indexOf( values[ key ] ) !== -1; } );
					row.hidden = ! visible;
					row.querySelectorAll( 'input, select' ).forEach( function ( control ) { control.disabled = ! active || ! visible; } );
				} );
			} );
		}
		function updateDirty() {
			dirty = new URLSearchParams( new FormData( form ) ).toString() !== initial;
			status.textContent = dirty ? 'Masz niezapisane zmiany' : 'Brak nowych zmian';
			form.classList.toggle( 'has-unsaved-changes', dirty );
		}
		function updateParameterButton() { addParameter.disabled = parameters.children.length >= 20; }
		updateFields();
		updateParameterButton();
		initial = new URLSearchParams( new FormData( form ) ).toString();
		form.addEventListener( 'input', updateDirty );
		form.addEventListener( 'change', function () { updateFields(); updateDirty(); } );
		form.addEventListener( 'submit', function () { leaving = true; } );
		window.addEventListener( 'beforeunload', function ( event ) {
			if ( dirty && ! leaving ) { event.preventDefault(); event.returnValue = ''; }
		} );
		addParameter.addEventListener( 'click', function () {
			if ( parameters.children.length >= 20 ) { return; }
			var row = parameterTemplate.cloneNode( true );
			row.querySelectorAll( 'input' ).forEach( function ( input ) { input.value = ''; } );
			parameters.appendChild( row );
			row.querySelector( 'input' ).focus();
			updateParameterButton();
			updateDirty();
		} );
		parameters.addEventListener( 'click', function ( event ) {
			var button = event.target.closest( '[data-remove-parameter]' );
			if ( ! button ) { return; }
			button.closest( '.adinet-resource-parameter' ).remove();
			updateParameterButton();
			updateDirty();
		} );
		form.querySelector( '[data-remove-reference]' ).addEventListener( 'click', function () {
			reference.value = '0';
			preview.replaceChildren();
			updateDirty();
		} );
		form.querySelector( '[data-select-reference]' ).addEventListener( 'click', function () {
			if ( ! window.wp || ! window.wp.media ) { return; }
			var frame = window.wp.media( { title: 'Zrzut ustawień zasobu', button: { text: 'Wybierz zrzut' }, library: { type: [ 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif' ] }, multiple: false } );
			frame.on( 'select', function () {
				var attachment = frame.state().get( 'selection' ).first().toJSON();
				var image = document.createElement( 'img' );
				reference.value = String( attachment.id );
				image.src = attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url;
				image.alt = 'Zrzut ustawień zasobu';
				preview.replaceChildren( image );
				updateDirty();
			} );
			frame.open();
		} );
	} );
}() );
